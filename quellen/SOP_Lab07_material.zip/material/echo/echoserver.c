/* echoserver.c - TCP server: sends every line back in upper case.
 * Port: environment variable PORT (default 5000).
 * Every received line is appended to the file given by LOG_FILE
 * (default /data/echo.log). */
#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static void serve(int fd, FILE *log) {
    FILE *in = fdopen(fd, "r");
    char line[512];
    while (in != NULL && fgets(line, sizeof line, in) != NULL) {
        fputs(line, log);
        fflush(log);
        for (char *p = line; *p; p++) {
            *p = (char)toupper((unsigned char)*p);
        }
        if (write(fd, line, strlen(line)) < 0) {
            break;
        }
    }
    if (in != NULL) {
        fclose(in);
    }
}

int main(void) {
    const char *port_s = getenv("PORT");
    const char *log_path = getenv("LOG_FILE");
    int port = port_s ? atoi(port_s) : 5000;
    if (log_path == NULL) {
        log_path = "/data/echo.log";
    }
    signal(SIGPIPE, SIG_IGN);

    FILE *log = fopen(log_path, "a");
    if (log == NULL) {
        perror(log_path);
        return EXIT_FAILURE;
    }
    int s = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof one);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);
    if (bind(s, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(s, 5) < 0) {
        perror("bind/listen");
        return EXIT_FAILURE;
    }
    printf("echoserver listens on port %d, log: %s\n", port, log_path);
    fflush(stdout);
    for (;;) {
        int c = accept(s, NULL, NULL);
        if (c >= 0) {
            serve(c, log);
        }
    }
}
