/* showkey.c - prints the length of the secret API_KEY, never the key. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    const char *key = getenv("API_KEY");
    if (key == NULL || *key == '\0') {
        fprintf(stderr, "showkey: API_KEY is not set\n");
        return 2;
    }
    printf("API key found, %zu characters\n", strlen(key));
    return 0;
}
