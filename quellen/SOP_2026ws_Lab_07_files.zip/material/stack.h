#ifndef STACK_H
#define STACK_H

#include <stddef.h>

/*
 * TODO: Define the type Stack (and every helper type you need) here.
 *       The stack stores values of type int.
 */

/* Initializes s as an empty stack. */
void stack_init(Stack *s);

/* Puts value on top of the stack.
 * Returns 0 on success and -1 if no memory could be allocated. */
int stack_push(Stack *s, int value);

/* Removes the top element and stores its value in *value.
 * Returns 0 on success and -1 if the stack is empty. */
int stack_pop(Stack *s, int *value);

/* Stores the top element in *value without removing it.
 * Returns 0 on success and -1 if the stack is empty. */
int stack_peek(const Stack *s, int *value);

/* Returns 1 if the stack is empty and 0 otherwise. */
int stack_is_empty(const Stack *s);

/* Returns the number of elements on the stack. */
size_t stack_size(const Stack *s);

/* Removes all elements and releases their memory.
 * The stack can be used again afterwards. */
void stack_clear(Stack *s);

#endif
