/*
 * A small address book. The persons are stored in a dynamic array of
 * pointers.
 *
 * Usage: ./addressbook <scenario>      (scenario 1 to 6)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY 4

typedef struct
{
    char name[16];
    int age;
} Person;

typedef struct
{
    Person **entries;
    size_t count;
    size_t capacity;
} AddressBook;

void book_init(AddressBook *book)
{
    book->entries = malloc(INITIAL_CAPACITY * sizeof(Person *));
    book->count = 0;
    book->capacity = INITIAL_CAPACITY;
}

int book_add(AddressBook *book, const char *name, int age)
{
    if (book->count == book->capacity)
    {
        book->entries = realloc(book->entries, book->capacity * sizeof(Person *));
        book->capacity *= 2;
    }

    Person *person = malloc(sizeof(Person));
    strcpy(person->name, name);
    person->age = age;
    book->entries[book->count++] = person;
    return 0;
}

Person *book_find(const AddressBook *book, const char *name)
{
    for (size_t i = 0; i < book->count; i++)
    {
        if (strcmp(book->entries[i]->name, name) == 0)
        {
            return book->entries[i];
        }
    }
    return NULL;
}

int book_remove(AddressBook *book, const char *name)
{
    for (size_t i = 0; i < book->count; i++)
    {
        if (strcmp(book->entries[i]->name, name) == 0)
        {
            free(book->entries[i]);
            return 0;
        }
    }
    return -1;
}

void book_print(const AddressBook *book)
{
    for (size_t i = 0; i < book->count; i++)
    {
        printf("%zu: %s (%d)\n", i, book->entries[i]->name, book->entries[i]->age);
    }
}

void book_log(const char *message)
{
    printf(message);
    printf("\n");
}

void book_greeting(const char *name)
{
    char text[32];
    sprintf(text, "Hello, %s! Welcome back.", name);
    puts(text);
}

void book_free(AddressBook *book)
{
    for (size_t i = 0; i < book->count; i++)
    {
        free(book->entries[i]);
    }
    book->count = 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <scenario 1-6>\n", argv[0]);
        return 1;
    }

    AddressBook book;
    book_init(&book);

    switch (atoi(argv[1]))
    {
    case 1: /* a person with a long name */
        book_add(&book, "Alexandra-Katharina Schmidt-Bauer", 41);
        book_print(&book);
        break;

    case 2: /* remove a person, then print the address book */
        book_add(&book, "Ada", 36);
        book_add(&book, "Linus", 54);
        book_add(&book, "Grace", 85);
        book_remove(&book, "Linus");
        book_print(&book);
        break;

    case 3: /* normal use: add, search, print */
    {
        book_add(&book, "Ada", 36);
        book_add(&book, "Linus", 54);
        book_add(&book, "Grace", 85);
        Person *found = book_find(&book, "Linus");
        if (found != NULL)
        {
            printf("Found %s, age %d\n", found->name, found->age);
        }
        book_print(&book);
        break;
    }

    case 4: /* a name with special characters */
        book_add(&book, "%x.%x.%x.%x", 20);
        book_log(book.entries[0]->name);
        break;

    case 5: /* a greeting for a visitor with a long name */
        book_greeting("Maximilian-Alexander von Hohenzollern");
        break;

    case 6: /* many persons */
        for (int i = 0; i < 10; i++)
        {
            char name[16];
            snprintf(name, sizeof name, "Person%d", i);
            book_add(&book, name, 20 + i);
        }
        book_print(&book);
        break;

    default:
        fprintf(stderr, "Unknown scenario\n");
        return 1;
    }

    book_free(&book);
    return 0;
}
