/* Memory layout of a C program: where do data and functions live? */
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int counter = 0;
int table[1000];
int primes[5] = {2, 3, 5, 7, 11};
const int limit = 100;
const char *greeting = "hello";

int adder(int a, int b)
{
    return a + b;
}

int main(void)
{
    int x = 2;
    int *p = malloc(sizeof(int));
    char *big = malloc(1000000);
    if (p == NULL || big == NULL)
    {
        return 1;
    }
    *p = adder(x, 3);

    printf("process id: %d\n\n", (int)getpid());
    printf("main:        %p\n", (void *)main);
    printf("\"hello\":     %p\n", (const void *)greeting);
    printf("limit:       %p\n", (const void *)&limit);
    printf("primes:      %p\n", (void *)primes);
    printf("counter:     %p\n", (void *)&counter);
    printf("table:       %p\n", (void *)table);
    printf("*p:          %p\n", (void *)p);
    printf("*big:        %p\n", (void *)big);
    printf("x:           %p\n", (void *)&x);

    printf("\nPress Enter to end the program ...\n");
    getchar();

    free(big);
    free(p);
    return 0;
}
