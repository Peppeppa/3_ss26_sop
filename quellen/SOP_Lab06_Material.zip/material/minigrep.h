#ifndef MINIGREP_H
#define MINIGREP_H

#include <regex.h>
#include <stdio.h>

/* Result of the argument parsing. */
typedef struct
{
    int ignore_case;        /* -i: ignore upper/lower case                 */
    int numbers;            /* -n: print line numbers                      */
    int count_only;         /* -c: print only the number of matching lines */
    int use_regex;          /* -E: PATTERN is an extended regular expression */
    const char *pattern;    /* text (or regular expression) to search for  */
    int first_file;         /* index of the first FILE in argv, or argc    */
} Options;

/* The compiled pattern. */
typedef struct
{
    const Options *opts;    /* options (pattern, -i, -E)                   */
    regex_t regex;          /* only used if opts->use_regex is set         */
} Matcher;

/* Parses argv. Options start with '-' and end at the first argument that
 * does not start with '-' or at "--". Several flags may be combined (-in).
 * Returns 0 on success and -1 on an unknown option or a missing PATTERN
 * (after printing a message to stderr for an unknown option). */
int parse_args(int argc, char *argv[], Options *opts);

/* Prepares the matcher. With opts->use_regex, the pattern is compiled with
 * regcomp (REG_EXTENDED | REG_NOSUB, plus REG_ICASE for -i).
 * Returns 0 on success and -1 (after printing the error message of regerror
 * to stderr) if the regular expression is invalid. */
int matcher_init(Matcher *m, const Options *opts);

/* Returns 1 if the line contains the pattern, otherwise 0.
 *  - plain text:  the line contains the pattern as a substring
 *                 (with -i: upper and lower case are the same)
 *  - with -E:     the regular expression matches somewhere in the line */
int matcher_match(const Matcher *m, const char *line);

/* Releases everything that matcher_init has allocated (regfree). */
void matcher_free(Matcher *m);

/* Reads in line by line and writes every line that matches to out (with the
 * line number and a colon in front if opts->numbers is set). Lines that are
 * longer than the internal buffer are written completely, but only their
 * first characters are searched, and they count as ONE line.
 * With opts->count_only nothing is written.
 * Returns the number of matching lines. */
long grep_stream(FILE *in, const Matcher *m, FILE *out);

#endif
