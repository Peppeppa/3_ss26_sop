/* upper_pipe: sends a text from the parent to a child through a pipe.
 * Usage: upper_pipe TEXT
 * The parent writes TEXT into the pipe. The child reads from the pipe until
 * end of file and prints the text in upper case, followed by a line feed.
 * The parent waits for the child and returns the exit code of the child. */
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int fd[2];
    pid_t pid;
    int status;

    if (argc != 2 || pipe(fd) < 0)
    {
        fprintf(stderr, "Usage: %s TEXT\n", argv[0]);
        return 1;
    }
    pid = fork();
    if (pid == 0)
    {
        char c;

        while (read(fd[0], &c, 1) == 1)
        {
            putchar(toupper((unsigned char)c));
        }
        putchar('\n');
        return 0;
    }
    close(fd[0]);
    if (write(fd[1], argv[1], sizeof argv[1]) < 0)
    {
        perror("write");
    }
    close(fd[1]);
    waitpid(pid, &status, 0);
    return WIFEXITED(status) ? WEXITSTATUS(status) : 1;
}
