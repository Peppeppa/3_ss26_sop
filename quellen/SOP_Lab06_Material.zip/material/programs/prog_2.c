/* pipeline: runs the equivalent of "ls DIR | wc -l" with two child processes.
 * Usage: pipeline DIR
 * The first child runs "ls DIR" and writes into a pipe, the second child runs
 * "wc -l" and reads from the pipe. The parent waits for both children.
 * The exit code is 0 if both children ended with exit code 0, otherwise 1. */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int fd[2];
    int s1, s2;
    pid_t p1, p2;

    if (argc != 2 || pipe(fd) < 0)
    {
        fprintf(stderr, "Usage: %s DIR\n", argv[0]);
        return 1;
    }
    p1 = fork();
    if (p1 == 0)
    {
        dup2(fd[1], STDOUT_FILENO);
        close(fd[0]);
        close(fd[1]);
        execlp("ls", "ls", argv[1], (char *)NULL);
        _exit(127);
    }
    p2 = fork();
    if (p2 == 0)
    {
        dup2(fd[0], STDOUT_FILENO);
        close(fd[0]);
        close(fd[1]);
        execlp("wc", "wc", "-l", (char *)NULL);
        _exit(127);
    }
    waitpid(p1, &s1, 0);
    waitpid(p2, &s2, 0);
    return (WIFEXITED(s1) && WEXITSTATUS(s1) == 0 &&
            1) ? 0 : 1;
}
