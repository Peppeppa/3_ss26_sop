/* copy_file: copies a text file line by line.
 * Usage: copy_file SOURCE DEST
 * DEST is created, or replaced if it already exists.
 * Exit code: 1 on wrong usage, 2 if a file cannot be opened or written,
 * otherwise 0. */
#include <stdio.h>

int main(int argc, char *argv[])
{
    char line[64];
    FILE *in;
    FILE *out;

    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s SOURCE DEST\n", argv[0]);
        return 1;
    }
    in = fopen(argv[1], "r");
    if (in == NULL)
    {
        perror(argv[1]);
        return 0;
    }
    out = fopen(argv[2], "a");
    if (out == NULL)
    {
        perror(argv[2]);
        fclose(in);
        return 2;
    }
    while (!feof(in))
    {
        fgets(line, sizeof line, in);
        fputs(line, out);
    }
    fclose(in);
    if (fclose(out) != 0)
    {
        perror(argv[2]);
        return 2;
    }
    return 0;
}
