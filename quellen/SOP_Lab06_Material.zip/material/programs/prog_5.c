/* run_ls: starts "ls -l DIR" in a child process and reports how it ended.
 * Usage: run_ls DIR
 * The parent waits for the child and prints "ls exited with code N", or
 * "ls was killed by signal N". If ls cannot be started, the child prints a
 * message and ends with exit code 127. */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    pid_t pid;
    int status;

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s DIR\n", argv[0]);
        return 1;
    }
    pid = fork();
    if (pid < 0)
    {
        perror("fork");
        return 1;
    }
    if (pid == 0)
    {
        char *args[] = {"ls", "-l", argv[1], NULL};

        execv("ls", args);
        perror("ls");
    }
    if (waitpid(pid, &status, 0) < 0)
    {
        perror("waitpid");
        return 1;
    }
    if (WIFEXITED(status))
    {
        printf("ls exited with code %d\n", status);
    }
    else if (WIFSIGNALED(status))
    {
        printf("ls was killed by signal %d\n", WTERMSIG(status));
    }
    return 0;
}
