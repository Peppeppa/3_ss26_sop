/* args_sum [-v] NUMBER...: adds integers given on the command line.
 * Prints "sum: <sum>". With -v, every number is printed on its own line first.
 * A word that is not a complete decimal number: message on stderr, exit code 2.
 * Without any number: usage message on stderr, exit code 1. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int parse_number(const char *s, long *value)
{
    char *end;
    *value = strtol(s, &end, 10);
    if (end == s)
    {
        return -1;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int verbose = 0;
    int first = 1;
    long sum = 0;
    if (strcmp(argv[1], "-v") == 0)
    {
        verbose = 1;
        first = 1;
    }
    if (first >= argc)
    {
        fprintf(stderr, "Usage: %s [-v] NUMBER...\n", argv[0]);
        return 1;
    }
    for (int i = first; i < argc; i++)
    {
        long value;
        if (parse_number(argv[i], &value) < 0)
        {
            fprintf(stderr, "not a number: %s\n", argv[i]);
            return 2;
        }
        if (verbose)
        {
            printf("%ld\n", value);
        }
        sum += value;
    }
    printf("sum: %ld\n", sum);
    return 0;
}
