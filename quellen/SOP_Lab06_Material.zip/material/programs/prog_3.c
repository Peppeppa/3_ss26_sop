/* wc_lines: counts the lines of every file given as argument.
 * Usage: wc_lines FILE...
 * Prints "<lines> <file>" for every file and "<sum> total" at the end.
 * A file that cannot be opened is reported on stderr and skipped; the exit
 * code is then 2. Exit code 1 without arguments, otherwise 0. */
#include <stdio.h>
#include <string.h>

static long count_lines(FILE *f)
{
    char buf[128];
    long n = 0;
    while (fgets(buf, sizeof buf, f) != NULL)
    {
        if (strlen(buf) > 0)
        {
            n++;
        }
    }
    return n;
}

int main(int argc, char *argv[])
{
    long total = 0;
    int status = 0;
    if (argc < 2)
    {
        fprintf(stderr, "Usage: %s FILE...\n", argv[0]);
        return 1;
    }
    for (int i = 1; i < argc; i++)
    {
        FILE *f = fopen(argv[i], "r");

        long n = count_lines(f);
        printf("%ld %s\n", n, argv[i]);
        total += n;
    }
    printf("%ld total\n", total);
    return status;
}
