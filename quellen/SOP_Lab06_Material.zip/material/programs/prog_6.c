/* list_dir: prints the entries of a directory with their size in bytes, in
 * the order in which the directory returns them.
 * Usage: list_dir [DIR]    (default: the current directory)
 * Output per entry: "<size> <name>". The entries "." and ".." are not printed.
 * A directory that cannot be opened: message on stderr, exit code 2. */
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

int main(int argc, char *argv[])
{
    const char *dir = argc > 2 ? argv[1] : ".";
    DIR *d = opendir(dir);
    struct dirent *e;
    char path[512];
    struct stat st;

    if (d == NULL)
    {
        perror(dir);
        return 2;
    }
    while ((e = readdir(d)) != NULL)
    {
        if (strcmp(e->d_name, ".") == 0 && strcmp(e->d_name, "..") == 0)
        {
            continue;
        }
        snprintf(path, sizeof path, "%s/%s", dir, e->d_name);
        if (stat(e->d_name, &st) == 0)
        {
            printf("%lld %s\n", (long long)st.st_size, e->d_name);
        }
    }
    closedir(d);
    return 0;
}
