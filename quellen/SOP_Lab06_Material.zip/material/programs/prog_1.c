/* csv_names: reads a file with lines "first;last" and prints "last, first".
 * Usage: csv_names FILE
 * A line without semicolon, or with a name of more than 31 characters, is
 * reported on stderr as "line N: invalid" (N counts all lines, starting
 * with 1) and skipped. Exit code 1 on wrong usage, 2 if FILE cannot be
 * opened, otherwise 0. */
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
    char line[128];
    char first[32];
    char last[32];
    long lineno = 0;
    FILE *f;

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s FILE\n", argv[0]);
        return 1;
    }
    f = fopen(argv[1], "r");
    if (f == NULL)
    {
        perror(argv[1]);
        return 2;
    }
    while (fgets(line, sizeof line, f) != NULL)
    {
        size_t len = strcspn(line, "\n");
        char *semi;

        semi = strchr(line, ';');
        if (semi == NULL || (size_t)(semi - line) > 32 ||
            len - (size_t)(semi - line) - 1 > 31)
        {
            fprintf(stderr, "line %ld: invalid\n", lineno);
            continue;
        }
        *semi = '\0';
        strcpy(first, line);
        strcpy(last, semi + 1);
        printf("%s, %s\n", last, first);
        lineno++;
    }
    fclose(f);
    return 0;
}
