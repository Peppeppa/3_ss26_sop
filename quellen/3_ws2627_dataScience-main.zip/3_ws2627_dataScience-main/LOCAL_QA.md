# Technische lokale Quellenprüfung

39 einzelne PDF-Quellen: 33 Kurs-PDFs (535 Seiten) + 6 PDFs aus Unit-ZIPs (11 Seiten). Zusätzlich ist die alte Sammel-PDF (103 Seiten) als redundanzverdächtige separate Quelle vorhanden, aber nicht in diese Zählung integriert. Prüfsummen, fortlaufende Seitenüberschriften und Bildreferenzen des vorigen Importpakets wurden für 33 Quellen geprüft; die 6 neuen Quellen haben neue PNGs und Originalhashes. Semantische Vollprüfung nicht bestanden/noch offen.

| ID | Markdown-Ziel | SHA-256 PDF | Seiten | Technischer Status |
|---|---|---|---:|---|
| DS-M1-EX | `portfolio/M1/sources/M1_sheet.md` | `b9b20e7fbea1d817a73dc88ad8be549751e91135d95943a9de383bac788cbcc6` | 3 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-M2-EX | `portfolio/M2/sources/M2_sheet.md` | `6bb9f1e2f61028ce6f6727e3264316b1ee002c6356048902b5c093c14f5f6481` | 3 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-M3-EX | `portfolio/M3/sources/M3_sheet.md` | `08310e2151a8acfb79f1e7daeaa91c130b08746c735cd8e922c46b2bdc6afff4` | 3 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-R001 | `quellen/organisation/sources/portfolio_studis_de.md` | `b0fb8541aae6b69360c8654c7ad7b1b25ca2411b2cd727c4add74025093829a4` | 9 | PASS |
| DS-R002 | `quellen/primer/sources/profiling_primer.md` | `e4c9cae9911993d2316d6d1e9380597970e540f21da36a132de1fb1076154cdb` | 8 | PASS |
| DS-R003 | `quellen/primer/sources/python_primer.md` | `4ea8a6dc48c1750ef365125408fb5816780680289513c216cc4d6ce776d8e845` | 9 | PASS |
| DS-R004 | `quellen/organisation/sources/Schedule_Data_Science_students.md` | `7308fd4a2897beb2913348258a19b3ac3d889d2e48d8b5396cdd61e6cbb5237f` | 1 | PASS |
| DS-R005 | `quellen/primer/sources/statistic_stochastic_primer_short_en.md` | `0f9a16f47309b973a528d2e25255ae6834ca5b4f3d77798586e5a8a1b253d5b8` | 11 | PASS |
| DS-R006 | `quellen/organisation/sources/submission_howto_de.md` | `067e06ca478549b53b735e2fe567c064fd40a765ac3b4e078a0d962cc4a5dc85` | 3 | PASS |
| DS-R007 | `quellen/primer/sources/Glossary_en.md` | `0aadd36dbd28dcf3b900638f60e750cc98ad970f59a94a5527c5ecd239aa423c` | 3 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-R008 | `quellen/organisation/sources/HANDIN.md` | `37d61885c93a5c4d014507e7f0de8a053e754232de857bc75a8edd2c48ce073e` | 5 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-R009 | `portfolio/M1/sources/midterm_slide.md` | `3b6275cd44b299b6514b03c0b6495da21957387c93690266e76383d44a7a9292` | 1 | PASS (Original/Seitenbilder; MD auf GitHub separat geprüft) |
| DS-U00-EX | `units/U00/sources/Unit00_Exercises_en.md` | `e212a1895c563ef7c56663534cb7ef36273aa2bcc4238b7248d9e7aeddf2f2fe` | 1 | PASS |
| DS-U00-L-DE | `units/U00/sources/Unit00_slides_de.md` | `92a0b4d924434842e9fc9e8014d76d8f3bc10b8eda85954b1a5ea33f8adfd966` | 43 | PASS |
| DS-U00-L-EN | `units/U00/sources/Unit00_slides_en.md` | `f4f1f1066107298e74119061280a602ea40c4f0ece95a7ffb25ea81f3c144df2` | 43 | PASS |
| DS-U00-R-KNIME-CHEATSHEET | `units/U00/sources/knime_cheatsheet.md` | `c830f781f2390481f9d14477be837f71f0ab6f2382047e774765216fa20529fa` | 1 | PASS |
| DS-U01-EX | `units/U01/sources/Unit01_Exercises_en.md` | `41c47d73f01f5eff1ac040dc32674fd603cf88d9f62f98207ce49ddb01a4b1da` | 2 | PASS |
| DS-U01-L-EN | `units/U01/sources/Unit01_slides_en.md` | `59048243f96fe07c35e5316db76a4c3ac487d2c571378ae6399bfb24a58405fa` | 29 | PASS |
| DS-U01-R-KNIME-CHEATSHEET | `units/U01/sources/knime_cheatsheet.md` | `eaf4a7a701ef75152c9043da6c74384e095a790ad05a50dd32a4596f160d87f7` | 1 | PASS |
| DS-U02-EX | `units/U02/sources/Unit02_Exercises_en.md` | `5998e24da81f2552703023754c05b2bf9589a7bb44001f6e52cda49a66027e74` | 2 | PASS |
| DS-U02-L-EN | `units/U02/sources/Unit02_slides_en.md` | `1815d107d0db06bd983de8738d2fab2c320b0159a1e4790e9c24d7ae1c1764b1` | 38 | PASS |
| DS-U02-R-KNIME-CHEATSHEET | `units/U02/sources/knime_cheatsheet.md` | `d56ceaca2211c30a6250b3d33224fb2cda760f0072f6f0f9572e7e52fad55170` | 1 | PASS |
| DS-U03-EX | `units/U03/sources/Unit03_Exercises_en.md` | `27dc79c773155367733230712848f609286375d26e55473e9ac6274a84110dca` | 2 | PASS |
| DS-U03-L-EN | `units/U03/sources/Unit03_slides_en.md` | `12ff10f9ab2ea0f72f6da8fc63241bc205d83a57155cc4a47946c9065a66e337` | 44 | PASS |
| DS-U04-EX | `units/U04/sources/Unit04_Exercises_en.md` | `818d868ba449bd8c0b2e2b5adf91d45f7fcf1fbda57de18268a8335580c7deac` | 2 | PASS |
| DS-U04-L-EN | `units/U04/sources/Unit04_slides_en.md` | `9b33bfec5421a1315ef2812835904e9ee8f62efa5862b60d1f30c827f8fb2add` | 42 | PASS |
| DS-U04-R-CLEANING-LOG-TEMPLATE | `units/U04/sources/cleaning_log_template.md` | `1a39538a72b05b658fe0e1e204221316048e5385bbd7690b5289d5b6d54aa90b` | 5 | PASS |
| DS-U05-EX | `units/U05/sources/Unit05_Exercises_en.md` | `e0c8444b4efee73f64eab9d5c57e4fbb02fdfebb1789eb8f6ab249695e03e792` | 2 | PASS |
| DS-U05-L-EN | `units/U05/sources/Unit05_DS_en.md` | `10bdbf3242deab76a5132b11dee9d9d787358c0816db5ea20461404d03cda3d1` | 48 | PASS |
| DS-U06-EX | `units/U06/sources/Unit06_Exercises_en.md` | `561eaf2802894b7463fa7faef7b83a7cf946421e1c891b86a6c1c52408b702b0` | 2 | PASS |
| DS-U06-L-EN | `units/U06/sources/Unit06_DS_en.md` | `2cd5d41f1969725e3b26017b803309824d141b1135c5acb661a969cb1d8686ec` | 38 | PASS |
| DS-U07-EX | `units/U07/sources/Unit07_Exercises_en.md` | `ccb243c20aa97a25b237eee9c9018c0fbdc05433780439ce4e33d0c8556a277d` | 2 | PASS |
| DS-U07-L-EN | `units/U07/sources/Unit07_slides_en.md` | `bd293a2e873015e641908c4e4738dbd9ba346bac8c7c6768a7f6612c7a5f79bf` | 45 | PASS |
| DS-U08-EX | `units/U08/sources/Unit08_Exercises_en.md` | `f704c3c6c6c0baf698806f8d0604a6ad73c86527cceef1bd561edf67e64846bd` | 2 | PASS |
| DS-U08-L-EN | `units/U08/sources/Unit08_slides_en.md` | `c5f845a17146aec4ee2f0c18bd77a9a506eee76fe61fc2481f1f5bd379f92917` | 40 | PASS |
| DS-U09-EX | `units/U09/sources/Unit09_Exercises_en.md` | `f4ea156d5450dd6766503c92cf6add0f720e09f3b2e0a5c46139d4a62af80a00` | 2 | PASS |
| DS-U09-L-EN | `units/U09/sources/Unit09_slides_en.md` | `79d8c5ab522fc8b31fa9684e45f1b82009943576b322381aa42c1093f313a9b1` | 47 | PASS |
| DS-U09-R-KNIME-CHEATSHEET | `units/U09/sources/knime_cheatsheet.md` | `1056ce0a009738eebac37e48047d4373c46112ea06ea60f324273713967cbaf3` | 1 | PASS |
| DS-U09-R-ML-READINESS-TEMPLATE | `units/U09/sources/ml_readiness_template.md` | `8c7c49a7f3b891b0a32db77a6a02bfeb263bcc94289d38e65bb2e752910315b1` | 2 | PASS |

Keine automatische Vollprüfung fachlich relevanter Bilder, Formeln oder Tabellen. Kein Dokument wird aufgrund dieser technischen Prüfung als verified bezeichnet.
