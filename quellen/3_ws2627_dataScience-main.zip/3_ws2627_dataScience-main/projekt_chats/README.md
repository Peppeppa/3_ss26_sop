# Chat- und Erkenntnisindex

**Hinweis:** Dies ist ein Index der aus dem Projektkontext verfügbaren Gespräche, kein vollständiger Chat-Export. Einzelne Dialoge können nicht automatisiert aus allen Projektchats rekonstruiert werden.

| Datum | Thema | Belegbar bekannter Gesprächsfokus |
|---|---|---|
| 2026-10-12 | Framework / Projektstart | Data-Science-Kurs, Portfolio-Prüfung, Projektquellen und Organisation |
| 2026-10-26 | U03 Formate, Serialisierung, Metadaten | Flat-Table-CSV aus AWC mit `slices.csv` vergleichen; Slice-Zeile S11 Germany Bikes; keine hartcodierten Messwerte; bewusste Einleseparameter; Frage zu k-Anonymität |
| 2026-10-26 | U04 Datenqualität | Überblick der Vorlesungsfolien und Verständnishilfe zu Übungen |
| 2026-10-26 | U05 Zeitreihen und Graphen | Überblick von Folien und Übungen, Klarstellung der Aufgabenstellung |
| 2026-11-10 | SQL / AdventureWorks | Tabelleninventar und Abfragen, SQL-Fehlersuche und Vereinfachung |
| 2026-11-17 | U06 Features und Distanzen | Wunsch nach Überblick über Vorlesungsfolien und Übungen |
| 2026-11-19 | GitHub-Dokumentation | Privates Repository, Struktur für Units und Portfolio, Dokumentationsstand |

## Regeln für weitere Einträge

Neue Erkenntnisse nach Thema und Datum ergänzen. SQL-/Python-Code samt Quellen und realen Ausgaben in der zugehörigen Unit oder in `portfolio/M*` ablegen. Keine nicht verfügbaren Gesprächsinhalte als wörtliche Transkripte darstellen.
