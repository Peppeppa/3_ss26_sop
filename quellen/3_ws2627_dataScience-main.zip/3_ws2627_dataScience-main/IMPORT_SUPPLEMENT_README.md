# Ergänzungspaket zum GitHub-Build

Im Root des lokalen `3_ws2627_dataScience` entpacken. Vorher `git pull --ff-only` und `git status`; vorhandene Arbeitsdateien nicht überschreiben. Beispiel: `unzip -n /pfad/DS_repo_ergaenzung.zip -d .`. Danach `git status` prüfen, gezielt die importierten Dateien hinzufügen, committen und pushen. Kein automatischer GitHub-Upload durch das ZIP.

Enthalten: 13 ZIP-Originale, ihre 134 extrahierten Nutzdateien (116 Unit, 4 AWC, je 7 M2/M3), 6 zusätzliche Markdown-Referenzen aus den Unit-ZIPs, 546 Seitenbilder, VISUAL_INDEX.md, ARCHIVE_INVENTORY.md, LOCAL_QA.md. Die bereits auf GitHub gespeicherten 33 Markdown-Quellen bleiben unangetastet. Die 39 Markdown-PDF-Quellen insgesamt sind erst nach Merge vorhanden. AWC/awc_flat.csv ist nicht im AWC_tables.zip; es wird vom eigenen Extraktionsskript gebaut. M1_template.zip und eigene M1/M2-Abgaben sind nicht enthalten. U09-Dashboards fehlen in der offiziellen Unit-ZIP.

Beachte die Freigabe der Kursunterlagen; Repository privat halten. Keine Passwörter oder persönlichen Abgabeinformationen in neue Dateien kopieren. Vor Push Git-Diff prüfen. Keine Rohdaten oder Code aus der eigenen Gruppe überschreiben.
