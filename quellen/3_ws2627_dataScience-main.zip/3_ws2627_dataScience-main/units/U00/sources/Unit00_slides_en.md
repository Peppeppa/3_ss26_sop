---
source_id: DS-U00-L-EN
original_file: Unit00_slides_en.pdf
source_type: lecture
language: en
page_count: 43
source_sha256: f4f1f1066107298e74119061280a602ea40c4f0ece95a7ffb25ea81f3c144df2
verification: partial
---
# Unit00_slides_en

[Original PDF](../../../quellen/Unit00_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit00_slides_en.pdf#page=1)

~~~~text
Data Science
INTRODUCTION, SETUP & FIRST
CONTACT WITH DATA
Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit00_slides_en.pdf#page=2)

~~~~text
LEARNING GOALS
• Understand the module structure, the tools, and the portfolio (M1–M4)
• Set up your working environment (Python + Jupyter or KNIME)
• Distinguish data, information, knowledge, and wisdom (DIKW)
• Assign scale levels: nominal, ordinal, interval, ratio — plus cyclic
• Take a first critical look at AdventureWorks Cycling: what one row is, and what
the data cannot answer
2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit00_slides_en.pdf#page=3)

~~~~text
THE WHOLE COURSE, ON ONE SLIDE

Setup & data
00 !
Tidy & joins
01 /
SQL → code
02 T
Formats & metadata
03 s
Data quality
04 
Time & graphs
05 #Features
& distance
06 ó
Reduce
& cluster
07 |
Explore &
visualise
08 A
Dashboard
& ML-ready
09
1. Get trustworthy data 2. ... and check it 3. Represent it 4. Reduce & see 5. Decide
Each step needs the one before — that is the order.
raw data a defensible decision
We turn raw AdventureWorks data into a decision you can defend. One unit per step, and
the order is not arbitrary: you cannot clean what you cannot load, cannot reduce features
you have not built, cannot communicate what you have not checked.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit00_slides_en.pdf#page=4)

~~~~text
ORGANISATION
4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit00_slides_en.pdf#page=5)

~~~~text
WHAT IS THIS MODULE ABOUT?
Core idea
Developing an operational understanding of data — their origin, structure, quality,
and meaning — as the foundation for Machine Learning.
• Models are not the goal — that is the ML course. One model appears once, in
U09, to test the data for leakage
• Focus: understanding, cleaning, enriching, documenting data
• One dataset all semester, AdventureWorks Cycling (AWC); the portfolio is built
on it
• Your choice: Python/pandas or KNIME (or both), in any programme. The
exercises are tool-independent; what I expect is simply more Python in BIN and
more KNIME in BWI
5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit00_slides_en.pdf#page=6)

~~~~text
REGULATIONS
Instructor:
• Frank-Michael Schleif → frank-michael.schleif@thws.de
Prerequisites (recommended):
• Databases (SQL basics)
• Programming experience (any language — Python is taught on the fly)
• Basic statistics — not assumed; a refresher deck is in Moodle
Materials:
• https://elearning.thws.de
• Slides, exercise sheets, the database, starter kits; HANDIN.pdf for the portfolio;
all dates in Schedule.pdf
6
~~~~

## Page 007

[Original page 7](../../../quellen/Unit00_slides_en.pdf#page=7)

~~~~text
LECTURE FORMAT
• 4 SWS = 4 × 45 min per week: lecture + integrated exercises
• Bring your own device — laptop required for exercises
• Software: Python 3 + Jupyter + pandas or KNIME Analytics Platform + MySQL
• Exercises are part of the lecture: download the sheet, work it here for 15–20
min while I am in the room, then we go through it
• BSED take it asynchronously: same sheets at home, plus their own weekly slot
for questions and solutions — time in Schedule.pdf, Zoom link in the Moodle
course
AI policy
LLMs (ChatGPT, Copilot, Claude) are allowed, and you own what you hand in. In the
oral part (M4) you explain and defend your decisions. What you cannot explain,
you have not understood — with or without an LLM.
7
~~~~

## Page 008

[Original page 8](../../../quellen/Unit00_slides_en.pdf#page=8)

~~~~text
ASSESSMENT: A PORTFOLIO IN FOUR PARTS
Every part is built on your group’s own slice of AWC, and each builds on the one before.
What Due Weight
M1 metadata file, profiling report, cleaning log date of U05 20 %
M2 cleaned flat table, similarity study, cluster analysis, five plots
after peer review
after U08 20 %
M3 three supported questions, KPI dashboard, leakage test,
ML-readiness
first exam day 30 %
M4 oral defence: the group presents its result and answers
questions
exam period 20 %
Formal clean, complete, on time — across all parts 10 %
Every deadline, with its date and time, is in Schedule.pdf in Moodle. M1 and M2 are discussed
during the semester, so the feedback can still change what you do next. Marks are per group as a
rule, individual where needed; all are given at the end.
8
~~~~

## Page 009

[Original page 9](../../../quellen/Unit00_slides_en.pdf#page=9)

~~~~text
GROUPS, HAND-IN, THE ORAL PART
• Groups, sized by enrolment; BIN and BWI may mix, BSED forms its own. Registration
opens today, closes next date; then groups and slices, each group’s upload link by mail.
• Each group gets its own slice — one territory × one category — so every group’s
numbers differ.
• One archive per group and milestone; its manifest names who did what. If your group
will not represent your work, mail me before the deadline.
• Joining after the M1 deadline: M1 is not graded for you — 20 % gone, no substitute
task.
• The oral part (M4) is in the exam period — everyone attends. Without it the portfolio is
not taken.
What and how to hand in
Per milestone, a task sheet in Moodle says what to do; HANDIN.pdf says how to
hand it in. Both come with a starter kit and a checker.
9
~~~~

## Page 010

[Original page 10](../../../quellen/Unit00_slides_en.pdf#page=10)

~~~~text
SEMESTER ROADMAP
Unit Key output
00 Introduction, Setup & First Contact with Data (today) Environment ready, scale-level table
01 Tabular Data, Tidy Data & Joins AWC flat-table
02 From the SQL Console to a Program Re-runnable extract script
03 Formats, Serialisation & Metadata Metadata + data dictionary
04 Data Quality: Profiling, then Cleaning With Reasons Profiling + cleaning log
05 Beyond Tables: Time Series & Graphs Time series + graph queries
M1 hand-in, then discussed on the next date metadata, profiling, cleaning log
06 Features, Similarity & Distance Distances under three measures
07 Dimensionality Reduction: PCA, t-SNE & Clusters Cluster analysis
08 Exploratory Data Analysis: Statistics & Visualisation Annotated EDA plots
M2 hand-in, then discussed on the next date clean table, similarity, clusters, plots
09 Dashboards, Communication & ML-Readiness Dashboard, leakage test, ML checklist
M3 hand-in on the first exam day M4: oral part, exam period
10 units, both cohorts, same material — online one session per unit, in presence the same ten with U08 on two
dates. Dates: Schedule.pdf in Moodle.
10
~~~~

## Page 011

[Original page 11](../../../quellen/Unit00_slides_en.pdf#page=11)

~~~~text
GETTING TO KNOW EACH OTHER
SQL
Python
KNIME
Two minutes. Link on the projector.
Anonymous — no names, no personal data. This is how we get to know the room.
BSED: the same poll, as a Moodle activity in your course.
11
~~~~

## Page 012

[Original page 12](../../../quellen/Unit00_slides_en.pdf#page=12)

~~~~text
Break
10 minutes
Then: Setting up — hands on
~~~~

## Page 013

[Original page 13](../../../quellen/Unit00_slides_en.pdf#page=13)

~~~~text
SETTING UP YOUR ENVIRONMENT
13
~~~~

## Page 014

[Original page 14](../../../quellen/Unit00_slides_en.pdf#page=14)

~~~~text
HANDS ON: DO THIS NOW, NOT LATER
The slides up to “A Look at KNIME” are instructions, not a lecture, in four steps: 1 MySQL
server, 2 the AWC database, 3 your tool (Python or KNIME), 4 connect the tool to the
database.
Why now: from U01 on, every unit reads from this database.
Here, now BSED, asynchronous
≈25 minutes. Work at your own machine. I
walk around; ask the moment something fails.
Same slides, same order, at home. Blockers go
to your weekly slot in week 1 — reserved for
exactly this.
The only thing that counts as “done”
This command prints a number: mysql -u sqladmin -p -e "SELECT COUNT(*) FROM
Adventureworks2019.Sales_SalesOrderHeader;" If it prints 31465, you are set up. If it prints
anything else, you are not — say so now, while I am in the room. BSED: bring it to the
weekly slot.
14
~~~~

## Page 015

[Original page 15](../../../quellen/Unit00_slides_en.pdf#page=15)

~~~~text
STEP 1: MYSQL SERVER + WORKBENCH
AWC lives in a MySQL database — you need a running server on your machine.
Installation (Ubuntu/Debian):
1 sudo apt-get install mysql-server
2 sudo systemctl start mysql.service
3 sudo snap install mysql-workbench-community
Initial configuration (run once after install):
1 sudo mysql
2 mysql> ALTER USER 'root'@'localhost'
3 IDENTIFIED BY 'YOUR-ROOT-PASSWORD';
4 mysql> CREATE USER 'sqladmin'@'%'
5 IDENTIFIED BY 'YOUR-USER-PASSWORD';
6 mysql> FLUSH PRIVILEGES;
Windows/Mac: download from https://dev.mysql.com/downloads/ — the installer sets the service
up. Then mysql -u root -p for sudo mysql, MySQL’s bin folder on the PATH, and step 2’s
import in cmd.exe: PowerShell rejects <.
15
~~~~

## Page 016

[Original page 16](../../../quellen/Unit00_slides_en.pdf#page=16)

~~~~text
STEP 2: IMPORT THE AWC DATABASE
Step 1: Download AdventureWorks2019.sql from Moodle (≈100 MB, 71 tables).
Step 2: Import from the command line:
1 mysql -u root -p -e "CREATE DATABASE Adventureworks2019;"
2 mysql -u root -p Adventureworks2019 < AdventureWorks2019.sql
Step 3: Grant permissions to your non-root user (the SET line lets U02 create triggers):
1 mysql -u root -p
2 mysql> GRANT ALL PRIVILEGES
3 ON Adventureworks2019.* TO 'sqladmin'@'%';
4 mysql> SET PERSIST log_bin_trust_function_creators = 1;
5 mysql> FLUSH PRIVILEGES;
Step 4: Verify — open MySQL Workbench, connect as sqladmin, browse the tables. Workbench
password-manager fix (Ubuntu snap): sudo snap connect mysql-workbench-community:password-manager-service
:password-manager-service
Quick test
mysql -u sqladmin -p -e "SELECT COUNT(*) FROM Adventureworks2019.Sales_SalesOrderHeader;"
16
~~~~

## Page 017

[Original page 17](../../../quellen/Unit00_slides_en.pdf#page=17)

~~~~text
A LOOK AT MYSQL WORKBENCH
The schema tree carries Adventureworks2019, and the count returns 31465. That is the whole test.
17
~~~~

## Page 018

[Original page 18](../../../quellen/Unit00_slides_en.pdf#page=18)

~~~~text
STEP 3, OPTION A: PYTHON
What you need:
• Python 3.10+ (https://www.python.org or Anaconda)
• Jupyter Notebook / JupyterLab (pip install jupyterlab)
• Core packages:
1 pip install pandas numpy matplotlib seaborn
2 pip install plotly scikit-learn
3 pip install sqlalchemy mysql-connector-python
4 pip install pyarrow pyyaml h5py jsonpath-ng # formats (U03)
5 pip install streamlit pydeck # dashboard + map (U09)
Quick test
Open a Jupyter notebook, run import pandas as pd;
print(pd.__version__) — done.
18
~~~~

## Page 019

[Original page 19](../../../quellen/Unit00_slides_en.pdf#page=19)

~~~~text
STEP 3, OPTION B: KNIME
What you need:
• KNIME Analytics Platform 5.x (https://www.knime.com/downloads)
• Free, open source, drag-and-drop workflow tool
• Extensions to install via KNIME Hub:
• Geospatial Analytics Extension — the U09 map
• KNIME Python Integration — not optional, the Geospatial nodes need it
• KNIME Statistics Nodes (Labs) — the t-SNE node (L. Jonsson), U06 and U07
• Network Mining + Distance Matrix (graphs) and Plotly (time series) — U05
• Big Data File Formats — the Parquet nodes, U03
Quick test
Build: MySQL Connector → DB Table Selector → DB Reader → Data Explorer. If
Sales_SalesOrderHeader shows 31,465 rows, KNIME is ready.
19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit00_slides_en.pdf#page=20)

~~~~text
STEP 4: CONNECT FROM PYTHON / KNIME
Python
1 pip install sqlalchemy mysql-connector-python
2
3 from sqlalchemy import create_engine
4 import pandas as pd
5
6 engine = create_engine(
7 "mysql+mysqlconnector://sqladmin:"
8 "YOUR-PASSWORD@localhost/"
9 "Adventureworks2019")
10
11 df = pd.read_sql(
12 "SELECT * FROM Sales_Customer "
13 "LIMIT 10", engine)
KNIME
• MySQL Connector node
• Host: localhost, Port: 3306
• User: sqladmin
• DB: Adventureworks2019
• Then: DB Table Selector → DB
Reader
20
~~~~

## Page 021

[Original page 21](../../../quellen/Unit00_slides_en.pdf#page=21)

~~~~text
A LOOK AT KNIME
All three lights green; Sales_SalesOrderDetail, the order lines, shows 121,317 rows below.
21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit00_slides_en.pdf#page=22)

~~~~text
THE DATASET: ADVENTUREWORKS CYCLING
A fictional bicycle maker, built by Microsoft as a demo database: realistic enough to be
messy, public so everyone can have it. The numbers you just installed:
71
tables
31,465
orders
121,317
order items
19,119
customers who
ordered
504
products, 266 ever
sold
10
sales territories, 6
countries
2011–14
orders from May
2011 to June 2014
109.8 M
revenue (sum of
LineTotal)
Real AWC, Adventureworks2019.
⇒ Why one dataset all semester: each unit builds on the last, and you learn to read one
business well. The next slides: what its tables mean, and why “the customers” are two
different groups.
22
~~~~

## Page 023

[Original page 23](../../../quellen/Unit00_slides_en.pdf#page=23)

~~~~text
WHAT THE TABLES ACTUALLY MEAN
“Header” and “Detail” come from paper forms. On a printed order the top block — who
ordered, when, ship-to, total — appears once; the rows underneath — product, quantity,
price — repeat. Software kept the split.
Table In plain words One row is
Sales_SalesOrderHeader the head of the order form: who, when, where,
total
one order
Sales_SalesOrderDetail its lines: article, quantity, price one order line
Production_Product the catalogue: 504 articles one article
Sales_Customer the account an order is billed to one account
Sales_SalesTerritory 5 US regions + CA, FR, DE, GB, AU one of 10 regions
Order 43659, Better Bike Shop, 2011-05-30: 1 header row and 12 detail lines. That is why
Header has 31,465 rows and Detail 121,317.
23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit00_slides_en.pdf#page=24)

~~~~text
ONE TABLE, TWO BUSINESSES
AWC sells the same bicycles two ways. OnlineOrderFlag in Header says which:
=0 reseller (B2B) =1 online (B2C)
who buys bike shops that resell private buyers
how they order through a sales rep on the website
orders 3,806 27,659
customers 635 18,484
avg TotalDue 23,851 1,173
max TotalDue 187,488 3,954
SalesPersonID always set always NULL
Two consequences, now
The largest online TotalDue (3,954) sits below the average reseller one (23,851): “AWC customers” is
ambiguous by a factor of twenty until you name the population. And SalesPersonID = NULL on
27,659 rows is not missing data — it is the business model.
24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit00_slides_en.pdf#page=25)

~~~~text
ADVENTUREWORKS CYCLING - SCHEMA
Sales (19)
SalesOrderHeader
SalesOrderDetail
Customer
Store
SalesTerritory
CountryRegionCurrency
CreditCard
Currency
CurrencyRate
PersonCreditCard
SalesOrderHeaderSalesReason
SalesPerson
SalesPersonQuotaHistory
SalesReason
SalesTaxRate
SalesTerritoryHistory
ShoppingCartItem
SpecialOffer
SpecialOfferProduct
Production (25)
Product
ProductSubcategory
ProductCategory
BillOfMaterials
Culture
Document
Illustration
Location
ProductCostHistory
ProductDescription
ProductDocument
ProductInventory
ProductListPriceHistory
ProductModel
ProductModelIllustration
ProductPhoto
ProductProductPhoto
ProductReview
ScrapReason
TransactionHistory
TransactionHistoryArchive
UnitMeasure
WorkOrder
WorkOrderRouting
ProductModelProductDescriptionCulture
HumanResources (6)
Department
Employee
EmployeeDepartmentHistory
EmployeePayHistory
JobCandidate
Shift
Purchasing (5)
ProductVendor
PurchaseOrderDetail
PurchaseOrderHeader
ShipMethod
Vendor
Person (13)
Person
BusinessEntityAddress
Address
StateProvince
CountryRegion
AddressType
BusinessEntity
BusinessEntityContact
ContactType
EmailAddress
Password
PersonPhone
PhoneNumberType
dbo (3)
AWBuildVersion
DatabaseLog
ErrorLog
Highlighted: the tables this course uses. Arrows: only their joins. The dump declares 90 foreign keys in all;
Workbench draws every one (Database → Reverse Engineer).
25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit00_slides_en.pdf#page=26)

~~~~text
Break
10 minutes
Then: Data, Information, Context
~~~~

## Page 027

[Original page 27](../../../quellen/Unit00_slides_en.pdf#page=27)

~~~~text
DATA, INFORMATION, CONTEXT
27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit00_slides_en.pdf#page=28)

~~~~text
DATA ARE EVERYWHERE
Image: Marc Miller, LLNL — https://people.llnl.gov/miller86
• Spreadsheets, images, sensor readings, social media, DNA, road networks, ...
• Data are not always numbers in a table
• So before computing anything, ask three questions — the next slides: which
context (DIKW)? which scale level? which origin?
28
~~~~

## Page 029

[Original page 29](../../../quellen/Unit00_slides_en.pdf#page=29)

~~~~text
DIKW: FROM DATA TO WISDOM
Data symbols without context: 475912.56
Information data + context: “Westside Plaza, a reseller, ordered for 475,913
(TotalDue) in 2013”
Knowledge a pattern across many facts: “resellers order in month-end batches,
online buyers on any day”
Wisdom judging what to do with it — for us, a decision you can defend: “plan
reseller stock for the month end”
Units 01–08 work mostly from data to knowledge; U09 ends in the decision. (Ackoff 1989;
Rowley 2007)
29
~~~~

## Page 030

[Original page 30](../../../quellen/Unit00_slides_en.pdf#page=30)

~~~~text
SCALE LEVELS: WHAT YOU MAY COMPUTE
Level You may Typical statistic Everyday example
Nominal =, ̸= count, mode colour, country
Ordinal + <, > median, percentiles size S/M/L, school grade
Interval + differences − mean, standard deviation date, temperature in °C
Ratio + ratios ÷ all of the above, “twice as much” price, weight, quantity, age
Cyclic∗
differences mod k circular mean weekday, month, hour
Each level allows everything of the one above (Stevens 1946). ∗Cyclic values wrap around — Sunday
to Monday is 1 day, not 6 — and come from circular statistics (Fisher 1993).
Why does this matter?
The scale level decides what you may meaningfully compute. Averaging zip codes
is possible but nonsense.
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit00_slides_en.pdf#page=31)

~~~~text
MOST COLUMNS ARE EASY — READ THE MEANING, NOT THE TYPE
Six real AWC columns. The database stores a type; you decide the level:
column stored as level so you may
Weight decimal number ratio average it; “twice as heavy”
OrderQty integer ratio (a count) sum and average it
age, from BirthDate integer (years) ratio mean age; “twice as old”
Color text nominal count it, find the most common
OrderDate timestamp interval days between two orders — not “twice
the date”
TerritoryID integer nominal count only — the mean territory is
nonsense
⇒ Amounts, weights, counts, ages: ratio, everything allowed. Text labels: nominal. The
storage type is a hint, not the answer — pandas dtypes and KNIME column types show the
type, never the level.
31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit00_slides_en.pdf#page=32)

~~~~text
THE TRICKY CASES
Not always obvious
• Star ratings (1–5): ordinal or interval? Is the gap 1→2 the same as 4→5?
• Dates: interval — but with cyclic parts (weekday, hour)
• Income brackets: ordinal, even though they contain numbers
• Product IDs: nominal — the number is a label, not a quantity
Income brackets (example)
1 2 3 4
0 € 20k € 40k € 80k €
same step in the code, not in euros
Star ratings
1 2 3 4 5
? ? ? ?
order is sure, the gaps are not
⇒ Scale depends on meaning, not appearance.
32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit00_slides_en.pdf#page=33)

~~~~text
HANDS ON — EXERCISE 1: DATA INVENTORY
20 minutes
Sheet on Moodle: Unit00_Exercises_en.pdf
Connect to Adventureworks2019 — Python or KNIME, not a CSV. I am in the room.
33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit00_slides_en.pdf#page=34)

~~~~text
WHERE DATA COME FROM
The origin predicts the typical error — and so what to check first:
Origin Example Its typical failure
Measured sensors, GPS, lab instruments calibration drift — the instrument slowly
stops agreeing with reality
Observed manual entry, surveys, annotations typos, blanks, and answers people
preferred to give
Derived total_revenue = price × qty a wrong formula, applied perfectly
consistently
Simulated models, Monte Carlo, synthetic data it encodes the model’s assumptions, not
the world’s
Scraped web pages, APIs, documents silent breakage when the layout changes;
sampling gaps
Drift looks the same in the data whether the instrument wanders or the world changes (concept drift,
U09): one feature’s distribution moves. So ask which feature drifted, and why (Hinder et al. 2024).
34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit00_slides_en.pdf#page=35)

~~~~text
“RAW DATA” IS A FICTION
Provenance
Every datum is shaped by decisions:
• What to measure (selection bias)
• How to measure (instrument, precision)
• When to sample (temporal coverage)
• How to encode (format, rounding, units)
• How to store (schema, normalization)
AWC example
OrderDate shows a clock time, but it is 18:30 UTC on all 31,465 orders (a client on
German time shows 19:30 or 20:30). Was the order placed at 9 AM or 11 PM? That
was never recorded.
35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit00_slides_en.pdf#page=36)

~~~~text
Break
10 minutes
Then: What a dataset cannot tell you
~~~~

## Page 037

[Original page 37](../../../quellen/Unit00_slides_en.pdf#page=37)

~~~~text
FIVE WAYS A DATASET SAYS NO
Before any analysis: can this data answer the question at all?
A question AWC cannot answer Why — measured
1. Column absent “What is our return rate?” No returns table (ScrapReason is factory
scrap).
2. Wrong grain “Which weekday do resellers
order on?”
3,806 orders on only 40 dates, all month
ends: batch dates.
3. Wrong
population
“Why do customers buy from us?” Sales reasons exist for 83% of online
orders, 0% of resellers.
4. Observational “Would a 10% discount raise
revenue?”
Discounts exist, but nobody assigned
them at random.
5. Effect too small “Do men and women in the US
spend differently?”
Too few orders for so small a difference
— next slide.
⇒ Only 1 is visible in the schema. The dangerous question is not the absurd one — it is the
one you were about to answer.
37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit00_slides_en.pdf#page=38)

~~~~text
5. TOO SMALL TO FIND
10 100 1k 10k 100k
order value
resellers vs. online — d = 1.50
10 100 1k 10k 100k
order value
men vs. women, US — d = 0.03
Real AWC order values, log axis. d = gap between the means in units of the spread, d = (¯x1 − ¯x2)/spooled.
AWC has 31,465 orders. Is that a lot?
Left: d = 1.50 needs 8 orders per group. Right: d = 0.03 needs ≈17,000 per group — we hold 4,776 and 4,791. A
dataset is large or small relative to the effect you are chasing.
38
~~~~

## Page 039

[Original page 39](../../../quellen/Unit00_slides_en.pdf#page=39)

~~~~text
HANDS ON — EXERCISE 2: PROVENANCE &
QUESTIONS
15 minutes
Sheet on Moodle: Unit00_Exercises_en.pdf
Uses the same four columns you chose before the break.
39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit00_slides_en.pdf#page=40)

~~~~text
SUMMARY
• The course turns raw data into a decision you can defend; today laid the base
• Set up means: the count prints 31465
• Know what one row is and which population you look at: order vs. order line,
reseller vs. online
• Data need context (DIKW); the scale level — the meaning, not the storage type
— decides what you may compute
• Every datum has a provenance, and a dataset can say no in five ways — check
before you answer
• Next: Unit 01 — Tabular Data, Tidy Data & Joins
40
~~~~

## Page 041

[Original page 41](../../../quellen/Unit00_slides_en.pdf#page=41)

~~~~text
REFERENCES I — DATA SCIENCE & ANALYSIS
• Cohen (1988), Statistical Power Analysis for the Behavioral Sciences, 2nd ed., Routledge — the
origin of d
doi.org/10.4324/9780203771587
• Lakens (2013), Calculating and reporting effect sizes..., Frontiers in Psychology 4:863 — a
gentler, worked route to the same d
doi.org/10.3389/fpsyg.2013.00863
• S. Skiena: The Data Science Design Manual, Springer, 2017.
Free via THWS/SpringerLink (click)
• J. VanderPlas: Python Data Science Handbook, O’Reilly, 2023.
Free online (click)
• W. McKinney: Python for Data Analysis, O’Reilly, 3rd ed., 2022.
Free online (click)
• H. Wickham, M. Çetinkaya-Rundel, G. Grolemund: R for Data Science, O’Reilly, 2nd ed., 2023.
Free online (click)
• Kaggle Learn: Intro to Pandas / Data Cleaning / Data Visualization.
Free interactive courses (click)
41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit00_slides_en.pdf#page=42)

~~~~text
REFERENCES II — DATA MANAGEMENT & ENGINEERING
• J. Reis, M. Housley: Fundamentals of Data Engineering, O’Reilly, 2022.
THWS Library (click)
• P. Strengholt: Data Management at Scale, 2nd ed., O’Reilly, 2023.
O’Reilly Learning via THWS (click)
• G. Saake, K. Sattler, A. Heuer: Datenbanken: Konzepte und Sprachen, mitp, 2013.
Check THWS Library (click)
42
~~~~

## Page 043

[Original page 43](../../../quellen/Unit00_slides_en.pdf#page=43)

~~~~text
REFERENCES III — THE CONCEPTS OF THIS UNIT
• R. L. Ackoff (1989): From Data to Wisdom, Journal of Applied Systems Analysis 16, 3–9.
• J. Rowley (2007): The wisdom hierarchy: representations of the DIKW hierarchy, Journal of
Information Science 33(2), 163–180.
doi.org/10.1177/0165551506070706
• S. S. Stevens (1946): On the Theory of Scales of Measurement, Science 103(2684), 677–680.
doi.org/10.1126/science.103.2684.677
• N. I. Fisher (1993): Statistical Analysis of Circular Data, Cambridge University Press.
doi.org/10.1017/CBO9780511564345
• F. Hinder, V. Vaquet, B. Hammer (2024): One or two things we know about concept drift, Frontiers
in Artificial Intelligence 7 — Part A detects drift, Part B locates and explains it.
doi.org/10.3389/frai.2024.1330257 · doi.org/10.3389/frai.2024.1330258
43
~~~~
