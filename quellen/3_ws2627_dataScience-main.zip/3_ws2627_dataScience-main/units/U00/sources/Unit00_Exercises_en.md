---
source_id: DS-U00-EX
original_file: Unit00_Exercises_en.pdf
source_type: exercise
language: en
page_count: 1
source_sha256: e212a1895c563ef7c56663534cb7ef36273aa2bcc4238b7248d9e7aeddf2f2fe
verification: partial
---
# Unit00_Exercises_en

[Original PDF](../../../quellen/Unit00_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit00_Exercises_en.pdf#page=1)

<a id="ds-u00-ex-t01"></a>

**DS-U00-EX-T01 — Data Inventory**

<a id="ds-u00-ex-t02"></a>

**DS-U00-EX-T02 — Provenance & Questions**

~~~~text
  Unit 00 — Exercises                                                                                        First Contact with AWC
Look at ten tables and say what they are — exploring and documenting, no cleaning, no plotting.
▶ In the room         what ﬁts the stop — all that is expected.
⃝ Extra               voluntary, at home.
Stop A, 20 min        Exercise 1      Stop B, 15 min: Exercise 2
Asynchronous          the same sheet, before your weekly slot; bring what did not run.
You need              a running Adventureworks2019. Check: mysql -u sqladmin -p -e "SELECT COUNT(*) FROM
                      Adventureworks2019.Sales_SalesOrderHeader;" must print 31,465.


Exercise 1 — Data Inventory stop A · ▶ 20 min
 1 For each of the ten tables in this query write down rows, columns, and what one row stands for. table_rows is only an
   estimate: take the exact rows from SELECT COUNT(*) FROM <table>.
         SELECT t.table_name, t.table_rows,
                (SELECT COUNT(*) FROM information_schema.columns c
                 WHERE c.table_schema = t.table_schema AND c.table_name = t.table_name) AS cols
         FROM information_schema.tables t
         WHERE LOWER(t.table_schema) = 'adventureworks2019'
           AND LOWER(t.table_name) IN ('sales_salesorderheader', 'sales_salesorderdetail',
               'production_product', 'production_productsubcategory', 'production_productcategory',
               'sales_customer', 'sales_salesterritory', 'person_person', 'person_address', 'sales_store');

        Example — the two rows the lecture did; do the other eight the same way

        table                             rows   cols   one row is . . .
        Sales_SalesOrderHeader         31,465      26   one order
        Sales_SalesOrderDetail        121,317      11   one order line — order 43659 has 12 of them

 2 Pick four columns from different tables. Give each its scale level — nominal, ordinal, interval or ratio — and one sentence
   why.
        Example — one column
        Sales_SalesOrderDetail.OrderQty: ratio — a count with a true zero; 4 items are twice 2 items.

 3 Find one column whose scale level is ambiguous, and give the argument for each reading.
⃝ Extra: do steps 2 and 3 for ten columns and three ambiguous ones. The tenth is harder than the ﬁrst.
Exercise 2 — Provenance & Questions stop B · ▶ 15 min · the same four columns
 1 For the same four columns, guess the origin: generated automatically, entered by hand, or derived from other columns.
   Note your reason; checking it comes later.
 2 Write two questions this dataset can answer, each with how you would compute it.
 3 Write one question it cannot answer — a question a colleague could plausibly ask and that looks answerable from the
   column names. Say which failure mode it is:
          failure mode         the question is . . .
    1     column absent        about something the schema never recorded
    2     wrong grain          ﬁner than the rows are
    3     wrong population     about people or events the data never saw
    4     observational        about a cause, and the data is not an experiment
    5     effect too small     answerable in principle, but not with this many rows

        Example — mode 1; ﬁnd yours for another mode
        “What is our return rate?” — a colleague asks it, the orders tables suggest it, but there is no returns table. (“What colour is the
        CEO’s car?” scores zero: nobody asks it, and nothing in the schema suggests an answer.)
⃝ Extra: ﬁnd an unanswerable question for each of the ﬁve modes. Mode 5 is the hardest — working out why is worth more
than the other four.

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• the inventory: ten rows — table, rows, columns, what one row stands for
• four columns with scale level, reason and origin; the one ambiguous column with both readings
• two answerable questions and one unanswerable one, with its failure mode




Unit 00 · Data Science · exercise sheet                                                                                                       1
~~~~
