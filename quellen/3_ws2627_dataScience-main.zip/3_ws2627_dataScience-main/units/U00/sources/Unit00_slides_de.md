---
source_id: DS-U00-L-DE
original_file: Unit00_slides_de.pdf
source_type: lecture
language: de
page_count: 43
source_sha256: 92a0b4d924434842e9fc9e8014d76d8f3bc10b8eda85954b1a5ea33f8adfd966
verification: partial
---
# Unit00_slides_de

[Original PDF](../../../quellen/Unit00_slides_de.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit00_slides_de.pdf#page=1)

~~~~text
Data Science
EINFÜHRUNG, SETUP & ERSTER
KONTAKT MIT DATEN
Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit00_slides_de.pdf#page=2)

~~~~text
LERNZIELE
• Modulstruktur, Werkzeuge und das Portfolio (M1–M4) verstehen
• Arbeitsumgebung einrichten (Python + Jupyter oder KNIME)
• Daten, Information, Wissen und Weisheit unterscheiden (DIKW)
• Skalenniveaus zuordnen: nominal, ordinal, Intervall, Verhältnis — dazu zyklisch
• Einen ersten kritischen Blick auf AdventureWorks Cycling werfen: was eine
Zeile ist und was die Daten nicht beantworten
2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit00_slides_de.pdf#page=3)

~~~~text
DER GANZE KURS AUF EINER FOLIE

Setup & Daten
00 !
Tidy & Joins
01 /
SQL → Code
02 T
Formate & Metadaten
03 s
Datenqualität
04 
Zeit & Graphen
05 #Merkmale
& Distanz
06 ó
Reduzieren
& Clustern
07 |
Explorieren &
Visualisieren
08 A
Dashboard
& ML-Reife
09
1. Vertrauenswürdige Daten 2. ... und prüfen 3. Darstellen 4. Reduzieren & sehen 5. Entscheiden
Jeder Schritt braucht den vorigen — das ist die Reihenfolge.
Rohdaten eine verteidigbare Entscheidung
Wir machen aus rohen AdventureWorks-Daten eine verteidigbare Entscheidung. Eine
Einheit je Schritt, und die Reihenfolge ist nicht willkürlich: man kann nicht bereinigen, was
man nicht laden kann, keine Merkmale reduzieren, die man nicht gebaut hat, nichts
kommunizieren, was ungeprüft ist.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit00_slides_de.pdf#page=4)

~~~~text
ORGANISATION
4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit00_slides_de.pdf#page=5)

~~~~text
WORUM GEHT ES?
Kernidee
Ein operatives Verständnis von Daten entwickeln — Herkunft, Struktur, Qualität,
Bedeutung — als Grundlage für Machine Learning.
• Modelle sind nicht das Ziel — das ist der ML-Kurs. Nur in U09 prüft ein Modell
die Daten auf Leakage
• Fokus: Daten verstehen, bereinigen, anreichern, dokumentieren
• Ein Datensatz fürs ganze Semester: AdventureWorks Cycling (AWC), auch fürs
Portfolio
• Werkzeug frei: Python/pandas oder KNIME (oder beides), in jedem
Studiengang. Die Übungen sind werkzeugunabhängig; ich rechne nur mit mehr
Python in BIN und mehr KNIME in BWI
5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit00_slides_de.pdf#page=6)

~~~~text
ORGANISATORISCHES
Dozent:
• Frank-Michael Schleif → frank-michael.schleif@thws.de
Voraussetzungen (empfohlen):
• Datenbanken (SQL-Grundkenntnisse)
• Programmiererfahrung (beliebige Sprache — Python wird im Kurs eingeführt)
• Statistik-Grundlagen — nicht vorausgesetzt; Auffrischungsdeck in Moodle
Materialien:
• https://elearning.thws.de
• Folien, Blätter, Datenbank, Starter-Kits, HANDIN.pdf; Termine in Schedule.pdf
6
~~~~

## Page 007

[Original page 7](../../../quellen/Unit00_slides_de.pdf#page=7)

~~~~text
VERANSTALTUNGSFORMAT
• 4 SWS = 4 × 45 min pro Woche: Vorlesung + integrierte Übungen
• Bring your own device — Laptop erforderlich
• Software: Python 3 + Jupyter + pandas oder KNIME Analytics Platform +
MySQL
• Übungen sind Teil der Vorlesung: Aufgabenblatt laden, hier 15–20 min
bearbeiten, solange ich im Raum bin, danach besprechen wir es
• BSED belegen ihn asynchron: dieselben Blätter zu Hause, dazu ein eigener
wöchentlicher Termin für Fragen und Lösungen — Zeit in Schedule.pdf,
Zoom-Link im Moodle-Kurs
KI-Richtlinie
LLMs (ChatGPT, Copilot, Claude) sind erlaubt, und ihr steht für das ein, was ihr
abgebt. Im mündlichen Teil (M4) erklärt und begründet ihr eure Entscheidungen.
Was ihr nicht erklären könnt, habt ihr nicht verstanden — mit oder ohne LLM.
7
~~~~

## Page 008

[Original page 8](../../../quellen/Unit00_slides_de.pdf#page=8)

~~~~text
BEWERTUNG: EIN PORTFOLIO IN VIER TEILEN
Jeder Teil nutzt den AWC-Ausschnitt eurer Gruppe und baut auf dem vorigen auf.
Was Fällig Gewicht
M1 Metadaten, Profiling-Bericht, Bereinigungsprotokoll Termin von U05 20 %
M2 bereinigte Flat-Table, Ähnlichkeitsstudie,
Clusteranalyse, fünf Plots nach Peer-Review
nach U08 20 %
M3 drei belegte Fragen, KPI-Dashboard, Leakage-Test,
ML-Readiness
erster Prüfungstag 30 %
M4 mündliche Verteidigung: die Gruppe stellt ihr
Ergebnis vor und beantwortet Fragen
Prüfungszeitraum 20 %
Formales sauber, vollständig, pünktlich — über alle Teile 10 %
Jede Frist, mit Datum und Uhrzeit, steht in Schedule.pdf in Moodle. M1 und M2 werden im
Semester besprochen, damit das Feedback noch wirkt. Noten in der Regel pro Gruppe, wo nötig
individuell; alle gibt es am Ende.
8
~~~~

## Page 009

[Original page 9](../../../quellen/Unit00_slides_de.pdf#page=9)

~~~~text
GRUPPEN, ABGABE, MÜNDLICHER TEIL
• Gruppen, Größe je nach Teilnehmerzahl; BIN und BWI gemischt, BSED unter sich.
Anmeldung ab heute bis zum nächsten Termin; dann kommen Gruppen und
Ausschnitte, der Upload-Link jeder Gruppe per Mail.
• Jede Gruppe hat ihren eigenen Ausschnitt (Gebiet × Kategorie), also andere Zahlen.
• Ein Archiv pro Gruppe und Meilenstein; das Manifest nennt, wer was gemacht hat. Wer
sich nicht vertreten fühlt, schreibt mir vor der Frist eine Mail.
• Beitritt nach der M1-Frist: M1 wird nicht bewertet — 20 % weg, kein Ersatz.
• Der mündliche Teil (M4) liegt im Prüfungszeitraum — alle sind da. Ohne ihn ist das
Portfolio nicht abgelegt.
Was und wie abgegeben wird
Pro Meilenstein sagt ein Aufgabenblatt in Moodle, was zu tun ist; HANDIN.pdf, wie
abgegeben wird. Dazu Starter-Kit und Prüfskript.
9
~~~~

## Page 010

[Original page 10](../../../quellen/Unit00_slides_de.pdf#page=10)

~~~~text
SEMESTERFAHRPLAN
Einheit Kernergebnis
00 Einführung, Setup & Erster Kontakt mit Daten (heute) Umgebung steht, Skalenniveau-Tabelle
01 Tabellarische Daten, Tidy Data & Joins AWC Flat-Table
02 Von der SQL-Konsole zum Programm Wiederholbares Extrakt-Skript
03 Formate, Serialisierung & Metadaten Metadaten + Data Dictionary
04 Datenqualität: Profiling, dann Bereinigen mit Begründung Profiling + Bereinigungsprotokoll
05 Jenseits von Tabellen: Zeitreihen & Graphen Zeitreihe + Graph-Abfragen
M1-Abgabe, am nächsten Termin besprochen Metadaten, Profiling, Bereinigungsprotokoll
06 Merkmale, Ähnlichkeit & Distanz Distanzen unter drei Maßen
07 Dimensionsreduktion: PCA, t-SNE & Cluster Clusteranalyse
08 Explorative Datenanalyse: Statistik & Visualisierung Kommentierte EDA-Plots
M2-Abgabe, am nächsten Termin besprochen bereinigte Tabelle, Ähnlichkeit, Cluster, Plots
09 Dashboards, Kommunikation & ML-Readiness Dashboard + Leakage-Test + ML-Checkliste
M3-Abgabe zum ersten Prüfungstag M4: mündlicher Teil, Prüfungszeitraum
10 Einheiten, beide Kohorten, gleiches Material — online eine Sitzung je Einheit, in Präsenz dieselben zehn mit
U08 auf zwei Terminen. Termine: Schedule.pdf in Moodle.
10
~~~~

## Page 011

[Original page 11](../../../quellen/Unit00_slides_de.pdf#page=11)

~~~~text
KENNENLERNEN
SQL
Python
KNIME
Zwei Minuten. Link am Beamer.
Anonym — keine Namen, keine persönlichen Daten. So lernen wir den Raum kennen.
BSED: dieselbe Umfrage, als Moodle-Aktivität in eurem Kurs.
11
~~~~

## Page 012

[Original page 12](../../../quellen/Unit00_slides_de.pdf#page=12)

~~~~text
Pause
10 Minuten
Danach: Einrichten — praktisch
~~~~

## Page 013

[Original page 13](../../../quellen/Unit00_slides_de.pdf#page=13)

~~~~text
ARBEITSUMGEBUNG EINRICHTEN
13
~~~~

## Page 014

[Original page 14](../../../quellen/Unit00_slides_de.pdf#page=14)

~~~~text
PRAXIS: JETZT, NICHT SPÄTER
Die Folien bis ‚Ein Blick auf KNIME’ sind eine Anleitung, keine Vorlesung, in vier Schritten: 1
MySQL-Server, 2 die AWC-Datenbank, 3 euer Werkzeug (Python oder KNIME), 4 Werkzeug
mit der Datenbank verbinden.
Warum jetzt: ab U01 liest jede Einheit aus dieser Datenbank.
Hier, jetzt BSED, asynchron
≈25 Minuten. An eurem eigenen Rechner. Ich
gehe herum; fragt, sobald etwas klemmt.
Dieselben Folien, zu Hause. Probleme in euren
wöchentlichen Termin in Woche 1 — genau
dafür da.
Das Einzige, was als ‚fertig’ zählt
Dieser Befehl gibt eine Zahl aus: mysql -u sqladmin -p -e "SELECT COUNT(*) FROM
Adventureworks2019.Sales_SalesOrderHeader;" Wenn 31465 erscheint, ist alles
eingerichtet. Wenn etwas anderes erscheint, nicht — sagt es jetzt, solange ich im Raum
bin. BSED: bringt es in den wöchentlichen Termin.
14
~~~~

## Page 015

[Original page 15](../../../quellen/Unit00_slides_de.pdf#page=15)

~~~~text
SCHRITT 1: MYSQL SERVER + WORKBENCH
AWC lebt in einer MySQL-Datenbank — ihr braucht einen laufenden Server.
Installation (Ubuntu/Debian):
1 sudo apt-get install mysql-server
2 sudo systemctl start mysql.service
3 sudo snap install mysql-workbench-community
Erstkonfiguration (einmalig nach Installation):
1 sudo mysql
2 mysql> ALTER USER 'root'@'localhost'
3 IDENTIFIED BY 'YOUR-ROOT-PASSWORD';
4 mysql> CREATE USER 'sqladmin'@'%'
5 IDENTIFIED BY 'YOUR-USER-PASSWORD';
6 mysql> FLUSH PRIVILEGES;
Windows/Mac: Download von https://dev.mysql.com/downloads/ — der Installer richtet den
Dienst ein. Dann mysql -u root -p statt sudo mysql, MySQLs bin-Ordner in den PATH, den Import
der nächsten Folie in cmd.exe: PowerShell kennt kein <.
15
~~~~

## Page 016

[Original page 16](../../../quellen/Unit00_slides_de.pdf#page=16)

~~~~text
SCHRITT 2: AWC-DATENBANK IMPORTIEREN
Schritt 1: AdventureWorks2019.sql aus Moodle laden (≈100 MB, 71 Tabellen).
Schritt 2: Import über die Kommandozeile:
1 mysql -u root -p -e "CREATE DATABASE Adventureworks2019;"
2 mysql -u root -p Adventureworks2019 < AdventureWorks2019.sql
Schritt 3: Rechte für den Nicht-Root-Benutzer vergeben (SET erlaubt Trigger in U02):
1 mysql -u root -p
2 mysql> GRANT ALL PRIVILEGES
3 ON Adventureworks2019.* TO 'sqladmin'@'%';
4 mysql> SET PERSIST log_bin_trust_function_creators = 1;
5 mysql> FLUSH PRIVILEGES;
Schritt 4: Prüfen — Workbench öffnen, als sqladmin verbinden, Tabellen ansehen. Workbench
Passwort-Fix (Ubuntu snap): sudo snap connect mysql-workbench-community:password-manager-service :password-manager-service
Schnelltest
mysql -u sqladmin -p -e "SELECT COUNT(*) FROM Adventureworks2019.Sales_SalesOrderHeader;"
16
~~~~

## Page 017

[Original page 17](../../../quellen/Unit00_slides_de.pdf#page=17)

~~~~text
EIN BLICK AUF MYSQL WORKBENCH
Im Schema-Baum steht Adventureworks2019, und die Zählung liefert 31465. Das ist der ganze Test.
17
~~~~

## Page 018

[Original page 18](../../../quellen/Unit00_slides_de.pdf#page=18)

~~~~text
SCHRITT 3, OPTION A: PYTHON
Was ihr braucht:
• Python 3.10+ (https://www.python.org oder Anaconda)
• Jupyter Notebook / JupyterLab (pip install jupyterlab)
• Kernpakete:
1 pip install pandas numpy matplotlib seaborn
2 pip install plotly scikit-learn
3 pip install sqlalchemy mysql-connector-python
4 pip install pyarrow pyyaml h5py jsonpath-ng # formats (U03)
5 pip install streamlit pydeck # dashboard + map (U09)
Schnelltest
Öffnet ein Jupyter Notebook, führt import pandas as pd;
print(pd.__version__) aus — fertig.
18
~~~~

## Page 019

[Original page 19](../../../quellen/Unit00_slides_de.pdf#page=19)

~~~~text
SCHRITT 3, OPTION B: KNIME
Was ihr braucht:
• KNIME Analytics Platform 5.x (https://www.knime.com/downloads)
• Kostenlos, Open Source, Drag-and-Drop-Workflow-Tool
• Extensions über KNIME Hub installieren:
• Geospatial Analytics Extension — die U09-Karte
• KNIME Python Integration — nicht optional, die Geospatial-Nodes brauchen es
• KNIME Statistics Nodes (Labs) — der t-SNE-Node (L. Jonsson), U06 und U07
• Network Mining + Distance Matrix (Graphen) und Plotly (Zeitreihen) — U05
• Big Data File Formats — die Parquet-Nodes, U03
Schnelltest
Baut: MySQL Connector → DB Table Selector → DB Reader → Data Explorer. Zeigt
Sales_SalesOrderHeader 31.465 Zeilen, ist KNIME bereit.
19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit00_slides_de.pdf#page=20)

~~~~text
SCHRITT 4: ZUGRIFF AUS PYTHON / KNIME
Python
1 pip install sqlalchemy mysql-connector-python
2
3 from sqlalchemy import create_engine
4 import pandas as pd
5
6 engine = create_engine(
7 "mysql+mysqlconnector://sqladmin:"
8 "YOUR-PASSWORD@localhost/"
9 "Adventureworks2019")
10
11 df = pd.read_sql(
12 "SELECT * FROM Sales_Customer "
13 "LIMIT 10", engine)
KNIME
• MySQL Connector Node
• Host: localhost, Port: 3306
• Benutzer: sqladmin
• DB: Adventureworks2019
• Dann: DB Table Selector → DB
Reader
20
~~~~

## Page 021

[Original page 21](../../../quellen/Unit00_slides_de.pdf#page=21)

~~~~text
EIN BLICK AUF KNIME
Alle Ampeln grün; Sales_SalesOrderDetail (Positionen) zeigt 121.317 Zeilen.
21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit00_slides_de.pdf#page=22)

~~~~text
DER DATENSATZ: ADVENTUREWORKS CYCLING
Ein fiktiver Fahrradhersteller, von Microsoft als Demodatenbank gebaut: realistisch genug,
um unordentlich zu sein, öffentlich, damit alle ihn haben können. Die Zahlen, die ihr gerade
installiert habt:
71
Tabellen
31.465
Bestellungen
121.317
Bestellpositionen
19.119
Kunden mit
Bestellung
504
Produkte, 266 je
verkauft
10
Vertriebsgebiete, 6
Länder
2011–14
Bestellungen Mai
2011 bis Juni 2014
109,8 Mio.
Umsatz (Summe
LineTotal)
Echte AWC-Daten, Adventureworks2019.
⇒ Warum ein Datensatz fürs ganze Semester: jede Einheit baut auf der vorigen auf, und
ihr lernt, ein Geschäft gut zu lesen. Die nächsten Folien: was die Tabellen bedeuten und
warum ‚die Kunden’ zwei verschiedene Gruppen sind.
22
~~~~

## Page 023

[Original page 23](../../../quellen/Unit00_slides_de.pdf#page=23)

~~~~text
WAS DIE TABELLEN TATSÄCHLICH BEDEUTEN
‚Header’ und ‚Detail’ kommen vom Papierformular. Auf einem gedruckten Auftrag steht
der Kopf — wer, wann, wohin, Gesamtbetrag — einmal; die Zeilen darunter — Produkt,
Menge, Preis — wiederholen sich. Die Software hat die Teilung behalten.
Tabelle In Klartext Eine Zeile ist
Sales_SalesOrderHeader der Auftragskopf: wer, wann, wohin,
Gesamtbetrag
eine Bestellung
Sales_SalesOrderDetail seine Positionen: Artikel, Menge, Preis eine Position
Production_Product der Katalog: 504 Artikel ein Artikel
Sales_Customer das Konto, auf das berechnet wird ein Kundenkonto
Sales_SalesTerritory 5 US-Regionen + CA, FR, DE, GB, AU eine von 10 Regionen
Auftrag 43659, Better Bike Shop, 30.05.2011: 1 Header-Zeile und 12 Detail-Positionen.
Deshalb hat Header 31.465 Zeilen und Detail 121.317.
23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit00_slides_de.pdf#page=24)

~~~~text
EINE TABELLE, ZWEI GESCHÄFTE
AWC verkauft dieselben Räder auf zwei Weisen. OnlineOrderFlag sagt, welche:
=0 Reseller (B2B) =1 Online (B2C)
wer kauft Läden, die weiterverkaufen Privatkunden
wie bestellt über Vertriebler über die Website
Bestellungen 3,806 27,659
Kunden 635 18,484
∅ TotalDue 23,851 1,173
max. TotalDue 187,488 3,954
SalesPersonID immer gesetzt immer NULL
Zwei Konsequenzen, sofort
Der größte Online-TotalDue (3.954) liegt unter dem durchschnittlichen der Reseller (23.851) —
‚AWC-Kunden’ bleibt um Faktor zwanzig unbestimmt, solange die Population nicht benannt ist. Und
SalesPersonID = NULL auf 27.659 Zeilen ist kein fehlender Wert, sondern das Geschäftsmodell.
24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit00_slides_de.pdf#page=25)

~~~~text
ADVENTUREWORKS CYCLING - SCHEMA
Sales (19)
SalesOrderHeader
SalesOrderDetail
Customer
Store
SalesTerritory
CountryRegionCurrency
CreditCard
Currency
CurrencyRate
PersonCreditCard
SalesOrderHeaderSalesReason
SalesPerson
SalesPersonQuotaHistory
SalesReason
SalesTaxRate
SalesTerritoryHistory
ShoppingCartItem
SpecialOffer
SpecialOfferProduct
Production (25)
Product
ProductSubcategory
ProductCategory
BillOfMaterials
Culture
Document
Illustration
Location
ProductCostHistory
ProductDescription
ProductDocument
ProductInventory
ProductListPriceHistory
ProductModel
ProductModelIllustration
ProductPhoto
ProductProductPhoto
ProductReview
ScrapReason
TransactionHistory
TransactionHistoryArchive
UnitMeasure
WorkOrder
WorkOrderRouting
ProductModelProductDescriptionCulture
HumanResources (6)
Department
Employee
EmployeeDepartmentHistory
EmployeePayHistory
JobCandidate
Shift
Purchasing (5)
ProductVendor
PurchaseOrderDetail
PurchaseOrderHeader
ShipMethod
Vendor
Person (13)
Person
BusinessEntityAddress
Address
StateProvince
CountryRegion
AddressType
BusinessEntity
BusinessEntityContact
ContactType
EmailAddress
Password
PersonPhone
PhoneNumberType
dbo (3)
AWBuildVersion
DatabaseLog
ErrorLog
Hervorgehoben: vom Kurs genutzt, Pfeile: deren Joins. Der Dump deklariert 90 Fremdschlüssel; Workbench
zeichnet alle (Database → Reverse Engineer).
25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit00_slides_de.pdf#page=26)

~~~~text
Pause
10 Minuten
Danach: Daten, Information, Kontext
~~~~

## Page 027

[Original page 27](../../../quellen/Unit00_slides_de.pdf#page=27)

~~~~text
DATEN, INFORMATION, KONTEXT
27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit00_slides_de.pdf#page=28)

~~~~text
DATEN SIND ÜBERALL
Bild: Marc Miller, LLNL — https://people.llnl.gov/miller86
• Tabellen, Bilder, Sensordaten, Social Media, DNA, Straßennetze, ...
• Daten sind nicht immer Zahlen in einer Tabelle
• Also vor jeder Rechnung drei Fragen — die nächsten Folien: welcher Kontext
(DIKW)? welches Skalenniveau? welche Herkunft?
28
~~~~

## Page 029

[Original page 29](../../../quellen/Unit00_slides_de.pdf#page=29)

~~~~text
DIKW: VON DATEN ZU WEISHEIT
Daten Symbole ohne Kontext: 475912.56
Information Daten + Kontext: ‚Westside Plaza, ein Reseller, bestellte 2013 für
475.913 (TotalDue)’
Wissen ein Muster über viele Fakten: ‚Reseller bestellen in Batches zum
Monatsende, Online-Kunden an jedem Tag’
Weisheit beurteilen, was daraus folgt — bei uns eine verteidigbare
Entscheidung: ‚Reseller-Bestand zum Monatsende planen’
Die Einheiten 01–08 arbeiten meist von Daten zu Wissen; U09 endet bei der Entscheidung.
(Ackoff 1989; Rowley 2007)
29
~~~~

## Page 030

[Original page 30](../../../quellen/Unit00_slides_de.pdf#page=30)

~~~~text
SKALENNIVEAUS: WAS MAN RECHNEN DARF
Niveau Erlaubt Typische Statistik Alltagsbeispiel
Nominal =, ̸= Häufigkeit, Modus Farbe, Land
Ordinal + <, > Median, Perzentile Größe S/M/L, Schulnote
Intervall + Differenzen − Mittelwert, Standardabw. Datum, Temperatur in °C
Verhältnis + Verhältnisse ÷ alles, ‚doppelt so viel’ Preis, Gewicht, Menge, Alter
Zyklisch∗ Differenzen mod k zirkulärer Mittelwert Wochentag, Monat, Stunde
Jedes Niveau erlaubt alles des darüberliegenden (Stevens 1946). ∗Zyklische Werte laufen um —
Sonntag bis Montag ist 1 Tag, nicht 6 — und stammen aus der Kreisstatistik (Fisher 1993).
Warum wichtig?
Das Skalenniveau entscheidet, was man sinnvoll berechnen darf. Der Mittelwert
von Postleitzahlen ist möglich, aber sinnlos.
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit00_slides_de.pdf#page=31)

~~~~text
DIE MEISTEN SPALTEN SIND EINFACH — BEDEUTUNG LESEN, NICHT TYP
Sechs echte AWC-Spalten. Die Datenbank speichert einen Typ; das Niveau entscheidet ihr:
Spalte gespeichert als Niveau also darf man
Weight Dezimalzahl Verhältnis mitteln; ‚doppelt so schwer’
OrderQty Ganzzahl Verhältnis (Anzahl) summieren, mitteln
Alter, aus BirthDate Ganzzahl (Jahre) Verhältnis mitteln; ‚doppelt so alt’
Color Text nominal zählen, häufigste finden
OrderDate Zeitstempel Intervall Tage dazwischen — kein
‚doppeltes Datum’
TerritoryID Ganzzahl nominal nur zählen — ‚mittleres Gebiet’ ist
Unsinn
⇒ Beträge, Gewichte, Anzahlen, Alter: Verhältnis, alles erlaubt. Text-Labels: nominal. Der
Speichertyp ist ein Hinweis, nicht die Antwort — pandas-dtypes und KNIME-Spaltentypen
zeigen den Typ, nie das Niveau.
31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit00_slides_de.pdf#page=32)

~~~~text
GRENZFÄLLE
Nicht immer eindeutig
• Sternebewertungen (1–5): ordinal oder Intervall?
• Datumsangaben: Intervall — aber mit zyklischen Anteilen
• Einkommensklassen: ordinal, obwohl Zahlen drin stehen
• Produkt-IDs: nominal — die Zahl ist ein Label, keine Menge
Einkommensklassen (Beispiel)
1 2 3 4
0 € 20k € 40k € 80k €
gleicher Schritt im Code, nicht in Euro
Sternebewertungen
1 2 3 4 5
? ? ? ?
die Reihenfolge ist sicher, die Abstände nicht
⇒ Das Niveau hängt von der Bedeutung ab, nicht vom Aussehen.
32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit00_slides_de.pdf#page=33)

~~~~text
PRAXIS — ÜBUNG 1: DATENINVENTAR
20 Minuten
Aufgabenblatt in Moodle: Unit00_Exercises_de.pdf
Verbindet euch mit Adventureworks2019 — Python oder KNIME, keine CSV. Ich bin im Raum.
33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit00_slides_de.pdf#page=34)

~~~~text
WOHER KOMMEN DATEN?
Die Herkunft sagt den typischen Fehler voraus — und damit, was zuerst zu prüfen ist:
Herkunft Beispiel Sein typischer Fehler
Gemessen Sensoren, GPS, Laborgeräte Kalibrierungsdrift — das Gerät weicht
langsam von der Realität ab
Beobachtet manuelle Eingabe, Umfragen,
Annotationen
Tippfehler, Lücken und Antworten, die
man lieber gibt
Abgeleitet total_revenue = Preis × Menge eine falsche Formel, völlig konsistent
angewandt
Simuliert Modelle, Monte Carlo, synthetische
Daten
es kodiert die Annahmen des Modells,
nicht die der Welt
Gecrawlt Webseiten, APIs, Dokumente stiller Bruch bei Layout-Änderungen;
Sampling-Lücken
Drift sieht in den Daten gleich aus, ob das Messgerät wandert oder sich die Welt ändert (Concept
Drift, U09): die Verteilung eines Merkmals verschiebt sich. Also fragen: welches Merkmal driftet,
und warum (Hinder et al. 2024).
34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit00_slides_de.pdf#page=35)

~~~~text
‚ROHDATEN’ SIND EINE FIKTION
Provenienz
Jedes Datum wird durch Entscheidungen geformt:
• Was gemessen wird (Selektionsbias)
• Wie gemessen wird (Instrument, Präzision)
• Wann abgetastet wird (zeitliche Abdeckung)
• Wie kodiert wird (Format, Rundung, Einheiten)
• Wie gespeichert wird (Schema, Normalisierung)
AWC-Beispiel
OrderDate zeigt eine Uhrzeit, aber überall dieselbe: 18:30 UTC auf allen 31.465
Bestellungen (auf deutscher Zeit 19:30 oder 20:30). 9 oder 23 Uhr? Nie erfasst.
35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit00_slides_de.pdf#page=36)

~~~~text
Pause
10 Minuten
Danach: Was ein Datensatz nicht sagen kann
~~~~

## Page 037

[Original page 37](../../../quellen/Unit00_slides_de.pdf#page=37)

~~~~text
FÜNF ARTEN, WIE EIN DATENSATZ NEIN SAGT
Vor jeder Analyse: können diese Daten die Frage überhaupt beantworten?
Eine Frage, die AWC nicht
beantwortet
Warum — gemessen
1. Spalte fehlt ‚Wie hoch ist unsere
Retourenquote?’
Keine Retourentabelle (ScrapReason ist
Fertigungsausschuss).
2. Falsche
Granularität
‚An welchem Wochentag
bestellen Reseller?’
3.806 Bestellungen an nur 40 Daten, alle
Monatsenden: Batch-Daten.
3. Falsche
Population
‚Warum kaufen Kunden bei uns?’ Kaufgründe gibt es für 83% der Online-,
0% der Reseller-Bestellungen.
4. Beobachtend ‚Würden 10% Rabatt den Umsatz
steigern?’
Rabatte gibt es, aber niemand vergab sie
zufällig.
5. Effekt zu klein ‚Geben Männer und Frauen in den
USA anders aus?’
Zu wenige Bestellungen für so einen
kleinen Unterschied — nächste Folie.
⇒ Nur 1 ist im Schema sichtbar. Gefährlich ist nicht die absurde Frage — sondern die, die
ihr gerade beantworten wolltet.
37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit00_slides_de.pdf#page=38)

~~~~text
5. ZU KLEIN ZUM FINDEN
10 100 1k 10k 100k
Bestellwert
Reseller vs. Online — d = 1.50
10 100 1k 10k 100k
Bestellwert
Männer vs. Frauen, USA — d = 0.03
Echte AWC-Bestellwerte, Log-Achse. d = Abstand der Mittelwerte in Einheiten der Streuung, d = (¯x1 − ¯x2)/spooled.
AWC hat 31.465 Bestellungen. Ist das viel?
Links: d = 1,50 braucht 8 Bestellungen je Gruppe. Rechts: d = 0,03 braucht ≈17.000 je Gruppe — wir haben
4.776 und 4.791. Ein Datensatz ist groß oder klein relativ zum gesuchten Effekt.
38
~~~~

## Page 039

[Original page 39](../../../quellen/Unit00_slides_de.pdf#page=39)

~~~~text
PRAXIS — ÜBUNG 2: PROVENIENZ & FRAGEN
15 Minuten
Aufgabenblatt in Moodle: Unit00_Exercises_de.pdf
Nutzt dieselben vier Spalten, die ihr vor der Pause gewählt habt.
39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit00_slides_de.pdf#page=40)

~~~~text
ZUSAMMENFASSUNG
• Der Kurs macht aus Rohdaten eine verteidigbare Entscheidung; heute war das
Fundament
• Eingerichtet heißt: die Zählung liefert 31465
• Wissen, was eine Zeile ist und welche Population man ansieht: Bestellung vs.
Position, Reseller vs. Online
• Daten brauchen Kontext (DIKW); das Skalenniveau — die Bedeutung, nicht der
Speichertyp — entscheidet, was man rechnen darf
• Jedes Datum hat eine Herkunft, und ein Datensatz kann auf fünf Arten Nein
sagen — vor der Antwort prüfen
• Nächstes Mal: Einheit 01 — Tabellarische Daten, Tidy Data & Joins
40
~~~~

## Page 041

[Original page 41](../../../quellen/Unit00_slides_de.pdf#page=41)

~~~~text
LITERATUR I — DATA SCIENCE & ANALYSE
• Cohen (1988), Statistical Power Analysis for the Behavioral Sciences, 2. Aufl., Routledge —
Ursprung von d
doi.org/10.4324/9780203771587
• Lakens (2013), Calculating and reporting effect sizes..., Frontiers in Psychology 4:863 —
sanfterer, gerechneter Weg zum selben d
doi.org/10.3389/fpsyg.2013.00863
• S. Skiena: The Data Science Design Manual, Springer, 2017.
Frei über THWS/SpringerLink (klick)
• J. VanderPlas: Python Data Science Handbook, O’Reilly, 2023.
Frei online (klick)
• W. McKinney: Python for Data Analysis, O’Reilly, 3rd ed., 2022.
Frei online (klick)
• H. Wickham, M. Çetinkaya-Rundel, G. Grolemund: R for Data Science, O’Reilly, 2nd ed., 2023.
Frei online (klick)
• Kaggle Learn: Intro to Pandas / Data Cleaning / Data Visualization.
Kostenlose interaktive Kurse (klick)
41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit00_slides_de.pdf#page=42)

~~~~text
LITERATUR II — DATENMANAGEMENT & ENGINEERING
• J. Reis, M. Housley: Fundamentals of Data Engineering, O’Reilly, 2022.
THWS Bibliothek (klick)
• P. Strengholt: Data Management at Scale, 2nd ed., O’Reilly, 2023.
O’Reilly Learning über THWS (klick)
• G. Saake, K. Sattler, A. Heuer: Datenbanken: Konzepte und Sprachen, mitp, 2013.
THWS Bibliothek (klick)
42
~~~~

## Page 043

[Original page 43](../../../quellen/Unit00_slides_de.pdf#page=43)

~~~~text
LITERATUR III — BEGRIFFE DIESER EINHEIT
• R. L. Ackoff (1989): From Data to Wisdom, Journal of Applied Systems Analysis 16, 3–9.
• J. Rowley (2007): The wisdom hierarchy: representations of the DIKW hierarchy, Journal of
Information Science 33(2), 163–180.
doi.org/10.1177/0165551506070706
• S. S. Stevens (1946): On the Theory of Scales of Measurement, Science 103(2684), 677–680.
doi.org/10.1126/science.103.2684.677
• N. I. Fisher (1993): Statistical Analysis of Circular Data, Cambridge University Press.
doi.org/10.1017/CBO9780511564345
• F. Hinder, V. Vaquet, B. Hammer (2024): One or two things we know about concept drift, Frontiers
in Artificial Intelligence 7 — Teil A erkennt Drift, Teil B lokalisiert und erklärt sie.
doi.org/10.3389/frai.2024.1330257 · doi.org/10.3389/frai.2024.1330258
43
~~~~
