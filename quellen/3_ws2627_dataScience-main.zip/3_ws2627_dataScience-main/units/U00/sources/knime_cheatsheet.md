---
source_id: DS-U00-R-KNIME-CHEATSHEET
original_file: "Scripts/knime_cheatsheet.pdf"
source_type: reference
language: en
page_count: 1
source_sha256: c830f781f2390481f9d14477be837f71f0ab6f2382047e774765216fa20529fa
verification: partial
---

# knime_cheatsheet

> Automatische Layout-Textfassung; Seitenbilder sind als visuelle Referenz beigefügt. Tabellen, Code, Formeln und Diagrammsemantik sind noch nicht vollständig manuell normalisiert oder geprüft.

## Page 001

![Originalseite 1](assets/DS-U00-R-KNIME-CHEATSHEET/p001.png)

~~~~text
  KNIME — U00 cheat sheet                                                                         get it connected, then stop


Everything on this sheet has one purpose: reach Adventureworks2019 from KNIME and see one number. If that works,
you are set up. If it does not, the answer is almost certainly in “Two failures” below.

Install: KNIME 5.x + four extensions
    KNIME Analytics Platform 5.x              knime.com/downloads — free, open source
    Geospatial Analytics                      the U09 map
    KNIME Python Integration                  not optional — the Geospatial nodes run on Python
    t-SNE (L. Jonsson)                        needed to open AWC_Customer_Segmentation
All four from the KNIME Hub. You do not need Network Mining — nothing in this course uses it.

The four nodes that prove it works

         MySQL Connector                    DB Table Selector                  DB Reader               Data Explorer

                                            Sales_SalesOrderHeader                                        31,465 rows



Connector settings: host localhost · port 3306 · database Adventureworks2019 · user sqladmin. No extra JDBC pa-
rameters.

Two failures you may actually hit

 server time zone value ’CEST’ is                                 1    Public Key Retrieval is not allowed                  2
 unrecognized                                                          Add allowPublicKeyRetrieval=true.     Only ever against
 You    picked   the   bundled     8.0.11     driver.       Choose     localhost.
 the   newest    MySQL    driver   in   the    node     —   or   add
 serverTimezone=Europe/Berlin.



Which tool should I pick?
 Either tool, in any programme — the exercises are tool-independent. What I expect is simply more Python in BIN and
more KNIME in BWI, and that is an expectation, not a rule. KNIME is low-code, not less work: U01’s ﬂat table is about
eight lines of pandas or about 29 nodes. What KNIME gives you instead is a picture of the dataﬂow that is its own
documentation.


           If Sales_SalesOrderHeader shows 31,465 rows, you are done here. Close KNIME and go to U01.
~~~~
