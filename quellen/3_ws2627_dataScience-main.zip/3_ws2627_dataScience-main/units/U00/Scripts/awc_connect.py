import os
from sqlalchemy import create_engine
import pandas as pd
try:
    AWC_DB_PW = os.environ["AWC_DB_PW"]
except KeyError:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")
engine = create_engine(
"mysql+mysqlconnector://sqladmin:"
f"{AWC_DB_PW}@localhost/"
"Adventureworks2019")
df = pd.read_sql(
"SELECT * FROM Sales_Customer "
"LIMIT 10", engine)
print(f"Result",df)
