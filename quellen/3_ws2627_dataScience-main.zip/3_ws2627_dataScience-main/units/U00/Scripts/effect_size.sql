-- Unit 00 -- can this dataset answer this question at all?  (slide "Too Small to Find")
--
-- The same two questions as effect_size.py, straight in MySQL Workbench against
-- Adventureworks2019 (MySQL 8: needs WITH). Order value = sum of its LineTotal,
-- compared on log10, because on the raw scale the reseller and online spreads
-- differ by 22x and a pooled d would not mean anything.
--
--   d        = (mean_1 - mean_2) / s_pooled                  (Cohen's d)
--   n_needed = 2 (1.959964 + 0.841621)^2 / d^2               per group,
--              two-sided t-test, alpha 0.05, power 0.80 (normal approximation)
--
-- Expected (checked against the dump):
--   Q1  resellers vs online          3,806 vs 27,659   d =  1.497   n_needed = 8
--   Q2  men vs women, online, US     4,776 vs  4,791   d = -0.030   n_needed = 16,967
--
-- THE JOIN THAT MATTERS: an order's CustomerID is NOT a person id. Gender sits in
-- Person_Person.Demographics, reached through Sales_Customer.PersonID:
--   SalesOrderHeader.CustomerID -> Sales_Customer.PersonID -> Person_Person.BusinessEntityID
-- Joining CustomerID straight to BusinessEntityID runs without an error and gives
-- every order a stranger's gender.


-- Q1: resellers (OnlineOrderFlag = 0) vs online (1) ----------------------------
WITH o AS (
  SELECT h.SalesOrderID, h.OnlineOrderFlag AS grp, LOG10(SUM(d.LineTotal)) AS lv
  FROM Sales_SalesOrderHeader h
  JOIN Sales_SalesOrderDetail d ON d.SalesOrderID = h.SalesOrderID
  GROUP BY h.SalesOrderID, h.OnlineOrderFlag
), s AS (
  SELECT grp, COUNT(*) AS n, AVG(lv) AS m, STDDEV_SAMP(lv) AS sd FROM o GROUP BY grp
), x AS (
  SELECT MAX(CASE WHEN grp = 0 THEN n  END) n1, MAX(CASE WHEN grp = 1 THEN n  END) n2,
         MAX(CASE WHEN grp = 0 THEN m  END) m1, MAX(CASE WHEN grp = 1 THEN m  END) m2,
         MAX(CASE WHEN grp = 0 THEN sd END) s1, MAX(CASE WHEN grp = 1 THEN sd END) s2
  FROM s
), e AS (
  SELECT n1, n2, (m1 - m2) / SQRT(((n1-1)*s1*s1 + (n2-1)*s2*s2) / (n1+n2-2)) AS d FROM x
)
SELECT 'resellers vs online' AS question, n1 AS n_group1, n2 AS n_group2,
       ROUND(d, 4) AS d, CEIL(2 * POW(1.959964 + 0.841621, 2) / POW(d, 2)) AS n_needed
FROM e;


-- Q2: men vs women, online orders of US customers -----------------------------
WITH o AS (
  SELECT h.SalesOrderID, h.CustomerID, LOG10(SUM(d.LineTotal)) AS lv
  FROM Sales_SalesOrderHeader h
  JOIN Sales_SalesOrderDetail d ON d.SalesOrderID = h.SalesOrderID
  JOIN Sales_SalesTerritory   t ON t.TerritoryID  = h.TerritoryID
  WHERE h.OnlineOrderFlag = 1 AND t.CountryRegionCode = 'US'
  GROUP BY h.SalesOrderID, h.CustomerID
), g AS (
  SELECT o.lv, ExtractValue(p.Demographics, '//Gender') AS grp
  FROM o
  JOIN Sales_Customer c ON c.CustomerID       = o.CustomerID
  JOIN Person_Person  p ON p.BusinessEntityID = c.PersonID
), s AS (
  SELECT grp, COUNT(*) AS n, AVG(lv) AS m, STDDEV_SAMP(lv) AS sd
  FROM g WHERE grp IN ('M', 'F') GROUP BY grp
), x AS (
  SELECT MAX(CASE WHEN grp = 'M' THEN n  END) n1, MAX(CASE WHEN grp = 'F' THEN n  END) n2,
         MAX(CASE WHEN grp = 'M' THEN m  END) m1, MAX(CASE WHEN grp = 'F' THEN m  END) m2,
         MAX(CASE WHEN grp = 'M' THEN sd END) s1, MAX(CASE WHEN grp = 'F' THEN sd END) s2
  FROM s
), e AS (
  SELECT n1, n2, (m1 - m2) / SQRT(((n1-1)*s1*s1 + (n2-1)*s2*s2) / (n1+n2-2)) AS d FROM x
)
SELECT 'men vs women, online, US' AS question, n1 AS n_group1, n2 AS n_group2,
       ROUND(d, 4) AS d, CEIL(2 * POW(1.959964 + 0.841621, 2) / POW(d, 2)) AS n_needed
FROM e;
-- Drop "AND t.CountryRegionCode = 'US'" to see all online customers:
-- 13,917 vs 13,742, d = -0.036, n_needed = 11,846 -- there the data would be enough.
