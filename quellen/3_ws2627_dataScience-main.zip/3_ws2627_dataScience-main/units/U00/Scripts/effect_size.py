"""
Unit 00 -- can this dataset answer this question at all?  (slide "Too Small to Find")

Reads straight from Adventureworks2019, like every first contact in this unit; the
password comes from the environment (export AWC_DB_PW='...'). effect_size.sql next
to this file asks the same two questions in MySQL Workbench.

Cohen's d, and the sample size a two-sample t-test would need, for two questions
asked of the SAME AWC data. The point of the slide: "31,465 orders" is neither
big nor small until you say what you are looking for.

THE JOIN THAT MATTERS. An order's CustomerID is not a person id. Gender sits in
Person_Person.Demographics, reached through Sales_Customer.PersonID. Joining
CustomerID straight to BusinessEntityID runs without an error and hands every
order a stranger's gender (an earlier version of this script did exactly that).

WHY THE LOG SCALE. On raw order values the two groups of question 1 have spreads
that differ by 22x (reseller sd 25,560 vs online sd 1,149). Cohen's d pools those
into one number, which assumes they are comparable -- so a raw-scale d there is
not interpretable, and drawing it as two equally wide bells would be a lie about
the data. On log10(order value) all four groups have sd ~0.88 decades and mild
skew, so the pooled d is meaningful and the picture on the slide is the real shape.

Verified output (recomputed from the dump):

  Q1  resellers vs online, order value
      raw:  n = 3,806 vs 27,659   sd 25,560 vs 1,149  (ratio 22.2x -- do not pool)
      log:  d = 1.4971   n needed per group =      8
  Q2  men vs women, order value (online customers in the US)
      log:  n = 4,776 vs 4,791    mean 2.395 vs 2.421   sd 0.881 vs 0.879
      log:  d = 0.0304   n needed per group = 16,967

So AWC answers Q1 with eight orders to spare and cannot answer Q2: we hold 9,567
relevant orders and would need about 34,000. No analysis fixes that; only
different data would. (Across all online customers, 13,917 vs 13,742, d = 0.036
needs 11,846 per group -- there the data would just suffice.)

n per group, two-sided two-sample t-test, alpha = 0.05, power = 0.80:
    n = 2 (z_{1-a/2} + z_{1-b})^2 / d^2       z = 1.95996, 0.84162
The textbook normal approximation -- close enough to make the point, and the
statistics module can do it properly later.
"""
import os
import sys
import xml.etree.ElementTree as ET
from urllib.parse import quote_plus

import numpy as np
import pandas as pd

NS = "{http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey}"
ZA, ZB = 1.959964, 0.841621

# One row per order: its value, channel, country, and -- through Sales_Customer.PersonID --
# the buyer's Demographics XML (NULL for reseller orders, which have no person).
ORDERS = """
SELECT h.SalesOrderID, SUM(d.LineTotal) AS value, h.OnlineOrderFlag AS online,
       t.CountryRegionCode AS country, p.Demographics AS demographics
FROM Sales_SalesOrderHeader h
JOIN Sales_SalesOrderDetail d ON d.SalesOrderID = h.SalesOrderID
JOIN Sales_SalesTerritory   t ON t.TerritoryID  = h.TerritoryID
JOIN Sales_Customer         c ON c.CustomerID   = h.CustomerID
LEFT JOIN Person_Person     p ON p.BusinessEntityID = c.PersonID
GROUP BY h.SalesOrderID, h.OnlineOrderFlag, t.CountryRegionCode, p.Demographics
"""


def cohens_d(a, b):
    """Pooled-SD standardised mean difference."""
    na, nb = len(a), len(b)
    sp = np.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    return (a.mean() - b.mean()) / sp


def n_per_group(d):
    return int(np.ceil(2 * (ZA + ZB) ** 2 / d ** 2))


def gender(blob):
    if not isinstance(blob, str):
        return ""
    try:
        return (ET.fromstring(blob).findtext(NS + "Gender") or "").strip()
    except ET.ParseError:
        return ""


def load_orders():
    from sqlalchemy import create_engine
    pw = os.environ.get("AWC_DB_PW")
    if not pw:
        sys.exit("AWC_DB_PW is not set. First run:  export AWC_DB_PW='...'")
    engine = create_engine(
        f"mysql+mysqlconnector://sqladmin:{quote_plus(pw)}@localhost/Adventureworks2019")
    orders = pd.read_sql(ORDERS, engine)
    orders["gender"] = orders.pop("demographics").map(gender)
    return orders


def main(orders=None):
    orders = load_orders() if orders is None else orders

    a, b = orders[orders.online == 0].value, orders[orders.online == 1].value
    print("Q1  resellers vs online, order value")
    print(f"    raw:  n = {len(a):,} vs {len(b):,}   sd {a.std(ddof=1):,.0f} vs "
          f"{b.std(ddof=1):,.0f}  (ratio {a.std(ddof=1)/b.std(ddof=1):.1f}x -- do not pool)")
    d1 = cohens_d(np.log10(a), np.log10(b))
    print(f"    log:  d = {d1:.4f}   n needed per group = {n_per_group(d1):,}")

    us = orders[(orders.online == 1) & (orders.country == "US")]
    m, w = np.log10(us[us.gender == "M"].value), np.log10(us[us.gender == "F"].value)
    print("Q2  men vs women, order value (online customers in the US)")
    print(f"    log:  n = {len(m):,} vs {len(w):,}    mean {m.mean():.3f} vs {w.mean():.3f}"
          f"   sd {m.std(ddof=1):.3f} vs {w.std(ddof=1):.3f}")
    d2 = cohens_d(m, w)
    print(f"    log:  d = {abs(d2):.4f}   n needed per group = {n_per_group(d2):,}")


if __name__ == "__main__":
    main()
