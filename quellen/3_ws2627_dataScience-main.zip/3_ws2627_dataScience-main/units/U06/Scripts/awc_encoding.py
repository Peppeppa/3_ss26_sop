"""
Unit 06 — turning a table into the matrix a model actually sees.

Runs on AWC/awc_flat.csv. Standard library only.

This is V14's feature-engineering material brought FORWARD, because U06 and U07
cannot compute a distance until the customer table is numeric and comparable.
Teaching similarity first and encoding later would be teaching the answer before
the question.

VERIFIED RESULT -- scaling is not cosmetic, it changes who your neighbours are.
All 19,119 customers of AWC/awc_flat.csv, three features (revenue, #orders,
#distinct products), every scaling fitted on ALL customers, Euclidean distance:

    rank of each customer as a neighbour of 29818 (Brakes and Gears)
                         raw   z   min-max   robust
        29715              1   1      1        1
        29722              2  13     15        2
        30117              3   2      4        3
        29614              4   3      3        4
        29639              5   4      2        5
        29617              7   5      5        7

    29722 has 118 products against 29818's 81: invisible raw, decisive once
    scaled. Robust scaling lets the products count too (IQR 2; revenue's IQR
    is 2,767): 29722's squared robust distance is 161.8 revenue + 342.2
    products = 504.0, just below 30117's 511.6 -- so it is 2nd again, by a hair.

    Raw squared-distance contributions, 29818 vs 29715 (the two biggest):
        revenue   540,935,154.6
        orders              0.0
        products            1.0

The mechanism: euclidean distance sums squared differences. Revenue differs
between customers by tens of thousands; order count differs by single digits.
Unscaled, the revenue term is ~10^8 and the order term is ~10^0, so the distance
IS the revenue difference and the other two features are decoration.
"""
import csv
import io
import math
import statistics
from collections import defaultdict
from pathlib import Path

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir()   # the canonical extract


def read(name):
    """Read the canonical extract (AWC/, from Adventureworks2019)."""
    with open(AWC / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


# ── encoding categoricals ───────────────────────────────────────────────────

def one_hot(values, categories):
    """NOMINAL categories: no order exists, so give each its own axis.

    Cost: one column per category. With 37 subcategories that is 37 columns of
    mostly zeros, and in that space every pair of distinct categories is exactly
    the same distance apart -- which is the honest representation of "no order".
    """
    index = {c: i for i, c in enumerate(categories)}
    vec = [0] * len(categories)
    for v in values:
        if v in index:
            vec[index[v]] = 1
    return vec


def ordinal(value, order):
    """ORDINAL categories: an order DOES exist, so one axis is enough.

    U04 met this as YearlyIncome stored as '0-25000', '25001-50000', ...
    One-hot would throw the ordering away; ordinal keeps it but asserts that the
    steps are equally sized, which is usually a lie you should record.
    """
    return order.index(value) if value in order else None


# ── scaling ─────────────────────────────────────────────────────────────────

def z_score(rows):
    """Centre and divide by standard deviation. Sensitive to outliers -- and U04
    found 6.8% of orders holding 70.9% of revenue, so those outliers inflate the
    standard deviation and squash everyone else toward zero."""
    cols = list(zip(*rows))
    mu = [statistics.mean(c) for c in cols]
    sd = [statistics.stdev(c) or 1.0 for c in cols]
    return [[(v - m) / s for v, m, s in zip(r, mu, sd)] for r in rows]


def min_max(rows):
    """Map to [0,1]. Bounded, but a single extreme value compresses everything
    else into a narrow band near zero."""
    cols = list(zip(*rows))
    lo = [min(c) for c in cols]
    hi = [max(c) for c in cols]
    return [[(v - l) / (h - l) if h > l else 0.0 for v, l, h in zip(r, lo, hi)] for r in rows]


def robust(rows):
    """Subtract the median, divide by the IQR -- the U04 tools. Not a cure-all:
    a variable whose IQR is small next to its tail still dominates."""
    cols = list(zip(*rows))
    med = [statistics.median(c) for c in cols]
    iqr = []
    for c in cols:
        q = statistics.quantiles(c, n=4, method="inclusive")
        iqr.append((q[2] - q[0]) or 1.0)
    return [[(v - m) / i for v, m, i in zip(r, med, iqr)] for r in rows]


def customer_table():
    revenue, orders, products = defaultdict(float), defaultdict(set), defaultdict(set)
    for r in read("awc_flat.csv"):
        c = r["CustomerID"]
        revenue[c] += float(r["LineTotal"])
        orders[c].add(r["SalesOrderID"])
        products[c].add(r["ProductID"])
    return {c: [revenue[c], float(len(orders[c])), float(len(products[c]))] for c in revenue}


if __name__ == "__main__":
    print("=" * 74)
    print("1. ENCODING: the same category column, two defensible representations")
    categories = ["Accessories", "Bikes", "Clothing", "Components"]
    print(f"   nominal, one-hot  ({len(categories)} columns):")
    print(f"     bought Bikes + Components -> {one_hot(['Bikes', 'Components'], categories)}")
    print("   ordinal, single column:")
    bands = ["0-25000", "25001-50000", "50001-75000", "75001-100000", "greater than 100000"]
    for b in bands[:3] + bands[-1:]:
        print(f"     {b:<22} -> {ordinal(b, bands)}")
    print("   ordinal asserts the steps are EQUAL. Band 4 is not 'twice' band 2.")
    print("   If that assertion is wrong, use the band midpoints instead - and say so.")

    print("\n" + "=" * 74)
    print("2. SCALING: why euclidean distance is meaningless without it")
    table = customer_table()
    top = sorted(table, key=lambda c: -table[c][0])[:6]
    ref = top[0]

    print(f"   {'cust':>6}{'revenue':>12}{'orders':>8}{'products':>10}")
    for c in top:
        print(f"   {c:>6}{table[c][0]:>12,.0f}{table[c][1]:>8.0f}{table[c][2]:>10.0f}")

    print(f"\n   contribution of each feature to the raw squared distance, {ref} vs {top[1]}:")
    for name, i in [("revenue", 0), ("orders", 1), ("products", 2)]:
        diff = (table[ref][i] - table[top[1]][i]) ** 2
        print(f"     {name:<10} {diff:>18,.1f}")
    print("   -> revenue contributes ~10^8, the other two ~10^0. Unscaled, the")
    print("      'three-feature' distance is a revenue comparison in disguise.")

    ids = list(table)
    rows = [table[c] for c in ids]
    variants = {"raw": rows, "z": z_score(rows), "min-max": min_max(rows),
                "robust": robust(rows)}
    ranks = {}
    for label, vecs in variants.items():
        r = vecs[ids.index(ref)]
        order = sorted(range(len(ids)), key=lambda k: math.dist(r, vecs[k]))
        ranks[label] = {ids[k]: pos for pos, k in enumerate(order)}   # ref itself = 0
    shown = sorted({c for lab in ranks for c, pos in ranks[lab].items() if 1 <= pos <= 5},
                   key=lambda c: ranks["raw"][c])
    print(f"\n   rank as a neighbour of {ref} among all {len(ids):,} customers"
          " (each scaling fitted on all of them):")
    print(f"     {'cust':>6}" + "".join(f"{lab:>9}" for lab in variants))
    for c in shown:
        print(f"     {c:>6}" + "".join(f"{ranks[lab][c]:>9}" for lab in variants))
    print("\n   Same customers, same three features, same distance function.")
    print("   The only thing that changed was the units. Scaling is a MODELLING")
    print("   decision, and it belongs in the cleaning log with a reason.")
