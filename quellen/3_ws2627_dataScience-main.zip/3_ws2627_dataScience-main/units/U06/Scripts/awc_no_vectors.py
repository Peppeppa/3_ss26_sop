"""
Unit 06 — two measures that need no vector space at all.

DTW for time series, edit distance for strings.
Standard library only. All numbers below verified by running this file.

--- DTW -----------------------------------------------------------------------
On the real AWC monthly series of the four top-revenue resellers, in U05's
business months: awc_flat.csv comes from the database, and U05 showed that the
database's calendar months are the business months, so no shift is needed.
38 months, May 2011 - Jun 2014:

    two rhythms, every three months, one month apart:
      Brakes and Gears (29818), Totes & Baskets (30117)     Jun, Sep, Dec, Mar
      Excellent Riding (29715), Vigorous Exercise (29722)   Jul, Oct, Jan, Apr
    Brakes and Gears and Excellent Riding never order in the same month.

    closest pair by euclidean : Brakes and Gears + Totes & Baskets   (same months)
    closest pair by DTW       : Excellent Riding + Totes & Baskets   (one month apart)

Euclidean asks WHEN; DTW treats the shift as free and compares the pattern.

Synthetic proof of the same property:
    identical           euclid =   0.0   DTW =   0.0
    shifted by 1 step   euclid = 200.0   DTW =   0.0      <- identity axiom broken
(DTW sums |differences|, Euclidean is a root of squares: compare each measure
with itself, never the two numbers with each other.)

--- Edit distance -------------------------------------------------------------
Normalised = Levenshtein / length of the longer string.

    made-up spelling variants (same thing, to be merged):
      'Wuerzburg' vs 'Wurzburg'   0.11        'Mueller' vs 'Muller'   0.14
    U04's 14 candidate groups (same surname + first initial, VL_4_DS/Data/
    customers.csv) = 18 pairs of DIFFERENT people, from
      'Linda Gonzales' vs 'Lynn Gonzales'   0.21   (the closest)
    to 0.58. U04 inspected them and merged none.

So a threshold that merges the variants and none of U04's pairs must sit
between 0.14 and 0.21 -- a window 0.07 wide, on this dataset only. That is the
whole fuzzy-matching problem, and why U04 refused to merge automatically.
"""
import csv
import datetime
import io
import itertools
import math
from collections import defaultdict
from pathlib import Path

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir()   # the canonical extract
# Names and types: the repo's AWC/ copy, else the one the unit kit ships in Data/.
CUSTOMERS = next((p for p in (AWC / "awc_customers.csv",
                              Path(__file__).resolve().parents[1] / "Data" / "awc_customers.csv")
                  if p.exists()), AWC / "awc_customers.csv")


# ── DTW ─────────────────────────────────────────────────────────────────────

def dtw(a, b):
    """Cheapest monotone alignment of two sequences, by dynamic programming.

    D[i][j] = cost of aligning a[:i] with b[:j]. Each step may consume one
    element of a, one of b, or one of each -- which is exactly the freedom that
    lets DTW absorb a time shift. Cost O(n*m); the classic speed-ups (Sakoe-Chiba
    band, lower bounds) restrict how far the path may stray from the diagonal.
    """
    n, m = len(a), len(b)
    inf = float("inf")
    D = [[inf] * (m + 1) for _ in range(n + 1)]
    D[0][0] = 0.0
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            D[i][j] = abs(a[i - 1] - b[j - 1]) + min(D[i - 1][j], D[i][j - 1], D[i - 1][j - 1])
    return D[n][m]


def monthly_series():
    """Per-customer monthly revenue, using U05's business-month correction."""
    raw = (AWC / "awc_flat.csv").read_bytes().replace(b"\r", b"\n")
    series, revenue = defaultdict(lambda: defaultdict(float)), defaultdict(float)
    for r in csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))):
        d = datetime.date.fromisoformat(r["OrderDate"])   # daily dates: no shift needed
        value = float(r["LineTotal"])
        series[r["CustomerID"]][(d.year, d.month)] += value
        revenue[r["CustomerID"]] += value
    months = sorted({k for s in series.values() for k in s})
    return {c: [series[c].get(m, 0.0) for m in months] for c in series}, months, revenue


# ── edit distance ───────────────────────────────────────────────────────────

def levenshtein(a, b):
    """Minimum single-character insertions, deletions and substitutions."""
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


VARIANTS = [("Wuerzburg", "Wurzburg"), ("Mueller", "Muller")]   # made up
U04 = Path(__file__).resolve().parents[2] / "VL_4_DS" / "Data" / "customers.csv"


def normalised_edit(a, b):
    return levenshtein(a, b) / max(len(a), len(b))


def u04_name_pairs():
    """U04's fuzzy-duplicate candidates: same surname + same first initial.
    customers.csv is cp1252, not UTF-8 (U04's finding)."""
    raw = U04.read_bytes().replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    rows = csv.DictReader(io.StringIO(raw.decode("cp1252")))
    norm = lambda s: "".join(ch for ch in s.lower() if "a" <= ch <= "z")
    groups = defaultdict(set)
    for r in rows:
        groups[(norm(r["LastName"]), norm(r["FirstName"])[:1])].add(r["FullName"])
    near = [sorted(v) for v in groups.values() if len(v) > 1]
    pairs = [(a, b) for names in near for a, b in itertools.combinations(names, 2)]
    return near, sorted(pairs, key=lambda p: normalised_edit(*p))


if __name__ == "__main__":
    print("=" * 74)
    print("DTW on the real AWC customer series")
    vectors, months, revenue = monthly_series()
    top = sorted(revenue, key=lambda c: -revenue[c])[:4]
    print(f"  {len(months)}-month index. Active months per customer (revenue/1000):")
    names = {r["CustomerID"]: r["CustomerName"] for r in csv.DictReader(
        CUSTOMERS.open(encoding="utf-8"))}
    mon = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()
    for c in top:
        active = [mon[months[i][1] - 1] for i, v in enumerate(vectors[c]) if v > 0]
        print(f"    {c} {names[c]:<27}: {', '.join(active[:4])} ... "
              + " ".join(f"{v / 1000:.0f}" for v in vectors[c][:12]))

    scores = {}
    print(f"\n  {'pair':>13}{'euclidean':>13}{'DTW':>13}")
    for a, b in itertools.combinations(top, 2):
        e, d = math.dist(vectors[a], vectors[b]), dtw(vectors[a], vectors[b])
        scores[(a, b)] = (e, d)
        print(f"  {a}-{b:>7}{e:>13,.0f}{d:>13,.0f}")
    by_e = min(scores, key=lambda k: scores[k][0])
    by_d = min(scores, key=lambda k: scores[k][1])
    print(f"\n  closest by euclidean: {by_e}")
    print(f"  closest by DTW      : {by_d}      same? {by_e == by_d}")

    print("\n  the defining property, on a clean synthetic example:")
    base = [0, 0, 100, 200, 100, 0, 0, 0]
    for label, other in [("identical", base),
                         ("shifted by 1", [0, 0, 0, 100, 200, 100, 0, 0])]:
        print(f"    {label:<14} euclid={math.dist(base, other):>7.1f}   dtw={dtw(base, other):>7.1f}")

    print("\n" + "=" * 74)
    print("Edit distance — and U04's fuzzy-duplicate threshold problem")
    for a, b in VARIANTS:
        print(f"  made up  {a!r:<18} vs {b!r:<18} {normalised_edit(a, b):.2f}")
    if not U04.exists():     # the unit zips travel one by one
        print(f"  U04's customers.csv not found at {U04} -- the U04 pairs are skipped.")
    else:
        groups, pairs = u04_name_pairs()
        print(f"  U04: {len(groups)} candidate groups = {len(pairs)} pairs of different people")
        for a, b in pairs[:3] + pairs[-1:]:
            print(f"           {a!r:<18} vs {b!r:<18} {normalised_edit(a, b):.2f}")
        lo = max(normalised_edit(*v) for v in VARIANTS)
        hi = normalised_edit(*pairs[0])
        print(f"  -> a threshold must lie between {lo:.2f} and {hi:.2f}: {hi - lo:.2f} wide.")
