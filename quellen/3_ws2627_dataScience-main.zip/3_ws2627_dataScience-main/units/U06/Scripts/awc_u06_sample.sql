-- ─────────────────────────────────────────────────────────────────────────────
-- U06 — your 40 customers: 20 resellers and 20 individuals who ordered, each
-- with its type, its name and a Label that starts with the type.
--
--   KNIME:  paste into a DB Query Reader (after the MySQL Connector)
--   shell:  mysql -u sqladmin -p Adventureworks2019 < awc_u06_sample.sql
--
-- Change the seed 6 (twice) to your group number: same seed, same 40.
-- One row per sample customer. The Label ("R 29893 Weekend Bike Tours",
-- "I 20186 Connor Li") becomes the RowID later: sorting by it puts all
-- individuals before all resellers, and the ID keeps it unique, because some
-- store names occur more than once.
-- ─────────────────────────────────────────────────────────────────────────────

(SELECT c.CustomerID,
        'reseller'                              AS CustomerType,
        st.Name                                 AS CustomerName,
        CONCAT('R ', c.CustomerID, ' ', st.Name) AS Label
 FROM Sales_Customer c
 JOIN Sales_Store st ON st.BusinessEntityID = c.StoreID
 WHERE EXISTS (SELECT 1 FROM Sales_SalesOrderHeader h WHERE h.CustomerID = c.CustomerID)
 ORDER BY RAND(6)
 LIMIT 20)
UNION ALL
(SELECT c.CustomerID,
        'individual',
        CONCAT(pp.FirstName, ' ', pp.LastName),
        CONCAT('I ', c.CustomerID, ' ', pp.FirstName, ' ', pp.LastName)
 FROM Sales_Customer c
 JOIN Person_Person pp ON pp.BusinessEntityID = c.PersonID
 WHERE c.StoreID IS NULL
   AND EXISTS (SELECT 1 FROM Sales_SalesOrderHeader h WHERE h.CustomerID = c.CustomerID)
 ORDER BY RAND(6)
 LIMIT 20);
