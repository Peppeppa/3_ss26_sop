"""
Unit 06 -- the same six resellers, three measures, and who is most like
Brakes and Gears (29818), the reseller with the highest revenue.

Runs on ../../AWC/awc_flat.csv and awc_customers.csv. Standard library only.

VERIFIED RESULT (reproduce with: python3 awc_similarity.py):

  euclidean  revenue, #orders, #products; z-scored, FITTED ON ALL 19,119
             customers (as on the scaling slide) -> Excellent Riding Supplies
  jaccard    the set of products bought          -> Vigorous Exercise Company
  cosine     the category revenue shares         -> no real answer: three
             resellers at 0.99992 / 0.99983 / 0.99982

  The two real answers are opposite: Excellent Riding Supplies is Euclidean's
  nearest and Jaccard's last (0.038), Vigorous Exercise is Jaccard's first
  (0.605) and Euclidean's last.

  Why: Brakes and Gears and Excellent Riding Supplies have nearly identical
  aggregates (877k vs 854k revenue, 12 orders each, 81 vs 82 products) but not
  one bike model in common -- 32 mountain bikes against 43 road bikes; they
  share 6 of 157 products. All 27 bike models of Vigorous Exercise are among
  Brakes and Gears' 32.
"""
import csv
import io
import itertools
import math
import statistics
from collections import defaultdict
from pathlib import Path

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir()   # the canonical extract
# Names and types: the repo's AWC/ copy, else the one the unit kit ships in Data/.
CUSTOMERS = next((p for p in (AWC / "awc_customers.csv",
                              Path(__file__).resolve().parents[1] / "Data" / "awc_customers.csv")
                  if p.exists()), AWC / "awc_customers.csv")


def read(name):
    """Read the canonical extract (AWC/, from Adventureworks2019)."""
    with open(AWC / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def product_to_category():
    """The flat table already carries Category on every line."""
    rows = read("awc_flat.csv")
    p2c = {r["ProductID"]: (r["Category"] or "?") for r in rows}
    return p2c, sorted({c for c in p2c.values() if c != "?"})


def customer_features():
    """Three different VIEWS of the same customer. Each one implies a measure."""
    p2c, categories = product_to_category()
    revenue, orders, products = defaultdict(float), defaultdict(set), defaultdict(set)
    cat_revenue = defaultdict(lambda: defaultdict(float))
    for r in read("awc_flat.csv"):
        c, value = r["CustomerID"], float(r["LineTotal"])
        revenue[c] += value
        orders[c].add(r["SalesOrderID"])
        products[c].add(r["ProductID"])
        cat_revenue[c][p2c.get(r["ProductID"], "?")] += value

    feats = {}
    for c in revenue:
        profile = [cat_revenue[c].get(k, 0.0) for k in categories]
        total = sum(profile) or 1.0
        feats[c] = {
            "numeric": [revenue[c], len(orders[c]), len(products[c])],  # -> euclidean
            "profile": [p / total for p in profile],                    # -> cosine
            "products": products[c],                                    # -> jaccard
            "revenue": revenue[c],
        }
    return feats, categories


# ── the three measures ──────────────────────────────────────────────────────

def euclidean(a, b):
    """Scale-DEPENDENT. Revenue in the tens of thousands will drown a count of 12
    unless every feature is standardised first. Forgetting that is the single most
    common mistake with this measure."""
    return math.dist(a, b)


def cosine(a, b):
    """Measures the ANGLE, not the magnitude. A customer who buys the same mix at
    a tenth of the volume is identical under cosine. Sometimes exactly right."""
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return sum(x * y for x, y in zip(a, b)) / (na * nb) if na and nb else 0.0


def jaccard(a, b):
    """|A and B| / |A or B|. Needs no vector space at all -- just sets. Note it
    cannot see quantity: buying one helmet and buying fifty is the same element."""
    union = a | b
    return len(a & b) / len(union) if union else 0.0


def standardise(rows):
    """z-score each column. Without this, euclidean() is a revenue comparison
    wearing a three-dimensional costume."""
    cols = list(zip(*rows))
    mu = [statistics.mean(c) for c in cols]
    sd = [statistics.stdev(c) or 1.0 for c in cols]
    return [[(v - m) / s for v, m, s in zip(row, mu, sd)] for row in rows]


if __name__ == "__main__":
    feats, categories = customer_features()
    print(f"{len(feats)} customers, categories: {categories}\n")

    top = sorted(feats, key=lambda c: -feats[c]["revenue"])[:6]
    print(f"{'cust':>6}{'revenue':>12}{'orders':>8}{'products':>10}  category profile")
    for c in top:
        f = feats[c]
        print(f"{c:>6}{f['revenue']:>12,.0f}{f['numeric'][1]:>8.0f}{f['numeric'][2]:>10.0f}  "
              + "  ".join(f"{k[:4]}={v:.2f}" for k, v in zip(categories, f["profile"])))

    # fitted on ALL customers, not on the six: the six alone have sd(#orders) = 0
    everyone = list(feats)
    z = dict(zip(everyone, standardise([feats[c]["numeric"] for c in everyone])))
    names = {r["CustomerID"]: r["CustomerName"] for r in csv.DictReader(CUSTOMERS.open(encoding="utf-8"))}
    ref = top[0]

    print(f"\nmost similar to {names[ref]} ({ref})?")
    print(f"{'cust':>6}  {'reseller':<28}{'euclidean':>10}{'cosine':>10}{'jaccard':>10}")
    scores = {}
    for c in top[1:]:
        scores[c] = (euclidean(z[ref], z[c]),
                     cosine(feats[ref]["profile"], feats[c]["profile"]),
                     jaccard(feats[ref]["products"], feats[c]["products"]))
        print(f"{c:>6}  {names[c]:<28}{scores[c][0]:>10.3f}{scores[c][1]:>10.6f}{scores[c][2]:>10.3f}")

    rankings = {
        "euclidean (nearest first)": sorted(scores, key=lambda c: scores[c][0]),
        "cosine    (most similar) ": sorted(scores, key=lambda c: -scores[c][1]),
        "jaccard   (most similar) ": sorted(scores, key=lambda c: -scores[c][2]),
    }
    print()
    for label, order in rankings.items():
        print(f"  {label}: {order}")
    print("\n  Euclidean and Jaccard give OPPOSITE answers. Cosine cannot choose:")
    print("  on a 4-category profile where everyone is ~90% Bikes, three resellers")
    print("  differ only in the 4th decimal. A measure is only as discriminating as")
    print("  the features you feed it.")
