"""
Unit 06 — the normalisation progression, on AWC's own customers.

    python3 awc_u06_scaling.py    -> ../Images/fig_u06_scaling{,_de}.pdf

Three panels on the same customers:

    raw          revenue (currency) vs. #distinct products (a count)
    the axis     what the revenue axis actually looks like, on a log scale
    z-scored     each axis divided by its own standard deviation

Panels 1 and 3 are drawn with an EQUAL aspect ratio -- one unit right is as long
as one unit up -- because that is what a Euclidean distance sees. On the raw
axes the #products direction has no measurable extent, so the cloud is a
horizontal line and a distance there is a revenue comparison. Auto-scaled axes
would hide exactly the effect the slide claims.

The middle panel shows revenue on a log scale, not a mean-centred cloud:
centring shifts the cloud by the mean, 5,745, on an axis spanning 877,106 --
0.66 %, about six pixels, so a centred panel looks exactly like the raw one.
The mean of this variable sits at the 89.6th percentile (median 549, mean
5,745, max 877,107): nowhere near the middle, and on a linear axis the whole
distribution is one bar. Source: AWC/awc_flat.csv, so the numbers agree with
awc_encoding.py.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir() / "awc_flat.csv"
IMG = Path(__file__).resolve().parent.parent / "Images"
BLUE, ORANGE, GREY = "#2A78D6", "#EB6834", "#8A8A8A"
MARKED = [29818, 29715, 29722]
STR = {
    "en": dict(raw="raw", centred="revenue, log scale", z="z-scored",
               revraw="revenue (currency)", revc=r"revenue $-\ \mu$",
               revz=r"(revenue $-\ \mu)\,/\,\sigma$",
               prod="#products", prodc=r"#products $-\ \mu$",
               prodz=r"(#products $-\ \mu)\,/\,\sigma$",
               mean="mean", median="median", count="customers",
               band="every customer within a\n{n}-unit band",
               cap="same customers, same Euclidean distance, equal aspect in all three panels"),
    "de": dict(raw="roh", centred="Umsatz, log-Skala", z="z-standardisiert",
               revraw="Umsatz (Währung)", revc=r"Umsatz $-\ \mu$",
               revz=r"(Umsatz $-\ \mu)\,/\,\sigma$",
               prod="#Produkte", prodc=r"#Produkte $-\ \mu$",
               prodz=r"(#Produkte $-\ \mu)\,/\,\sigma$",
               mean="Mittelwert", median="Median", count="Kunden",
               band="jeder Kunde in einem Band\nvon {n} Einheiten",
               cap="dieselben Kunden, dieselbe euklidische Distanz, gleiches Seitenverhältnis in allen drei Panels"),
}
plt.rcParams.update({"font.size": 8, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.02})


def thousands(v, _pos):
    if v == 0:
        return "0"
    return f"{v/1000:,.0f}k" if abs(v) >= 1000 else f"{v:,.0f}"


def customers():
    """revenue and #distinct products per customer, all of them."""
    df = pd.read_csv(AWC, usecols=["CustomerID", "LineTotal", "ProductID"])
    g = df.groupby("CustomerID")
    return pd.DataFrame({"revenue": g["LineTotal"].sum(),
                         "products": g["ProductID"].nunique().astype(float)})


def panel(ax, x, y, idx, half, s, title, xlab, ylab, cx=None, cy=None):
    """One square window of half-width `half`, centred on (cx, cy) or the mean."""
    mx, my = x.mean(), y.mean()
    cx = mx if cx is None else cx
    cy = my if cy is None else cy
    ax.scatter(x, y, s=3.5, c=GREY, alpha=0.30, linewidths=0)
    ax.scatter(x[idx], y[idx], s=18, c=BLUE, zorder=3, linewidths=0)
    ax.plot(mx, my, marker="+", ms=12, mew=1.8, c=ORANGE, zorder=4)
    ax.annotate(s["mean"], (mx, my), textcoords="offset points",
                xytext=(7, -12), color=ORANGE, fontsize=7)
    ax.set_xlim(cx - half, cx + half)
    ax.set_ylim(cy - half, cy + half)
    ax.set_aspect("equal")
    ax.set_title(title, fontsize=8, pad=3)
    ax.set_xlabel(xlab, fontsize=7, labelpad=2)
    ax.set_ylabel(ylab, fontsize=7, labelpad=2)
    ax.tick_params(labelsize=6, pad=1.5)
    ax.locator_params(axis="y", nbins=4)
    ax.locator_params(axis="x", nbins=5)


def spread(ax, rev, s):
    """The revenue axis on its own, log-binned, with median and mean marked.
    A linear histogram of this variable is a single bar at the left edge."""
    bins = np.logspace(np.log10(max(rev.min(), 1e-2)), np.log10(rev.max()), 34)
    ax.hist(rev, bins=bins, color=GREY, alpha=0.55, linewidth=0)
    ax.set_xscale("log")
    for v, c, lab, dy in ((np.median(rev), BLUE, s["median"], 1.0),
                          (rev.mean(), ORANGE, s["mean"], 0.86)):
        ax.axvline(v, color=c, lw=1.2)
        ax.annotate(f"{lab} {v:,.0f}", xy=(v, 0), xytext=(0.03, dy),
                    textcoords="axes fraction", color=c, fontsize=5.6,
                    va="top", ha="left")
    ax.set_xlabel(STR_X, fontsize=7, labelpad=2)
    ax.set_ylabel(s["count"], fontsize=7, labelpad=2)
    ax.tick_params(labelsize=6, pad=1.5)
    ax.locator_params(axis="y", nbins=4)


def build(lang, c):
    s = STR[lang]
    rev, prod = c["revenue"].to_numpy(), c["products"].to_numpy()
    idx = [c.index.get_loc(m) for m in MARKED if m in c.index]
    # the window spans the whole revenue range, so every customer is in frame;
    # equal aspect then makes the #products extent what it really is: a line
    half = 0.55 * (rev.max() - rev.min())
    mid = 0.5 * (rev.max() + rev.min())

    fig, axes = plt.subplots(1, 3, figsize=(5.6, 1.62))
    panel(axes[0], rev, prod, idx, half, s, s["raw"], s["revraw"], s["prod"],
          cx=mid, cy=prod.mean())
    global STR_X
    STR_X = s["revraw"]
    spread(axes[1], rev, s)
    axes[1].set_title(s["centred"], fontsize=8, pad=3)
    axes[1].spines[["top", "right"]].set_visible(False)
    axes[0].annotate(s["band"].format(n=int(np.ptp(prod))),
                     xy=(mid, prod.mean()), xytext=(0.56, 0.82),
                     textcoords="axes fraction", ha="center", fontsize=5.6,
                     color=BLUE,
                     arrowprops=dict(arrowstyle="->", color=BLUE, lw=0.8))
    panel(axes[2], (rev - rev.mean()) / rev.std(),
          (prod - prod.mean()) / prod.std(), idx, 3.0, s, s["z"], s["revz"],
          s["prodz"])
    # "200k" instead of a 1e5 offset box, which collides with the axis label
    for ax in axes[:1]:
        for axis in (ax.xaxis, ax.yaxis):
            axis.set_major_formatter(matplotlib.ticker.FuncFormatter(thousands))
    fig.tight_layout(w_pad=0.9, pad=0.4)
    p = IMG / ("fig_u06_scaling.pdf" if lang == "en" else "fig_u06_scaling_de.pdf")
    fig.savefig(p)
    plt.close(fig)
    return p


if __name__ == "__main__":
    c = customers()
    print(f"{len(c):,} customers, revenue sd {c.revenue.std():,.0f}, "
          f"products sd {c['products'].std():.2f} "
          f"-> the raw axes differ by a factor of {c.revenue.std()/c['products'].std():,.0f}")
    for lang in ("en", "de"):
        print("  wrote", build(lang, c).name)
