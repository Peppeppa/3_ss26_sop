---
source_id: DS-U06-L-EN
original_file: Unit06_DS_en.pdf
source_type: lecture
language: en
page_count: 38
source_sha256: 2cd5d41f1969725e3b26017b803309824d141b1135c5acb661a969cb1d8686ec
verification: partial
---
# Unit06_DS_en

[Original PDF](../../../quellen/Unit06_DS_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit06_DS_en.pdf#page=1)

~~~~text
Data Science

FEATURES, SIMILARITY &
DISTANCE


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit06_DS_en.pdf#page=2)

~~~~text
                                                                LEARNING GOALS


    • Explain why methods that compare rows see only the dissimilarities between them —
      and what that means for the table you build
    • Encode categories, scale numbers, and show how scaling changes who is a neighbour
    • State the metric axioms and what they buy you
    • Compute Euclidean, cosine and Jaccard, and explain in business terms why they
      disagree
    • Compare time series and strings directly: DTW and edit distance
    • Read a sorted dissimilarity matrix as a picture: which groups does a measure see?
    • Decide when a learned embedding — word2vec, an LLM — is the right tool, and what
      using one obliges you to record


2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit06_DS_en.pdf#page=3)

~~~~text
                                                       THE QUESTION OF THIS UNIT


        Many methods compare records: customers, products, time series, names.
                 When are two records “similar” — and who decides?


                    Matrix              Measure      Without vectors         Learned

                                                  Euclidean: Excellent Riding Supplies
                    Example: which of
                  AWC’s six top-revenue
                                                  Jaccard: Vigorous Exercise Company
                   resellers is most like
                    Brakes and Gears?
                                                        Cosine: no clear winner


    The three measures are explained in step 2. Steps 1–2 are the standard route for tables;
    steps 3–4 are for data without ﬁxed columns: series, names, text.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit06_DS_en.pdf#page=4)

~~~~text
                                                 WHY THIS MATTERS AT WORK


        Recommend               Deduplicate               Search                  Detect

     Marketing wants        The CRM has the         A shop or a help        A payment is far
     customers like         same customer           desk ﬁnds the           from all normal
     its best ones: a       twice, typed            products or texts       ones: check it for
     lookalike campaign.    differently (U04).      closest to a query.     fraud.



    Tools: scikit-learn pairwise_distances, KNIME Distance Matrix nodes, vector databases
    (e.g. PostgreSQL with pgvector) for search.

    In every case someone chose a measure
    If it is the wrong one, the result looks just as convincing — no error message.

4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit06_DS_en.pdf#page=5)

~~~~text
             STEP 1: BUILD THE MATRIX


    Matrix       Measure   Without vectors   Learned




5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit06_DS_en.pdf#page=6)

~~~~text
                                                     FROM TABLE TO DISSIMILARITIES

    Many methods work only on dissimilarities (how unlike two rows are) — nearest neighbours, many
    clustering methods, 2-D pictures of the data (U07):

                                      step 1:                                 step 2:
                 your table        encode, scale           X             choose a measure
                                                                                                       D
               City | Category |                   a matrix of numbers                   dissimilarities between rows
               revenue | #orders                   n rows × p features                              n×n




                                        dropped here: column names, types, this is all the method ever sees
                                            units, your documentation



    So the two arrows decide what “similar” means
    Change the encoding, the scaling or the measure, and every neighbour and cluster can
    change — with no error message.


6                Matrix                       Measure                       Without vectors                   Learned
~~~~

### DS-U06-L-EN-P006-D01 — Rekonstruktion

```mermaid
flowchart LR
 A[Table] -->|encode, scale| X[X: n × p features]
 X -->|choose measure| D[D: n × n dissimilarities]
```
Names, types, units and documentation are lost at encoding.

## Page 007

[Original page 7](../../../quellen/Unit06_DS_en.pdf#page=7)

~~~~text
                        ENCODING CATEGORIES: NOMINAL AND ORDINAL

    Nominal — no order. One-hot: one column per              Ordinal — the order is real. U03 met
    category, one 1 per row (four real AWC                   YearlyIncome as text in the Demographics
    products):                                               XML:
         product     Accessories Bikes Clothing Components   band (text)                     code    midpoint
    Minipump             1         0      0         0
                                                             ’0-25000’                          0     12,500
    Road-650 Red, 48     0         1      0         0
                                                             ’25001-50000’                      1     37,500
    AWC Logo Cap         0         0      1         0
                                                             ’50001-75000’                      2     62,500
    Chain                0         0      0         1
                                                             ’75001-100000’                     3     87,500
     • + all categories equally far apart: honest            ’greater than 100000’              4          ?
       “no order”
     • − 37 subcategories ⇒ 37 mostly-zero                   The real decision: the top band
       columns
     • − a category seen only in new data has no             Bands 0–3: codes and midpoints are equally
       column                                                spaced, so after scaling the differences are the
                                                             same. The top band has no end, so no midpoint:
                                                             any number is an assumption. Log it.

7                   Matrix                    Measure              Without vectors       Learned
~~~~

## Page 008

[Original page 8](../../../quellen/Unit06_DS_en.pdf#page=8)

~~~~text
                                                                                                   SCALING: NOT COSMETIC

                                          raw                                         revenue, log scale                                         z-scored
                                   every customer within a               2000 median 549
                                        117-unit band                                                                                   2




                                                                                                                 (#products − μ) / σ
                                                                                 mean 5,745
                         250k




                                                             customers
             #products
                            0                                            1000                                                           0
                                   mean                                                                                                                 mean
                         -250k
                                                                                                                                       −2
                                                                            0
                                 0 200k 400k 600k 800k                          100      102     104       106                              −2      0       2
                                  revenue (currency)                                  revenue (currency)                                    (revenue − μ) / σ

    Without scaling, distance = revenue
    Euclidean distance adds up squared differences. Brakes and Gears vs Excellent Riding Supplies, the
    two biggest customers: revenue differs by 23,258, squared about 541 million; #products differs by 1,
    squared 1. Dividing by the standard deviation σ gives every feature a say (panel 3).

    Real AWC: all 19,119 customers. #products = number of different products a customer bought. Revenue is
    skewed: mean 5,745, median 549 (panel 2) — a few huge customers.
8                          Matrix                              Measure                                 Without vectors                                  Learned
~~~~

## Page 009

[Original page 9](../../../quellen/Unit06_DS_en.pdf#page=9)

~~~~text
                       MEASURED: SCALING REORDERS YOUR NEIGHBOURS

    Rank of each reseller as a neighbour of Brakes and Gears (877,107 revenue, 81 products), raw and
    under three scalings:
    reseller                               revenue    #products raw      z: x−µ
                                                                             σ
                                                                                            x−min
                                                                                  min–max: max − min
                                                                                                         robust: x−med
                                                                                                                  IQR

    Excellent Riding Supplies              853,849            82    1       1               1                  1
    Vigorous Exercise Company              841,909           118    2      13              15                  2
    Totes & Baskets Company                816,756            93    3       2               4                  3
    Retail Mall                            799,278            91    4       3               3                  4
    Corner Bicycle Supply                  787,773            88    5       4               2                  5
    Thorough Parts & Repair Services       740,986            84    7       5               5                  7


    Vigorous Exercise: 2nd nearest, or 15th?
    Raw, only revenue counts: its 37 extra products are invisible. Huge customers make revenue’s σ
    large, so z shrinks revenue and #products wins: 13th (min–max: 15th). Robust divides by the small
    IQR (2,767): revenue counts again, 2nd. Log your choice and one you rejected.

    Real AWC, all 19,119 customers; features revenue, #orders (12 for all six), #products; ﬁtted on all; µ = mean.

9                   Matrix                    Measure                   Without vectors           Learned
~~~~

## Page 010

[Original page 10](../../../quellen/Unit06_DS_en.pdf#page=10)

~~~~text
                                THE SAME STEPS IN KNIME, ON ANOTHER AWC TABLE

                                                                                                           String to Date&Time                                                                     Date&Time Difference
                 DB Connector    DB Query Reader              String Manipulation                              (deprecated)      String Replacer      Cell Splitter        String to Number            (deprecated)




                                                              Clean_Date_String                               Proper dates        Clean_salary     Split_Income_Range       Numeric_Cols             Simplify_Birthdate
                                                                                    String Manipulation


                                   Excel Writer                                                                                                                                                                    Scatter Plot (JavaScript)
                                                                                                                                                                                                                           (legacy)
                                                                                    Regex_with_variables



                                       One to Many
                                                                                                Normalizer (Apply)               Column Filter           Row Sampler          t-SNE (L. Jonsson)   Color Manager



                                One_hot_encoding_categorial            Normalizer

                                                                                                                                    Clean_Up           Reduce_complexity



                                                                    Normalizer_Model
                                                                                                                                                                                 CSV Writer




     String Replacer, Cell Splitter                                          ordinal: income band → its lower bound — a third choice; the top band
                                                                             becomes 100001, the logged assumption
     One to Many                                                             nominal: one-hot for Occupation, Gender, Education, MaritalStatus
     Normalizer → (Apply)                                                    z-score, ﬁtted once and passed on as a model; Apply would give new
                                                                             customers the same µ and σ (here: the same rows)
     Real AWC: 4,413 surveyed bike buyers (demographics, not the ﬂat table). The last nodes (t-SNE) belong to U07.
     pandas: get_dummies; scikit-learn: StandardScaler.
10                       Matrix                                                          Measure                                                        Without vectors                                            Learned
~~~~

## Page 011

[Original page 11](../../../quellen/Unit06_DS_en.pdf#page=11)

~~~~text
              STEP 2: CHOOSE A MEASURE


     Matrix       Measure   Without vectors   Learned




11
~~~~

## Page 012

[Original page 12](../../../quellen/Unit06_DS_en.pdf#page=12)

~~~~text
                                               WHAT MAKES A DISTANCE A DISTANCE

     d is a metric, or distance, if for all x, y, z:             Manhattan
                                                            10 6 + 8 = 14 y           all points at distance 1
     d(x, y) ≥ 0                   never negative                                   1                  Maximum
                                                             8
     d(x, y) = 0 ⇔ x = y           0 only for identical                                                Euclidean
                                                             6




                                                                            0
                                                                           Maximum 0




                                                                          =1
                                   objects
                                                                           =8                          Manhattan
                                                             4




                                                                           an
     d(x, y) = d(y, x)             symmetric                                       −1




                                                                      lide
                                                             2 x




                                                                   Euc
     d(x, z) ≤ d(x, y) + d(y, z)   triangle: no shortcut                              −1 0 1
                                   via a third point         0         6
                                                               0 2 4 6 8
                                                                         √∑
                                                            Euclidean         (xi − yi )2 : straight line. Manhattan
     Why you should care                                    ∑
                                                               |xi − yi |: along the axes. Maximum maxi |xi − yi |: the
                                                            worst axis. All three are metrics. Right: all points at
     If x is close to y and y is close to z, then x         distance 1 from the centre.
     cannot be far from z. So groups of neighbours
     stay groups, and a search can skip points
     instead of comparing everything.
       Keep the square root: squared Euclidean is not a metric (0, 1, 2 on a line: 4 > 1 + 1). Cosine
       and DTW, later today, are not metrics either: dissimilarities, not distances. Allowed — if you know it.

12                     Matrix                     Measure               Without vectors           Learned
~~~~

### DS-U06-L-EN-P012-D01 — Rekonstruktion

Metric axioms: $d(x,y)\ge0$, $d(x,y)=0\iff x=y$, $d(x,y)=d(y,x)$, $d(x,z)\le d(x,y)+d(y,z)$. Displacement (6,8): Manhattan 14, Euclidean 10, maximum 8. Unit balls: diamond, circle, square respectively. $d_2=\sqrt{\sum_i(x_i-y_i)^2}$; $d_1=\sum_i|x_i-y_i|$; $d_\infty=\max_i|x_i-y_i|$.

## Page 013

[Original page 13](../../../quellen/Unit06_DS_en.pdf#page=13)

~~~~text
                                            A METRIC THAT IS NOT THE STRAIGHT LINE

      Boulogne-sur-Mer                                The French railway metric: every trip goes via Paris (p):
                             Roncq, Croix
                           Paris                                  {
                           12 resellers               d(x, y) =
                                                                   ∥x − y∥           if x, y, p on one line out of Paris
          Saint-Ouen      Orléans                                  ∥x − p∥ + ∥p − y∥ otherwise
                          by train:
                          588 km                      ∥ · ∥ = straight-line distance. All four axioms hold. AWC’s
                                                      resellers:
     Aujan-Mournède      Colomiers                    reseller in             nearest, straight         nearest by train
                 72 km
                                                      Colomiers               Aujan-Mournède, 72 km     Paris, 588 km
                                                      Croix                   Roncq, 8 km               Paris, 211 km


     “Distance” is whatever your problem says it is
     By train, for every reseller outside Paris the nearest reseller in another town is in Paris. A valid metric
     (Deza & Deza, 2013) — and for a sales trip by car, the wrong one.

     AWC’s 40 French resellers; town coordinates from OpenStreetMap. A model: some TGV lines bypass Paris.
13                       Matrix                  Measure                  Without vectors          Learned
~~~~

## Page 014

[Original page 14](../../../quellen/Unit06_DS_en.pdf#page=14)

~~~~text
                               TWO MORE MEASURES: COSINE AND JACCARD

     Cosine — compares the direction: the mix, or            Jaccard — compares sets: which things, not how
     proﬁle:                                                 many:

                components                                                         A            B
                                   z            y

                                                                                Mini-   Chain   Road-
                               x                                                pump     Cap     650

                                        bikes
                                                                                    |A ∩ B|      2
                                   ∑
                                      i xi yi                          J(A, B) =             =      = 0.5
                     cos(x, y) =
                                   ∥x∥ ∥y∥                                          |A ∪ B|      4
     ∥x∥ = arrow length. x: 2k revenue in bikes, 1k in       Shared things ÷ all things of the two. Bought once or
     components; y: ten times that. Same mix: cos = 1,       100 times: the same.
     though Euclidean says 20.1k apart.

      Both are similarities: 1 = alike
      1 − cos and 1 − J turn them into dissimilarities; only 1 − J is a metric, i.e. a distance. KNIME: Numeric
      Distances (cosine), Bit Vector Distances (Tanimoto = Jaccard on 0/1).

14                    Matrix                    Measure             Without vectors              Learned
~~~~

### DS-U06-L-EN-P014-D01 — Rekonstruktion

Cosine: x=(2000,1000), y=10x, same direction. Jaccard: A={Minipump, Chain, Cap}, B={Chain, Cap, Road-650}; intersection 2, union 4. $\cos(x,y)=\frac{\sum_i x_i y_i}{\|x\|\|y\|}$; $J(A,B)=\frac{|A\cap B|}{|A\cup B|}=0.5$.

## Page 015

[Original page 15](../../../quellen/Unit06_DS_en.pdf#page=15)

~~~~text
                                     WHO IS MOST LIKE BRAKES AND GEARS?

     The six top-revenue AWC resellers. Euclidean compares revenue, #orders, #products (z, ﬁtted on all
     customers); Jaccard compares the products bought.

     reseller                                    revenue    #products    Euclidean distance         Jaccard
                                                                           small = similar      large = similar

     Brakes and Gears (reference)                877,107           81           —                     —
     Excellent Riding Supplies                   853,849           82     0.61 — nearest         0.038 — last
     Totes & Baskets Company                     816,756           93          2.23                 0.055
     Retail Mall                                 799,278           91          2.41                 0.055
     Corner Bicycle Supply                       787,773           88          2.48                 0.056
     Vigorous Exercise Company                   841,909          118     4.99 — farthest      0.605 — nearest


     Opposite answers — because each looks at different data
     Euclidean looks at how much, Jaccard at which products: Excellent Riding Supplies is Euclidean’s
     nearest and Jaccard’s last, Vigorous Exercise Company the reverse. Cosine on the category shares
     cannot choose: all six buy 71–91 % bikes (by revenue), and its top three differ only in the 4th decimal.

15                 Matrix                  Measure                Without vectors           Learned
~~~~

## Page 016

[Original page 16](../../../quellen/Unit06_DS_en.pdf#page=16)

~~~~text
                                                             SAME SPEND, DIFFERENT BIKES


                                                                 Brakes and Gears and Excellent Riding
               Brakes and Gears
                 32 mountain
                                                                 (Supplies): 877k vs 854k revenue, 12 orders
                                             Excellent           each, 81 vs 82 products. Euclidean calls them
                   Vigorous                   Riding             twins. But one buys mountain bikes, the other
                    Exercise                  43 road
                  27 mountain
                                                                 road bikes: not one bike in common.
                                                                 Vigorous Exercise (Company) buys more (118
                                  0 shared
                                                                 products), yet all 27 of its bikes are among
                                                                 Brakes and Gears’ 32.
     Bike products bought (model, size, colour). Real AWC.

      One word, two campaigns
      For a lookalike campaign, Euclidean ﬁnds a reseller who spends the same; Jaccard ﬁnds
      one who buys the same things. Decide which you mean before you compute.



16                     Matrix                      Measure          Without vectors       Learned
~~~~

## Page 017

[Original page 17](../../../quellen/Unit06_DS_en.pdf#page=17)

~~~~text
                                                                          CHOOSING ON PURPOSE

                        Sees                              Blind to                          Metric?
      Euclidean         size of every feature             nothing: units decide, scale      yes
                                                          ﬁrst
      Cosine            the mix (proportions)             overall size                      1 − cos: no
      Jaccard           which items                       how many, how much                1 − J: yes
      DTW (step 3)      shape over time                   time shift (on purpose)           no
      Edit (step 3)     character changes                 meaning                           count: yes; normalised:
                                                                                            no
      Gower             mixed types: numbers              nothing; range (max−min) sets     yes †
                        |x − y|/range, categories         the weight
                        same/different
     Decision rule: what must the measure ignore? Take the row whose “blind to” says it.

     And if a cell is missing?
     scikit-learn’s pairwise_distances (default) stops with an error; nan_euclidean_distances calls
     [1, 2, 3] and [1, NaN, 3] identical (0.0); KNIME: check your node. Decide, and log it.

     † on complete data (Gower & Legendre, 1986).


17                    Matrix                    Measure                   Without vectors         Learned
~~~~

## Page 018

[Original page 18](../../../quellen/Unit06_DS_en.pdf#page=18)

~~~~text
             Break
            10 minutes




Then: Step 3: Similarity Without Vectors
~~~~

## Page 019

[Original page 19](../../../quellen/Unit06_DS_en.pdf#page=19)

~~~~text
     STEP 3: SIMILARITY WITHOUT VECTORS


     Matrix   Measure   Without vectors   Learned




19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit06_DS_en.pdf#page=20)

~~~~text
                               TIME SERIES: WHEN, OR ONLY THE PATTERN?
     Brakes and Gears                                              Both resellers order every three months,
                 67            67
     21                                     31                     one month apart: month i of one is not the
                                                                   right partner for month i of the other.
     Jun Jul Aug Sep Oct Nov Dec Jan Feb Mar Apr
                                                                   Month by month (Euclidean), their orders
                                                      DTW
                                                      matches      never meet. DTW (Dynamic Time Warping)
     Jun Jul Aug Sep Oct Nov Dec Jan Feb Mar Apr                   may pair a month with a later one: each
                                                                   order meets the other’s next.
          26          48                         48
                                    59                             Real AWC, business months as in U05; a dot is a
     Excellent Riding Supplies           revenue, thousands        month without an order (0).


     The rule DTW follows

                            D(i, j) = |ui − vj | + min{ D(i−1, j−1), D(i−1, j), D(i, j−1) }

     u, v: the two series; D(i, j): the cheapest total cost of matching the ﬁrst i points of u with the ﬁrst
     j of v. A point may be reused, so shifts and longer peaks cost little or nothing. Müller (2007), ch. 4

20                 Matrix                    Measure                 Without vectors          Learned
~~~~

### DS-U06-L-EN-P020-D01 — Rekonstruktion

DTW connects peaks offset by a month. $D(i,j)=|u_i-v_j|+\min\{D(i-1,j-1),D(i-1,j),D(i,j-1)\}$. A point can be reused.

## Page 021

[Original page 21](../../../quellen/Unit06_DS_en.pdf#page=21)

~~~~text
                        DTW IS NOT A METRIC — AND THAT IS THE POINT

                                                      The same peak, lasting three steps in the second series.
                                                      The lengths differ (5 vs 8), so Euclidean is not even
     5 values
                                                      deﬁned. DTW matches the peak to all three points:
                                                      DTW = 0.
                                                      Two different series at dissimilarity 0: the identity axiom
                                                      breaks, on purpose.
     8 values
      On AWC’s four top-revenue resellers, the two measures pick different pairs:
                  closest pair                                      why
      Euclidean   Brakes and Gears, Totes & Baskets                 order in the same months
      DTW         Excellent Riding, Totes & Baskets                 similar amounts, shift ignored


      Euclidean asks when, DTW asks what pattern
      A delivery plan needs when; a customer proﬁle may not. DTW is slow on long series; real systems
      ﬁrst ﬁlter with a cheap estimate (Keogh & Ratanamahatana, 2005).

21                  Matrix                  Measure                   Without vectors          Learned
~~~~

## Page 022

[Original page 22](../../../quellen/Unit06_DS_en.pdf#page=22)

~~~~text
                           STRINGS: EDIT DISTANCE, AND U04’S PROBLEM

     Levenshtein distance: the fewest single-character insertions, deletions and substitutions
     that turn one string into the other. Divided by the longer length, it lies between 0 and 1 — a
     dissimilarity, no longer a metric.

                                           any threshold
                                           must fall here        Levenshtein ÷ longer length
         spelling variants (made up): merge     0.14
                                   0.0       0.1     0.2      0.3       0.4     0.5      0.6

                                    U04's 18 name pairs: different people, do not merge
                                                      Linda Gonzales / Lynn Gonzales 0.21
     U04’s 14 name groups (18 pairs), measured
     To merge the spelling variants and none of U04’s different people, a threshold must lie
     between 0.14 (our invented variants) and 0.21 — a narrow window, on this dataset only.
     That is why U04’s groups stay a list to check by hand.
22                Matrix                 Measure             Without vectors      Learned
~~~~

## Page 023

[Original page 23](../../../quellen/Unit06_DS_en.pdf#page=23)

~~~~text
                        BEFORE THE EXERCISES: A DISSIMILARITY MATRIX AS A PICTURE

                                                                                                     sorted by group, measure
                                arbitrary order       sorted by group      8                         uses only feature 2 (noise)   3.5
                                                                                                                                   3.0




                                                                           distance (dark = close)
                                                                           6                                                       2.5




                                                                                                                                     own scale
                                                                                                                                   2.0
                                                                           4
                                                                                                                                   1.5
                                                                           2                                                       1.0
                                                                                                                                   0.5
                                                                           0                                                       0.0

                                                  group 1        group 2
     Cell (i, j) is the dissimilarity of objects i and j (here: Euclidean distance). Unsorted, you see nothing.
     Sort rows and columns by a label you know: dark blocks mean the measure puts a group’s members
     close together.

     No blocks: the measure does not see what makes the groups differ
     Right: the measure uses only feature 2, which is alike in both groups — no blocks, on any colour
     scale. When blocks appear, ask which feature made them.

     Synthetic: 30 objects, two groups of 15. Feature 1 differs between the groups, feature 2 is random noise.
23                  Matrix                        Measure                                            Without vectors                             Learned
~~~~

## Page 024

[Original page 24](../../../quellen/Unit06_DS_en.pdf#page=24)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit06_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit06_DS_en.pdf#page=25)

~~~~text
        Break
      10 minutes




Then: Step 4: Learn the Space
~~~~

## Page 026

[Original page 26](../../../quellen/Unit06_DS_en.pdf#page=26)

~~~~text
              STEP 4: LEARN THE SPACE


     Matrix       Measure   Without vectors   Learned




26
~~~~

## Page 027

[Original page 27](../../../quellen/Unit06_DS_en.pdf#page=27)

~~~~text
                                                           FROM WORD2VEC TO A TRANSFORMER

     Free text has no columns. An embedding is a learned table of coordinates: one row per word, node
     or text. word2vec: a small network learns to predict the words around a word; keep only what it
     learned: one vector per word.

                                       word2vec                                                   transformer

            “. . . river bank. . . ”
                                                                      the   river       bank                 [ 0.12 −0.80 . . . ]
                                                    bank
                                             [ 0.31 −0.72 . . . ]
          “. . . savings bank. . . ”
                                                                      the   savings        bank             [ −0.08 0.44 . . . ]



                           one vector per word, looked                               one vector per word in its sentence
                          up, the same in every sentence                            — attention mixes in the other words


     A transformer keeps the network: the vector depends on the whole sentence. Large and trained on
     huge amounts of text, it is the model behind large language models (LLMs). Embedding models
     such as Sentence-BERT are trained further so that cosine reﬂects similarity — the training data
     decide what counts as similar.
     Recommended: Andrej Karpathy, Let’s build GPT — youtube.com/watch?v=kCc8FmEb1nY
27                          Matrix                          Measure             Without vectors                     Learned
~~~~

## Page 028

[Original page 28](../../../quellen/Unit06_DS_en.pdf#page=28)

~~~~text
                                  NODE2VEC: THE SAME TRICK ON A GRAPH

                                                       word2vec needs sentences; a graph like U05’s
                                                       customer–product graph has none. So make
                                        s8             them: random walks along the edges are the
     s1             s2
                            s7                         sentences, each node is a word. Two settings p, q
                                                       steer the walk: stay near the start (orange) or
              u                    s6                  move away (magenta).

                             s5                        Out comes a table again: one row per node, e.g.
                                             s9        64 columns — ready for any measure from step 2.
     s3             s4
                                                       Products often bought together end up close: a
                                                       recommendation.

     Every arrow is a choice
     table → graph → walks → vectors → cosine. Walk length, number of walks, p, q, vector size: write
     them down, or nobody can repeat your result. (Grover & Leskovec, 2016; ﬁgure after their Fig. 1)



28                Matrix                 Measure               Without vectors       Learned
~~~~

## Page 029

[Original page 29](../../../quellen/Unit06_DS_en.pdf#page=29)

~~~~text
                                                    SHOULD AN LLM DO THE WORK?

     Yes, when                                        No, when
      • the input is free text and you need             • the features already are numbers: scale them
        similarity                                      • the coordinates must be explainable to an auditor
      • you cannot build good numeric features          • the data may not leave the building
        yourself

                                                                hundreds to
                free text,                                                                 clustering, a
                                    LLM embedding              thousands of
              e.g. reviews                                                              ranking, a decision
                                                             numbers per row

                             here U03 and U04 apply: pin the model version, store the
                             vectors, check the ranking against a sample you labelled


      A tool, or a data source?
      An LLM that drafts SQL for you is a tool: you check its answer yourself. An embedding inside your
      pipeline is a data source: when the model is updated, every similarity moves.

29                  Matrix                Measure                 Without vectors           Learned
~~~~

## Page 030

[Original page 30](../../../quellen/Unit06_DS_en.pdf#page=30)

~~~~text
       Break
      10 minutes




Then: Hands On — Exercise 3
~~~~

## Page 031

[Original page 31](../../../quellen/Unit06_DS_en.pdf#page=31)

~~~~text
                HANDS ON — EXERCISE 3
                                20 minutes
              Sheet on Moodle: Unit06_Exercises_en.pdf

     All the measures get compared here, so everyone needs their matrix ready.




31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit06_DS_en.pdf#page=32)

~~~~text
                                                                       KEY MESSAGES

     • Matrix: encoding and scaling are decisions, not cosmetics — scaling alone moved
       Vigorous Exercise from 2nd to 15th neighbour
     • Measure: a metric guarantees properties, not the right answer — on the same resellers,
       “how much” (Euclidean) and “which products” (Jaccard) gave opposite answers
     • Without vectors: DTW and edit distance compare series and strings directly; DTW
       ignores shifts and stretches on purpose, so two different series can be at dissimilarity
       0
     • Picture: sort a dissimilarity matrix by a label; blocks show what the measure sees —
       ask which feature made them
     • Learned: an embedding learns the coordinates; a hosted one is a data source — pin
       the version, store the vectors, check against labels
     • The answer: “similar” is decided by whoever chooses the features and the measure —
       you, or for a learned embedding its training data. Say what it must be blind to, and
       write it down
     • Next: U07 — Dimensionality Reduction: PCA, t-SNE & Clusters
32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit06_DS_en.pdf#page=33)

~~~~text
     EXTRA: TWO MORE VIEWS




33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit06_DS_en.pdf#page=34)

~~~~text
                                               OR SKIP THE EMBEDDING: GRAPH KERNELS

       node2vec learns vectors, then measures. A graph kernel is a similarity that compares two graphs
       directly: count the matching parts. Two small graphs, the same four labels:
                                                                 Kernel matrix K = matching pairs of . . .
                 G1 (ring)           G2 (triangle)                node labels        label + neighbour labels
              B|CC       C|AB         B|CC      C|BC                   G1 G2                    G1 G2
                B         C            B         C                G1 6      6              G1 6         1
                                                                  G2 6      6              G2 1         4
                                                                 Counting labels, every entry is 6: G2 looks identical to G1 .
                C         A            C         A
                                                                 With the neighbours, only one part is shared (B|CC): the
              C|AB       A|CC        C|ABC       A|C
                                                                 ring and the triangle differ. Repeat that step h times and
                                                                 add up the counts of all rounds: the Weisfeiler–Lehman
     B = Bike, C = Component, A = Accessory; grey: each node’s
     label with its neighbours’ labels.                          kernel, the standard baseline.

       Why count parts instead of editing?
       The intuitive measure, graph edit distance, is NP-hard (no known fast algorithm). A kernel needs no
       training and is deterministic (Kriege et al., 2020); node2vec depends on random walks and their settings.

34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit06_DS_en.pdf#page=35)

~~~~text
                                                                  HIGH DIMENSIONS BEHAVE BADLY — SOMETIMES
                                                                                                                                 A 0/1 “bought” matrix over AWC’s subcategories




                                                                                                        everything equidistant
                                                                                                                                 has 35 columns (35 of 37 ever bought); with
                                        1.0
     mean nearest / farthest distance




                                                                                                                                 products, hundreds. The textbook warning: in
                                                  i.i.d. uniform points (the textbook premise)
                                        0.8       AWC one-hot customers (sparse, many identical rows)                            high dimensions nearest and farthest become
                                        0.6                                                                                      equally far, and “nearest neighbour” stops
                                        0.4                                                                                      meaning anything (Beyer et al., 1999). On

                                        0.2                                                                                      random points that is exactly what happens: the
                                                                                                                                 ratio nearest ÷ farthest climbs 0.03 → 0.87
                                        0.0
                                              2              10          35       100             500                            from 2 to 500 dimensions. On our 35-column
                                                                   dimensions                                                    0/1 matrix it stays at 0.05.

                                    Whether the curse bites is a property of your data, not its width
                                    AWC’s matrix is sparse (2.6 ones per row) and full of identical rows (1,655 distinct among 19,119), so
                                    the nearest distance is ≈ 0 and the ratio never lifts. Measure it before you reach for a cure. If it
                                    bites: reduce the dimensions (U07) or learn a space for your similarity.

35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit06_DS_en.pdf#page=36)

~~~~text
                                           SOURCES & FURTHER READING (1/3)

     • Deza & Deza (2013), Encyclopedia of Distances, 2nd ed., Springer — the French railway
       metric and several hundred others
       doi.org/10.1007/978-3-642-30958-8

     • Sakoe & Chiba (1978), Dynamic programming algorithm optimization for spoken word
       recognition, IEEE Trans. ASSP 26(1):43–49 — the classic DTW paper, and the band that
       makes it fast
       doi.org/10.1109/TASSP.1978.1163055

     • Müller (2007), Information Retrieval for Music and Motion, Springer — ch. 4 is the
       clearest worked exposition of DTW: the cost matrix, the recursion, step-size conditions
       and the warping-window variants
       doi.org/10.1007/978-3-540-74048-3

     • Keogh & Ratanamahatana (2005), Exact indexing of dynamic time warping, Knowledge
       and Information Systems 7(3):358–386 — the lower bounds real systems prune with,
       and why an index cannot do it directly
       doi.org/10.1007/s10115-004-0154-9

36
~~~~

## Page 037

[Original page 37](../../../quellen/Unit06_DS_en.pdf#page=37)

~~~~text
                                         SOURCES & FURTHER READING (2/3)


     • Mikolov et al. (2013), Efﬁcient Estimation of Word Representations in Vector Space, ICLR
       Workshop (arXiv:1301.3781) — word2vec; Grover & Leskovec (2016), node2vec, KDD, 855–864
       arxiv.org/abs/1301.3781
     • Vaswani et al. (2017), Attention Is All You Need, NeurIPS 30, 5998–6008 — the transformer;
       Reimers & Gurevych (2019), Sentence-BERT, EMNLP-IJCNLP, 3982–3992 — text embeddings
       meant for cosine comparison
       doi.org/10.18653/v1/D19-1410
     • (Extra) Kriege, Johansson & Morris (2020), A survey on graph kernels, Applied Network Science
       5:6 — the graph kernels in one survey, Weisfeiler–Lehman included, with their costs
       doi.org/10.1007/s41109-019-0195-3
     • (Extra) Shervashidze et al. (2011), Weisfeiler-Lehman Graph Kernels, JMLR 12:2539–2561
       jmlr.org/papers/v12/shervashidze11a.html




37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit06_DS_en.pdf#page=38)

~~~~text
                                               SOURCES & FURTHER READING (3/3)

     • (Extra) Beyer, Goldstein, Ramakrishnan & Shaft (1999), When Is “Nearest Neighbor” Meaningful?, ICDT, LNCS
       1540:217–235 — the result behind the textbook warning
       doi.org/10.1007/3-540-49257-7_15
     • (Extra) Aggarwal, Hinneburg & Keim (2001), On the Surprising Behavior of Distance Metrics in High
       Dimensional Space, ICDT, LNCS 1973:420–434 — which Lp measure suffers least in high dimensions
       (fractional p < 1 is not a metric)
       doi.org/10.1007/3-540-44503-X_27
     • Aggarwal (2015), Data Mining: The Textbook, Springer — ch. 3 (similarity and distances) and ch. 2 (feature
       transformation) at the level this unit condenses
       doi.org/10.1007/978-3-319-14142-8
     • (Further reading) Kulis (2013), Metric Learning: A Survey, Foundations and Trends in Machine Learning
       5(4):287–364 — when the distance itself should be learned rather than chosen
       doi.org/10.1561/2200000019
     • Gower (1971), A General Coefﬁcient of Similarity and Some of Its Properties, Biometrics 27(4):857–871 — the
       original coefﬁcient
       doi.org/10.2307/2528823
     • Gower & Legendre (1986), Metric and Euclidean properties of dissimilarity coefﬁcients, Journal of
       Classiﬁcation 3:5–48 — which coefﬁcients are metric, and which are Euclidean, are two different questions
       doi.org/10.1007/BF01896809
38
~~~~
