---
source_id: DS-U06-EX
original_file: Unit06_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: 561eaf2802894b7463fa7faef7b83a7cf946421e1c891b86a6c1c52408b702b0
verification: partial
---
# Unit06_Exercises_en

[Original PDF](../../../quellen/Unit06_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit06_Exercises_en.pdf#page=1)

<a id="ds-u06-ex-t01"></a>

**DS-U06-EX-T01 — One Matrix, Scaled**

<a id="ds-u06-ex-t02"></a>

**DS-U06-EX-T02 — One Measure Each**

~~~~text
  Unit 06 — Exercises                                                                    Features, Similarity and Distance
Build one small matrix, and watch scaling change the answer.
▶ In the room        what ﬁts the stop — all that is expected. The room splits in Exercise 2: each of you takes one measure;
                     you compare them in Exercise 3.
⃝ Extra              voluntary, at home.
Stop A, 20 min       Exercise 1 (everyone), then Exercise 2      Stop B, 20 min: Exercise 3, together
Asynchronous         the same sheet, before your weekly slot; bring what did not run.
You need             your ﬂat table AWC/awc_flat.csv. Scaling and encoding are your decisions — write down why.

Exercise 1 — One Matrix, Scaled stop A · ▶ ∼10 min · everyone
 1 Build one row per customer with four columns: total revenue, number of orders, distinct products, share of revenue in
   bikes. Keep 40 customers: 20 resellers and 20 individuals. This is your matrix for the whole sheet. Keep CustomerType
   beside the matrix, not in it — you need it in Exercise 3.
      Example — the customer type is derived, not stored
      A customer with a StoreID is a reseller, one with only a PersonID an individual (Sales_Customer):
      CASE WHEN c.StoreID IS NOT NULL THEN 'reseller' ELSE 'individual' END AS CustomerType

 2 Take two customers. For each raw feature, compute its contribution to their squared Euclidean distance. Which feature
   dominates, and by what factor?
      Squared Euclidean distance is i (xi − yi )2 , so feature i contributes (xi − yi )2 — one number per column; together they add up
                                       ∑
      to the distance. The factor is the largest contribution divided by the second largest.
 3 Scale the matrix (z-score) and compute the same two contributions again. What changed, and why is that a decision,
   not a formality?
  In KNIME
  Scripts/awc_u06_sample.sql draws your 40 — put your group number in as the seed, paste it into a DB Query Reader. Then:
  1 Joiner with your ﬂat table on CustomerID (matching rows, columns of both tables) · 2 Rule Engine: BikeRevenue, $Category$ =
  "Bikes" => $LineTotal$, TRUE => 0 · 3 GroupBy on Label: Sum LineTotal, Unique count SalesOrderID and ProductID, Sum
  BikeRevenue · 4 Math Formula for the bike share, RowID (use column Label). Step 3: Normalizer (z-score).

⃝ Extra:    scale    a     third    way      (min-max   or   robust):   does   the   dominant      feature    change     again?     Kit:
Scripts/awc_u06_scaling.py.

Exercise 2 — One Measure Each stop A · ▶ ∼10 min · the room splits: one measure each
    measure                               on what
A Euclidean                the scaled four columns
B Cosine                   the category proﬁle (shares of revenue, not totals)
C Jaccard                  the sets of products bought
D DTW                      each customer’s monthly revenue series
E normalised edit distance the customer names
 1 Compute your 40 × 40 distance matrix. Report its range and the closest pair.
 2 Name one business question your measure answers well — and one it would answer wrongly.
  In KNIME
  A distance node deﬁnes the measure, Distance Matrix Calculate applies it. A, B: Numeric Distances (Euclidean; cosine). C:
  Pivot lines to customer × product (count, missing → 0), Create Bit Vector, Bit Vector Distances (Tanimoto = Jaccard on 0/1).
  Distance Matrix Pair Extractor gives one row per pair. D and E run in Python (Scripts/awc_no_vectors.py) — in KNIME take A,
  B or C.
Kit: Scripts/awc_similarity.py. D and E take longer to get running — that is a ﬁnding too.
⃝ Extra: ﬁnd the furthest pair as well and look both pairs up. Are the close ones really similar?




Unit 06 · Data Science · exercise sheet                                                                                                  1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit06_Exercises_en.pdf#page=2)

<a id="ds-u06-ex-t03"></a>

**DS-U06-EX-T03 — Does the Measure See the Label?**

~~~~text
Exercise 3 — Does the Measure See the Label? stop B · ▶ 20 min · together
 1 Sort and look. Order rows and columns by CustomerType, plot the matrix as an image. Do blocks appear — dark inside
   each type, light between?
      Example — the picture in Python

      order = np.argsort(types)                      # all individuals, then all resellers
      plt.imshow(D[order][:, order], cmap="Blues_r") # dark = close

 2 Put the pictures of A–E side by side. Which measures found the type, which did not?
 3 One measure will separate almost perfectly. Before you call it a success: which of your four features made it easy — a
   ﬁnding or a tautology?
  In KNIME
  A Python View node (not Python Script) on your matrix — for A the scaled one. The RowIDs are the labels from Exercise 1, so
  sorting by them puts all individuals ﬁrst. For B write pdist(X, "cosine"), for C pdist(X > 0, "jaccard"):
  import knime.scripting.io as knio, matplotlib.pyplot as plt
  from scipy.spatial.distance import pdist, squareform
  X = knio.input_tables[0].to_pandas().sort_index()    # I ... before R ...
  fig, ax = plt.subplots(); ax.imshow(squareform(pdist(X)), cmap="Blues_r")
  knio.output_view = knio.view(fig)

⃝ Extra: feed the same matrix into t-SNE with metric="precomputed" and colour the points by CustomerType. Two clouds
or one — and does it agree with your block picture?

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: the 40 × 4 matrix, the dominant feature before scaling and its factor
• Ex 2: your distance matrix — range, closest pair, the question it answers well
• Ex 3: the block picture, whether your measure found the type, and one sentence: ﬁnding or tautology?




Unit 06 · Data Science · exercise sheet                                                                                         2
~~~~
