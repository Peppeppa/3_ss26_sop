"""
Unit 08 (EDA II) -- the four big chart defects, each beside its repair.

    python3 awc_chart_defects.py  -> ../Images/fig_u08_defects{,_de}.pdf

The slide states the four defects in a table. A table is the right place for the
RULE and the wrong place for the EFFECT: nobody is fooled by the sentence
"truncating the axis rescales every comparison", and everybody is fooled by the
picture. So: top row how it misleads, bottom row the same numbers repaired.

ONE dataset throughout -- AWC revenue by order QUARTER, the eight
quarters of the full years 2012 Q1 .. 2013 Q4 (2011 and 2014 are part years), by OrderDate as it
stands in the extract -- so the reader never has to ask whether the rows are
comparable:

    quarter   revenue (m)   orders
    2012 Q1      6.51            779
    2013 Q3     12.78          5,336
    2013 Q4     12.19          6,124

Why each pair works on exactly these numbers:

  truncated  2012 Q1 and 2013 Q3 are 6.51 and 12.78, a ratio of 2.0. Start the
             axis at 5 and the bars read 1.51 against 7.78 -- a ratio of 5.1.
  dual axis  orders grow 7.9x (index 786 in 2013 Q4), revenue only 1.9x (187):
             more, smaller orders. Two free scales can draw both as one curve;
             indexing both to 100 at 2012 Q1 puts them on one scale.
  rainbow    revenue by category x quarter (log scale, same norm in both panels,
             colour bar on both). jet paints hard bands where the numbers are smooth.
  3D pie     the four quarters of 2013, seen at an angle, 13Q4 in front: its side
             wall shows, so it looks larger than 13Q3 -- yet 13Q3 is larger
             (12.78 vs 12.19). The sorted bars rank them at a glance.

3D bars are the table's fourth defect and cannot be drawn here: this matplotlib
has no Axes3D. The exploded pie is the same failure -- perspective and occlusion
substituted for position -- and it is what a BI tool actually produces.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir() / "awc_flat.csv"
IMG = Path(__file__).resolve().parent.parent / "Images"
BLUE, ORANGE, GREY, TEAL = "#2A78D6", "#EB6834", "#8A8A8A", "#1B7A6B"
INK, NOTE, BAD = "#333333", "#5E5E5E", "#C0392B"
CATS = ["Bikes", "Components", "Clothing", "Accessories"]

STR = {
 "en": dict(
   bad="how it misleads", good="the same numbers, repaired",
   d1="Truncated axis", d2="Dual axis", d3="Rainbow scale", d4="3D pie",
   b1="13Q3 vs 12Q1: looks 5$\\times$", g1="really 2.0$\\times$ (12.78 vs 6.51)",
   b2="two y-axes: grew alike?", g2="orders 7.9$\\times$, revenue 1.9$\\times$",
   b3="yellow or cyan: which is more?", g3="darker = more",
   b4="13Q4 looks largest (in front)", g4="13Q3 is larger (12.78 vs 12.19)",
   ylab="revenue, million", ylab2="index, 12Q1 = 100", cbar="revenue, million (log)", start="axis starts at 5", two="two y-axes, each scaled to fit",
   lgd_rev="revenue", lgd_cnt="orders",
   cap="Real AWC, the eight quarters of the full years 2012 Q1 to 2013 Q4 (OrderDate as in the extract).",
 ),
 "de": dict(
   bad="wie es täuscht", good="dieselben Zahlen, behoben",
   d1="Abgeschnittene Achse", d2="Doppelachse", d3="Regenbogenskala", d4="3D-Torte",
   b1="13Q3 zu 12Q1: wirkt 5-fach", g1="wirklich 2,0-mal (12,78 zu 6,51)",
   b2="zwei y-Achsen: gleich gewachsen?", g2="Bestellungen 7,9-fach, Umsatz 1,9-fach",
   b3="Gelb oder Cyan: was ist mehr?", g3="dunkler = mehr",
   b4="13Q4 wirkt am größten (vorn)", g4="13Q3 ist größer (12,78 zu 12,19)",
   ylab="Umsatz, Mio.", ylab2="Index, 12Q1 = 100", cbar="Umsatz, Mio. (log)", start="Achse beginnt bei 5", two="zwei y-Achsen, je passend skaliert",
   lgd_rev="Umsatz", lgd_cnt="Bestellungen",
   cap="Echte AWC, die acht Quartale der vollen Jahre 2012 Q1 bis 2013 Q4 (OrderDate wie im Extrakt).",
 ),
}


def find_extract():
    """AWC/awc_flat.csv in this folder or any folder above it."""
    for base in Path(__file__).resolve().parents:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    raise SystemExit("AWC/awc_flat.csv not found above this folder. Put your group's "
                     "extract there, or edit find_extract().")


def load():
    d = pd.read_csv(find_extract(), usecols=["SalesOrderID", "LineTotal", "OrderDate", "Category"])
    d["Q"] = pd.PeriodIndex(d.OrderDate, freq="Q")
    d = d[(d.Q >= pd.Period("2012Q1")) & (d.Q <= pd.Period("2013Q4"))]
    rev = d.groupby("Q").LineTotal.sum() / 1e6
    cnt = d.groupby("Q").SalesOrderID.nunique()      # orders per quarter
    grid = (d.pivot_table(index="Category", columns="Q", values="LineTotal",
                          aggfunc="sum").reindex(CATS) / 1e6)
    return rev, cnt, grid


def tag(ax, text, colour):
    ax.set_title(text, fontsize=5.0, color=colour, pad=3, style="italic")


def qlab(q):
    return f"{str(q.year)[2:]}Q{q.quarter}"


LO = 5          # the truncated axis starts here (million)


def pie3d(a, vals, labels, front, tilt=0.55, depth=0.28):
    """A pie seen at an angle, drawn by hand (this matplotlib has no Axes3D). The
    slice `front` is centred at the bottom, so its side wall shows and it looks
    bigger than it is -- the distortion a 3D pie adds."""
    frac = np.asarray(vals) / np.sum(vals)
    start = 270 - 180 * frac[front] - 360 * frac[:front].sum()   # centre `front` at 270 deg
    angles = start + 360 * np.concatenate([[0], np.cumsum(frac)])
    face, side = "#86B6EF", "#4F86C6"
    for k in range(len(vals)):
        t = np.radians(np.linspace(angles[k], angles[k + 1], 60))
        xs, ys = np.cos(t), tilt * np.sin(t)
        vis = ys < 0                                     # the near half shows its wall
        if vis.any():
            xw, yw = xs[vis], ys[vis]
            a.fill(np.r_[xw, xw[::-1]], np.r_[yw, yw[::-1] - depth], color=side,
                   ec="white", lw=0.4, zorder=1)
        a.fill(np.r_[0, xs, 0], np.r_[0, ys, 0], color=face, ec="white", lw=0.5, zorder=2)
        m = np.radians((angles[k] + angles[k + 1]) / 2)
        a.text(1.28 * np.cos(m), 1.28 * tilt * np.sin(m) - (depth / 2 if np.sin(m) < 0 else 0),
               labels[k], ha="center", va="center", fontsize=4.4, color=INK)
    a.set_xlim(-1.3, 1.3); a.set_ylim(-1.05, 0.8); a.set_aspect("equal")


def draw(rev, cnt, grid, lang):
    s = STR[lang]
    qs = list(rev.index); x = np.arange(len(qs)); xl = [qlab(q) for q in qs]
    fig, ax = plt.subplots(2, 4, figsize=(4.8, 2.75))      # authored at slide size
    fig.subplots_adjust(left=0.10, right=0.985, top=0.83, bottom=0.12,
                        hspace=0.95, wspace=0.62)
    for a in ax.ravel():
        a.tick_params(labelsize=4.5, length=1.5, pad=1)
        for side in ("top", "right"):
            a.spines[side].set_visible(False)

    # 1 truncated ------------------------------------------------------------
    for a, lo, t in ((ax[0, 0], LO, s["b1"]), (ax[1, 0], 0, s["g1"])):
        a.bar(x, rev.to_numpy(), width=0.65, color=BLUE if lo == 0 else BAD)
        a.set_ylim(lo, 14.5); a.set_xticks(x); a.set_xticklabels(xl, fontsize=3.6, rotation=90)
        a.set_ylabel(s["ylab"], fontsize=5.0); tag(a, t, BAD if lo else NOTE)
        if lo:
            # show WHY it looks 5x: the axis starts at LO, so a bar shows value - LO
            a.set_yticks([LO, 8, 11, 14])
            a.get_yticklabels()[0].set_color(BAD); a.get_yticklabels()[0].set_fontweight("bold")
            r = rev.to_numpy()
            for i in (0, 6):
                v = f"{r[i] - LO:.1f}".replace(".", "," if lang == "de" else ".")
                a.text(i, r[i] + 0.25, v, fontsize=4.0, color=INK, ha="center", va="bottom",
                       fontweight="bold")

    # 2 dual axis: limits chosen so the two curves look alike ---------------
    a = ax[0, 1]
    a.plot(x, rev.to_numpy(), "-o", color=BLUE, lw=0.9, ms=2)
    a.set_ylim(6, 13); a.tick_params(axis="y", colors=BLUE)
    b = a.twinx(); b.plot(x, cnt.to_numpy() / 1e3, "-s", color=ORANGE, lw=0.9, ms=1.8)
    b.set_ylim(0.3, 6.9)   # start and end points coincide with revenue's
    b.tick_params(labelsize=4.5, colors=ORANGE, pad=1, length=1.5)
    b.spines["top"].set_visible(False)
    # make the TWO axes impossible to miss: each spine in its series' colour
    a.spines["left"].set_color(BLUE); a.spines["left"].set_linewidth(1.4)
    b.spines["right"].set_color(ORANGE); b.spines["right"].set_linewidth(1.4)
    b.spines["left"].set_visible(False)
    a.set_ylabel(s["ylab"], fontsize=5.0, color=BLUE)
    b.set_ylabel(s["lgd_cnt"] + (", 1,000" if lang == "en" else ", Tsd."), fontsize=5.0, color=ORANGE, labelpad=1)
    a.set_xticks(x); a.set_xticklabels(xl, fontsize=3.6, rotation=90)
    tag(a, s["b2"], BAD)

    a = ax[1, 1]
    a.plot(x, rev.to_numpy() / rev.iloc[0] * 100, "-o", color=BLUE, lw=0.9, ms=2,
           label=s["lgd_rev"])
    a.plot(x, cnt.to_numpy() / cnt.iloc[0] * 100, "-s", color=ORANGE, lw=0.9, ms=1.8,
           label=s["lgd_cnt"])
    a.set_xticks(x); a.set_xticklabels(xl, fontsize=3.6, rotation=90)
    a.set_ylabel(s["ylab2"], fontsize=5.0)
    a.legend(fontsize=4.0, frameon=False, loc="upper left", handlelength=1.2)
    tag(a, s["g2"], NOTE)

    # 3 rainbow: same log norm in both, colour bar on both --------------------
    norm = matplotlib.colors.LogNorm(vmin=np.nanmin(grid.to_numpy()),
                                     vmax=np.nanmax(grid.to_numpy()))
    for a, cmap, t in ((ax[0, 2], "jet", s["b3"]), (ax[1, 2], "Blues", s["g3"])):
        im = a.imshow(grid.to_numpy(), aspect="auto", cmap=cmap, norm=norm)
        a.set_xticks(x); a.set_xticklabels(xl, fontsize=3.6, rotation=90)
        a.set_yticks(range(4))
        a.set_yticklabels(["Bikes", "Comp.", "Cloth.", "Access."] if lang == "en" else
                          ["Fahrr.", "Komp.", "Kleid.", "Zub."], fontsize=4.0)
        cb = fig.colorbar(im, ax=a, fraction=0.08, pad=0.03)
        cb.ax.tick_params(labelsize=3.6, length=1.2)
        cb.outline.set_linewidth(0.3)
        cb.set_label(s["cbar"], fontsize=3.8, labelpad=1)
        tag(a, t, BAD if cmap == "jet" else NOTE)

    # 4 exploded pie vs sorted bars: the four quarters of 2013 ---------------
    y13 = rev[[q for q in qs if q.year == 2013]]
    l13 = [qlab(q) for q in y13.index]
    a = ax[0, 3]
    pie3d(a, y13.to_numpy(), l13, front=l13.index("13Q4"))
    tag(a, s["b4"], BAD)
    for side in ("left", "bottom"):
        a.spines[side].set_visible(False)
    a.set_xticks([]); a.set_yticks([])

    a = ax[1, 3]
    o = np.argsort(-y13.to_numpy())
    a.barh(np.arange(4)[::-1], y13.to_numpy()[o], height=0.6, color=BLUE)
    a.set_yticks(np.arange(4)[::-1]); a.set_yticklabels([l13[i] for i in o], fontsize=4.0)
    a.set_xlabel(s["ylab"], fontsize=5.0); tag(a, s["g4"], NOTE)

    for j, key in enumerate(("d1", "d2", "d3", "d4")):
        box = ax[0, j].get_position()
        fig.text((box.x0 + box.x1) / 2, 0.955, s[key], ha="center", fontsize=6.0, color=INK)
    for row, (key, colour) in enumerate(((("bad"), BAD), ("good", NOTE))):
        box = ax[row, 0].get_position()
        fig.text(0.005, (box.y0 + box.y1) / 2, s[key], rotation=90, va="center",
                 ha="left", fontsize=5.0, color=colour)
    # s["cap"] (the provenance) is printed on the slide, above the bullets

    out = IMG / f"fig_u08_defects{'' if lang == 'en' else '_de'}.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.02); plt.close(fig)
    return out


if __name__ == "__main__":
    rev, cnt, grid = load()
    print("quarter  revenue(m)  orders  index rev  index orders")
    for q in rev.index:
        print(f"  {q}   {rev[q]:6.2f}   {cnt[q]:8,d}   {rev[q]/rev.iloc[0]*100:6.0f}   {cnt[q]/cnt.iloc[0]*100:6.0f}")
    r = rev.to_numpy()
    print(f"true 2013Q3 : 2012Q1 ratio  {r[6]/r[0]:.2f}")
    print(f"read off an axis starting at {LO}: {(r[6]-LO)/(r[0]-LO):.2f}")
    for lang in ("en", "de"):
        print("wrote", draw(rev, cnt, grid, lang))
