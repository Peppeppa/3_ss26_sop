"""
Unit 08 — compute the EDA statistics and emit plot data for the slides.

Standard library only. Writes the .dat files the deck plots with pgfplots and
Data/anscombe.csv for the exercise sheet (Ex 2).

VERIFIED OUTPUT (reproduce with: python3 awc_eda_data.py), all 31,465 orders:

  TotalDue per order
    mean 3,916   median 865   mean/median 4.53
    sd  12,515   IQR  2,553
    skewness 5.83   excess kurtosis 40.56       (a normal distribution: 0 and 0)
    deciles 28 44 77 207 865 1,441 2,536 2,681 3,954

  Pareto: top 1/5/10/20 % of orders hold 24.1 / 65.8 / 74.5 / 82.7 % of revenue

  TWO POPULATIONS, named by OnlineOrderFlag:
    online   n=27,659  median   657  max   3,954
    reseller n= 3,806  median 9,282  max 187,488   (14x apart)
  INSIDE the online orders, a bike or none (the histogram's deepest valley):
    no bike   n=12,454  median    44  max    289
    bike      n=15,205  median 2,289  min    597
    reseller orders at or below the online maximum: 1,353 of 3,806

  order value vs total quantity: Pearson 0.869   Spearman 0.215
  per customer: revenue vs #products r=0.871, vs #orders 0.490; #orders vs #products 0.679

  Anscombe's quartet, recomputed (mean x 9.00, var x 11.00, mean y 7.50,
  var y 4.12-4.13, corr 0.816-0.817, slope 0.500 in all four)

  overplotting: 26x22 grid, 227 cells occupied, busiest 12,376 of 121,317 (10.2 %)
"""
import csv
import io
import math
import statistics
from collections import defaultdict
from pathlib import Path

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC  = awc_dir()    # the canonical extract
DATA = Path(__file__).resolve().parent.parent / "Data"   # this unit's plot data

# The canonical Anscombe (1973) data.
ANSCOMBE = {
    "I":   ([10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5],
            [8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84, 4.82, 5.68]),
    "II":  ([10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5],
            [9.14, 8.14, 8.74, 8.77, 9.26, 8.10, 6.13, 3.10, 9.13, 7.26, 4.74]),
    "III": ([10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5],
            [7.46, 6.77, 12.74, 7.11, 7.81, 8.84, 6.08, 5.39, 8.15, 6.42, 5.73]),
    "IV":  ([8, 8, 8, 8, 8, 8, 8, 19, 8, 8, 8],
            [6.58, 5.76, 7.71, 8.84, 8.47, 7.04, 5.25, 12.50, 5.56, 7.91, 6.89]),
}


def read(name):
    """Read from the canonical extract (AWC/, from Adventureworks2019)."""
    with open(AWC / name, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def pearson(a, b):
    ma, mb = statistics.mean(a), statistics.mean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    den = math.sqrt(sum((x - ma) ** 2 for x in a) * sum((y - mb) ** 2 for y in b))
    return num / den


def ranks(a):
    """Average ranks, ties shared -- required for Spearman to be correct."""
    order = sorted(range(len(a)), key=lambda i: a[i])
    out = [0.0] * len(a)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and a[order[j + 1]] == a[order[i]]:
            j += 1
        for k in range(i, j + 1):
            out[order[k]] = (i + j) / 2 + 1
        i = j + 1
    return out


def spearman(a, b):
    return pearson(ranks(a), ranks(b))


def quantile(sorted_values, p):
    n = len(sorted_values)
    k = (n - 1) * p
    f = int(k)
    if f + 1 >= n:
        return sorted_values[f]
    return sorted_values[f] + (sorted_values[f + 1] - sorted_values[f]) * (k - f)


if __name__ == "__main__":
    rows = read("awc_flat.csv")
    per_order, lines_per_order, qty = {}, defaultdict(int), defaultdict(float)
    for r in rows:
        oid = r["SalesOrderID"]
        per_order[oid] = float(r["TotalDue"])
        lines_per_order[oid] += 1
        qty[oid] += float(r["OrderQty"])

    values = sorted(per_order.values())
    n = len(values)
    mean, median, sd = statistics.mean(values), statistics.median(values), statistics.stdev(values)
    skew = sum(((x - mean) / sd) ** 3 for x in values) / n
    # excess kurtosis as pandas Series.kurt() (unbiased, Fisher), so a check with pandas/KNIME matches
    m2 = sum((x - mean) ** 2 for x in values); m4 = sum((x - mean) ** 4 for x in values)
    kurt = (n * (n + 1) * (n - 1) * m4 / m2 ** 2 - 3 * (n - 1) ** 2) / ((n - 2) * (n - 3))

    print(f"TotalDue per order, n={n:,}")
    print(f"  mean {mean:>10,.0f}   median {median:>10,.0f}   mean/median {mean / median:.2f}")
    print(f"  sd   {sd:>10,.0f}   IQR    {quantile(values, .75) - quantile(values, .25):>10,.0f}")
    print(f"  skewness {skew:.2f}   excess kurtosis {kurt:.2f}   (normal: 0 and 0)")
    print("  deciles " + " ".join(f"{quantile(values, i / 10):,.0f}" for i in range(1, 10)))

    print("\nPareto check:")
    for frac in (0.01, 0.05, 0.10, 0.20):
        k = int(n * frac)
        print(f"  top {frac:4.0%} of orders hold {sum(values[-k:]) / sum(values):6.1%} of revenue")
    print("  -> not 80/20. Quote the number, not the folklore.")

    # The mechanism is a documented column, not a line-count proxy:
    # OnlineOrderFlag separates two businesses inside one table.
    online_flag = {}
    for r in rows:
        online_flag[r["SalesOrderID"]] = r["OnlineOrderFlag"]
    small = [v for o, v in per_order.items() if online_flag[o] == "1"]   # online
    large = [v for o, v in per_order.items() if online_flag[o] == "0"]   # reseller
    print(f"\nTWO POPULATIONS in one column, named by OnlineOrderFlag:")
    print(f"  online   (flag=1): n={len(small):>6}  median {statistics.median(small):>10,.0f}"
          f"  max {max(small):>10,.0f}")
    print(f"  reseller (flag=0): n={len(large):>6}  median {statistics.median(large):>10,.0f}"
          f"  max {max(large):>10,.0f}"
          f"   ({statistics.median(large) / statistics.median(small):.0f}x apart)")

    ids = sorted(per_order)
    value, quantity = [per_order[i] for i in ids], [qty[i] for i in ids]
    print(f"\norder value vs total quantity:")
    print(f"  Pearson {pearson(value, quantity):.3f}   Spearman {spearman(value, quantity):.3f}")

    # ── the confounder: three correlations that only make sense together ──────
    revenue, products, orders_of = defaultdict(float), defaultdict(set), defaultdict(set)
    for r in rows:
        c = r["CustomerID"]
        revenue[c] += float(r["LineTotal"])
        products[c].add(r["ProductID"])
        orders_of[c].add(r["SalesOrderID"])
    cs = sorted(revenue)
    rev = [revenue[c] for c in cs]
    npr = [len(products[c]) for c in cs]
    nor = [len(orders_of[c]) for c in cs]
    print(f"\nthe confounder demo (per customer):")
    print(f"  revenue vs #distinct products : r={pearson(rev, npr):.3f}")
    print(f"  revenue vs #orders            : r={pearson(rev, nor):.3f}")
    print(f"  #orders vs #distinct products : r={pearson(nor, npr):.3f}")
    print("  -> all three are entangled by customer SIZE. No pair is evidence of a")
    print("     mechanism until size is held constant.")

    print("\nAnscombe's quartet, recomputed:")
    print(f"  {'set':<5}{'mean x':>9}{'var x':>8}{'mean y':>9}{'var y':>8}{'corr':>8}{'slope':>8}")
    for k, (x, y) in ANSCOMBE.items():
        mx, my = statistics.mean(x), statistics.mean(y)
        slope = sum((a - mx) * (b - my) for a, b in zip(x, y)) / sum((a - mx) ** 2 for a in x)
        print(f"  {k:<5}{mx:>9.2f}{statistics.variance(x):>8.2f}{my:>9.2f}"
              f"{statistics.variance(y):>8.3f}{pearson(x, y):>8.3f}{slope:>8.3f}")

    # ── emit plot data ───────────────────────────────────────────────────────
    # the same four sets as one CSV for the exercise sheet (Ex 2): the kit ships Data/*.csv,
    # the .dat files are only the deck's pgfplots input
    with open(DATA / "anscombe.csv", "w", newline="") as f:
        f.write("set,x,y\n")
        for k, (x, y) in ANSCOMBE.items():
            for a, b in zip(x, y):
                f.write(f"{k},{a},{b}\n")
    for k, (x, y) in ANSCOMBE.items():
        with open(DATA / f"anscombe_{k}.dat", "w") as f:
            f.write("x y\n")
            for a, b in zip(x, y):
                f.write(f"{a} {b}\n")

    # log-spaced histogram of TotalDue, as counts per bin
    lo, hi = math.log10(min(values)), math.log10(max(values))
    bins = 20
    counts = [0] * bins
    for v in values:
        counts[min(bins - 1, int((math.log10(v) - lo) / (hi - lo) * bins))] += 1
    with open(DATA / "totaldue_hist.dat", "w") as f:
        f.write("mid count\n")
        for i, c in enumerate(counts):
            mid = 10 ** (lo + (hi - lo) * (i + 0.5) / bins)
            f.write(f"{mid:.2f} {c}\n")

    # the same histogram split by the mechanism, to show the mixture
    for label, subset in (("small", small), ("large", large)):
        counts = [0] * bins
        for v in subset:
            counts[min(bins - 1, int((math.log10(v) - lo) / (hi - lo) * bins))] += 1
        with open(DATA / f"totaldue_hist_{label}.dat", "w") as f:
            f.write("mid count\n")
            for i, c in enumerate(counts):
                mid = 10 ** (lo + (hi - lo) * (i + 0.5) / bins)
                f.write(f"{mid:.2f} {c}\n")

    # The deepest valley is INSIDE the online orders: with a bike or without one.
    # Those two groups do not overlap at all (max 289 against min 597), while the
    # reseller orders overlap both. Same bins, so the three curves add up.
    has_bike = defaultdict(bool)
    for r in rows:
        if r["Category"] == "Bikes":
            has_bike[r["SalesOrderID"]] = True
    groups = {
        "online_nobike": [v for o, v in per_order.items() if online_flag[o] == "1" and not has_bike[o]],
        "online_bike":   [v for o, v in per_order.items() if online_flag[o] == "1" and has_bike[o]],
    }
    print("\nINSIDE the online orders, a bike or none:")
    for label, subset in groups.items():
        print(f"  {label:<14} n={len(subset):>6}  median {statistics.median(subset):>8,.0f}"
              f"  min {min(subset):>8,.1f}  max {max(subset):>8,.0f}")
        counts = [0] * bins
        for v in subset:
            counts[min(bins - 1, int((math.log10(v) - lo) / (hi - lo) * bins))] += 1
        with open(DATA / f"totaldue_hist_{label}.dat", "w") as f:
            f.write("mid count\n")
            for i, c in enumerate(counts):
                mid = 10 ** (lo + (hi - lo) * (i + 0.5) / bins)
                f.write(f"{mid:.2f} {c}\n")
    below = sum(1 for v in large if v <= max(small))
    print(f"  reseller orders at or below the online maximum: {below:,} of {len(large):,}")

    # scatter for the overplotting demo: every order line, value against quantity
    with open(DATA / "overplot.dat", "w") as f:
        f.write("x y\n")
        for r in rows:
            f.write(f"{float(r['OrderQty'])} {float(r['LineTotal']):.2f}\n")

    # ── overplotting: the broken version and the fix ─────────────────────────
    # A 121,317-point scatter is the DEMONSTRATION of overplotting, but putting
    # 121,317 marks in a PDF exceeds TeX's main memory -- so the slide plots a
    # subsample for the "broken" panel and this 2D density for the "fixed" one.
    xs = [float(r["OrderQty"]) for r in rows]
    ys = [float(r["LineTotal"]) for r in rows]
    nx, ny = 26, 22
    xlo, xhi = min(xs), max(xs)
    ylo, yhi = math.log10(max(min(ys), 0.01)), math.log10(max(ys))
    grid = defaultdict(int)
    for x, y in zip(xs, ys):
        if y <= 0:
            continue
        i = min(nx - 1, int((x - xlo) / (xhi - xlo) * nx))
        j = min(ny - 1, int((math.log10(y) - ylo) / (yhi - ylo) * ny))
        grid[(i, j)] += 1
    # Emit ONLY occupied cells. Writing the zeros too would paint every empty
    # region with the lightest step of the ramp, so "no data here" would look
    # like "a little data here" -- the ramp must start at 1, not at 0.
    with open(DATA / "overplot_density.dat", "w") as f:
        f.write("x y c\n")
        for (i, j), count in sorted(grid.items()):
            xm = xlo + (xhi - xlo) * (i + 0.5) / nx
            ym = 10 ** (ylo + (yhi - ylo) * (j + 0.5) / ny)
            f.write(f"{xm:.3f} {ym:.4f} {count}\n")
    occupied = len(grid)
    print(f"  density grid: {nx}x{ny} = {nx*ny} cells, {occupied} occupied, "
          f"busiest cell holds {max(grid.values()):,} of {len(rows):,} points "
          f"({max(grid.values())/len(rows):.1%})")

    # The left panel of the overplotting slide. All 121,317 points blow past
    # TeX's main memory, so we ship a deterministic every-Nth sample -- which is
    # itself the point of the slide: even 1-in-48 is already a solid smear.
    step = 48
    sample = rows[::step]
    with open(DATA / "overplot_sample.dat", "w") as f:
        f.write("x y\n")
        for r in sample:
            f.write(f"{float(r['OrderQty'])} {float(r['LineTotal']):.2f}\n")
    print(f"  overplot_sample.dat: 1-in-{step} sample, "
          f"{len(sample):,} of {len(rows):,} points")

    print(f"\nwrote anscombe_*.dat, totaldue_hist*.dat, overplot.dat "
          f"({len(rows):,} points), overplot_sample.dat, overplot_density.dat "
          f"to ../Data/")
