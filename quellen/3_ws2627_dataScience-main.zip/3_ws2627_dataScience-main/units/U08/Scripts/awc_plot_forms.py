"""
Unit 08 (EDA I) — one dataset, six geometries.

    python3 awc_plot_forms.py    -> ../Images/fig_u08_plot_forms{,_de}.pdf

Panels a-d are the SAME numbers: revenue (LineTotal) by product category, and
for c/d additionally split by order year.  Only the geometry changes, and with
it which comparison is cheap:

    a  pie            share of a whole      -- 86.2 % in one slice, three slivers
    b  bar, sorted    ranking               -- the same four numbers, rankable
    c  stacked bar    totals over time      -- totals aligned, middle bands not
    d  grouped bar    segments over time    -- segments aligned, totals gone

Panels c and d count LINE ITEMS rather than revenue, because revenue is 86 %
Bikes: on a revenue axis both stacks collapse to one visible band and the
stacked/grouped contrast -- the point of the pair -- would not be visible.

Panels e-f change the question, and no bar chart answers either:

    e  box plot       the distribution one bar hides
    f  scatter        do two variables move together?

VERIFIED (AWC/awc_flat.csv, 121,317 line items, orders 2011-2014):

    revenue by category      Bikes       94,651,173   86.17 %
                             Components  11,802,590   10.74 %
                             Clothing     2,120,543    1.93 %
                             Accessories  1,272,073    1.16 %

    line items by category   Accessories 41,194   <- sells the MOST line items
                             Bikes       40,031      and 1.16 % of the revenue
                             Clothing    21,394
                             Components  18,698

    line value, median       Bikes 1,944.0   Components 356.9
                             Clothing  54.0  Accessories 21.5

The pie is not a straw man: at these shares it is what a default BI tool draws.
Clothing (1.93 %) and Accessories (1.16 %) differ by a factor 1.7 and are
indistinguishable as slices; as sorted bars the ratio is read off the axis.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir() / "awc_flat.csv"
IMG = Path(__file__).resolve().parent.parent / "Images"
# the validated course palette (thwsbeamertheme.sty), in its fixed order
BLUE, ORANGE, AQUA, VIOLET = "#2A78D6", "#EB6834", "#1BAF7A", "#4545BF"
# colour follows the entity, as in U07 (classes in alphabetical order)
CATCOL = {"Accessories": BLUE, "Bikes": ORANGE, "Clothing": AQUA, "Components": VIOLET}

STR = {
    "en": dict(
        a="a  pie — share of a whole", b="b  sorted bar — a ranking",
        c="c  stacked — totals per year", d="d  grouped — segments per year",
        e="e  box — the spread in each", f="f  scatter — two variables",
        rev="revenue, million", cnt="order items, 1,000",
        val="item value (LineTotal)", qty="units per item",
        price="unit price", cats={k: k for k in CATCOL},
        cap="* part years: the orders run from the end of May 2011 to the end of June 2014"),
    "de": dict(
        a="a  Torte — Anteil am Ganzen", b="b  Balken, sortiert — eine Rangfolge",
        c="c  gestapelt — Summen je Jahr", d="d  gruppiert — Segmente je Jahr",
        e="e  Box — die Streuung je Gruppe", f="f  Scatter — zwei Variablen",
        rev="Umsatz, Mio.", cnt="Bestellpositionen, Tsd.",
        val="Positionswert (LineTotal)", qty="Menge je Position",
        price="Stückpreis",
        cats=dict(Bikes="Fahrräder", Components="Komponenten",
                  Clothing="Kleidung", Accessories="Zubehör"),
        cap="* Teiljahre: die Bestellungen reichen von Ende Mai 2011 bis Ende Juni 2014"),
}
plt.rcParams.update({"font.size": 5.5, "axes.titlesize": 5.8, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 150,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.02})


def load():
    d = pd.read_csv(AWC, usecols=["Category", "OrderDate", "LineTotal",
                                  "UnitPrice", "OrderQty"])
    d["year"] = pd.to_datetime(d.OrderDate).dt.year
    return d


def draw(d, lang):
    s = STR[lang]
    order = d.groupby("Category").LineTotal.sum().sort_values(ascending=False)
    cats = list(order.index)
    lab = [s["cats"][c] for c in cats]
    col = [CATCOL[c] for c in cats]
    piv = (d.pivot_table(index="year", columns="Category", values="LineTotal",
                         aggfunc="count").fillna(0)[cats] / 1e3)
    # 2011 and 2014 are part years; say so on the axis, not only in the caption
    years = [f"{y}*" if y in (2011, 2014) else str(y) for y in piv.index]

    fig, ax = plt.subplots(2, 3, figsize=(4.4, 2.1))   # authored at its size on the slide

    # a  pie
    ax[0, 0].pie(order.values, colors=col, startangle=90,
                 wedgeprops=dict(linewidth=0.4, edgecolor="white"))
    ax[0, 0].set_title(s["a"], loc="left")

    # b  bar, sorted
    ax[0, 1].bar(lab, order.values / 1e6, color=col, width=0.68)
    ax[0, 1].set_ylabel(s["rev"])
    ax[0, 1].set_title(s["b"], loc="left")

    # c  stacked
    bottom = np.zeros(len(piv))
    for c in cats:
        ax[0, 2].bar(years, piv[c], bottom=bottom,
                     color=CATCOL[c], width=0.62)
        bottom += piv[c].values
    ax[0, 2].set_ylabel(s["cnt"])
    ax[0, 2].set_title(s["c"], loc="left")

    # d  grouped
    x = np.arange(len(piv))
    w = 0.2
    for i, c in enumerate(cats):
        ax[1, 0].bar(x + (i - 1.5) * w, piv[c], width=w, color=CATCOL[c])
    ax[1, 0].set_xticks(x, years)
    ax[1, 0].set_ylabel(s["cnt"])
    ax[1, 0].set_title(s["d"], loc="left")

    # e  box, log scale
    bp = ax[1, 1].boxplot([d.LineTotal[d.Category == c].values for c in cats],
                          patch_artist=True, showfliers=False, widths=0.6,
                          medianprops=dict(color="black", linewidth=0.9))
    for patch, c in zip(bp["boxes"], col):
        patch.set(facecolor=c, alpha=0.75, linewidth=0.4)
    ax[1, 1].set_yscale("log")
    ax[1, 1].set_xticks(range(1, len(cats) + 1), lab)
    ax[1, 1].set_ylabel(s["val"])
    ax[1, 1].set_title(s["e"], loc="left")

    # f  scatter
    sub = d.sample(4000, random_state=0)
    # all categories at once: neutral grey, since blue means Accessories here
    ax[1, 2].scatter(sub.UnitPrice, sub.OrderQty, s=2, alpha=0.15,
                     color="#555555", linewidths=0)
    ax[1, 2].set_xscale("log")
    ax[1, 2].set_xlabel(s["price"])
    ax[1, 2].set_ylabel(s["qty"])
    ax[1, 2].set_title(s["f"], loc="left")

    for a in ax.ravel():
        a.tick_params(labelsize=4.8, length=2)
        for t in a.get_xticklabels():
            t.set_rotation(0)
    for a in (ax[0, 1], ax[1, 1]):
        for t in a.get_xticklabels():
            t.set_rotation(20)
            t.set_ha("right")
    ax[0, 0].set_ylabel("")

    handles = [plt.Rectangle((0, 0), 1, 1, facecolor=CATCOL[c]) for c in cats]
    fig.legend(handles, lab, loc="lower center", ncol=4, frameon=False,
               fontsize=5.2, bbox_to_anchor=(0.5, -0.06), handlelength=1.1,
               handleheight=0.8, columnspacing=1.4)
    # s["cap"] (the part-year note) is printed on the slide, next to the c/d bullet
    fig.tight_layout(pad=0.35, w_pad=1.0, h_pad=0.9)
    out = IMG / (f"fig_u08_plot_forms{'' if lang == 'en' else '_de'}.pdf")
    fig.savefig(out)
    plt.close(fig)
    return out


if __name__ == "__main__":
    d = load()
    rev = d.groupby("Category").LineTotal.sum().sort_values(ascending=False)
    print("revenue by category")
    for c, v in rev.items():
        print(f"  {c:12s} {v:14,.0f}  {v / rev.sum() * 100:5.2f} %")
    print("line items by category")
    for c, v in d.Category.value_counts().items():
        print(f"  {c:12s} {v:7,d}")
    print("median line value")
    for c, v in d.groupby("Category").LineTotal.median().sort_values(ascending=False).items():
        print(f"  {c:12s} {v:9,.1f}")
    for lang in ("en", "de"):
        print("wrote", draw(d, lang))
