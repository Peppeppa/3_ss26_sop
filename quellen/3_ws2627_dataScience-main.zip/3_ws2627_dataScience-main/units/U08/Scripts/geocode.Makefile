all:
	bash ./get_geo_codes.sh
	python3 ./geocode_awc_stateprovince.py awc_stateprovince_geocode_input.csv awc_stateprovince_geocoded.csv
	python3 ./clean_geocodes.py awc_stateprovince_geocoded.csv awc_stateprovince_geocoded_clean.csv
