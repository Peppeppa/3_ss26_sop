#!/usr/bin/env python3
r"""Check a categorical palette before it reaches a slide or a dashboard.

    python3 tools/validate_palette.py "#2A78D6,#EB6834,#1BAF7A,#4545BF" --mode light

Four checks, because a palette fails in four different ways:

  Lightness band   every swatch inside [0.45, 0.80] OKLab L on a light ground.
                   Too dark and it reads as "the emphasised one"; too light and
                   it disappears into the page.
  Chroma floor     OKLab C >= 0.10. Below that a hue reads as grey, and grey
                   has a job already: it means "nothing", the neutral midpoint
                   of a diverging scale (U08).
  CVD separation   worst pair >= 15 dE under protanopia, deuteranopia and
                   tritanopia, simulated with Vienot, Brettel & Mollon (1999).
  Normal vision    worst pair >= 20 dE with ordinary colour vision.

dE is CIE76 in CIELAB under D65 -- the plain Euclidean distance. CIEDE2000 is
the better metric for near matches and is not what this test is about: the
question here is "can these be told apart at a glance", not "do these match".

Greys are exempt from the chroma floor and the lightness band when passed as
--neutral, since a deliberate neutral is not a failed hue.

Exit status is 0 when every check passes, 1 otherwise, so it can gate a build.
"""
import argparse
import itertools
import math
import sys

import numpy as np

L_BAND = {"light": (0.45, 0.80), "dark": (0.55, 0.88)}
CHROMA_FLOOR = 0.10
CVD_FLOOR = 15.0
NORMAL_FLOOR = 20.0

_M_LMS = np.array([[17.8824, 43.5161, 4.11935],
                   [3.45565, 27.1554, 3.86714],
                   [0.0299566, 0.184309, 1.46709]])
_M_LMS_INV = np.linalg.inv(_M_LMS)
_SIM = {
    "protan": np.array([[0, 2.02344, -2.52581], [0, 1, 0], [0, 0, 1]]),
    "deutan": np.array([[1, 0, 0], [0.494207, 0, 1.24827], [0, 0, 1]]),
    "tritan": np.array([[1, 0, 0], [0, 1, 0], [-0.395913, 0.801109, 0]]),
}
_XYZ = np.array([[0.4124564, 0.3575761, 0.1804375],
                 [0.2126729, 0.7151522, 0.0721750],
                 [0.0193339, 0.1191920, 0.9503041]])
_WP = np.array([0.95047, 1.0, 1.08883])


def to_rgb(h: str) -> np.ndarray:
    h = h.strip().lstrip("#")
    if len(h) != 6:
        raise SystemExit(f"not a six-digit hex colour: #{h}")
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)


def _linear(rgb):
    c = np.asarray(rgb, float) / 255
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _encode(lin):
    c = np.clip(lin, 0, 1)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - 0.055) * 255


def oklab(rgb):
    m1 = np.array([[0.4122214708, 0.5363325363, 0.0514459929],
                   [0.2119034982, 0.6806995451, 0.1073969566],
                   [0.0883024619, 0.2817188376, 0.6299787005]])
    m2 = np.array([[0.2104542553, 0.7936177850, -0.0040720468],
                   [1.9779984951, -2.4285922050, 0.4505937099],
                   [0.0259040371, 0.7827717662, -0.8086757660]])
    return m2 @ np.cbrt(m1 @ _linear(rgb))


def lab(rgb):
    xyz = (_XYZ @ _linear(rgb)) / _WP
    f = np.where(xyz > (6 / 29) ** 3, np.cbrt(xyz), xyz / (3 * (6 / 29) ** 2) + 4 / 29)
    return np.array([116 * f[1] - 16, 500 * (f[0] - f[1]), 200 * (f[1] - f[2])])


def de76(a, b):
    return float(np.linalg.norm(lab(a) - lab(b)))


def simulate(rgb, kind):
    return _encode(_M_LMS_INV @ (_SIM[kind] @ (_M_LMS @ _linear(rgb))))


def worst_pair(hexes, rgbs):
    pairs = itertools.combinations(range(len(rgbs)), 2)
    return min(((de76(rgbs[i], rgbs[j]), hexes[i], hexes[j]) for i, j in pairs),
               default=(math.inf, "", ""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("palette", help="comma-separated hex colours")
    ap.add_argument("--mode", choices=sorted(L_BAND), default="light")
    ap.add_argument("--neutral", default="",
                    help="comma-separated hex colours that are deliberately grey")
    args = ap.parse_args()

    hexes = ["#" + h.strip().lstrip("#").upper() for h in args.palette.split(",") if h.strip()]
    neutral = {"#" + h.strip().lstrip("#").upper() for h in args.neutral.split(",") if h.strip()}
    if len(hexes) < 2:
        raise SystemExit("need at least two colours")
    rgbs = [to_rgb(h) for h in hexes]
    lo, hi = L_BAND[args.mode]
    ok = True

    out = [h for h, r in zip(hexes, rgbs)
           if h not in neutral and not (lo <= oklab(r)[0] <= hi)]
    if out:
        ok = False
        print(f"  [FAIL] Lightness band     outside band: "
              + ", ".join(f"{h} ({oklab(to_rgb(h))[0]:.3f})" for h in out))
    else:
        print(f"  [PASS] Lightness band     all within [{lo:.2f}, {hi:.2f}]")

    flat = []
    for h, r in zip(hexes, rgbs):
        _, a, b = oklab(r)
        if h not in neutral and math.hypot(a, b) < CHROMA_FLOOR:
            flat.append((h, math.hypot(a, b)))
    if flat:
        ok = False
        print("  [FAIL] Chroma floor       reads gray:   "
              + ", ".join(f"{h} ({c:.3f})" for h, c in flat))
    else:
        print(f"  [PASS] Chroma floor       all >= {CHROMA_FLOOR:.2f}")

    for kind in ("protan", "deutan", "tritan"):
        d, x, y = worst_pair(hexes, [simulate(r, kind) for r in rgbs])
        tag = "PASS" if d >= CVD_FLOOR else "FAIL"
        ok &= d >= CVD_FLOOR
        print(f"  [{tag}] CVD separation     worst {x} <-> {y}  dE {d:.1f} ({kind})")

    d, x, y = worst_pair(hexes, rgbs)
    tag = "PASS" if d >= NORMAL_FLOOR else "FAIL"
    ok &= d >= NORMAL_FLOOR
    print(f"  [{tag}] Normal-vision      worst {x} <-> {y}  dE {d:.1f}")

    print("  -> PASSED" if ok else "  -> FAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
