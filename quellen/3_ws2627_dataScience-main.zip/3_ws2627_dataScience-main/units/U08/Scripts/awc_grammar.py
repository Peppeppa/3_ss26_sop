"""
Unit 08 (EDA I) -- the grammar of graphics, named on real plots.

    python3 awc_grammar.py    -> ../Images/fig_u08_grammar{,_de}.pdf

The grammar slide lists five choices. A list is not yet vocabulary: a student can
recite "aesthetic" and still not point at one. So this figure POINTS, using the
words the portfolio will use.

Top panel: one plot, every part labelled where it physically sits.
Bottom row: the same DATA three times with exactly ONE choice swapped -- stat,
geom, coord. That is what "independent choices" means, and why "chart type" is
the wrong unit of thought: none of these is a different chart type, each is one
substitution.

The stat substitution is the one that earns its place. Revenue per category and
LINE ITEMS per category are the same table summarised two ways, and they do not
even agree on the ranking:

    revenue     Bikes 86.17 %  Components 10.74 %  Clothing 1.93 %  Accessories 1.16 %
    line items  Accessories 33.96 %  Bikes 33.00 %  Clothing 17.63 %  Components 15.41 %

Accessories is last by money and FIRST by count. Same data, same geometry, same
axes -- only the statistical transformation changed, and the answer inverted.

Every panel carries its limitation in one line, because "what this plot cannot
show" is the half students forget and the half that earns marks.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir() / "awc_flat.csv"
IMG = Path(__file__).resolve().parent.parent / "Images"
BLUE, ORANGE, GREY, TEAL = "#2A78D6", "#EB6834", "#8A8A8A", "#1B7A6B"
INK, NOTE = "#333333", "#5E5E5E"
ORDER = ["Bikes", "Components", "Clothing", "Accessories"]

STR = {
 "en": dict(
   title="One plot, five names",
   data="DATA  121,317 order items, four categories",
   geom="GEOM\nbars",
   aes="AESTHETIC\nheight carries revenue",
   stat="STAT\nsum per category",
   coord="COORD\ncartesian, linear",
   lim0="Cannot show: single orders, or the spread inside a category.",
   h2="Change exactly one choice; the data stay the same.",
   p1="STAT: sum $\\rightarrow$ count",
   p2="GEOM: bars $\\rightarrow$ dots",
   p3="COORD: linear $\\rightarrow$ log",
   l1="Ranking inverts: last by\nmoney, first by count.",
   l2="No length from zero:\nratios are hard to judge.",
   l3="Equal steps = equal ratios;\nbar length is not the value.",
   ylab="revenue, million", ylab1="order items, 1,000",
   cap="AWC, 121,317 order items, orders 2011-2014. The same items in every panel.",
 ),
 "de": dict(
   title="Ein Plot, fünf Namen",
   data="DATEN  121.317 Bestellpositionen, vier Kategorien",
   geom="GEOM\nBalken",
   aes="ÄSTHETIK\nHöhe trägt den Umsatz",
   stat="STAT\nSumme je Kategorie",
   coord="COORD\nkartesisch, linear",
   lim0="Zeigt nicht: einzelne Aufträge oder die Streuung in einer Kategorie.",
   h2="Genau eine Entscheidung ändern; die Daten bleiben gleich.",
   p1="STAT: Summe $\\rightarrow$ Anzahl",
   p2="GEOM: Balken $\\rightarrow$ Punkte",
   p3="COORD: linear $\\rightarrow$ log",
   l1="Rangfolge kippt: letzter beim\nGeld, erster bei der Anzahl.",
   l2="Keine Länge ab null:\nVerhältnisse schwer ablesbar.",
   l3="Gleiche Schritte = gleiche Verhält-\nnisse; Balkenlänge ist nicht der Wert.",
   ylab="Umsatz, Mio.", ylab1="Bestellpositionen, Tsd.",
   cap="AWC, 121.317 Positionen, Aufträge 2011-2014. Dieselben Positionen in jedem Bild.",
 ),
}


def load():
    d = pd.read_csv(AWC, usecols=["LineTotal", "Category"])
    rev = d.groupby("Category").LineTotal.sum().reindex(ORDER)
    cnt = d.Category.value_counts().reindex(ORDER)
    return rev, cnt


def short(lang):
    if lang == "de":
        return {"Bikes": "Fahrr.", "Components": "Komp.", "Clothing": "Kleid.", "Accessories": "Zub."}
    return {"Bikes": "Bikes", "Components": "Comp.", "Clothing": "Cloth.",
            "Accessories": "Access."}


def draw(rev, cnt, lang):
    s, lab = STR[lang], [short(lang)[c] for c in ORDER]
    x = np.arange(4)
    fig = plt.figure(figsize=(3.6, 3.15))   # authored at its size on the slide
    gs = fig.add_gridspec(2, 3, height_ratios=[1.35, 1.0],
                          hspace=1.05, wspace=0.55,
                          left=0.12, right=0.985, top=0.87, bottom=0.16)

    # ── top: one plot, every part named ──────────────────────────────────────
    ax = fig.add_subplot(gs[0, :])
    ax.bar(x, rev.to_numpy() / 1e6, width=0.58, color=BLUE, edgecolor="white", linewidth=0.5)
    ax.set_xticks(x); ax.set_xticklabels(lab, fontsize=6)
    ax.set_ylabel(s["ylab"], fontsize=5.3); ax.tick_params(labelsize=5)
    ax.set_ylim(0, 118)
    ax.set_title(s["title"], fontsize=7, color=INK, pad=10)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)

    arrow = lambda c: dict(arrowstyle="-|>", color=c, lw=0.75, shrinkA=2, shrinkB=3,
                           connectionstyle="arc3,rad=0.2")
    # annotation_clip=False on every one of them: matplotlib DROPS an annotation
    # without a word when its anchor sits outside the axes, and an anchor on the
    # axis line itself is exactly that borderline case. The COORD label vanished
    # twice before this was pinned down.
    ax.set_xlim(-0.62, 3.62)
    ax.annotate(s["geom"], annotation_clip=False, xy=(1.0, 8), xytext=(1.55, 44), fontsize=5, color=BLUE,
                ha="center", va="center", linespacing=1.35, arrowprops=arrow(BLUE))
    ax.annotate(s["aes"], annotation_clip=False, xy=(0.30, 92), xytext=(1.05, 105), fontsize=5, color=ORANGE,
                ha="center", va="center", linespacing=1.35, arrowprops=arrow(ORANGE))
    ax.annotate(s["stat"], annotation_clip=False, xy=(2.0, 4), xytext=(2.62, 46), fontsize=5, color=TEAL,
                ha="center", va="center", linespacing=1.35, arrowprops=arrow(TEAL))
    ax.annotate(s["coord"], annotation_clip=False, xy=(3.48, 1.0), xytext=(3.16, 70), fontsize=5, color=GREY,
                ha="center", va="center", linespacing=1.35, arrowprops=arrow(GREY))
    ax.text(0.0, 1.03, s["data"], transform=ax.transAxes, fontsize=5.2, color=INK)
    ax.text(0.0, -0.30, s["lim0"], transform=ax.transAxes, fontsize=5,
            color=NOTE, style="italic")

    fig.text(0.5, 0.455, s["h2"], ha="center", fontsize=6, color=INK)

    # ── bottom: one substitution each ────────────────────────────────────────
    a1 = fig.add_subplot(gs[1, 0])
    a1.bar(x, cnt.to_numpy() / 1e3, width=0.58, color=ORANGE, edgecolor="white", linewidth=0.4)
    a1.set_ylabel(s["ylab1"], fontsize=4.8)

    a2 = fig.add_subplot(gs[1, 1])
    a2.plot(x, rev.to_numpy() / 1e6, "o", color=TEAL, markersize=4.2)
    a2.set_ylim(0, 118)

    a3 = fig.add_subplot(gs[1, 2])
    a3.bar(x, rev.to_numpy() / 1e6, width=0.58, color=GREY, edgecolor="white", linewidth=0.4)
    a3.set_yscale("log"); a3.set_ylim(0.8, 300)

    for a, cap, lim in ((a1, s["p1"], s["l1"]), (a2, s["p2"], s["l2"]), (a3, s["p3"], s["l3"])):
        a.set_xticks(x); a.set_xticklabels(lab, fontsize=4.5, rotation=30, ha="right")
        a.tick_params(labelsize=4.5, length=2)
        for side in ("top", "right"):
            a.spines[side].set_visible(False)
        a.set_title(cap, fontsize=5.2, color=INK, pad=3)
        a.text(0.5, -0.50, lim, transform=a.transAxes, fontsize=4.8, color=NOTE,
               style="italic", ha="center", va="top", linespacing=1.35)

    out = IMG / f"fig_u08_grammar{'' if lang == 'en' else '_de'}.pdf"
    fig.savefig(out, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    return out


if __name__ == "__main__":
    rev, cnt = load()
    tot_r, tot_c = rev.sum(), cnt.sum()
    print("revenue / line items per category")
    for c in ORDER:
        print(f"  {c:12s} {rev[c]:14,.0f} ({rev[c]/tot_r*100:5.2f} %)   "
              f"{cnt[c]:7,d} ({cnt[c]/tot_c*100:5.2f} %)")
    print(f"  ranking by revenue: {list(rev.sort_values(ascending=False).index)}")
    print(f"  ranking by count:   {list(cnt.sort_values(ascending=False).index)}")
    for lang in ("en", "de"):
        print("wrote", draw(rev, cnt, lang))
