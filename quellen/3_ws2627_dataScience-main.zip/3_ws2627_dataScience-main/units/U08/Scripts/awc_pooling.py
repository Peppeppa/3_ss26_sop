"""
Unit 08 (EDA I) -- pooling two populations makes a correlation.

    python3 awc_pooling.py    -> ../Images/fig_u08_pooling{,_de}.pdf

Two panels on LINEAR axes, because Pearson is computed on linear values: on a
log axis the reader would not see why the pooled line is so steep.

    left   per order     quantity (sum OrderQty) vs value (TotalDue)
    right  per customer  distinct products vs revenue (sum LineTotal)

VERIFIED (AWC/awc_flat.csv, 31,465 orders, 19,119 customers):

                                   all      online    reseller
    order:    Pearson r           0.869    -0.135      0.811
              Spearman rho        0.215    -0.032      0.906
    customer: Pearson r           0.871     0.388      0.847

The online orders sit in a dense blob near the origin; the 3,806 reseller
orders spread far to the upper right. The pooled least-squares line (grey)
joins the two groups.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import spearmanr

IMG = Path(__file__).resolve().parent.parent / "Images"
BLUE, ORANGE, INK, NOTE = "#2A78D6", "#EB6834", "#333333", "#5E5E5E"


def find_extract():
    """AWC/awc_flat.csv in this folder or any folder above it."""
    for base in Path(__file__).resolve().parents:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    raise SystemExit("AWC/awc_flat.csv not found above this folder. Put your group's "
                     "extract there, or edit find_extract().")


STR = {
 "en": dict(t1="per order", t2="per customer",
            x1="quantity (sum of OrderQty)", y1="order value (TotalDue)",
            x2="distinct products bought", y2="revenue (sum of LineTotal)",
            on="online", res="reseller", all="all",
            blob1="all 27,659 online orders", blob2="all 18,484 online customers", fit="pooled line"),
 "de": dict(t1="je Bestellung", t2="je Kunde",
            x1="Menge (Summe OrderQty)", y1="Bestellwert (TotalDue)",
            x2="verschiedene gekaufte Produkte", y2="Umsatz (Summe LineTotal)",
            on="online", res="Reseller", all="alle",
            blob1="alle 27.659 Online-Bestellungen", blob2="alle 18.484 Online-Kunden", fit="gemeinsame Gerade"),
}


def load():
    d = pd.read_csv(find_extract())
    orders = d.groupby("SalesOrderID").agg(x=("OrderQty", "sum"), y=("TotalDue", "first"),
                                           f=("OnlineOrderFlag", "first"))
    cust = d.groupby("CustomerID").agg(x=("ProductID", "nunique"), y=("LineTotal", "sum"),
                                       f=("OnlineOrderFlag", "max"))
    return orders, cust


def fmt(v, lang):
    s = f"{v:.2f}".replace("-", "−")
    return s.replace(".", ",") if lang == "de" else s


def panel(ax, t, title, xl, yl, s, lang, blob):
    on, res = t[t.f == 1], t[t.f == 0]
    k, c0 = np.polyfit(t.x, t.y, 1)             # the pooled least-squares line
    xs = np.array([0, t.x.max()])
    ax.plot(xs, c0 + k * xs, color="#8A8A8A", lw=0.9, ls="-", zorder=1)
    ax.text(xs[1], c0 + k * xs[1], s["fit"], color=NOTE, fontsize=5.5, ha="right", va="bottom")
    ax.scatter(res.x, res.y, s=1.2, color=ORANGE, alpha=0.35, linewidths=0, rasterized=True)
    ax.scatter(on.x, on.y, s=1.2, color=BLUE, alpha=0.35, linewidths=0, rasterized=True)
    bx, by = on.x.median(), on.y.median()
    ax.annotate(blob, xy=(bx, by), xytext=(0.30, 0.10), textcoords="axes fraction", va="center",
                color=BLUE, fontsize=6, bbox=dict(fc="white", ec="none", pad=0.6),
                arrowprops=dict(arrowstyle="->", color=BLUE, lw=0.7, shrinkB=2))
    ax.set_title(title, fontsize=7.5, color=INK)
    ax.set_xlabel(xl)
    ax.set_ylabel(yl)
    ax.ticklabel_format(style="plain")
    ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(
        lambda v, _: f"{v/1000:.0f}k" if v else "0"))
    lines = [(s["all"], t, INK), (s["on"], on, BLUE), (s["res"], res, ORANGE)]
    for i, (name, g, col) in enumerate(lines):
        r = g.x.corr(g.y)
        ax.text(0.03, 0.97 - 0.10 * i, f"{name}:  r = {fmt(r, lang)}", transform=ax.transAxes,
                color=col, fontsize=6, va="top", fontweight="bold" if i == 0 else "normal")
    return {n: (g.x.corr(g.y), spearmanr(g.x, g.y)[0]) for n, g, _ in lines}


def draw(orders, cust, lang):
    s = STR[lang]
    fig, axes = plt.subplots(1, 2, figsize=(4.4, 1.6))
    a = panel(axes[0], orders, s["t1"], s["x1"], s["y1"], s, lang, s["blob1"])
    b = panel(axes[1], cust, s["t2"], s["x2"], s["y2"], s, lang, s["blob2"])
    fig.tight_layout(w_pad=1.5)
    name = "fig_u08_pooling" + ("" if lang == "en" else "_de")
    fig.savefig(IMG / f"{name}.pdf", bbox_inches="tight", dpi=300)
    plt.close(fig)
    return a, b


plt.rcParams.update({"font.size": 6, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#8A8A8A", "axes.linewidth": 0.5,
                     "xtick.color": NOTE, "ytick.color": NOTE,
                     "axes.labelcolor": INK, "pdf.fonttype": 42})

if __name__ == "__main__":
    orders, cust = load()
    for lang in ("en", "de"):
        a, b = draw(orders, cust, lang)
    print("per order    (Pearson, Spearman):", {k: tuple(round(v, 3) for v in x) for k, x in a.items()})
    print("per customer (Pearson, Spearman):", {k: tuple(round(v, 3) for v in x) for k, x in b.items()})
    print(f"orders {len(orders):,}, customers {len(cust):,} -> ../Images/fig_u08_pooling{{,_de}}.pdf")
