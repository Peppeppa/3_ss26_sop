---
source_id: DS-U08-L-EN
original_file: Unit08_slides_en.pdf
source_type: lecture
language: en
page_count: 40
source_sha256: c5f845a17146aec4ee2f0c18bd77a9a506eee76fe61fc2481f1f5bd379f92917
verification: partial
---
# Unit08_slides_en

[Original PDF](../../../quellen/Unit08_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit08_slides_en.pdf#page=1)

~~~~text
Data Science

EXPLORATORY DATA ANALYSIS:
STATISTICS & VISUALISATION


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit08_slides_en.pdf#page=2)

~~~~text
                                                                    LEARNING GOALS

    • Choose a summary that suits the shape — and split a column that holds several groups
    • Explain why identical statistics can describe different data, and plot before trusting
      them
    • Diagnose a relationship with Pearson against Spearman, and spot a correlation made
      by pooling
    • Read a conﬁdence interval correctly, and say when its promise fails
    • Pick a chart form from the question, and name a plot’s choices (data, stat, geom,
      aesthetic, coord)
    • Diagnose and repair truncated axes, dual axes, rainbow scales, 3D pies and
      overplotting
    • Assign colour by its job, and compute colour-blind safety rather than eyeball it
    • Check a derived column such as geocodes, and map rates with their counts

2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit08_slides_en.pdf#page=3)

~~~~text
    A STATISTIC IS A SUMMARY




3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit08_slides_en.pdf#page=4)

~~~~text
                                                        SHAPE DECIDES THE SUMMARY

     Shape             Recognise by                    Report                         Misleads
     Symmetric         mean ≈ median                   mean and standard              — the easy case
                                                       deviation (sd)
     Skewed            mean/median far from 1;         median and IQR (U04)           mean and sd: one large
                       skewness ̸= 0                                                  value moves both
     Heavy-tailed      excess kurtosis > 0;            median, IQR and the            sd, and any “normal”
                       extreme maxima                  maximum                        assumption
     Bimodal           two peaks; jumps                one summary per                every single number for
                       between deciles                 population                     the whole column
    Mode (most frequent value): the “typical” value for categories; unstable on continuous values.

    Two new numbers, and one that costs nothing
    Skewness: on which side the long tail is (0 = symmetric, > 0 = tail to the right). Excess kurtosis: how
    heavy the tails are compared with a normal distribution (0 = normal). pandas skew(), kurt(); KNIME
    Statistics node. mean/median: 1 = symmetric; far from 1 = skewed — and “the average” is the wrong
    word, before any plot.

4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit08_slides_en.pdf#page=5)

~~~~text
                                                       MEASURED: AWC ORDER VALUES

                               Real AWC: TotalDue per order, all n = 31,465 orders
                               mean              3,916    standard deviation       12,515
                               median              865    IQR                       2,553
                               mean / median      4.53    skewness                   5.83
                                                          excess kurtosis          40.55

                      decile    1     2     3      4       5       6           7        8      9
                      value    28    44    77   207      865   1,441   2,536        2,681   3,954


    mean/median 4.53, skewness 5.83, excess kurtosis 40.55 (normal: 1, 0, 0): right-skewed and
    heavy-tailed. So, by the table: report the median (865) and the IQR (2,553), not the mean.

    Look at the deciles
    Deciles 7 and 8 lie only 145 apart (2,536 and 2,681): a tenth of all orders is packed into that narrow
    band, and 99.5 % of them contain exactly one bike. Skew alone does not pack orders like that.
    Something structural is in this column.

5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit08_slides_en.pdf#page=6)

~~~~text
                                          MEASURED: THREE GROUPS IN ONE COLUMN




                     orders per bin
                                       8,000                                              online, with a bike
                                       6,000
                                                              online, no bike
                                       4,000                                                   grey: all 31,465 orders
                                       2,000                                                            reseller
                                           0
                                            100         101             102         103        104                 105

                                                               order value TotalDue (log scale)

                                      real AWC, per order                       n   median     min              max
                                      online, no bike in the order        12,454         44    2.5           289
                                      online, with a bike                 15,205      2,289    597         3,954
                                      reseller                             3,806      9,282     1.5      187,488

    • The deepest valley (about 300–600) splits online orders without and with a bike — no overlap at
      all.
    • U04’s split still holds: online and reseller medians are 14× apart (657 vs 9,282), and above 3,954
      there are only resellers. But the ﬂag does not explain the valley.
    • The mean of all orders, 3,916, matches none of the three medians.
6
~~~~

## Page 007

[Original page 7](../../../quellen/Unit08_slides_en.pdf#page=7)

~~~~text
                      PARETO: QUOTE THE NUMBER, NOT THE FOLKLORE

    The 80/20 rule (Pareto) says: the top 20 % of items hold 80 % of the total. Measured on real AWC,
    items = orders, total = TotalDue:

          share of revenue held by the top . . .   all 31,465 orders   3,806 reseller    27,659 online
           1 % of orders                                     24.1 %            5.6 %             3.4 %
           5%                                                65.8 %           22.3 %            16.8 %
          10 %                                               74.5 %           37.5 %            30.4 %
          20 %                                               82.7 %           59.8 %            53.1 %

    All orders: almost exactly 80/20. Each population alone: nowhere near it. Same company, same
    table, three answers.

    Where the 80/20 comes from: the mixture
    Resellers place 12 % of the orders and pay 74 % of the revenue; the top 5 % of all orders are all reseller
    orders. U04’s 2,127 IQR outliers are the top 6.8 % of this list and hold 70.9 % — the orders we refused
    to delete. Name the population and the unit (order or customer) with every concentration number.

7
~~~~

## Page 008

[Original page 8](../../../quellen/Unit08_slides_en.pdf#page=8)

~~~~text
  Break
10 minutes




Then: Correlation
~~~~

## Page 009

[Original page 9](../../../quellen/Unit08_slides_en.pdf#page=9)

~~~~text
    CORRELATION




9
~~~~

## Page 010

[Original page 10](../../../quellen/Unit08_slides_en.pdf#page=10)

~~~~text
                             ANSCOMBE’S QUARTET: SAME NUMBERS, FOUR PICTURES



     Four small datasets (11 points each) with the same statistics: mean and variance of x (9.00, 11.00),
     mean of y (7.50), variance of y (4.12–4.13), correlation r = 0.82, ﬁtted line y = 3.00 + 0.50 x.

                         I                     II                       III                       IV

         12                        12                       12                        12

          8                         8                        8                         8

          4                         4                        4                         4

               5    10        15        5     10    15            5    10     15            5    10    15


     I a straight-line relationship. II a clean curve — a line is the wrong model. III a perfect line plus one
     outlier that tilts it. IV ten points share x=8; a single point at x=19 creates the whole correlation.
     Plot before you trust a summary.               Anscombe (1973), recomputed: Scripts/awc_eda_data.py




10
~~~~

### DS-U08-L-EN-P010-D01 — Rekonstruktion

Anscombe quartet: four scatterplots with same fitted regression line; I linear, II curved, III line with influential outlier, IV ten x=8 and one x=19. Exact points not transcribed; Data/anscombe.csv in local kit.

## Page 011

[Original page 11](../../../quellen/Unit08_slides_en.pdf#page=11)

~~~~text
                            THREE COEFFICIENTS, THREE ASSUMPTIONS


                    Measures                       Assumes                       KNIME
      Pearson r     how well a straight line ﬁts   linearity; outliers move it   Linear Correlation
      Spearman ρ    a monotone trend:              only the order; robust        Rank Correlation
                    Pearson on the ranks
      Kendall τ     how many pairs are in the      only the order; often used    Rank Correlation
                    same order                     for small n and many ties

     Compute Pearson and Spearman — the gap says what to look for in the plot. On Anscombe’s four
     sets:
      set     r     ρ     what the gap says
        I   0.82   0.82   about equal ⇒ close to a straight line
      III   0.82   0.99   Spearman higher ⇒ monotone, but a curve or an outlier bends the line
      IV    0.82   0.50   Pearson higher ⇒ a few extreme points carry the line
       II   0.82   0.69   both mislead: the curve turns, so it is not monotone either


11
~~~~

## Page 012

[Original page 12](../../../quellen/Unit08_slides_en.pdf#page=12)

~~~~text
                                                  MEASURED: POOLING MAKES A CORRELATION

                                                                     per order                                                                   per customer




                                                                                                  revenue (sum of LineTotal)
                         order value (TotalDue)
                                                         all: r = 0.87              pooled line                                       all: r = 0.87
                                                         online: r = −0.14                                                     800k   online: r = 0.39
                                                  150k   reseller: r = 0.81                                                           reseller: r = 0.85
                                                                                                                               600k                             pooled line
                                                  100k
                                                                                                                               400k

                                                   50k                                                                         200k
                                                                    all 27,659 online orders                                                     all 18,484 online customers
                                                    0                                                                            0

                                                         0    100     200     300    400    500                                       0     25      50     75      100
                                                             quantity (sum of OrderQty)                                                    distinct products bought

     Left, per order (real AWC): online alone r = −0.14 — almost no relationship; resellers alone 0.81.
     Pooled 0.87, higher than either: the line runs from the online blob at the origin to the reseller cloud.
     Anscombe IV, with 3,806 points instead of one.

     A confounder: a third variable that drives both
     Right, per customer, the same effect: online 0.39, pooled 0.87. Tempting: “more different products
     → more revenue, so show customers more products”. But being a reseller raises both (median 24
     products and 45,503 revenue; online 3 and 270). Recompute within each population before you
     tell the story.

12
~~~~

### DS-U08-L-EN-P012-D01 — Rekonstruktion

Two scatterplots: per order x=sum OrderQty, y=TotalDue; pooled Pearson 0.87, online −0.14, reseller 0.81. Per customer x=distinct products, y=sum LineTotal; pooled 0.87, online 0.39, reseller 0.85. Pooled line connects populations; reseller status is confounder.

## Page 013

[Original page 13](../../../quellen/Unit08_slides_en.pdf#page=13)

~~~~text
                                                       CONFIDENCE INTERVALS, HONESTLY
                                                        √
     A 95 % conﬁdence interval (CI), mean ± 1.96 · sd/ n, promises: draw many samples, build one
     interval from each — 95 % of them contain the true mean. Tested on real AWC, with all 31,465 orders
     as the population (true mean known):
                     40 samples of 100 orders, one 95 % interval each            how often the interval contains the true mean
                             true mean 3,916               misses: 6 / 40   100 %
                                                                                     promised: 95 %
                                                                                                                       94.2 %
                                                                             90 %                             91.4 %
                                                                                                   88.0 %
                                                                             80 %
                                                                                        75.2 %
                                                                             70 %

                                                                             60 %

                                                                             50 %
                     0    2,000   4,000   6,000   8,000 10,000 12,000                 30         100        200    1,000
                                  order value (TotalDue)                                     orders per sample n


      • Left: one line per sample, its interval from low to high end. Orange lines miss the true mean — 6
        of 40, not the promised 2.
      • Right: with 30 orders only 75 % of the intervals hit; even 1,000 fall short of 95 %. Nearly all
        misses lie too low: a small sample usually holds none of the few large reseller orders.
     The formula assumes a well-behaved shape. Shape ﬁrst, then the summary, then its uncertainty.
13
~~~~

### DS-U08-L-EN-P013-D01 — Rekonstruktion

Left: 40 horizontal 95% intervals from n=100, vertical true mean 3916, 6 misses orange. Right: x sample n, y coverage %: (30,75.2), (100,88.0), (200,91.4), (1000,94.2). Dashed 95% reference. Formula $\bar x\pm1.96s/\sqrt n$.

## Page 014

[Original page 14](../../../quellen/Unit08_slides_en.pdf#page=14)

~~~~text
           Break
          10 minutes




Then: Every Plot Answers a Question
~~~~

## Page 015

[Original page 15](../../../quellen/Unit08_slides_en.pdf#page=15)

~~~~text
     EVERY PLOT ANSWERS A QUESTION




15
~~~~

## Page 016

[Original page 16](../../../quellen/Unit08_slides_en.pdf#page=16)

~~~~text
                                                                                      THE GRAMMAR OF GRAPHICS: FIVE NAMES

                                                             One plot, five names                                                          A plot is not a “chart type” but a set of
                               DATA 121,317 order items, four categories                                                                   independent choices:
                                                            AESTHETIC
                           100                        height carries revenue
     revenue, million




                                                                                                                                             • data — the table behind it
                            80                                                                           COORD
                            60                                                                       cartesian, linear                       • stat — how it is summarised (none, count,
                                                                         GEOM                  STAT                                            sum, mean)
                            40                                            bars            sum per category
                            20                                                                                                               • geom — what you see: points, lines, bars
                             0                                                                                                               • aesthetic — which property carries the value
                                        Bikes                 Comp.                Cloth.             Access.                                  (position, length, colour, size)
                               Cannot show: single orders, or the spread inside a category.
                                                                                                                                             • coord — the coordinate system (linear, log,
                                                 Change exactly one choice; the data stay the same.                                            map)
                                          STAT: sum → count                GEOM: bars → dots                 COORD: linear → log
                                   40
                                                                                                                                           Say it in this order
              order items, 1,000




                                                                    100                               102

                                   20                               50                                101                                  “On data X I applied stat Y, drew it as geom Z with
                                                                                                      100
                                                                                                                                           the value on aesthetic A, in coord B — so it cannot
                                   0                                 0
                                            s p. h. s.                   s   p.   h.    s.                      s p. h. s.                 show C.” In your portfolio, and when you present
                                        Bike Com Clot Acces          Bike Com Clot Acces                    Bike Com Clot Acces
                                                                                                                                           it.
                                         Ranking inverts: last by           No length from zero:            Equal steps = equal ratios;
                                          money, first by count.          ratios are hard to judge.         bar length is not the value.   Five of the components in Wickham (2010), which builds on
                                                                                                                                           Wilkinson (2005) and underlies ggplot2; the full grammar
                                                                                                                                           adds scales, position and facets.

16
~~~~

## Page 017

[Original page 17](../../../quellen/Unit08_slides_en.pdf#page=17)

~~~~text
                                                    PICK THE FORM FROM THE JOB

     The question                      The form                            Watch out for
     How is one variable spread?       histogram; box or violin            bin width changes the story
     Do two variables move together?   scatter; hexbin if dense            overplotting
     How did it change over time?      line                                gaps mean something (U05)
     Which category is bigger?         bar, sorted by value                must start at zero
     Same pattern across groups?       small multiples / facets            share the axes
     Many variables at once?           parallel coordinates; scatterplot   axis order changes the picture
                                       matrix
     What share of a whole?            bar; pie only if ≤ 6 and coarse     never for close values
     One headline number?              not a chart — a stat tile           a one-bar bar chart


     The rule that makes the table unnecessary
     Write the question above the plot before you draw it. No question, no plot. Then let the
     title state the answer: “Bikes carry 86% of revenue”, never “Revenue by category”.


17
~~~~

## Page 018

[Original page 18](../../../quellen/Unit08_slides_en.pdf#page=18)

~~~~text
                                                                                                             ONE DATASET, SIX GEOMETRIES

                                                   a pie — share of a whole                            b sorted bar — a ranking                                      c stacked — totals per year




                                                                                                                                          order items, 1,000
                                                                             revenue, million
                                                                                                 75                                                            40
                                                                                                 50
                                                                                                 25                                                            20
                                                                                                  0                                                            0
                                                                                                                                                                      2011* 2012 2013 2014*
                                                                                                      Bikems ponents Clothingcessories
                                                                                                       Co                 Ac
                                              d grouped — segments per year                            e box — the spread in each                                    f scatter — two variables




                                                                       item value (LineTotal)
                    order items, 1,000


                                         20                                                                                                                    30




                                                                                                                                          units per item
                                                                                                103
                                                                                                102                                                            20
                                         10
                                                                                                101                                                            10
                                         0                                                      100                                                             0
                                               2011* 2012 2013 2014*
                                                                                                      Bikems ponents Clothingcessories                              100   101       102      103
                                                                                                       Co                 Ac                                                    unit price
                                                                  Bikes                          Components              Clothing        Accessories
     • a/b — the same four revenue shares. Clothing 1.93 % against Accessories 1.16 % (factor 1.7) reads off an
       axis, not between two slivers.
     • c/d — stacked aligns the totals, grouped the segments; never both (* = part years: May 2011 to June 2014). e
       — a bar hides the spread: median item value 1,944 for Bikes, 21.5 for Accessories. f — two variables, which
       no bar answers.
     • Accessories has the most order items (41,194) and 1.16 % of the revenue — the geometry decides
       which fact lands.
18
~~~~

## Page 019

[Original page 19](../../../quellen/Unit08_slides_en.pdf#page=19)

~~~~text
                                                 NINE DIMENSIONS WITHOUT REDUCING THEM

                                                                 size                                          product mix
                                        1
                                                                                                                                            largest share
                                                                                                                                               Accessories
                                                                                                                                               Bikes
                                                                                                                                               Clothing

                   (size: log scale)
                                                                                                                                              Components
                      scaled 0..1

                                       0.5




                                        0

                                             revenue   orders   products   quantity   avg order    share      share    share     share
                                                                                        value   Accessories   Bikes   Clothing Components

     Parallel coordinates: one vertical axis per feature, one line per customer — U07’s nine features, kept
     instead of reduced to two. Real AWC, 18 customers from each class (equal numbers, not
     proportional).
      • Mix: each colour peaks on its own share axis — that is how the colour is deﬁned.
      • Size: the Components lines run high on orders, products and quantity: all 75 such customers are resellers.
        Bikes lines peak on average order value instead.
      • The trade: nothing is discarded, but the picture depends on the order of the axes and on the scaling, and
        beyond a few hundred lines it is overplotting again.
19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit08_slides_en.pdf#page=20)

~~~~text
     Break
   10 minutes




Then: Hands On — EDA I
~~~~

## Page 021

[Original page 21](../../../quellen/Unit08_slides_en.pdf#page=21)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit08_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit08_slides_en.pdf#page=22)

~~~~text
                                                           END OF EDA I — WHERE WE ARE

     Established so far
      • AWC order values are skewed and heavy-tailed (mean/median 4.53) — and hold three groups:
        online without a bike, online with a bike, reseller
      • Anscombe: the same statistics, four different pictures — plot before you trust a summary
      • Pooling two populations makes a correlation (r = 0.87, online alone −0.14); the confounder is
        being a reseller
      • A textbook 95 % interval covers the true mean in only 75 % of samples of 30 orders
      • A plot is a set of choices (data, stat, geom, aesthetic, coord); the geometry decides which
        comparison is easy


     Still ahead: EDA II
     How a plot lies, and how to repair it · colour — and testing a palette · geodata: coordinates AWC does not have,
     derived and checked

     In presence, EDA II is the second date.
22
~~~~

## Page 023

[Original page 23](../../../quellen/Unit08_slides_en.pdf#page=23)

~~~~text
     HOW PLOTS LIE




23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit08_slides_en.pdf#page=24)

~~~~text
                                                                                 THE FOUR BIG ONES

      Defect                     Why it misleads                                 Fix
      Truncated y-axis on bars   bar length encodes the value; cutting the       bars start at 0; use a line or a
                                 axis rescales every comparison                  zoomed inset instead
      Dual y-axis                the alignment of the two scales is arbitrary,   two charts, small multiples, or
                                 so the chart invents a correlation              index both to 100 at t0
      Rainbow colour scale       not perceptually uniform: invents bands         one hue, light → dark
                                 where the data is smooth
      3D pie / 3D bars           perspective changes apparent size: the          2D. Always.
                                 front slice shows its side and looks larger;
                                 occlusion hides data


     In the words of the grammar
     A truncated bar axis breaks the aesthetic “length = value”. A dual axis puts two y-scales
     into one coord, and their alignment is arbitrary — so any two series can be made to look
     alike. A rainbow is a colour scale whose hues have no order.

24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit08_slides_en.pdf#page=25)

~~~~text
                                                                                          THE SAME NUMBERS, FOUR WAYS TO LIE

                                                                      Truncated axis                                           Dual axis                                 Rainbow scale                                                    3D pie

                                                                  13Q3 vs 12Q1: looks 5×                                 two y-axes: grew alike?                yellow or cyan: which is more?1
                                                                 14                                                                                                                         10                              13Q4 looks largest (in front)
                                                                                                                       12                      6                 Bikes                                                                         13Q2




                                                                                                                                                                                                  revenue, million (log)
                                                                                   7.8




                                              revenue, million




                                                                                                    revenue, million
                 how it misleads




                                                                                                                                               orders, 1,000
                                                                 11                                                                                            Comp.                        100                               13Q3
                                                                                                                       10                      4
                                                                                                                                                                                                                                                        13Q1
                                                                  8 1.5                                                                                         Cloth.                      10−1
                                                                                                                        8                      2                                                                                           13Q4
                                                                                                                                                               Access.
                                                                 5
                                                                      12Q1                                              6                                                                   10−2
                                                                      12Q2
                                                                      12Q3
                                                                      12Q4
                                                                      13Q1
                                                                      13Q2
                                                                      13Q3
                                                                      13Q4




                                                                                                                             12Q1
                                                                                                                             12Q2
                                                                                                                             12Q3
                                                                                                                             12Q4
                                                                                                                             13Q1
                                                                                                                             13Q2
                                                                                                                             13Q3
                                                                                                                             13Q4




                                                                                                                                                                         12Q1
                                                                                                                                                                         12Q2
                                                                                                                                                                         12Q3
                                                                                                                                                                         12Q4
                                                                                                                                                                         13Q1
                                                                                                                                                                         13Q2
                                                                                                                                                                         13Q3
                                                                                                                                                                         13Q4
                 the same numbers, repaired




                                                                 really 2.0× (12.78 vs 6.51)                            orders 7.9×, revenue 1.9×                        darker = more                                     13Q3 is larger (12.78 vs 12.19)
                                                                                                                       800                                                                  101


                                                                                               index, 12Q1 = 100
                                                                                                                               revenue                           Bikes                                                     13Q3




                                                                                                                                                                                                  revenue, million (log)
                                              revenue, million




                                                                                                                       600     orders
                                                                 10                                                                                            Comp.                        100                            13Q4
                                                                                                                       400                                      Cloth.                                                     13Q2
                                                                  5                                                                                                                         10−1
                                                                                                                       200                                     Access.                                                     13Q1
                                                                  0                                                                                                                         10−2
                                                                                                                                                                                                                                  0       5        10
                                                                      12Q1
                                                                      12Q2
                                                                      12Q3
                                                                      12Q4
                                                                      13Q1
                                                                      13Q2
                                                                      13Q3
                                                                      13Q4




                                                                                                                             12Q1
                                                                                                                             12Q2
                                                                                                                             12Q3
                                                                                                                             12Q4
                                                                                                                             13Q1
                                                                                                                             13Q2
                                                                                                                             13Q3
                                                                                                                             13Q4




                                                                                                                                                                         12Q1
                                                                                                                                                                         12Q2
                                                                                                                                                                         12Q3
                                                                                                                                                                         12Q4
                                                                                                                                                                         13Q1
                                                                                                                                                                         13Q2
                                                                                                                                                                         13Q3
                                                                                                                                                                         13Q4
                                                                                                                                                                                                                                      revenue, million
     Real AWC, the eight complete quarters (12Q1 = ﬁrst quarter of 2012); revenue = sum of LineTotal.
     Top: what the defect makes you believe; below: the same numbers, repaired, and what is true.
     Nothing was falsiﬁed. Ask of every chart: where does the axis start, and how many scales are
     in the frame?
25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit08_slides_en.pdf#page=26)

~~~~text
                                            OVERPLOTTING: A SCATTER SHOWS WHERE, NOT HOW MUCH




                   item value (LineTotal)
                                                       raw scatter                    2D density, one hue
                                                                                                              ·104
                                              4                               4
                                            10




                                                                                                                           items per cell
                                                                            10                                       1


                                            102                             102                                      0.5


                                            100                             100                                      0
                                                  0       20           40         0          20          40

                                                      order quantity                    order quantity

     Real AWC, all 121,317 order items (one product in one order, one row of the extract). Left: every 48th
     item (2,528 points) at 35 % opacity. The column at quantity 1 is solid: 62 % of all items sit on it, and
     the scatter cannot show how many. Right: all items counted per cell, one hue, empty cells left blank.
     The busiest cell holds 12,376 items, 10 %: one or two units for 32–50, more than half of them
     Sport-100 helmets. No opacity can show that.
     Other ﬁxes: jitter (made for a discrete axis like this one), hexbin, or a random sample named in the
     caption.

26
~~~~

## Page 027

[Original page 27](../../../quellen/Unit08_slides_en.pdf#page=27)

~~~~text
       Break
     10 minutes




Then: Colour Has Four Jobs
~~~~

## Page 028

[Original page 28](../../../quellen/Unit08_slides_en.pdf#page=28)

~~~~text
     COLOUR HAS FOUR JOBS




28
~~~~

## Page 029

[Original page 29](../../../quellen/Unit08_slides_en.pdf#page=29)

~~~~text
                                                               COLOUR HAS FOUR JOBS: ONE RULE EACH

                 Identity: one colour per category                  Magnitude: one hue                                                                                                         Polarity: two hues, grey middle                           State: colour + icon + word
                                          Bikes                                                                                 101                                                            +40 %
                                101




                                                                                                                                                                  change vs previous quarter
                                                          Accessories                                                                                                                                                                                                      ✓ ok: 160
                                                                                                                                                                                               +30 %
       revenue, million (log)




                                                                                                                                         revenue, million (log)
                                100       Components                                                                            10   0
                                                                                                                                                                                               +20 %
                                                                Bikes
                                          Clothing
                                                                                                                                                                                               +10 %                                                               ! flagged: 19
                                          Accessories
                                                             Clothing
                                10−1                                                                                            10−1                                                            +0 %

                                                                                                                                                                                                -10 %
                                                          Components
                                                                                                                                                                                                                                                               ✗ not found: 2
                                10−2                                                                                            10−2                                                            -20 %
                                                                                                                                                                                                                                                               0           200
                                       12Q1
                                       12Q2
                                       12Q3
                                       12Q4
                                       13Q1
                                       13Q2
                                       13Q3
                                       13Q4




                                                                        12Q1
                                                                               12Q2
                                                                                      12Q3
                                                                                             12Q4
                                                                                                    13Q1
                                                                                                           13Q2
                                                                                                                  13Q3
                                                                                                                         13Q4




                                                                                                                                                                                                        12Q2
                                                                                                                                                                                                               12Q3
                                                                                                                                                                                                                      12Q4
                                                                                                                                                                                                                             13Q1
                                                                                                                                                                                                                                    13Q2
                                                                                                                                                                                                                                           13Q3
                                                                                                                                                                                                                                                  13Q4
                                                                                                                                                                                                                                                                state/provinces

     Identity (categorical)                             ﬁxed hue order, never cycled; the colour follows the entity through every plot (Bikes is
                                                        orange everywhere). Not a light-to-dark ramp on categories
     Magnitude (sequential)                             one hue, light → dark: darker = more
     Polarity (diverging)                               two opposed hues for down and up, grey for “no change” (here: under 5 %); hues not
                                                        used for identity
     State (status)                                     reserved for good/bad, always with an icon and a word — red and green alone fail for
                                                        colour-blind readers
     Real AWC, the eight complete quarters; right: the geocoding check of the next section. Scheme types after
     Harrower & Brewer (2003) (ColorBrewer); status as a fourth job is this course’s addition.
29
~~~~

## Page 030

[Original page 30](../../../quellen/Unit08_slides_en.pdf#page=30)

~~~~text
                       COLOUR-BLIND READERS: COMPUTE IT, DO NOT EYEBALL IT


                            the old palette, normal vision                               the old palette, protanopia                                   the new palette, protanopia




                            Bikes vs Clothing: ΔE = 110.7                                 Bikes vs Clothing: ΔE = 1.5                                  Bikes vs Clothing: ΔE = 22.2
                                                                         Accessories           Bikes          Clothing          Components
                                   U07's PCA sample, 2,000 customers, coloured by dominant category. Panels 2 and 3 are simulated with the same transform validate_palette uses.

     Not AWC data this time — the colours of this course. The U07 cluster plot, drawn three times; panels
     2 and 3 simulate protanopia (about 1 in 100 men; some red–green deﬁciency: about 1 in 12,
     Birch 2012).
      • Old palette: Bikes and Clothing separate by ∆E = 1.5 under protanopia — the same olive — and the plot still
        looks ﬁne. Nobody noticed by looking; one validator command found it.
      • New palette: ∆E = 22.2. The ﬁrst replacement still failed (its violet was too dark for a light background) —
        re-run the check after every ﬁx.
      • Aqua has only 2.8 : 1 contrast on white, so every plot here names its colours in a legend or a label: identity
        never rests on colour alone.
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit08_slides_en.pdf#page=31)

~~~~text
          Break
         10 minutes




Then: Geodata: Derive, Then Check
~~~~

## Page 032

[Original page 32](../../../quellen/Unit08_slides_en.pdf#page=32)

~~~~text
     GEODATA: DERIVE, THEN CHECK




32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit08_slides_en.pdf#page=33)

~~~~text
                                                            THE THREE THINGS TO KNOW


      • A coordinate needs a reference system. “49.79, 9.95” is Würzburg only once you say
        WGS84 (the GPS standard). Two data sets in different systems can put the same
        street a few hundred metres apart.
      • Every ﬂat map distorts something. Web Mercator keeps angles and inﬂates area away
        from the equator: Greenland looks as large as Africa, which is 14 times larger. Never
        compare areas on a Mercator map.
      • GeoJSON is JSON with an agreed shape (Point, LineString, Polygon), so U03’s rules
        apply — and it writes longitude ﬁrst:

      1   {"type": "Point", "coordinates": [9.95, 49.79]}

     Two operations carry most practical work: point-in-polygon (which region is this customer
     in?) and distance (which store is nearest?) — and on a sphere the second one is not
     Pythagoras.

33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit08_slides_en.pdf#page=34)

~~~~text
                              GEOCODING: A DERIVED COLUMN NEEDS A CHECK

     Many data sets have place names but no coordinates. Geocoding looks each name up in a map
     database — for example Nominatim1 , the free search of OpenStreetMap, like typing it into a map
     app. It often returns an answer even for a misspelled name, so keep what it says about what it found,
     and check it.

                             Example: AWC’s 181 states and provinces
                             name in the data               should be         the map search returned
                             Pyrénées (Hautes)              Hautes-Pyrénées   a bus stop
                             Saône (Haute)                  Haute-Saône       a pond
                             La Vendée                      Vendée            a river
                             Toubs                          Doubs             nothing — a typo

     Of 181 names, 2 found nothing — and 19 of the 179 answers were wrong, with no error raised — the
     cause an input defect of the kind U04 teaches. The check: keep the type of place the service reports
     and accept only administrative regions. It rejects all 19.
     1
         nominatim.org — open-source geocoding on OpenStreetMap data


34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit08_slides_en.pdf#page=35)

~~~~text
                                           A MAP OF TOTALS IS A MAP OF CUSTOMERS

                                   total revenue                                                   revenue per customer

                                              Ontario                                                              Ontario
             Washington                                                           Washington




               California                                                            California


                                   Texas                                                                 Texas



                                                                      1 million                                                            100,000




       • Left, the total: California leads (15.5 M) because it has the most customers (4,509) — a map of totals mostly
         shows where customers are.
       • Right, the rate: California nearly vanishes (3,433 per customer); Texas is large (170,677) with 39 customers,
         35 of them resellers. The biggest circles are states with a handful of customers — a rate on few cases
         swings, so show the count beside it, and map both.
     Real AWC, all 19,119 customers, revenue = sum of LineTotal. Circle area = value; positions: the checked geocoding; longitude × cos 45◦ and latitude
     on linear axes; outlines: Natural Earth.

35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit08_slides_en.pdf#page=36)

~~~~text
     Break
    10 minutes




Then: Hands On — EDA II
~~~~

## Page 037

[Original page 37](../../../quellen/Unit08_slides_en.pdf#page=37)

~~~~text
           HANDS ON — EXERCISE 3
                           20 minutes
        Sheet on Moodle: Unit08_Exercises_en.pdf

     One exercise, twenty minutes: build the lie and its honest twin.




37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit08_slides_en.pdf#page=38)

~~~~text
                     MILESTONE 2
        Structure — what the data looks like from the inside
        20 % of the module · one archive M2_G<nn>.zip
              Due date: see the course overview in Moodle

  One upload, four parts — built across U06, U07 and today:
  1. the cleaned ﬂat table — your M1 log, executed
  2. the similarity study from U06 — measure chosen, and why
  3. the cluster analysis from U07 — PCA, t-SNE, ARI
  4. ﬁve plots, each titled with its answer, each revised after
     peer review

Graded on: does every plot answer a stated question, is every title
                          defensible?
— not on how attractive it is. “No crisp cluster structure” is a valid ﬁnding.
~~~~

## Page 039

[Original page 39](../../../quellen/Unit08_slides_en.pdf#page=39)

~~~~text
                                                                                         SUMMARY


     • Shape decides the summary — and one column can hold several groups: summarise each
     • Plot before you trust a statistic (Anscombe); Pearson against Spearman says what to look for
     • Pooling two populations makes a correlation — recompute within each before you tell the story
     • A 95 % interval promises coverage that a skewed shape can break
     • A plot is a set of choices; pick the form from the question, and let the title state the answer
     • Ask of every chart where the axis starts and how many scales are in the frame
     • Colour has four jobs — and colour-blind safety is computed, not eyeballed
     • A derived column needs a check; a map of totals shows where the customers are, so map rates
       with their counts
     • Next: Block 9 — Dashboards, Communication & ML-Readiness




39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit08_slides_en.pdf#page=40)

~~~~text
                                                        SOURCES & FURTHER READING

     • Anscombe (1973), Graphs in Statistical Analysis, The American Statistician 27(1) — the quartet
       doi.org/10.1080/00031305.1973.10478966
     • Wilkinson (2005), The Grammar of Graphics, 2nd ed., Springer
     • Wickham (2010), A Layered Grammar of Graphics, J. Comput. Graph. Stat. 19(1), 3–28 — the ﬁve names;
       ggplot2
       doi.org/10.1198/jcgs.2009.07098
     • Tufte (2001), The Visual Display of Quantitative Information, 2nd ed., Graphics Press — small multiples
     • Cleveland & McGill (1984), Graphical Perception, JASA 79(387) — which encodings people read accurately
       doi.org/10.1080/01621459.1984.10478080
     • Harrower & Brewer (2003), ColorBrewer.org, The Cartographic Journal 40(1), 27–37 — categorical, sequential,
       diverging
       doi.org/10.1179/000870403235002042
     • Crameri, Shephard & Heron (2020), The misuse of colour in science communication, Nature Communications
       11 — why rainbow scales mislead
       doi.org/10.1038/s41467-020-19160-7
     • Birch (2012), Worldwide prevalence of red-green color deﬁciency, JOSA A 29(3), 313–320
       doi.org/10.1364/JOSAA.29.000313


40
~~~~
