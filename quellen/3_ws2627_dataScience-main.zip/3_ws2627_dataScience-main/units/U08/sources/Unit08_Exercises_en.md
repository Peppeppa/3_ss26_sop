---
source_id: DS-U08-EX
original_file: Unit08_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: f704c3c6c6c0baf698806f8d0604a6ad73c86527cceef1bd561edf67e64846bd
verification: partial
---
# Unit08_Exercises_en

[Original PDF](../../../quellen/Unit08_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit08_Exercises_en.pdf#page=1)

<a id="ds-u08-ex-t01"></a>

**DS-U08-EX-T01 — Shape Before Summary**

<a id="ds-u08-ex-t02"></a>

**DS-U08-EX-T02 — Anscombe, and Your Own Correlations**

<a id="ds-u08-ex-t03"></a>

**DS-U08-EX-T03 — Break a Plot on Purpose**

~~~~text
  Unit 08 — Exercises                                                           Exploratory Data Analysis (EDA I and II)
Predict a shape before you plot it, then break a plot on purpose.
▶ In the room             what ﬁts the stop — all that is expected. The room splits at the EDA I stop: take one of Exercises 1
                          and 2; you hear the other one in the discussion.
⃝ Extra                   voluntary, at home.
EDA I stop, 20 min        Exercise 1 or 2      EDA II stop, 20 min: Exercise 3
Asynchronous              the same sheet, before your weekly slot; bring what did not run.
You need                  your ﬂat table AWC/awc_flat.csv and the unit’s Data/ and Scripts/ folders. The unit runs over two
                          dates: EDA I = statistics and choosing the picture, EDA II = how plots lie, colour.

Exercise 1 — Shape Before Summary EDA I stop · ▶ 20 min · or Exercise 2
 1 Make one row per order (TotalDue per SalesOrderID). Compute mean, median, sd, IQR, mean/median, skewness and
   excess kurtosis. Write down the shape you expect — before you plot.
      Example — one row per order, two of the seven numbers

      o = flat.groupby("SalesOrderID").TotalDue.first()            # TotalDue repeats on every line
      print(o.mean() / o.median(), o.skew())                       # the other five the same way

 2 Plot the histogram on a log x-axis. Was your prediction right? How many peaks?
 3 Plot it with 10, 30 and 100 bins. Which features are in all three? Only those are ﬁndings.
  In KNIME
  GroupBy on SalesOrderID (First of TotalDue) → Statistics (skewness, kurtosis) → Math Formula log10($TotalDue$) →
  Histogram of that column. Label the axis in powers of ten (2 = $100, 3 = $1,000).

⃝ Extra: (a) If there is more than one peak: ﬁnd the column that splits it and give the median of each group. On the full data
one column is not enough. (b) Compute the share of revenue held by the top 1, 5, 10 and 20 % — once per order, once per
customer. Is it 80/20? State both answers. Kit: Scripts/awc_eda_data.py.
Exercise 2 — Anscombe, and Your Own Correlations EDA I stop · ▶ 20 min · or Exercise 1
 1 Load the four sets from Data/anscombe.csv (column set = I–IV). For each, compute mean, variance and correlation —
   they must match. Then plot all four.
 2 Pick two AWC variables, e.g. order value and quantity per order. Compute Pearson and Spearman. What does the differ-
   ence tell you about the shape? Plot it and check.
  Example — both coefﬁcients in one line each

  from scipy.stats import pearsonr, spearmanr
  print(pearsonr(x, y)[0], spearmanr(x, y)[0])              # x, y: two columns, one row per order

  In KNIME
  CSV Reader → GroupBy on set (mean, variance) → Linear Correlation (Pearson) and Rank Correlation (Spearman), with a Row
  Filter per set.

⃝ Extra: ﬁnd a strong AWC correlation that is not a mechanism. Name the hidden third variable and how you would check
it. Then compute the correlation inside each OnlineOrderFlag group: how much is left? Kit: Scripts/awc_pooling.py.
Exercise 3 — Break a Plot on Purpose EDA II stop · ▶ 20 min
 1 Take one honest ﬁnding — e.g. revenue per quarter, complete quarters only — and build a misleading chart of it: cut the
   axis, or use a second y-axis. Build the honest version next to it, from the same data.
 2 Write the misleading headline the bad chart supports, and the accurate one the good chart supports.
 3 Run your colours through the colour-blindness check. If they pass at once, try a palette that fails, so you have seen a
   failure:
       python3 Scripts/validate_palette.py "#2A78D6,#EB6834,#1BAF7A,#4545BF" --mode light              # put in your colours
    It prints PASS or FAIL per check.
  In KNIME
  Bar Chart or Line Plot: set the axis range yourself in the view’s options — once from 0, once not.

⃝ Extra: ﬁnd overplotting in one of your plots and ﬁx it two ways: opacity or jitter, and binning. Which one answers your
question better? Kit: Scripts/awc_chart_defects.py, awc_grammar.py, awc_plot_forms.py.




Unit 08 · Data Science · exercise sheet                                                                                          1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit08_Exercises_en.pdf#page=2)

<a id="ds-u08-ex-t04"></a>

**DS-U08-EX-T04 — Five Questions, Five Plots**

~~~~text
Exercise 4 — Five Questions, Five Plots ⃝ Extra · takes real time
 1 Write ﬁve questions about AWC. For each, choose the chart type with the form table from the slides — and say why.
 2 Build all ﬁve. Each title states the answer, not the variables; add one or two sentences on what to read.
 3 Build a facet plot: revenue per quarter, one panel per product category, shared axes, complete quarters only. What does
   it show that the total hides?

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: your predicted shape, whether the histogram agreed, and what survived all three bin counts
• Ex 2: Anscombe reproduced, and Pearson against Spearman on two AWC variables
• Ex 3: the misleading chart and its honest twin, with both headlines; your palette check, and a palette you saw fail




Unit 08 · Data Science · exercise sheet                                                                                 2
~~~~
