---
source_id: DS-U02-L-EN
original_file: Unit02_slides_en.pdf
source_type: lecture
language: en
page_count: 38
source_sha256: 1815d107d0db06bd983de8738d2fab2c320b0159a1e4790e9c24d7ae1c1764b1
verification: partial
---
# Unit02_slides_en

[Original PDF](../../../quellen/Unit02_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit02_slides_en.pdf#page=1)

~~~~text
Data Science

FROM THE SQL CONSOLE TO A
PROGRAM


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit02_slides_en.pdf#page=2)

~~~~text
                                                             LEARNING GOALS



    • Tell an OLTP from an OLAP system, and say why analysis runs on a copy — a
      data warehouse in industry, one ﬂat ﬁle in this course
    • Place ODBC, JDBC and Python’s DB-API between program and database, and
      steer a session: commit, rollback, autocommit
    • Decide where the work runs — SQL, ORM, pandas or KNIME DB nodes — and
      write queries that user input cannot change
    • Turn a manual export into a re-runnable extract that carries its own proof




2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit02_slides_en.pdf#page=3)

~~~~text
                                              THE QUESTION OF THIS UNIT



        How do the data get from the business system into our analysis —
           and how do we prove next week that it is the same data?



           Source              Connect              Query               Extract


    In U01 you built the ﬂat table by hand, in the console. Could you — or a group
    member — rebuild it exactly in four weeks? Where is the record of which query
    made which ﬁle?
    Today the clicks become a program.

3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit02_slides_en.pdf#page=4)

~~~~text
    STEP 1: WHERE ANALYSIS DATA COMES FROM


      Source    Connect   Query     Extract




4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit02_slides_en.pdf#page=5)

~~~~text
                                   RUNNING THE BUSINESS VS. ANALYSING IT

                 OLTP — operative data                              OLAP — dispositive data

    job          run the business: orders, billing, stock           support decisions: plan, steer, compare
    access       many short reads and writes of single rows         few long reads over millions of rows
    data         current state, overwritten on change               history, appended, cleaned
    sources      one application                                    many, integrated
    users        clerks, the web shop                               analysts, controllers, data scientists
    example      AWC: an order is placed — a row is written         AWC: “which category carried our growth?”
    OLTP = online transaction processing, OLAP = online analytical processing. German literature: operative vs.
    dispositive data (Kemper, Baars & Mehanna, 2010).


    Consequence
    A long analysis query on the live system slows the business down, and the data change
    while you read them. So analysis runs on a copy.


5                           Source              Connect             Query               Extract
~~~~

## Page 006

[Original page 6](../../../quellen/Unit02_slides_en.pdf#page=6)

~~~~text
                          IN INDUSTRY, THE COPY IS A DATA WAREHOUSE


          Sources                       Integration             Data Warehouse                     Analysis
             OLTP                         ETL / ELT                    OLAP                      BI, Data Science
         ERP (e.g. SAP               SSIS (in SQL Server)       Microsoft SQL Server                 Power BI
                             E                              L
          S/4HANA)                       Informatica              SAP BW/4HANA                        Tableau
             CRM                            Talend                Teradata, Oracle                      Qlik
           web shop                        Pentaho              Snowﬂake, BigQuery               Python, KNIME
         spreadsheets                    dbt, KNIME              Amazon Redshift

                              T: clean, one key per customer

    ETL: extract from the sources, transform (clean, give one customer one key), load. In ELT
    the warehouse does the transform itself.
    A warehouse is subject-oriented (customer, product), integrated (one key, one code),
    time-variant (keeps history) and non-volatile (not overwritten) — Inmon, 2005.
    Product names are examples for each layer, not a ranking.

6                           Source               Connect           Query               Extract
~~~~

## Page 007

[Original page 7](../../../quellen/Unit02_slides_en.pdf#page=7)

~~~~text
                                   IN THIS COURSE, THE COPY IS ONE FLAT FILE



       AWC in MySQL            E        extract script       L      awc_flat.csv                  pandas, KNIME
     stands in for the OLTP            or KNIME workﬂow           + provenance record               U03–U09
                                         T: U01’s joins



    Why one ﬁle is enough here                                   What a warehouse would add
     • one source — nothing to integrate                          • history: how did the table look in March?
     • AWC no longer changes (orders 2011–2014)                   • many sources under one key
     • every tool reads CSV; no server to run                     • scheduled refresh
     • one hash proves “same ﬁle as last week”                    • rights per user

    Same job, laptop size: one agreed copy — the single point of truth every later unit reads.

7                             Source               Connect          Query               Extract
~~~~

### DS-U02-L-EN-P007-D01 — Rekonstruktion

```mermaid
flowchart LR
 A[AWC in MySQL] -->|Extract| B[Extract script or KNIME workflow]
 B -->|Load| C[awc_flat.csv + provenance record]
 C --> D[pandas / KNIME U03–U09]
```
Transformation in B: U01 joins. One frozen copy.

## Page 008

[Original page 8](../../../quellen/Unit02_slides_en.pdf#page=8)

~~~~text
                                                         INFORMATION LOSES VALUE OVER TIME

                                            Value
                                                     operative transaction


                                                         data available
                                                          in the DWH

                               value lost                                         analysis
                                                                                results ready
                                                                                                      decision                action
                                                                                                       taken               implemented




                                                        data         analysis              decision               action        Time
                                                      latency        latency               latency               latency

                                                                                 action time


    Action time = data + analysis + decision + action latency. A scripted extract shortens only
    the data latency — a faster pipeline does not ﬁx a slow decision.
    Concept after Hackathorn, as adapted in Kemper, Baars & Mehanna (2010).

8                                           Source                Connect                       Query                         Extract
~~~~

## Page 009

[Original page 9](../../../quellen/Unit02_slides_en.pdf#page=9)

~~~~text
    Break
   10 minutes




Then: Step 2: Connect
~~~~

## Page 010

[Original page 10](../../../quellen/Unit02_slides_en.pdf#page=10)

~~~~text
              STEP 2: CONNECT


     Source   Connect    Query   Extract




10
~~~~

## Page 011

[Original page 11](../../../quellen/Unit02_slides_en.pdf#page=11)

~~~~text
                       ONE PROGRAM, MANY DATABASES: THE DRIVER LAYER


                   program             Excel, Power BI                KNIME                   Python script



         standard interface              ODBC (C)                   JDBC (Java)              DB-API (PEP 249)



           driver for MySQL      MySQL Connector/ODBC            MySQL Connector/J       mysql-connector-python



                  database                               MySQL server — Adventureworks2019


     The standard interface is one set of calls — connect, execute, fetch — for every database;
     the driver translates it for one DBMS. Swap the driver, keep the program.
     The alternative, a vendor API (libpq for PostgreSQL, Oracle’s OCI), is faster and offers more — and
     ties the program to one database.


11                            Source                Connect           Query             Extract
~~~~

## Page 012

[Original page 12](../../../quellen/Unit02_slides_en.pdf#page=12)

~~~~text
                                            YOU ALREADY USE ODBC AND JDBC

                                                      JDBC: KNIME runs on Java, so every
                                                      KNIME DB node talks JDBC. The
                                                      connector dialog builds one URL:
                                                      jdbc:mysql://localhost:3306/
                                                         Adventureworks2019
                                                      protocol, host, port, database — the same
                                                      four facts Python needs.


                                                      Why you care
                                                      When a connection fails, the error comes
     ODBC (early 1990s): Windows registers a          from one of these layers. Knowing the
     data source with its driver, Excel reads from    layers tells you where to look.
     it. Your colleagues’ “Excel report” is often a
     live query.

12                         Source          Connect      Query           Extract
~~~~

## Page 013

[Original page 13](../../../quellen/Unit02_slides_en.pdf#page=13)

~~~~text
                         A SESSION IS A DIALOG: COMMIT OR ROLLBACK

     Example: one AWC order = one header row + three item rows. The third item fails.

                        autocommit ON                                 autocommit OFF
            program                   database           program                      database
                      INSERT header                           one transaction
                                           saved
                                                                    INSERT header
                      INSERT item 1        saved                    INSERT item 1
                      INSERT item 2        saved                    INSERT item 2

                      INSERT item 3        error                    INSERT item 3             error

                                                                       ROLLBACK               nothing saved
                  the database now holds
                       half an order
                                                              no error: COMMIT — all four rows saved

     Defaults differ: MySQL console, JDBC and ODBC start with autocommit on — programs
     that write switch it off. Python’s DB-API starts with it off: forget commit() and your
     writes are gone when the connection closes. KNIME: DB Transaction Start . . . DB Trans-
     action End.
13                         Source            Connect          Query                 Extract
~~~~

### DS-U02-L-EN-P013-D01 — Rekonstruktion

Autocommit ON saves header, item 1, item 2 separately; item 3 fails, leaving half an order. OFF: same INSERT sequence inside a transaction; item 3 failure followed by ROLLBACK leaves nothing saved; COMMIT if all succeed.

## Page 014

[Original page 14](../../../quellen/Unit02_slides_en.pdf#page=14)

~~~~text
                             SWITCHING AUTOCOMMIT OFF — PER TOOL

                     start the unit of work                       end it

     MySQL console   START TRANSACTION; or SET                    COMMIT; / ROLLBACK;
                     autocommit=0;
     JDBC (Java)     con.setAutoCommit(false);                    con.commit(); — on exception
                                                                  con.rollback();
     Python DB-API   nothing — already off (db.autocommit is      db.commit() / db.rollback()
                     False)
     SQLAlchemy      with engine.begin() as conn:                 automatic: commit at the end of
                                                                  the block, rollback on an error
     KNIME           DB Transaction Start                         DB Transaction End (commit or
                                                                  rollback)

     Always the same pattern: switch off → several statements → commit if all worked,
     rollback if one failed. Reading only (our extracts) needs no commit — but one transaction
     still gives one consistent state.

14                      Source            Connect         Query            Extract
~~~~

## Page 015

[Original page 15](../../../quellen/Unit02_slides_en.pdf#page=15)

~~~~text
                                  WHAT A TRANSACTION PROMISES: ACID

                    promise                          without it, in the order example

     Atomicity      all statements or none           half an order stays in the database
     Consistency    rules (keys, constraints) hold   an item points to a product that does not
                    before and after                 exist
     Isolation      others do not see unﬁnished      a report counts the header, but not yet the
                    work                             items
     Durability     after commit it survives a       a conﬁrmed order is lost after a power cut
                    crash


     Why an analyst cares
     Isolation works for readers too: an extract that reads inside one transaction sees one
     consistent state of the database, even while orders are being written.

15                      Source           Connect         Query            Extract
~~~~

## Page 016

[Original page 16](../../../quellen/Unit02_slides_en.pdf#page=16)

~~~~text
                                                  PYTHON ROUTE A: THE RAW DRIVER


      1   import os, mysql.connector
      2
      3   db = mysql.connector.connect(
      4     host="127.0.0.1", user="sqladmin", password=os.environ["AWC_DB_PW"],
      5     database="Adventureworks2019")
      6
      7   cursor = db.cursor()
      8   cursor.execute("SELECT ProductID, Name, ListPrice "
      9            "FROM Production_Product LIMIT 5")
     10   for product_id, name, list_price in cursor.fetchall():
     11     print(product_id, name, list_price)
     12   db.close()


     DB-API (PEP 249): connect → cursor → execute → fetchall — the same for
     every Python driver. You get tuples: no column names, no table. Fine for a health
     check.

16                            Source              Connect          Query           Extract
~~~~

## Page 017

[Original page 17](../../../quellen/Unit02_slides_en.pdf#page=17)

~~~~text
                                   PYTHON ROUTE B: SQLALCHEMY + PANDAS

      1   import os, pandas as pd
      2   from sqlalchemy import create_engine
      3
      4   engine = create_engine(
      5     f"mysql+mysqlconnector://sqladmin:{os.environ['AWC_DB_PW']}"
      6     "@localhost/Adventureworks2019")
      7
      8   df = pd.read_sql("SELECT ProductID, Name, ListPrice "
      9             "FROM Production_Product", engine)
     10   print(df.dtypes)


     What changed
     One call returns a typed table: column names, types, NULL as NaN. The route the
     rest of the course uses.
     SQLAlchemy has two layers: the engine (connections, plain SQL) — all we use here — and
     an ORM on top, which comes in step 3.
17                           Source              Connect          Query    Extract
~~~~

## Page 018

[Original page 18](../../../quellen/Unit02_slides_en.pdf#page=18)

~~~~text
                                         WHERE THE PASSWORD ACTUALLY LIVES

      1   pw = os.environ["AWC_DB_PW"]       # 1 shell: export AWC_DB_PW='...'


      1   # 2 ~/.my.cnf, chmod 600 - the client reads it, connect carries no password
      2   [client]
      3   user=sqladmin
      4   password=...


      1   pw = keyring.get_password("mysql", "sqladmin") # 3 store: keyring, Vault, cloud



     What each buys — and what it does not
     All three stop the same accident: a password in a commit. Each has a limit: every
     process of your account reads the variable, .my.cnf is only as safe as chmod 600,
     a store only moves the trust.
     KNIME: Credentials Conﬁguration, never a password saved in a node.
18                            Source              Connect             Query                 Extract
~~~~

## Page 019

[Original page 19](../../../quellen/Unit02_slides_en.pdf#page=19)

~~~~text
              THE KNIME ROUTE: THE SAME JDBC URL

                            • Credentials Conﬁguration → DB
                              Connector (or MySQL Connector) — the
                              JDBC URL
                            • → DB Table Selector — pick the table or
                              write SQL
                            • → DB Reader — this is the node that
                              actually transfers rows

                           Why the credentials node
                           Host, port, database — one JDBC URL. A
                           password typed into the connector is saved in
                           the workﬂow and travels with every exported
                           .knwf; Credentials Conﬁguration asks for it
                           instead.
19   Source      Connect      Query            Extract
~~~~

## Page 020

[Original page 20](../../../quellen/Unit02_slides_en.pdf#page=20)

~~~~text
                           WHEN THE CONNECTION REFUSES — REAL LIFE

     On a real server the ﬁrst connection often fails — and the message rarely names the
     cause. The usual four:
     cause               looks like                                        ﬁrst check

     version mismatch    driver vs. server — the MySQL 8.0.11 failures     update the driver before touching
                         from U00; DB2 the same                            anything else
     encoding / locale   connects, but Würzburg arrives garbled; a CEST    set charset=utf8mb4 and a named
                         timezone is rejected                              timezone
     ﬁrewall / network   it just hangs, then “connection timed out” — no   is the port open? telnet host 3306.
                         login prompt ever                                 VPN up?
     security / auth     “access denied”, “public key retrieval not        right user and host? plugin? TLS
                         allowed”, SSL required                            expected?


     The method, not the list
     Change one thing at a time and read the error literally: “timed out” is the network, “access denied”
     is auth, garbled text is encoding.

20                          Source             Connect             Query                Extract
~~~~

## Page 021

[Original page 21](../../../quellen/Unit02_slides_en.pdf#page=21)

~~~~text
     STEP 3: QUERY — SAFELY, AND IN THE RIGHT
                      PLACE


      Source     Connect    Query      Extract




21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit02_slides_en.pdf#page=22)

~~~~text
                                   NEVER BUILD SQL WITH STRING FORMATTING

      1    name = "' OR '1'='1"     # what a user types into a product search box
      2
      3    # UNSAFE - the value can change the STRUCTURE of the query
      4    pd.read_sql(f"SELECT ProductID, Name FROM Production_Product "
      5           f"WHERE Name = '{name}'", engine)
      6    # reaches the server as: ... WHERE Name = '' OR '1'='1'
      7    # -> the WHERE is now always true
      8
      9    # SAFE - the driver handles the value; it can no longer change the query
     10    pd.read_sql(text("SELECT ProductID, Name FROM Production_Product "
      11             "WHERE Name = :name"), engine, params={"name": name})
     12    # reaches the server as: ... WHERE Name = '\' OR \'1\'=\'1'
     13    # -> every quote escaped; the 11 characters stay one value

     The ﬁrst returns all 504 products, because the quote closed the string and OR ’1’=’1’
     replaced the ﬁlter. The second returns none — it looks for a product named ’ OR ’1’=’1,
     and there is no such product.

22                                Source             Connect             Query        Extract
~~~~

## Page 023

[Original page 23](../../../quellen/Unit02_slides_en.pdf#page=23)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit02_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit02_slides_en.pdf#page=24)

~~~~text
          Break
         10 minutes




Then: Step 3: Where the Work Runs
~~~~

## Page 025

[Original page 25](../../../quellen/Unit02_slides_en.pdf#page=25)

~~~~text
                             ONE QUESTION, THREE PLACES TO ANSWER IT

     Question: which products have a ListPrice over 3,000, in which subcategory? (real AWC:
     13)
              how it is written                                                 runs in

     SQL      SELECT p.Name, s.Name FROM Production_Product p JOIN              the database
              Production_ProductSubcategory s ON s.ProductSubcategoryID =
              p.ProductSubcategoryID WHERE p.ListPrice > 3000
     ORM      session.query(Product.Name, Subcategory.Name).join(Subcategory)   the database
              .filter(Product.ListPrice > 3000)
              Python expressions — the ORM writes the SQL above
     pandas   products.merge(subcats, on="ProductSubcategoryID")                your machine
              .query("ListPrice > 3000")
              after reading both tables completely
     KNIME    DB Joiner → DB Row Filter → DB Reader                             the database
              the DB nodes write SQL, like an ORM
              DB Reader → Joiner → Row Filter                                   your machine
     Same 13 rows every time — only the place differs. In KNIME the border is a node:
     everything before the DB Reader runs in the database.
25                          Source       Connect          Query           Extract
~~~~

## Page 026

[Original page 26](../../../quellen/Unit02_slides_en.pdf#page=26)

~~~~text
                                                            ORM: ROWS BECOME OBJECTS


      1   class Product(Base):        # table                 Object-relational mapping: class = table,
      2     __tablename__ = "Production_Product"              object = row, attribute = column. You
      3     ProductID = Column(Integer, primary_key=True)     change objects; the ORM writes the SQL.
      4     ListPrice = Column(Numeric(19, 4))
      5                                                        • Joins: yes — .join(), or a declared
      6   bike = session.get(Product, 749) # one row             relationship
      7   bike.ListPrice *= 1.05       # change it
      8   session.commit()             # UPDATE ...            • Views: map them like a table, read-only

     class as in Scripts/awc_orm.py; product 749 =
                                                               • Writing back: session.commit() — that is
     Road-150 Red, 62                                            what an ORM is for
                                                               • KNIME: after the DB Reader the table is a
                                                                 copy; changes reach the database only
                                                                 through DB Insert / Update / Merge /
                                                                 Delete
      For analysis: an ORM is built for applications that change single objects; analysis reads
      whole columns — we use read_sql.

26                            Source             Connect        Query            Extract
~~~~

## Page 027

[Original page 27](../../../quellen/Unit02_slides_en.pdf#page=27)

~~~~text
                                                                  THE ORM TRAP: N+1 QUERIES


      1   # revenue over all orders, the "natural" ORM way
      2   total = 0                                                      program                     database
      3   for order in session.query(Order): # 1 query                                 orders
      4     for item in order.items:       # +1 query per order
      5        total += item.LineTotal

     Looks like one loop. The ORM loads each                                  items of order 1, 2, . . .
     order’s items only when the loop touches them
     (lazy loading) — one more query per order.
      real AWC: all 31,465 orders, 121,317 items — same total each time            queries, counted
      the loop above (lazy loading)                                                             31,466
      the same loop with .options(joinedload(Order.items))                                           1
      plain SQL: SELECT SUM(LineTotal) ...                                                           1



27                              Source               Connect         Query            Extract
~~~~

## Page 028

[Original page 28](../../../quellen/Unit02_slides_en.pdf#page=28)

~~~~text
                    PUSH DOWN: LET THE DATABASE SHRINK THE DATA

     Question: revenue per product. Two ways, identical numbers:

          1 Pull everything, aggregate locally
                              121,317 rows over the wire
                                                                pandas groupby
              MySQL                                                             → 266 rows
                                                               or KNIME GroupBy



          2 Push the aggregation down

                                      266 rows
              MySQL
                                                                   pandas / KNIME
             GROUP BY

     Rule of thumb: ﬁlter and aggregate in SQL (or KNIME DB nodes); reshape,
     model and plot locally. Counter-rule: raw rows for proﬁling (U04) are pulled
     once and kept as a ﬁle. Measure it yourself: Scripts/awc_pushdown.py, Exer-
     cise 3.
28                      Source           Connect           Query             Extract
~~~~

## Page 029

[Original page 29](../../../quellen/Unit02_slides_en.pdf#page=29)

~~~~text
                                                  SEEING WHAT THE DATABASE DID

     “The aggregation runs in the database” is a claim. EXPLAIN ANALYZE in front of the
     push-down query makes the server show its plan:

                                   to your program



                         Group aggregate: sum(LineTotal)        actual 266 rows
                                  one row per product           estimated beforehand: 250



                       Index scan on Sales_SalesOrderDetail
                                                                actual 121,317 rows
                                 reads every order item


     Read from the bottom up. The gap 121,317 → 266 is the push-down, now vis-
     ible. EXPLAIN alone only estimates (250); ANALYZE runs the query and counts.
     KNIME shows the SQL its DB nodes built in the DB Query tab of the output port.
     (MySQL 8.0.46)

29                      Source               Connect          Query               Extract
~~~~

## Page 030

[Original page 30](../../../quellen/Unit02_slides_en.pdf#page=30)

~~~~text
                                                              THE FLAT TABLE AS A VIEW


       1   CREATE VIEW v_awc_ﬂat AS                             A view is a stored query that reads like
      2    SELECT d.SalesOrderID, d.LineTotal, h.OrderDate,     a table. Everybody who selects from it
      3       h.CustomerID, p.Name AS ProductName,              gets the same deﬁnition of the ﬂat
      4       c.Name AS Category
                                                                table.
      5    FROM Sales_SalesOrderDetail d
      6    JOIN Sales_SalesOrderHeader h                                 view              extract ﬁle
      7      ON h.SalesOrderID = d.SalesOrderID
      8    JOIN Production_Product p                            data     live, always      frozen at one
      9      ON p.ProductID = d.ProductID
      10   LEFT JOIN Production_ProductSubcategory sc
                                                                         current           moment
      11     ON sc.ProductSubcategoryID = p.                    needs    the server        nothing
                ProductSubcategoryID                            proof    the deﬁnition     a hash
      12   LEFT JOIN Production_ProductCategory c
      13     ON c.ProductCategoryID = sc.ProductCategoryID;     Rights: analysts may read the view, not the
                                                                base tables. A stored procedure does the
     Scripts/awc_view.sql: U01’s join chain, written once
                                                                same for a parameterised query — EXECUTE
                                                                on one name.

30                             Source            Connect       Query            Extract
~~~~

## Page 031

[Original page 31](../../../quellen/Unit02_slides_en.pdf#page=31)

~~~~text
     STEP 4: AN EXTRACT THAT PROVES ITSELF


      Source    Connect    Query     Extract




31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit02_slides_en.pdf#page=32)

~~~~text
                          DEVELOP ON A SAMPLE THAT LOOKS LIKE THE DATA

     Nobody re-runs 121,317 rows on every attempt, so everybody writes LIMIT 1000. That is
     not a sample — it is the ﬁrst 1,000 rows, here the earliest orders.

                                           months with orders, May 2011 – June 2014                     rows median LineTotal

           whole table                                                                         38     121,317    134.98
           LIMIT 1000                                                                          2        1,000    874.79
        hash on the key                                                                        34       1,096    144.99
                          2011            2012                   2013                   2014




     Sample on a hash of the key
     WHERE CRC32(SalesOrderID) % 121 = 0: the same rows every run, spread over the whole
     table, and it runs in the database. LIMIT 1000: 2 of 38 months, median 6.5× too high.
     Real AWC, awc_flat.csv — Scripts/awc_sampling.py


32                               Source                 Connect                 Query              Extract
~~~~

## Page 033

[Original page 33](../../../quellen/Unit02_slides_en.pdf#page=33)

~~~~text
                                         THE EXTRACT CARRIES ITS OWN PROOF


                                                            what                 why
         awc_extract.py
         SELECT ... JOIN ...                                a script, not        anyone can re-run it
         ORDER BY SalesOrderID, ...                         clicks
                          provenance.json                   ORDER BY             same rows in another order =
                                                                                 another ﬁle: hash
                          { "created_utc": "...",
     awc_flat.csv           "created_by": "...",                                 0ed4a491... vs
                            "query": "SELECT ...",                               f7c1cd4f...
                            "rows": 121317,
                            "rows_without_category":
                            "sha256": "..." }
                                                       0,   one query            one consistent state (step 2)
                                                            provenance           who, when, which query, how
                                                                                 many rows, which hash

     The question it answers: “Is this the same data I analysed last week?” — by a hash, not by
     memory. In industry the same facts are kept as data lineage: where each table came from,
     and how.
     Hashes: real AWC, 20,000 lines of awc_flat.csv, as read and shufﬂed (awc_sampling.py).

33                          Source               Connect           Query            Extract
~~~~

## Page 034

[Original page 34](../../../quellen/Unit02_slides_en.pdf#page=34)

~~~~text
                        WHEN THE SOURCE IS NOT ONE RELATIONAL DATABASE


                                                               CAP: when the network between copies fails
                                                               (Partition), a system must choose: stay
     “add to cart”                      report reads 2
                                                               Consistent (refuse to answer) or stay
                                                               Available (answer with possibly old data).

                                                               example                             chooses
       copy A                               copy B
       3 items
                           ×                2 items
                                                               bank transfer                       consistency (ACID)
                       network cut                             Amazon shopping cart                availability (BASE)
                                                               (DeCandia et al., 2007)
              later the copies agree again
                 (eventually consistent)
     For your numbers: two reads a second apart can give two totals — and neither is a bug.
     Know which guarantee your source gives before you defend a ﬁgure.
     BASE = basically available, soft state, eventually consistent. NoSQL stores are covered in the frontend/backend
     courses.

34                           Source              Connect             Query               Extract
~~~~

## Page 035

[Original page 35](../../../quellen/Unit02_slides_en.pdf#page=35)

~~~~text
            Break
          10 minutes




Then: Hands On — Your First Pipeline
~~~~

## Page 036

[Original page 36](../../../quellen/Unit02_slides_en.pdf#page=36)

~~~~text
     HANDS ON — EXERCISES 3 AND 4
                       20 minutes
       Sheet on Moodle: Unit02_Exercises_en.pdf

          Exercise 5 is voluntary — it needs no machine.




36
~~~~

## Page 037

[Original page 37](../../../quellen/Unit02_slides_en.pdf#page=37)

~~~~text
                                                                 KEY MESSAGES



     • Source: analysis runs on a copy, not on the live system — in industry a data
       warehouse, here one ﬂat ﬁle: our single point of truth
     • Connect: a standard interface plus a driver reaches any database; a session
       ends in commit or rollback — know whether autocommit is on
     • Query: bind parameters, never paste input into SQL; ﬁlter and aggregate in the
       database; an ORM’s loop can hide thousands of queries (N+1)
     • Extract: a script with ORDER BY, a hash sample for development, and a
       provenance record — then “the same data as last week” is a fact, not a hope
     • Next: U03 — formats, serialisation & metadata



37                    Source        Connect        Query          Extract
~~~~

## Page 038

[Original page 38](../../../quellen/Unit02_slides_en.pdf#page=38)

~~~~text
                                                         SOURCES & FURTHER READING

     • Kemper, Baars & Mehanna (2010), Business Intelligence — Grundlagen und praktische Anwendungen, 3rd ed.,
       Vieweg+Teubner — operative vs. dispositive data, ETL, action time doi:10.1007/978-3-8348-9727-5
     • Inmon (2005), Building the Data Warehouse, 4th ed., Wiley, ISBN 978-0-7645-9944-6 — the warehouse
       deﬁnition
     • Kleppmann (2017), Designing Data-Intensive Applications, O’Reilly — ch. 7 (transactions), ch. 9 (consistency)
     • DeCandia et al. (2007), Dynamo: Amazon’s Highly Available Key-Value Store, SOSP ’07 — the shopping-cart
       case doi:10.1145/1294261.1294281
     • SQLAlchemy documentation — engines, pooling, text() and bound parameters
       docs.sqlalchemy.org/en/20/core/connections
     • OWASP — SQL Injection Prevention Cheat Sheet cheatsheetseries.owasp.org
     • KNIME — Database Extension Guide (DB Connector, DB Reader, in-database processing)
       docs.knime.com/latest/db_extension_guide
     • Winand (2012), SQL Performance Explained, ISBN 978-3-9503078-2-5 — indexes and execution plans; free
       web edition use-the-index-luke.com
     • Leis et al. (2015), How Good Are Query Optimizers, Really?, PVLDB 9(3), 204–215 — why rows= is an estimate
       vldb.org/pvldb/vol9/p204-leis.pdf
     • MySQL 8.0 Reference Manual, ch. 10 Optimization — EXPLAIN ANALYZE, index use, slow query log
       dev.mysql.com/doc/refman/8.0/en/optimization

38
~~~~
