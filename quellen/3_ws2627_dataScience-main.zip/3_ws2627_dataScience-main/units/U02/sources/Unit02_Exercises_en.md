---
source_id: DS-U02-EX
original_file: Unit02_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: 5998e24da81f2552703023754c05b2bf9589a7bb44001f6e52cda49a66027e74
verification: partial
---
# Unit02_Exercises_en

[Original PDF](../../../quellen/Unit02_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit02_Exercises_en.pdf#page=1)

<a id="ds-u02-ex-t01"></a>

**DS-U02-EX-T01 — Get Out of the Console**

<a id="ds-u02-ex-t02"></a>

**DS-U02-EX-T02 — Break It, Then Fix It**

<a id="ds-u02-ex-t03"></a>

**DS-U02-EX-T03 — Push Down, or Pull and Aggregate?**

~~~~text
  Unit 02 — Exercises                                                                                              Your First Pipeline
Reach the database from a program, then attack your own query.
▶ In the room        what ﬁts the stop — all that is expected. The room splits at stop B: take one of the two exercises; you
                     hear the other one in the discussion.
⃝ Extra              voluntary, at home.
Stop A, 20 min       Exercises 1 and 2      Stop B, 20 min: Exercise 3 or 4
Asynchronous         the same sheet, before your weekly slot; bring what did not run.
You need             the running Adventureworks2019 and your join from Unit 01. Every exercise has a Python and a KNIME
                     route — do one; reading the other shows what your tool does for you.

Exercise 1 — Get Out of the Console stop A · ▶ 10 min
 1 Return the ﬁrst 10 rows of Production_Product from a program.
      Example — Python (kit: Scripts/awc_connect.py)

      engine = create_engine("mysql+mysqlconnector://sqladmin:"
                             f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019")
      df = pd.read_sql("SELECT * FROM Production_Product LIMIT 10", engine)

 2 Look at the types that came back (df.dtypes; in KNIME the output port’s Spec tab). Which AWC columns arrive as a
   type you did not expect? Note two.
  In KNIME
  MySQL Connector → DB Table Selector (Production_Product) → DB Reader; set the row limit on the reader, not in the SQL.

⃝ Extra: (a) Run the same query through the raw driver (mysql.connector, cursor.fetchall()), or replace the two KNIME
nodes with one DB Query Reader. Name three things you lost. (b) Get the password out of your ﬁles: an environment
variable AWC_DB_PW, a MySQL option ﬁle (~/.my.cnf, chmod 600), a secret store — in KNIME a Credentials Configuration
node instead of a password typed into the connector. Two sentences: what does your choice protect against, and what
does it leave open?
Exercise 2 — Break It, Then Fix It stop A · ▶ 10 min
Search for the product Mountain-100 Black, 38 (1 row), then attack your own search with ’ OR ’1’=’1.
 1 Build the SQL by gluing the search term into the string (Python: an f-string). Search for the product name: 1 row.
 2 Use ’ OR ’1’=’1 as the search term. How many rows? Print the SQL that was actually executed — print it, do not reason
   about it.
 3 Make it safe: a bound parameter, text("...         WHERE   Name   =    :name") with {"name":                              term} (kit:
   Scripts/awc_parameterised.py). Same hostile input — what comes back, and why?
 4 Zero rows could also mean a broken query. Search both versions for Men’s Sports Shorts, S, a real product with a
   quote in its name. Which one ﬁnds it, and what does the other do?
 5 One sentence: why is this a correctness problem as much as a security problem?
  In KNIME
  A ﬂow variable is one named value travelling beside the data (red connections); $${Sterm}$$ reads the String variable term.
  Right-click a node → Show ﬂow variable ports; execute the node before, then open the dialog. Steps 1–2: Variable Creator (term)
  → String Manipulation (Variable), new variable sql: join("SELECT ProductID, Name FROM Production_Product WHERE Name
  = ’", $${Sterm}$$, "’") → DB Table Selector (Flow Variables tab: customQuery ← sql) → DB Reader. The executed SQL is in
  the selector’s DB Query tab. Step 3: DB Table Selector + DB Row Filter with the value typed into its dialog; look at its DB Query tab.

Exercise 3 — Push Down, or Pull and Aggregate? stop B · ▶ 20 min · or Exercise 4
 1 Compute revenue per product category twice: (a) pull every line of Sales_SalesOrderDetail and groupby in your tool;
   (b) put the GROUP BY into the SQL and read back only the result. For both, record rows transferred — the rows your
   program received, len(df) — and wall-clock time. Check that both give the same totals, to the cent.
      Example — the table to ﬁll

      strategy               rows transferred   time
      pull, then groupby                  ...   ... s   The row ratio is the point — it is far larger than the time ratio.
      GROUP BY in SQL                     ...   ... s

  In KNIME
  DB Reader on the full table → GroupBy; then DB GroupBy before the DB Reader. Read the generated SQL in the node’s DB Query tab.
  Kit for Python: Scripts/awc_pushdown.py.
⃝ Extra:   name one analysis from the semester where pushing down is the wrong move, and why.


Unit 02 · Data Science · exercise sheet                                                                                                    1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit02_Exercises_en.pdf#page=2)

<a id="ds-u02-ex-t04"></a>

**DS-U02-EX-T04 — The Flat Table as a View**

<a id="ds-u02-ex-t05"></a>

**DS-U02-EX-T05 — It Refuses to Connect**

~~~~text
Exercise 4 — The Flat Table as a View stop B · ▶ 20 min · or Exercise 3
Run Scripts/awc_view.sql. It builds v_awc_flat: the same 121,317 lines as your extract. Query it.
 1 Name one question the view answers better than the extract, and one it cannot answer. (The last two lines of the script
   are a hint.)
 2 For your own ﬂat table: view, extract, or both — and why? Two sentences. There is a right answer for a given purpose,
   and none in general.
⃝ Extra: (triggers — database background). Run Scripts/awc_procedures.sql, then Scripts/awc_trigger.sql: an AFTER
UPDATE trigger on Production_Product. Call UpdateProducts(2) (it raises every price in category 2) and look at
PriceChangeLog. Which question does that log make answerable? And read the comment in awc_procedures.sql about
the extra SELECT: why does MySQL need it?
    A trigger is SQL bound to one table and one kind of write; it runs by itself for every changed row. BEFORE can check or correct the
    new row, AFTER can log it; OLD is the row before the write, NEW after it. There is no trigger on SELECT. If awc_trigger.sql stops with
    ERROR 1419 . . . binary logging is enabled, set once, as root: mysql -u root -p -e "SET PERSIST
    log_bin_trust_function_creators = 1;", then run it again. Everything runs on your own copy of the database.


Exercise 5 — It Refuses to Connect ⃝ Extra · no machine needed
Four connections fail. For each, name the cause and the ﬁrst thing you would check — one sentence each.
1    Public Key Retrieval is not allowed — the same script worked on a colleague’s machine
2    it connects, but Würzburg arrives as WÃ¼rzburg, and a date comparison rejects CEST
3    30 seconds of silence, then connection timed out; no login prompt, ever
4    Access denied for user ’sqladmin’@’192.168.1.40’ — but the password is right

Then break your own connection: port 3307, then a user that does not exist. Compare the two messages. Which one tells
you more — and why is that the dangerous one?

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: the two unexpected column types
• Ex 2: the SQL that was actually executed under the attack, and its row count
• Ex 3: your push-down table — rows transferred and time, both ways
• Ex 4: one question the view answers better than the extract, and one it cannot




Unit 02 · Data Science · exercise sheet                                                                                                      2
~~~~
