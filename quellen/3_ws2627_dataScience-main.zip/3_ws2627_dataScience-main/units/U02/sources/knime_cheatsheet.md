---
source_id: DS-U02-R-KNIME-CHEATSHEET
original_file: "Scripts/knime_cheatsheet.pdf"
source_type: reference
language: en
page_count: 1
source_sha256: d56ceaca2211c30a6250b3d33224fb2cda760f0072f6f0f9572e7e52fad55170
verification: partial
---

# knime_cheatsheet

> Automatische Layout-Textfassung; Seitenbilder sind als visuelle Referenz beigefügt. Tabellen, Code, Formeln und Diagrammsemantik sind noch nicht vollständig manuell normalisiert oder geprüft.

## Page 001

![Originalseite 1](assets/DS-U02-R-KNIME-CHEATSHEET/p001.png)

~~~~text
  KNIME — U02 cheat sheet                                                                             where the database ends


U02’s whole point in one line: some of your work runs on the server, some on your laptop, and the border is a node you
can see. In Python that border is invisible. This is the one place KNIME shows you something pandas cannot.

The border


     runs on the server                                                                                       runs in KNIME

       MySQL Connector       DB Table Selector    DB Reader                  Joiner             GroupBy        any node



                                                    every row crosses here



Two ways in, and they are not the same
    DB Table Selector               → point at a table, pull it. KNIME writes the SQL
    DB Reader
    DB Query Reader                     you write the SQL. Joins, WHERE, GROUP BY all stay server-side
    DB SQL Executor                     SQL that returns no rows. One statement per node
    GroupBy                             the same aggregation, done on your laptop instead

The experiment: same answer, two routes
 Revenue per category, computed twice. Change one thing — where the GROUP BY happens — and count what crosses
the border.


                                                                             rows crossing                result
                  pull — DB Query Reader (join only) → GroupBy                        121,317            4 rows
                  push — DB Query Reader (join and GROUP BY)                                4   the same 4 rows




  . The clock will not prove what you expect
  On localhost both routes take about the same time — the pull is sometimes even faster. That is not a mistake in
  your workﬂow. Push-down is about data movement, and on your own machine data movement is nearly free. It
  pays when the rows must cross a network, when the intermediate result will not ﬁt in memory, or when the server
  can use an index you cannot. Report the row counts, and say why the times are equal.


Two things that cost time


 Comment out every line                                       1     No multi-statement scripts                                2
 A – comment that wraps onto a second line makes that line          START TRANSACTION; ... ROLLBACK; is refused unless the
 live SQL. You get a syntax error instead of the error you were     connection sets allowMultiQueries=true. One statement per
 demonstrating.                                                     node is simpler.




The question to answer: name one analysis from this semester where pushing down would be wrong — and say why.
~~~~
