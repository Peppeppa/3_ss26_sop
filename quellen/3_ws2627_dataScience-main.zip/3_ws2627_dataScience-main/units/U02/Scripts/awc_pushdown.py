"""
Unit 02 — where should the work happen: in the database or in pandas?

Same answer, two strategies. Run both, compare rows transferred and wall time.
This is the exercise that decides how every later unit extracts its data.
"""
import os
from urllib.parse import quote_plus
import time

import pandas as pd
from sqlalchemy import create_engine

if "AWC_DB_PW" not in os.environ:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")

engine = create_engine(
    "mysql+mysqlconnector://sqladmin:"
    f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019"
)


def timed(label, fn):
    """fn returns (rows received from the server, result)."""
    start = time.perf_counter()
    received, result = fn()
    print(f"{label:<24} {received:>8,} rows transferred  "
          f"{len(result):>4} in the result  {time.perf_counter() - start:6.2f} s")
    return result


# ── Strategy 1: pull everything, aggregate in pandas ─────────────────────────
def pull_all():
    detail = pd.read_sql(
        "SELECT SalesOrderID, ProductID, LineTotal FROM Sales_SalesOrderDetail", engine
    )
    return len(detail), detail.groupby("ProductID", as_index=False)["LineTotal"].sum()


# ── Strategy 2: push the aggregation down into SQL ───────────────────────────
def push_down():
    result = pd.read_sql(
        """
        SELECT ProductID, SUM(LineTotal) AS LineTotal
        FROM   Sales_SalesOrderDetail
        GROUP  BY ProductID
        """,
        engine,
    )
    return len(result), result


a = timed("pull-all + pandas", pull_all)
b = timed("push-down to SQL", push_down)

# Same numbers either way — that is the point.
merged = a.merge(b, on="ProductID", suffixes=("_pandas", "_sql"))
print("max absolute difference:", (merged.LineTotal_pandas - merged.LineTotal_sql).abs().max())
