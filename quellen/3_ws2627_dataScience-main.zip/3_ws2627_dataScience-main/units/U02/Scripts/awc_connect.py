"""
Unit 02 — minimal database access from Python.

Database Adventureworks2019, user sqladmin. Tables are named Schema_Table,
so Sales_SalesOrderHeader, Production_Product, and so on.

Two routes to the same rows. Route B is the one used for the rest of the course.

The password is read from the environment, never written here. Set it once per
shell (or in your shell profile) before running anything:

    export AWC_DB_PW='...'

Three routes worth knowing, in increasing order of how little you have to think:
  1. an environment variable, as below -- nothing secret reaches the file;
  2. a MySQL option file, ~/.my.cnf with chmod 600, read by the client itself --
     then even the connect call carries no password;
  3. a secret store (keyring, Vault, a cloud secret manager) -- what production
     does, and overkill for a laptop.
All three protect against the same accident: a password committed to a
repository. None of them protect a password you paste into a chat or a ticket.
"""

# ── Route A: the raw driver (DB-API 2.0) ─────────────────────────────────────
# Closest to what the console does: you get tuples, you do the rest yourself.
import os
import mysql.connector

# A loud stop beats a silent fallback to a default password. In this course the
# database is on your own machine and the password is not a secret from anybody
# -- the habit is the lesson, not the secrecy.
try:
    AWC_DB_PW = os.environ["AWC_DB_PW"]
except KeyError:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")

db = mysql.connector.connect(
    host="127.0.0.1",
    user="sqladmin",
    password=AWC_DB_PW,
    database="Adventureworks2019",
)
cursor = db.cursor()
cursor.execute("SELECT ProductID, Name, ListPrice FROM Production_Product LIMIT 5")
for product_id, name, list_price in cursor.fetchall():
    print(product_id, name, list_price)
db.close()


# ── Route B: SQLAlchemy + pandas ─────────────────────────────────────────────
# One line gives you a typed DataFrame instead of tuples. This is what U03+ assume.
import pandas as pd
from sqlalchemy import create_engine

# quote_plus because a password with @ or / would otherwise break the URL --
# one more reason the password is a variable and not part of a literal string.
from urllib.parse import quote_plus

engine = create_engine(
    "mysql+mysqlconnector://sqladmin:"
    f"{quote_plus(AWC_DB_PW)}@localhost/Adventureworks2019"
)
df = pd.read_sql("SELECT ProductID, Name, ListPrice FROM Production_Product", engine)
print(df.dtypes)
print(df.head())
