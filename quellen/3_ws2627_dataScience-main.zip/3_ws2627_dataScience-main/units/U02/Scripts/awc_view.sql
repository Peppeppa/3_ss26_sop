-- Unit 02 -- the flat table as a VIEW, next to the extract that copies it.
-- The deck shows this on "The Flat-Table as a View"; the point of running it is
-- to hold the two side by side and decide which one your question needs.
USE Adventureworks2019;

DROP VIEW IF EXISTS v_awc_flat;
CREATE VIEW v_awc_flat AS
SELECT d.SalesOrderID, d.LineTotal, h.OrderDate, h.CustomerID,
       p.Name AS ProductName, c.Name AS Category
FROM      Sales_SalesOrderDetail        d
JOIN      Sales_SalesOrderHeader        h  ON h.SalesOrderID = d.SalesOrderID
JOIN      Production_Product            p  ON p.ProductID    = d.ProductID
LEFT JOIN Production_ProductSubcategory sc ON sc.ProductSubcategoryID
                                             = p.ProductSubcategoryID
LEFT JOIN Production_ProductCategory    c  ON c.ProductCategoryID
                                             = sc.ProductCategoryID;

-- 121,317 rows, like the extract -- and unlike the extract, it is never stale.
SELECT COUNT(*) AS n_lines FROM v_awc_flat;

-- What a view does NOT give you: a thing to hash and hand over. Try it:
--   SELECT MD5(GROUP_CONCAT(SalesOrderID)) FROM v_awc_flat;   -- and again tomorrow
