-- Unit 02 — SQL injection on AWC, server side.
-- Targets Production_Product, which exists in the 2019 schema we import.

USE Adventureworks2019;

-- ─── 1. The vulnerable pattern: query text built by string concatenation ────
SET @userInput = 'Mountain-100 Black, 38';

SET @sql = CONCAT(
  'SELECT ProductID, Name, ListPrice FROM Production_Product ',
  'WHERE Name = ''', @userInput, ''';'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- 1 row. Looks fine. Now the same code with hostile input:

SET @userInput = ''' OR ''1''=''1';

SET @sql = CONCAT(
  'SELECT ProductID, Name, ListPrice FROM Production_Product ',
  'WHERE Name = ''', @userInput, ''';'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- 504 rows. The WHERE clause was rewritten by the data.


-- ─── 2. The fix: the value never becomes part of the query text ─────────────
DROP PROCEDURE IF EXISTS FindProduct;
DELIMITER //
CREATE PROCEDURE FindProduct(IN inName VARCHAR(50))
BEGIN
    SELECT ProductID, Name, ListPrice
    FROM   Production_Product
    WHERE  Name = inName;
END //
DELIMITER ;

CALL FindProduct('Mountain-100 Black, 38');   -- 1 row
CALL FindProduct(''' OR ''1''=''1');          -- 0 rows: treated as a product name
