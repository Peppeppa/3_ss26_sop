-- Retargeted 2026-09-11 to the canonical database: Adventureworks2019,
-- tables Production_Product / Production_ProductSubcategory. The original
-- names (`adventureworks`.`product`) do not exist in this import.
USE Adventureworks2019;
DELIMITER //
DROP PROCEDURE IF EXISTS GetProductsByCategory;
CREATE PROCEDURE GetProductsByCategory(IN category_id INT)
BEGIN
    SELECT 
        p.ProductID,
        p.Name,
        p.ListPrice
    FROM Production_Product AS p
    JOIN Production_ProductSubcategory AS ps
        ON p.ProductSubcategoryID = ps.ProductSubcategoryID
    WHERE ps.ProductCategoryID = category_id;
END;
//
DELIMITER ;
CALL GetProductsByCategory(2);


/* UpdateProducts raises every list price in one category by 2.
   Note the extra SELECT * FROM (...) AS TempTable around the subquery. MySQL
   refuses an UPDATE whose subquery reads the table being updated (error 1093,
   "You can't specify target table ... for update in FROM clause"). Wrapping the
   subquery in a derived table makes MySQL materialise it first, and then the
   UPDATE is allowed. Other databases accept the plain subquery. */
DELIMITER //
DROP PROCEDURE IF EXISTS UpdateProducts;
CREATE PROCEDURE UpdateProducts(IN category_id INT)
BEGIN
    UPDATE Production_Product AS p
    SET p.ListPrice = p.ListPrice +2 
    WHERE p.ProductID IN (
        SELECT * FROM (
            SELECT pp.ProductID
            FROM Production_Product AS pp
            JOIN Production_ProductSubcategory AS ps
                ON pp.ProductSubcategoryID = ps.ProductSubcategoryID
            WHERE ps.ProductCategoryID = category_id
        ) AS TempTable
    );
END;
//
DELIMITER ;
-- Do not call it yet: run awc_trigger.sql first, then
--   CALL UpdateProducts(2);
-- so that PriceChangeLog records the change.
