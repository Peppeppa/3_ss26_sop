-- Retargeted 2026-09-11 to the canonical database: Adventureworks2019,
-- tables Production_Product / Production_ProductSubcategory. The original
-- names (`adventureworks`.`product`) do not exist in this import.
USE Adventureworks2019;
DROP TABLE IF EXISTS PriceChangeLog;
CREATE TABLE PriceChangeLog (
       ChangeID INT AUTO_INCREMENT PRIMARY KEY,
       ProductID INT NOT NULL,
       OldPrice DECIMAL(10, 2) NOT NULL,
       NewPrice DECIMAL(10, 2) NOT NULL,
       ChangedBy VARCHAR(255) NOT NULL,
       ChangeDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //
DROP TRIGGER IF EXISTS ProductPriceChangeTrigger;
CREATE TRIGGER ProductPriceChangeTrigger
AFTER UPDATE ON Production_Product
FOR EACH ROW
BEGIN
       IF NEW.ListPrice != OLD.ListPrice THEN
           INSERT INTO PriceChangeLog (ProductID, OldPrice, NewPrice, ChangedBy)
           VALUES (OLD.ProductID, OLD.ListPrice, NEW.ListPrice, USER());
       END IF;
END;
//
DELIMITER ;


