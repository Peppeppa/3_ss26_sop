"""
Unit 02 -- two things that bite between the database and your analysis.

    python3 awc_sampling.py

1. THE SAMPLE YOU DEVELOP ON. Nobody re-runs 121,317 rows on every attempt, so
   everybody writes LIMIT 1000. That is not a sample: it is the first 1000 rows
   in whatever order the engine hands them over, which here means the earliest
   orders. Measured below: the median comes out ~6.5x too high and 36 of the 38
   months are simply absent. You then tune your analysis against a slice of the
   data that does not look like the data.

   The fix costs nothing: sample on a HASH OF THE KEY. Deterministic (the same
   rows every run, so your numbers are comparable), spread across the whole
   table, and it pushes down to the database:

       WHERE CRC32(SalesOrderID) % 121 = 0        -- MySQL
       WHERE MOD(ABS(HASHTEXT(id)), 121) = 0      -- Postgres

   ORDER BY RAND() also samples, and reads the whole table to do it.

2. THE ORDER IS PART OF THE ANSWER. A query without ORDER BY does not promise
   one. The same rows in a different order are the same data -- but not the same
   FILE: the sha256 changes completely, so "the frozen, hashed extract" is only
   reproducible if the order is. And the float sum shifts in its last bit,
   because floating-point addition is not associative. That is why money is
   compared with a tolerance and never with ==.
"""
import hashlib
import io
import zlib
from pathlib import Path

import pandas as pd

def find_extract():
    """AWC/awc_flat.csv in this folder or any folder above it."""
    for base in Path(__file__).resolve().parents:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    raise SystemExit("AWC/awc_flat.csv not found above this folder. Put your group's "
                     "extract there, or edit find_extract().")


def sha(df):
    b = io.StringIO()
    df.to_csv(b, index=False)
    return hashlib.sha256(b.getvalue().encode()).hexdigest()[:16]


def key_sample(d, every=121):
    """Deterministic: the same rows on every run, spread over the whole table.
    zlib.crc32 of the id as text is what MySQL's CRC32(SalesOrderID) computes,
    so this keeps the same rows as  WHERE CRC32(SalesOrderID) % 121 = 0."""
    keep = d.SalesOrderID.astype(str).map(lambda s: zlib.crc32(s.encode()) % every == 0)
    return d[keep]


def profile(x, name):
    months = pd.to_datetime(x.OrderDate).dt.to_period("M").nunique()
    top = x.TerritoryName.value_counts(normalize=True)
    print(f"  {name:<18}{len(x):>8,}{x.LineTotal.median():>12,.2f}{months:>9}"
          f"   {top.index[0]} {top.iloc[0]:.0%}")


if __name__ == "__main__":
    d = pd.read_csv(find_extract())

    print("1. What you develop against\n")
    print(f"  {'':<18}{'':>8}{'median':>12}")
    print(f"  {'':<18}{'rows':>8}{'LineTotal':>12}{'months':>9}   top territory")
    profile(d, "the whole table")
    profile(d.head(1000), "LIMIT 1000")
    profile(key_sample(d), "hash on the key")
    print("\n  LIMIT 1000 is the first thousand rows, not a thousand random ones.\n")

    print("2. The order is part of the answer\n")
    a = d.head(20000)
    b = a.sample(frac=1, random_state=1)
    same = a.sort_index().equals(b.sort_index())
    print(f"  same rows: {same}")
    print(f"  as read     sha256 {sha(a)}   sum {a.LineTotal.sum()!r}")
    print(f"  reordered   sha256 {sha(b)}   sum {b.LineTotal.sum()!r}")
    d_rel = abs(a.LineTotal.sum() - b.LineTotal.sum()) / a.LineTotal.sum()
    print(f"\n  The file hash changes completely; the sum changes by {d_rel:.1e}"
          " relative\n  -- the last bit, because float addition is not associative.")
