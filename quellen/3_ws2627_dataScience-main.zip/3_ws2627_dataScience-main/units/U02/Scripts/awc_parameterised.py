"""
Unit 02 — the same lesson in Python: never build SQL by string formatting.

Both functions "work" in the demo. Only one of them is a query.
"""
import os
from urllib.parse import quote_plus
import pandas as pd
from sqlalchemy import create_engine, text

if "AWC_DB_PW" not in os.environ:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")

engine = create_engine(
    "mysql+mysqlconnector://sqladmin:"
    f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019"
)

HOSTILE = "' OR '1'='1"


def unsafe(name):
    # f-string in SQL: the input is allowed to change the query's structure.
    return pd.read_sql(
        f"SELECT ProductID, Name FROM Production_Product WHERE Name = '{name}'", engine
    )


def safe(name):
    # Bound parameter: the driver owns the value. mysql.connector escapes it
    # before sending, so the server receives  WHERE Name = '\' OR \'1\'=\'1'
    # -- one string, which can no longer change the query.
    return pd.read_sql(
        text("SELECT ProductID, Name FROM Production_Product WHERE Name = :name"),
        engine,
        params={"name": name},
    )


print("unsafe:", len(unsafe(HOSTILE)), "rows")   # every product
print("safe:  ", len(safe(HOSTILE)), "rows")     # none — there is no such product
