"""
Unit 02 — ORM in 20 lines, so you recognise one when you meet it.

An ORM is built for
applications that manipulate single objects; analytics reads whole columns, which
is why the rest of this course stays with read_sql. Know it exists, do not use it here.
"""
import os
from urllib.parse import quote_plus

from sqlalchemy import create_engine, Column, Integer, String, Numeric
from sqlalchemy.orm import declarative_base, sessionmaker

if "AWC_DB_PW" not in os.environ:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")

Base = declarative_base()


class Product(Base):
    __tablename__ = "Production_Product"
    ProductID = Column(Integer, primary_key=True)
    Name = Column(String(50))
    ListPrice = Column(Numeric(19, 4))


engine = create_engine(
    "mysql+mysqlconnector://sqladmin:"
    f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019"
)
session = sessionmaker(bind=engine)()

# Object-at-a-time access — natural for an application, wasteful for analysis.
for product in session.query(Product).filter(Product.ListPrice > 3000).limit(5):
    print(product.ProductID, product.Name, product.ListPrice)

session.close()
