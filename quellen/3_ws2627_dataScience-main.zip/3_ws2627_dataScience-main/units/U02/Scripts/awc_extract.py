"""
Unit 02 — the reproducible extract.

Replaces "click through Workbench and export a CSV" with a script that can be
re-run, diffed and version-controlled. Writes AWC/awc_flat.csv (below the folder
you run it from) plus AWC/awc_flat.provenance.json; the provenance idea is picked
up properly in U03.

    export AWC_DB_PW='...'
    python3 awc_extract.py

It writes the course table every unit's scripts read: all of AWC, one row per
order line, the 25 columns and names of the U01 sheet, Exercise 4. Not your
group's extract: that one is filtered to your slice and lives in your group
folder (M1, Task 1). It refuses to overwrite an existing AWC/awc_flat.csv, so it
can never replace the one you built; to swap yours for this one, rename yours first.
Run it twice into two empty folders: the ORDER BY makes both sha256 identical.
"""
import getpass
import hashlib
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from urllib.parse import quote_plus

from sqlalchemy import create_engine

DB = "Adventureworks2019"
OUT = Path("AWC")
target = OUT / "awc_flat.csv"

if "AWC_DB_PW" not in os.environ:
    raise SystemExit("Set the password first:  export AWC_DB_PW='...'")
if target.exists():
    raise SystemExit(f"{target} already exists -- not overwriting it. "
                     "Run this in an empty folder.")
OUT.mkdir(exist_ok=True)

QUERY = """
SELECT d.SalesOrderID, d.SalesOrderDetailID, d.ProductID, d.OrderQty,
       d.UnitPrice, d.UnitPriceDiscount, d.LineTotal,
       DATE(h.OrderDate) AS OrderDate, DATE(h.ShipDate) AS ShipDate,
       h.OnlineOrderFlag, h.CustomerID, h.TerritoryID, h.SalesPersonID,
       h.SubTotal, h.TaxAmt, h.Freight, h.TotalDue,
       p.Name AS ProductName, p.StandardCost, p.ListPrice,
       sc.Name AS SubCategory, c.Name AS Category,
       t.Name AS TerritoryName, t.CountryRegionCode, t.`Group` AS TerritoryGroup
FROM        Sales_SalesOrderDetail       d
JOIN        Sales_SalesOrderHeader       h  ON h.SalesOrderID          = d.SalesOrderID
JOIN        Production_Product           p  ON p.ProductID             = d.ProductID
LEFT JOIN   Production_ProductSubcategory sc ON sc.ProductSubcategoryID = p.ProductSubcategoryID
LEFT JOIN   Production_ProductCategory    c  ON c.ProductCategoryID     = sc.ProductCategoryID
LEFT JOIN   Sales_SalesTerritory          t  ON t.TerritoryID           = h.TerritoryID
ORDER BY    d.SalesOrderID, d.SalesOrderDetailID
"""

engine = create_engine(
    f"mysql+mysqlconnector://sqladmin:{quote_plus(os.environ['AWC_DB_PW'])}@localhost/{DB}"
)

flat = pd.read_sql(QUERY, engine)
flat.to_csv(target, index=False)

# Four tables have a column "Name"; the AS keeps them apart under the names every
# unit uses (ProductName, SubCategory, Category, TerritoryName).
# DATE(): OrderDate is a MySQL TIMESTAMP, shown in the session's time zone, so the
# raw value (and with it the file's sha256) would depend on the machine that ran it.
# Note the LEFT JOINs: a product without a subcategory must not silently vanish.
# U01 showed why; here we record how many such rows there are instead of hiding them.
provenance = {
    "created_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "created_by": getpass.getuser(),
    "host": platform.node(),
    "python": sys.version.split()[0],
    "pandas": pd.__version__,
    "source_database": DB,
    "query": " ".join(QUERY.split()),
    "rows": int(len(flat)),
    "columns": list(flat.columns),
    "rows_without_category": int(flat.Category.isna().sum()),
    "output": target.name,
    "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
}
(OUT / "awc_flat.provenance.json").write_text(json.dumps(provenance, indent=2))

print(f"{len(flat):,} rows -> {target}")
print(f"{provenance['rows_without_category']:,} rows have no product category")
