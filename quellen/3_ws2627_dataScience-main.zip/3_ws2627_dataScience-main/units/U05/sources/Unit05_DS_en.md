---
source_id: DS-U05-L-EN
original_file: Unit05_DS_en.pdf
source_type: lecture
language: en
page_count: 48
source_sha256: 10bdbf3242deab76a5132b11dee9d9d787358c0816db5ea20461404d03cda3d1
verification: partial
---
# Unit05_DS_en

[Original PDF](../../../quellen/Unit05_DS_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit05_DS_en.pdf#page=1)

~~~~text
Data Science

BEYOND TABLES: TIME SERIES &
GRAPHS


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit05_DS_en.pdf#page=2)

~~~~text
                                                                    LEARNING GOALS



    • Explain why a time series is not a table with a date column — and why the sampling
      rate decides which patterns you can see
    • Resample with the right aggregation and per day, and tell a season from a level shift
    • Decide whether a gap is a defect or a real zero before you ﬁll it, and say what a sliding
      window removed
    • Justify when a graph model beats a table, and compute degree and a projection on
      AWC
    • Python route: query a property graph in Cypher, including paths of unknown length




2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit05_DS_en.pdf#page=3)

~~~~text
                                                  THE QUESTION OF THIS UNIT


           Your data have an order in time, or links between records.
    When does a plain table give the wrong answer — and what shape gives the
                                     right one?


             Order            Grain & seasons            Links                 Paths

      Time series — steps 1 and 2                  Graphs — steps 3 and 4
      Rows have an order. Example: AWC’s web       Rows are linked. Example: which cus-
      shop — is November really its best month,    tomers bought what this customer bought
      and why?                                     — and who else?

    Both live in tables. What changes is the shape you give them for the question: a time index
    you aggregate along, or edges you follow.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit05_DS_en.pdf#page=4)

~~~~text
                                                     WHY THIS MATTERS AT WORK


                      Time series                                       Graphs
       Controlling: this month vs. last month, vs.    Fraud detection: accounts that share a
       the same month last year.                      phone number form a ring.
       Demand planning: sales per week or             Recommendations: “customers who
       month, ahead.                                  bought this also bought . . . ”.
       Monitoring: a value every second from          Supply chains, IT: what fails if this one
       machines and servers.                          supplier or server fails?
       Tools: SQL GROUP BY, pandas resample,          Tools: Neo4j, Amazon Neptune, Python
       KNIME Date&Time nodes, InﬂuxDB,                networkx, KNIME Network Mining.
       TimescaleDB.

    Both start from your ﬂat table (U02). The risk is the same: a correct computation on the
    wrong shape gives a conﬁdent wrong answer.


4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit05_DS_en.pdf#page=5)

~~~~text
     STEP 1: ORDER IS PART OF THE DATA


    Order   Grain & seasons   Links   Paths




5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit05_DS_en.pdf#page=6)

~~~~text
                                                 NOT JUST A TABLE WITH A DATE COLUMN


    The shufﬂe test: shufﬂe a table — nothing is lost. Shufﬂe a time series — the trend is gone.
    Part of the information is the order.
                           reseller net revenue per category (sum)                        reseller net revenue per month (sum)
                    50                                                       4
            M USD




                                                                     M USD
                                                                             2
                    0
                              Bikes    Comp.     Cloth.     Acc.                 0   5       10      15         20     25        30     35
                         reordered: nothing lost -- rows exchangeable                reordered: trend gone -- rows NOT exchangeable
                    50                                                       4
            M USD




                                                                     M USD
                                                                             2
                    0
                              Acc.     Comp.     Cloth.    Bikes                 0   5       10      15         20     25        30     35
                                                                                                          month 1–36


    So: neighbouring values depend on each other · a missing month needs a decision · split
    train and test by time, not at random (U09).


                          Order                              Grain & seasons                      Links                               Paths
6
~~~~

## Page 007

[Original page 7](../../../quellen/Unit05_DS_en.pdf#page=7)

~~~~text
    STEP 2: GRAIN AND SEASONS — CHOOSE, THEN
                      CHECK


       Order   Grain & seasons   Links   Paths




7
~~~~

## Page 008

[Original page 8](../../../quellen/Unit05_DS_en.pdf#page=8)

~~~~text
                  DOWNSAMPLING IS CHOOSING AN AGGREGATION


    Downsampling: from a ﬁne grain to a coarser one, e.g. days → months. You must say how
    a month summarises its days:
     Function   Correct when the quantity is. . .
     sum        a ﬂow: revenue, units sold, clicks
     mean       a level: temperature, price, exchange rate
     last       a state: account balance, stock on hand, headcount
     max        a limit: peak load, worst latency
     count      the events themselves: orders, logins

    No tool chooses for you: SQL SUM(...) with GROUP BY, pandas .resample('ME').sum(),
    KNIME GroupBy with a method per column. Months are not equal: 28 to 31 days. To
    compare months, divide by the days: per day.


                Order                 Grain & seasons   Links              Paths
8
~~~~

## Page 009

[Original page 9](../../../quellen/Unit05_DS_en.pdf#page=9)

~~~~text
                                                     FOUR THINGS THAT MOVE A SERIES

                                 the series you see = trend + season + level shift + remainder (synthetic)
                20
                15
                10


                         trend                + season (period 12)           + level shift             + remainder




    Trend            a long-term increase or decrease
    Season           a pattern with a ﬁxed, known period: week, month, year
    Level shift      an event: the level jumps once and stays (new products, a new system)
    Remainder        what is left when the others are taken out
    More: Chatﬁeld & Xing (2019), ch. 2; Hyndman & Athanasopoulos (2021), §2.3, §3.2. Both also name cycles: rises
    and falls without a ﬁxed period.
                    Order                    Grain & seasons         Links                      Paths
9
~~~~

### DS-U05-L-EN-P009-D01 — Rekonstruktion

Synthetic additive series = upward trend + periodic seasonal wave (period 12) + one sustained level shift + irregular remainder. Four small plots show components; exact samples not supplied.

## Page 010

[Original page 10](../../../quellen/Unit05_DS_en.pdf#page=10)

~~~~text
                                                      A SEASON IS THE SAME MONTH, EVERY YEAR

     AWC’s web shop: bikes sold per day, by month. Per day, because months have 28–31 days
     (February → March 2013: +25 % in total, only +13 % per day).
                                             2011 (from June)                2012                         2013
                                                                10
          bikes sold online per day



                                                                                              30
                                      6                          8                            25
                                                                 6                            20
                                      4
                                                                                              15
                                                                 4
                                      2                                                       10
                                                                 2                             5
                                      0                          0                             0
                                          J F MAM J J A S OND        J F MAM J J A S OND           J F MAM J J A S OND


     November is the top month in all three years
     +29 to +40 % above the mean of October and December. A season is a pattern tied to the
     calendar that repeats: one good November is an event, three are a season.
                                           Order                Grain & seasons       Links                      Paths
10
~~~~

### DS-U05-L-EN-P010-D01 — Rekonstruktion

Three monthly bar charts (2011 from June, 2012, 2013); x month, y bikes sold online per day; November highlighted orange and highest each year, 29–40% above mean Oct/Dec. Different y scales; exact monthly observations not transcribed.

## Page 011

[Original page 11](../../../quellen/Unit05_DS_en.pdf#page=11)

~~~~text
                                                    ZOOM IN BEFORE YOU NAME A CAUSE
                       2012: bikes sold online per day                                                      month mean
                                                   Thanksgiving + Black Friday                      24/25 Dec
                  20
                  10
                   0
                        November                                           December
                       2013: bikes sold online per day
                                                              Thanksgiving + Black Friday           24/25 Dec
                  50

                   0
                        November                                           December

     Black Friday? Christmas? No single day stands out — Thanksgiving and Black Friday show
     no peak. The whole month is higher: 24 of 30 November days in 2013 lie above the
     December mean.

     The month shows that, the days show how
     “Thanksgiving drives sales” would be a guess the monthly series cannot support. Real
     shops do show day peaks; AWC is generated data that lifts the whole month.
                 Order                                   Grain & seasons                    Links                        Paths
11
~~~~

### DS-U05-L-EN-P011-D01 — Rekonstruktion

Daily bars Nov orange and Dec blue, 2012 and 2013; horizontal monthly mean, labels Thanksgiving/Black Friday and Dec 24/25; no special-day peak. In 2013, 24/30 November days exceed December mean.

## Page 012

[Original page 12](../../../quellen/Unit05_DS_en.pdf#page=12)

~~~~text
                                                                                  A JUMP IS NOT A SEASON

                          all online orders per day
           60             bikes sold online per day
                                                                29 May 2013, new assortment:
                                                                        Accessories, Clothing,
           40                                                                   Touring bikes

           20

                2011-05     2011-09      2012-01      2012-05   2012-09     2013-01     2013-05   2013-09   2014-01     2014-05

     Online orders per day: 11 in May 2013, 51 in July (×4.6). Bikes: 11 → 16.5 (×1.5). The shop
     started to sell more kinds of products — the level moves once and stays. That is a level
     shift, not a season.

     Compare like with like
     “Orders July 2013 vs. July 2012: ×5.8” is true and says nothing about demand. Compare
     one product group, or the time before and after the change separately.
                     Order                              Grain & seasons                 Links                         Paths
12
~~~~

### DS-U05-L-EN-P012-D01 — Rekonstruktion

Monthly lines: x 2011-05 to 2014-05, y count per day; orange all online orders, blue bikes sold online. Vertical marker 29 May 2013 new assortment. Orders 11→51/day May→July 2013, bikes 11→16.5. Sustained level shift, not season.

## Page 013

[Original page 13](../../../quellen/Unit05_DS_en.pdf#page=13)

~~~~text
                                  SAMPLING RATE: THE IDEA BEHIND NYQUIST

     Nyquist–Shannon: to see a pattern that repeats f times per unit, sample more than 2f
     times per unit (Shannon, 1949). Below: f = 7, only 8 samples.

                  true signal: 7 cycles (synthetic)        samples: 8 per unit    what the samples suggest: 1 slow cycle




     The orange wave is not in the signal
     Aliasing: every sample is correct, and they still draw a wave that is not there. A daily
     snapshot or a monthly report is sampling.

                  Order                               Grain & seasons            Links                         Paths
13
~~~~

### DS-U05-L-EN-P013-D01 — Rekonstruktion

Gray true signal 7 cycles per unit; orange 8 samples per unit connected as 1 apparent slow cycle (aliasing). Sample frequency > 2f; exact sample values not supplied.

## Page 014

[Original page 14](../../../quellen/Unit05_DS_en.pdf#page=14)

~~~~text
                            RESELLERS ORDER ONCE A MONTH — THE GRID INVENTS A PATTERN



     Resellers (the shops that resell AWC bikes) order in one batch at each month end:
                                                      resellers: net revenue per day (3,806 orders)
                        4
                               snapshot on the 15th of each month
                M USD

                        2
                        0
                                              2012                            2013                    2014
                                                 the same days summed per 4-week period (28 days)
                        4                                empty                       empty                   empty
                M USD




                        2
                        0
                                                                       period 1–39

     A snapshot on the 15th: all 35 values are 0 — “resellers buy nothing”. 4-week periods drift
     against the month: 3 of 39 catch no batch, a yearly dip that is not there. Plot the raw dates
     ﬁrst, then sum whole cycles.


                   Order                               Grain & seasons                   Links                       Paths
14
~~~~

## Page 015

[Original page 15](../../../quellen/Unit05_DS_en.pdf#page=15)

~~~~text
                                                  GAPS: DEFECT, OR REAL ZERO?

     A month without rows is a question, not an answer:
      The gap means                       Correct handling           If handled wrongly
      Nothing happened (real zero)        ﬁll with 0                 interpolating invents trade
      Nothing was recorded                leave as NaN               ﬁlling 0 invents a slump
      System outage                       leave the period out       any ﬁll distorts the trend
      Orders dated in the wrong month     ﬁx the dates               ﬁlling hides the real error


     On AWC: the edges of the data
     June 2014: 2,047 online order lines, not one bike. Real zero, or the end of the recording?
     The ﬁle cannot tell. So the bike series uses whole months only, June 2011 to May 2014 —
     once a gap is ﬁlled, nobody can see it was a gap.


                 Order                 Grain & seasons       Links                 Paths
15
~~~~

## Page 016

[Original page 16](../../../quellen/Unit05_DS_en.pdf#page=16)

~~~~text
    Break
   10 minutes




Then: Sliding Windows
~~~~

## Page 017

[Original page 17](../../../quellen/Unit05_DS_en.pdf#page=17)

~~~~text
                                                           WHAT SMOOTHING REMOVES — AND REVEALS

     A rolling mean of width w replaces each month by the mean of itself and the w − 1 months
     before (pandas .rolling(12).mean(), KNIME Moving Aggregation).

                                                      per month
           bikes sold online per day


                                       30             November
                                                      trailing 12-month mean
                                       20

                                       10

                                            2011-05     2011-09    2012-01     2012-05   2012-09   2013-01   2013-05   2013-09   2014-01    2014-05

     The 12-month mean shows the trend: 6.1 → 26.7 bikes per day, about half a year late. And
     the orange Novembers are gone: a 12-month window removes the season by design.

     Want the season? Compare, do not smooth
     Each month against the same month last year, or against its 12-month mean (a ratio).
                                              Order                            Grain & seasons               Links                         Paths
17
~~~~

## Page 018

[Original page 18](../../../quellen/Unit05_DS_en.pdf#page=18)

~~~~text
                        DECOMPOSITION: TREND × SEASON × REMAINDER

                                                                               season index per calendar month (×)
                   30        bikes sold online per day                   1.3
                             trend (centred 12-month mean)
                   20
                   10                                                    1.2

                                  2012                2013        2014   1.1
                        remainder (×)
                  1.1                                                    1.0
                  1.0
                                                                         0.9
                  0.9
                                                                         0.8
                                  2012                2013        2014           J F M A M J J A S O N D

     Three steps: (1) trend = centred 12-month mean; (2) season = value / trend, averaged per
     calendar month; (3) remainder = what is left.

     November ×1.29 — from only 2 Novembers
     ×, not +: the season grows with the level. No slot for a level shift: the moving mean
     smears the 2013 jump into the trend.
                 Order                                 Grain & seasons    Links                                 Paths
18
~~~~

## Page 019

[Original page 19](../../../quellen/Unit05_DS_en.pdf#page=19)

~~~~text
                                                        DECOMPOSITION IN YOUR TOOL

                 the three steps
     KNIME       Moving Aggregation (central, 12 months — close to the exact centred mean) →
                 Math Formula (value / trend) → GroupBy on the month
     pandas      trend = s.rolling(12, center=True).mean()
                 idx = (s / trend).groupby(s.index.month).mean()
                 ready-made
     KNIME       Decompose Signal component (KNIME Hub, needs Python) — additive (+), with
                 a ﬁtted trend line
     Python      statsmodels: seasonal_decompose(s, model="multiplicative",
                 period=12)
     Do the three steps by hand once: then you know what a ready-made tool did, and which
     period you chose for it.
     More: Chatﬁeld & Xing (2019), ch. 2; Hyndman & Athanasopoulos (2021), §3.3–3.4; statistics primer.
                    Order                     Grain & seasons           Links                    Paths
19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit05_DS_en.pdf#page=20)

~~~~text
                                      WHY NOT JUST A NEURAL NETWORK?

     Deep models such as N-BEATS learn trend and season by themselves. The price:
                    simple methods (this unit)           deep models (N-BEATS and alike)
     data           one short series is enough           many series or long histories
     preparation    you choose grain, period, gaps       less — but still a regular grid, clear
                                                         gaps, a split by time
     explain it     every number can be read             hard

     In the M4 competition (100,000 series) the six pure machine-learning entries ranked 23rd
     to 57th of 60, behind combinations of simple methods (Makridakis et al., 2020). N-BEATS
     later beat the winner by 3 % — trained on all 100,000 series (Oreshkin et al., 2020).

     Our bike series: 36 months, 3 Novembers
     No model learns a yearly season from three examples. Simple methods are the baseline
     every model must beat — and often the answer.

                   Order               Grain & seasons    Links                  Paths
20
~~~~

## Page 021

[Original page 21](../../../quellen/Unit05_DS_en.pdf#page=21)

~~~~text
                              TIMESTAMP PATHOLOGIES YOU WILL MEET


      Trap                    What it does
      Local time stored       clock change: hourly data lose an hour in March, double one in
                              October
      Mixed zones             an order seems to ship before it was placed
      Mixed column types      one column is converted to local time on load, the next is not:
                              one of them is a day early
      One day off (U04)       AWC’s export dates each order one day late: month-end batches
                              land in the next month (Extra)
      Text dates, sentinels   dates as text sort wrongly; 1900-01-01 means “unknown”

     Store UTC, display local, know the zone of every value you load. A shift that is already in
     the ﬁle: the plot shows the symptom, only the source shows the cause.


                  Order                Grain & seasons       Links                Paths
21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit05_DS_en.pdf#page=22)

~~~~text
            HANDS ON — EXERCISES 1 AND 2
                                    20 minutes
                  Sheet on Moodle: Unit05_Exercises_en.pdf

           Work at your machine — I am in the room. We go through it right after.




     lab


22
~~~~

## Page 023

[Original page 23](../../../quellen/Unit05_DS_en.pdf#page=23)

~~~~text
       STEP 3: LINKS ARE DATA — GRAPHS


     Order   Grain & seasons   Links   Paths




23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit05_DS_en.pdf#page=24)

~~~~text
                                    WHO ELSE BOUGHT WHAT COLE BOUGHT?

     A recommender asks it, a fraud analyst asks it about shared addresses. In SQL on the U02
     tables:
      1   SELECT DISTINCT o2.CustomerID
      2   FROM orders o1
      3   JOIN order_lines l1 ON l1.SalesOrderID = o1.SalesOrderID
      4   JOIN order_lines l2 ON l2.ProductID = l1.ProductID -- same product
      5   JOIN orders o2 ON o2.SalesOrderID = l2.SalesOrderID
      6   WHERE o1.CustomerID = 13595 AND o2.CustomerID <> 13595;

     Answer: 8,892 customers. “And who bought what they bought?” — four more joins per
     step. “As many steps as it takes” is no ﬁxed number of joins at all.

     The question is about links, not rows
     Store and query the links as edges: a graph. Same data, new shape.

                    Order                   Grain & seasons         Links      Paths
24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit05_DS_en.pdf#page=25)

~~~~text
                                                                                                         THE PROPERTY GRAPH MODEL


             Customer               Bikes
             SalesOrder             Accessories                                                                             Cole: one customer, four orders, nine
             Product                                              Sport-100 Helmet, Blue
                                                                                 Touring-1000 Blue, 54
                                                                                                                            products:
                                                                        order 59204                                           • Nodes have a label (Customer,
                Water Bottle - 30 oz.                                   2013-10-30
                                                                                                                                . . . ) and properties
     Mountain-200 Black, 46
                                order 61094
                                2013-11-28
                                                                                                                              • Edges have a direction and a type
         Mountain Bottle Cage
                                                              Cole Stewart
                                                                Bobigny
                                                                                                                                (PURCHASED, . . . ), and properties
                                                                                                          HL Road Tire          too
                                                                                       order 64250
                                                   order 46803                         2014-01-14
                                                   2012-06-13
                                                                                                         Road Tire Tube     A relationship is a pointer; in a table, a
                                                                                        Road-250 Black, 44                  value you look up.
                                         Road-250 Black, 58
      Shape = node label, colour = product category, size = number of edges at a node (its degree).




                                    Order                                        Grain & seasons                          Links                    Paths
25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit05_DS_en.pdf#page=26)

~~~~text
                                                                            A HOP: LOOK IT UP, OR FOLLOW IT

     “Which products did Cole buy?” — two hops either way. What differs: what a hop costs.

                                      RDBMS                                                        graph store

                                    customers                                   Cust
                                                                                       PUR
                                                              index on                       CHA
                                                                                                SED
                                                             CustomerID

                                       orders                                                         Order
                                                                                                                   CON
                                                               index on                                               TAI
                                                                                                                           NS
                                                             SalesOrderID

                                  order_lines                                                                                   Prod

                              2 hops = 2 joins: each one                                     2 hops = 2 pointer follows:
                              looks a value up in an index                                     the edge is the address




                           RDBMS                                                                   Graph store
      One hop costs        a lookup, grows with log(rows)                                          grows with the node’s neighbours, not
                                                                                                   with the table size
      Unknown depth        WITH RECURSIVE (a join in a loop)                                       one * in the pattern (step 4)
     Not a better database: the revenue report belongs in SQL, “who else bought this” in a graph. The gap
     opens with many hops on large data.
                   Order                                      Grain & seasons                      Links                               Paths
26
~~~~

## Page 027

[Original page 27](../../../quellen/Unit05_DS_en.pdf#page=27)

~~~~text
                                                            A GRAPH IS AN EDGE TABLE

     You do not need a graph database to have a graph. The same four-node graph, written
     three ways:

                                   edge table            adjacency list         adjacency matrix
                                                                                   a b c d
                                   from     to              a:   b, c
               a           b                                                    a 0 1 1 0
                                   a             b          b:   a, d
                                   a             c          c:   a              b 1 0 0 1
                                   b             d          d:   b              c 1 0 0 0
               c           d                                                    d 0 1 0 0
                                 SQL, KNIME, a CSV     graph stores, networkx      mostly zeros




     Your ﬂat table holds the edge table: one row per (customer, product) after a GROUP BY.
     Following links needs the list. As a customer × product matrix (888 × 59), our AWC
     sample graph is 94 % zeros (density = edges present / edges possible).

                   Order                  Grain & seasons             Links                 Paths
27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit05_DS_en.pdf#page=28)

~~~~text
                                                                       AWC AS A BIPARTITE GRAPH

     The ﬁrst 997 orders (May–Oct 2011): 888 customers, 59 products, 3,187 edges, all between
     the two groups: bipartite.
                              715 customers bought one product (709 a bike; bar cut)
                         20
                                   mean 3.6                     173 customers bought 2 to 35: all resellers, median 12
                         15
             customers




                         10
                          5
                          0
                                     5          10            15          20         25          30          35
                                                     distinct products bought (degree)

     Two groups, not one
     In 2011 the web shop sold only bikes. The mean of 3.6 describes neither group: split ﬁrst
     (U04).
                          Order                      Grain & seasons             Links                        Paths
28
~~~~

## Page 029

[Original page 29](../../../quellen/Unit05_DS_en.pdf#page=29)

~~~~text
         Break
       10 minutes




Then: Graph Operations on AWC
~~~~

## Page 030

[Original page 30](../../../quellen/Unit05_DS_en.pdf#page=30)

~~~~text
                                                  DEGREE IS NOT BEST-SELLING


     Degree = how many different customers a product reaches. Order lines count every order.
     Top 6 of either list in bold:
      Product                                      order lines   rank     customers (degree)   rank
      Road-150 Red, 56                                    170         1                 144       2
      Road-150 Red, 62                                    159         2                 155       1
      Road-150 Red, 48                                    123         3                 123       3
      AWC Logo Cap                                        118         4                  86       6
      Road-650 Black, 52                                  118         4                  84       7
      Long-Sleeve Logo Jersey, L                          116         6                  77      11
      Road-150 Red, 52                                    109         8                 109       4
      Road-150 Red, 44                                    107        10                 107       5
     Jersey: bought again by the same people — 6th by lines, 11th by degree. Sales reports
     rank by lines, cross-selling by degree.


                  Order               Grain & seasons        Links                   Paths
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit05_DS_en.pdf#page=31)

~~~~text
                                                         REACHABILITY AND COMPONENTS

                             with the resellers: one piece                    without them: one piece per bike



                             62     56      48      44        52                62        56        48   44      52




                                             one-time buyer        reseller          Road-150 Red
     Real sample: 5 bike sizes, 5 one-time buyers each, 3 resellers (links to these bikes only).

     The resellers hold the graph together
     All 947 nodes form one piece. Remove the 173 multi-product buyers (all resellers): 59
     pieces, one per product. SQL: WITH RECURSIVE; Python: one call (connected_components).

                     Order                         Grain & seasons                    Links                           Paths
31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit05_DS_en.pdf#page=32)

~~~~text
                                                                        PROJECTION: “BOUGHT TOGETHER”

     Projection: keep only products; link two when the same customer bought both (width =
     how many). Clothing, all orders:
                                   web shoppers: strongest 9 of 184 pairs                                      resellers: strongest 9 of 447 pairs
                       Women's Mountain Shorts, M              Long-Sleeve Logo Jersey, L
                                                                                            Short-Sleeve Classic Jersey, L                  Half-Finger Gloves, M
               Women's Mountain Shorts, L                              Long-Sleeve Logo Jersey, M


           Short-Sleeve Classic Jersey, XL       AWC Logo Cap            Long-Sleeve Logo Jersey, XL                         AWC Logo Cap
                                                                                      Long-Sleeve Logo Jersey, XL                                 Long-Sleeve Logo Jersey, L

                 Short-Sleeve Classic Jersey, S                     Short-Sleeve Classic Jersey, L
                                          Short-Sleeve Classic Jersey, M                                             Long-Sleeve Logo Jersey, M


     Who you project decides the answer
     Web shoppers add the cap: one hub. Resellers stock several sizes of one jersey: a dense
     mesh. Mixed, the few resellers decide the strongest pairs.

                        Order                                       Grain & seasons                             Links                                      Paths
32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit05_DS_en.pdf#page=33)

~~~~text
        STEP 4: FOLLOW PATHS — CYPHER


     Order   Grain & seasons   Links   Paths




33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit05_DS_en.pdf#page=34)

~~~~text
                                                     AN EMBEDDED GRAPH DATABASE


     pip install ladybug: an embedded property-graph store, in your Python process like SQLite — no
     server, no port, no login — and it speaks Cypher.

       1   import ladybug as lb, pandas as pd
      2    con = lb.Connection(lb.Database("my_graph.ladybug")) # a new, empty one
      3    con.execute("CREATE NODE TABLE Product(productId INT64 PRIMARY KEY, ...)")
      4    con.execute("COPY Product FROM df", {"df": products}) # 3 columns of awc_products.csv

     COPY ...      FROM a DataFrame: what you cleaned in pandas goes straight into the graph.

     Cypher is the part you keep
     Neo4j and Memgraph speak it too; the ISO standard GQL (ISO/IEC 39075, 2024) draws heavily on it.

     This step is Python. KNIME’s Network Mining nodes build and analyse graphs, but there is no node for a query
     language; Exercise 3 works in KNIME.



                     Order                    Grain & seasons           Links                      Paths
34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit05_DS_en.pdf#page=35)

~~~~text
                                                                    SCHEMA FIRST — A FAMILIAR IDEA



      Customer                       SalesOrder                      Product
      customerId INT64   PURCHASED   orderId INT64     CONTAINS      productId INT64    IN_SUBCAT   SubCategory       IN_CAT   Category
                                     orderDate DATE                  productName                    subCategoryName            categoryName
      fullName, city,                                  quantity,
      country STRING                 totalDue DOUBLE                 STRING                         STRING                     STRING
                                     online BOOLEAN    unitPrice,    listPrice DOUBLE
                                                       lineTotal




     Every property typed, underlined = primary key, declared before loading — a wrong row is
     rejected:
      1   CREATE (:Product {productId: 1, listPrice: 'cheap'});
      2   // Conversion exception: Cast failed. cheap is not in DOUBLE range.

     Schema-on-write (U03), like SQL; Neo4j would store the row. This schema is your map for
     writing queries.



                         Order                          Grain & seasons                     Links                          Paths
35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit05_DS_en.pdf#page=36)

~~~~text
                                                        CYPHER: THE PATTERN IS THE QUERY

       1   MATCH (c:Customer)-[:PURCHASED]->(o:SalesOrder)-[:CONTAINS]->(:Product)
       2     -[:IN_SUBCAT]->(:SubCategory)-[:IN_CAT]->(k:Category)
       3   RETURN k.categoryName, o.online, count(DISTINCT c) AS customers;


                                          PURCHASED                  CONTAINS              IN_SUBCAT                    IN_CAT
             you write      c:Customer                o:SalesOrder              :Product               :SubCategory               k:Category



             one                                                            Mountain-200
                           Cole Stewart                61094, web                                      Mountain Bikes               Bikes
           match                                                             Black, 46



     You draw the shape in text — () a node,                                    customers                                  web       reseller
     -[:TYPE]-> an edge. The database ﬁnds
                                                                                Accessories                              15,114         347
     every match; RETURN counts them like                                       Bikes                                     9,132         587
     GROUP BY.                                                                  Clothing                                 6,852          475
                                                                                Components                                    —         580

                         Order                          Grain & seasons               Links                             Paths
36
~~~~

## Page 037

[Original page 37](../../../quellen/Unit05_DS_en.pdf#page=37)

~~~~text
                                                                 “BOUGHT TOGETHER” IS A V


     1   MATCH (p1:Product)<-[:CONTAINS]-(:SalesOrder)                                                one
                                                                       you write
                                                                                                    match
     2     <-[:PURCHASED]-(c:Customer)-[:PURCHASED]->
     3     (:SalesOrder)-[:CONTAINS]->(p2:Product)                                               Water       Mountain
         WHERE p1.productId < p2.productId                           p1                p2
     4                                                                                           Bottle     Bottle Cage
     5   RETURN p1.productName, p2.productName,
     6      count(DISTINCT c) AS customers
                                                                 :SalesOrder       :SalesOrder        61094
     7   ORDER BY customers DESC LIMIT 2;

                                                                               c                          Cole
     pair                                      customers
                                                                 In Ladybug both arms may be the same order; Neo4j
     Water Bottle - 30 oz., Mountain Bottle         1,704
                                                                               would skip those pairs.
     Cage
     Water Bottle - 30 oz., Road Bottle Cage       1,522

     Cole alone: 9 products, 36 pairs. The query ﬁnds the V for every customer and counts per
     pair: the Projection slide, over all categories.

                     Order                     Grain & seasons         Links                     Paths
37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit05_DS_en.pdf#page=38)

~~~~text
                                                         PATHS OF UNKNOWN LENGTH


      1   // How far is every customer from Cole?                       10,226 customers
      2   MATCH (a:Customer {customerId: 13595})                               6 edges
      3       -[e:PURCHASED|CONTAINS* SHORTEST 1..16]-                  8,892 customers
      4       (b:Customer)                                             4 edges: a shared product
      5   RETURN length(e) AS edges,
      6        count(*) AS customers;                                          2 edges:
                                                                              9 products

                                                                                Cole
     * = a path of any length (here up to 16
     edges), SHORTEST = the one with the fewest.
     You never say how many joins.
     Result: every customer is 4 or 6 edges from
     Cole — 8,892 + 10,226 = all 19,118 others.

                                                                      ring = edges from Cole


                     Order                  Grain & seasons   Links                         Paths
38
~~~~

## Page 039

[Original page 39](../../../quellen/Unit05_DS_en.pdf#page=39)

~~~~text
                                                                         . . . AND ONE PATH, DRAWN


      1   MATCH p = (a:Customer {customerId: 13595})
      2       -[:PURCHASED|CONTAINS* SHORTEST 1..16]-
      3       (b:Customer {customerId: 11000})
      4   RETURN nodes(p);



           Cole Stewart                     Sport-100        order 43659      Mountain-100                    Jon Yang
                             order 59204   Helmet, Blue                        Silver, 38    order 43793
              France                                       Better Bike Shop                                   Australia
                                  1                                                              5
                                                2                 3                   4                            6



     Six edges. Here the bridge is a reseller’s order — one of many: Cole and Jon share no
     product, but about 3,000 orders hold one of each. SQL can do it too — with WITH
     RECURSIVE, whose loop and stop you write yourself.


                     Order                          Grain & seasons           Links                        Paths
39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit05_DS_en.pdf#page=40)

~~~~text
      Break
    10 minutes




Then: Hands On — Graphs
~~~~

## Page 041

[Original page 41](../../../quellen/Unit05_DS_en.pdf#page=41)

~~~~text
     HANDS ON — EXERCISES 3 AND 4
                           20 minutes
         Sheet on Moodle: Unit05_Exercises_en.pdf

      Exercise 5 is voluntary: which model answers which question.




41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit05_DS_en.pdf#page=42)

~~~~text
                                                                       KEY MESSAGES

     • Order: a time series carries information in its order; sample fewer than twice per cycle
       and you see patterns that are not there (Nyquist) — know the rhythm before you
       choose the grid
     • Grain and seasons: choose the aggregation, compare per day; a season repeats every
       year, a level shift happens once — zoom in before you name a cause
     • Gaps and windows: ﬁnd out what a gap means before you ﬁll it; a 12-month window
       shows the trend and removes the season — decomposition splits trend, season and
       remainder
     • Links: when the question is about relationships, store them as edges — degree is not
       best-selling, and who you project decides the answer
     • Paths: in Cypher you draw the pattern; * follows paths of unknown length that SQL
       needs WITH RECURSIVE for
     • The answer: a plain table misleads when you ignore order, grain or links; give the data
       the shape the question needs — a time index, or edges
     • Next: U06 — Features, Similarity & Distance
                Order                 Grain & seasons      Links                Paths
42
~~~~

## Page 043

[Original page 43](../../../quellen/Unit05_DS_en.pdf#page=43)

~~~~text
     EXTRA: THREE MORE VIEWS




43
~~~~

## Page 044

[Original page 44](../../../quellen/Unit05_DS_en.pdf#page=44)

~~~~text
                                          ONE DAY OFF EMPTIES WHOLE MONTHS


                                          Feb                 Mar                   Apr            May
                                                28 Feb (91)         30 Mar (178)          30 Apr (179)
                      source (database)
                                          +1 day
                                              1 Mar (91)             31 Mar (178)          1 May (179)
                                export

                                                   1 Mar                 1 Apr                1 May



     A third-party export of the reseller orders (U04) dates every order one day late. A batch on
     the last day of a month moves to the 1st of the next: some months get two batches, others
     almost none — a 4,301-fold jump between neighbouring months.

     A correct computation on a wrong input
     Every check inside the ﬁle passes. The plot shows that something is wrong; only the
     source shows what.


44
~~~~

## Page 045

[Original page 45](../../../quellen/Unit05_DS_en.pdf#page=45)

~~~~text
                                                          ONE SERIES, THREE DASHBOARD TILES



                   net revenue
                                       4




                     (M USD)
                                       2

                                       0

                                     180
                   (count)
                    orders
                                     120
                                      60
                   avg order value




                                      32
                       (k USD)




                                      24
                                      16

                                           2011-05 2011-09 2012-01 2012-05 2012-09 2013-01 2013-05 2013-09 2014-01 2014-05


     Reseller orders, ﬁrst six months vs. last six: which tile goes on the
     dashboard?
     Net revenue ×1.99, orders ×2.46, average order value ×0.81: revenue doubled because the number
     of orders grew faster than the value per order fell. Tile 1 reports success; tile 3 says customers place
     smaller orders. Same data, opposite headlines: choosing the KPI is part of the analysis
     (dashboards: U09).

45
~~~~

## Page 046

[Original page 46](../../../quellen/Unit05_DS_en.pdf#page=46)

~~~~text
                                           FROM A CYPHER QUERY TO A PICTURE


      1   res = con.execute("""
     2     MATCH (c:Customer)-[p:PURCHASED]->(o:SalesOrder)
     3         -[e:CONTAINS]->(x:Product)
     4     WHERE c.customerId = 13595
     5     RETURN c, p, o, e, x""")
     6    g = res.get_as_networkx() # a graph, not a table
     7    from pyvis.network import Network
     8    net = Network(directed=True)
     9    for n, d in g.nodes(data=True):
     10      net.add_node(n, label=d.get("fullName")
     11               or d.get("productName") or n)
     12   for u, v, d in g.edges(data=True):
     13      net.add_edge(u, v, label=d["_LABEL"])
     14   net.save_graph("awc_graph.html")
                                                              In the browser: drag, zoom, hover.
     Return nodes and edges, not columns: c, p, o, e, x comes back as a graph. One call
     makes it networkx; pip install pyvis draws it like Neo4j’s browser, with no server.

46
~~~~

## Page 047

[Original page 47](../../../quellen/Unit05_DS_en.pdf#page=47)

~~~~text
                                          SOURCES & FURTHER READING (1/2)

     • Chatﬁeld & Xing (2019), The Analysis of Time Series: An Introduction with R, 7th ed., Chapman &
       Hall/CRC — ch. 2: trend, seasonal variation, moving averages, decomposition
       doi.org/10.1201/9781351259446
     • Hyndman & Athanasopoulos (2021), Forecasting: Principles and Practice, 3rd ed., OTexts — the
       book, also free online. §2.3 time series patterns; §3.2 components; §3.3 moving averages; §3.4
       classical decomposition; §3.6 STL
       otexts.com/fpp3
     • Makridakis, Spiliotis & Assimakopoulos (2020), The M4 Competition: 100,000 time series and 61
       forecasting methods, Int. J. Forecasting 36(1):54–74
       doi.org/10.1016/j.ijforecast.2019.04.014
     • Oreshkin, Carpov, Chapados & Bengio (2020), N-BEATS: Neural basis expansion analysis for
       interpretable time series forecasting, ICLR
       arxiv.org/abs/1905.10437
     • Shannon (1949), Communication in the Presence of Noise, Proc. IRE 37(1):10–21 — the sampling
       theorem
       doi.org/10.1109/JRPROC.1949.232969

47
~~~~

## Page 048

[Original page 48](../../../quellen/Unit05_DS_en.pdf#page=48)

~~~~text
                                          SOURCES & FURTHER READING (2/2)


     • Robinson, Webber & Eifrem (2015), Graph Databases, 2nd ed., O’Reilly — written at Neo4j
     • Ladybug documentation — its Cypher dialect, COPY FROM, SHORTEST paths
       docs.ladybugdb.com
     • NetworkX and pyvis documentation — graph algorithms, and interactive pictures of them
       networkx.org/documentation/stable    pyvis.readthedocs.io
     • Francis et al. (2018), Cypher: An Evolving Query Language for Property Graphs, SIGMOD,
       1433–1445 — the language, deﬁned
       doi.org/10.1145/3183713.3190657
     • Angles & Gutierrez (2008), Survey of Graph Database Models, ACM Computing Surveys
       40(1):1–39 — the models behind the products
       doi.org/10.1145/1322432.1322433
     • ISO/IEC 39075:2024 — GQL, the ISO standard graph query language; it draws heavily on Cypher
       iso.org/standard/76120.html



48
~~~~
