---
source_id: DS-U05-EX
original_file: Unit05_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: e0c8444b4efee73f64eab9d5c57e4fbb02fdfebb1789eb8f6ab249695e03e792
verification: partial
---
# Unit05_Exercises_en

[Original PDF](../../../quellen/Unit05_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit05_Exercises_en.pdf#page=1)

<a id="ds-u05-ex-t01"></a>

**DS-U05-EX-T01 — Build the Series, Then Distrust It**

<a id="ds-u05-ex-t02"></a>

**DS-U05-EX-T02 — Gaps and Windows**

<a id="ds-u05-ex-t03"></a>

**DS-U05-EX-T03 — AWC as a Graph**

~~~~text
  Unit 05 — Exercises                                                               Time Series, Sequences and Graphs
Build a monthly series and ﬁnd out where it lies. Then see AWC as a graph.
▶ In the room        what ﬁts the stop — all that is expected. The room splits at stop B: take one of the two exercises; you
                     hear the other one in the discussion.
⃝ Extra              voluntary, at home.
Stop A, 20 min       Exercises 1 and 2        Stop B, 20 min: Exercise 3 or 4
Asynchronous         the same sheet, before your weekly slot; bring what did not run.
You need             Ex 1–2: Data/orders.csv, the third-party export of the 3,806 reseller orders from the lecture (not your ﬂat
                     table). Ex 3: your ﬂat table and networkx, or KNIME. Ex 4: pip install ladybug and the ready-built
                     Scripts/awc_graph.ladybug. KNIME only? At stop B take Exercise 3.


Exercise 1 — Build the Series, Then Distrust It stop A · ▶ 10 min
 1 From Data/orders.csv, build monthly revenue with a plain GROUP BY on year-month. Plot it. Write down min, max and
   max/min.
      One row is one order line. SubTotal belongs to the order and repeats on each of its lines — sum LineTotal instead.

      Example — the naive series in pandas

      o = pd.read_csv("Data/orders.csv", parse_dates=["OrderDate"])
      m = o.groupby(o.OrderDate.dt.to_period("M")).LineTotal.sum()
      print(m.min(), m.max(), m.max() / m.min())

 2 List the distinct order dates, or plot them on a number line. What do you notice about the days of the month?
 3 Move every date on the 1st to the previous month and aggregate again. Report the new max/min.
The swing in step 1 is not a fact about the business: the export dates each order one day late, so month-end batches land
in the next month.
  In KNIME
  Extract Date&Time Fields (year, month) → GroupBy. For step 3: Date&Time Shift one day back on the dates that fall on the 1st,
  then the same two nodes. Kit: Scripts/awc_timeseries_plots.py.
⃝ Extra:   does the same pattern exist in the MySQL source, or only in the export? Answer with a query, not an opinion.
Exercise 2 — Gaps and Windows stop A · ▶ 10 min
 1 List every month with no orders in the naive series. For two of them decide: real zero, not recorded, system outage, or
   orders dated in the wrong month — with a reason.
 2 On the corrected series (Exercise 1, step 3) compute a 12-month rolling mean (s.rolling(12).mean(); KNIME Moving
   Aggregation). One sentence: what does it show that the raw series does not — and what does it destroy?
⃝ Extra: add a 3-month mean and report stdev/mean for all three series. Then count how many observations you have per
calendar month: is a seasonality claim defensible? Saying no is a valid answer.
Exercise 3 — AWC as a Graph stop B · ▶ 20 min · or Exercise 4
 1 Build the customer–product graph for your 20 highest-revenue customers. Report nodes, edges and density.
      Density on a bipartite graph: a customer never links to a customer, so the possible edges are customers × products: density =
      G.number_of_edges() / (n_customers * n_products). The lecture’s graph (888 customers, 59 products, 3,187 edges) gives
      0.061; networkx.density(G) would give 0.0071, because it counts pairs that cannot exist.
 2 Compute each customer’s degree (distinct products bought). In the lecture’s 997-order graph the median degree was 1.
   Why are yours so different — who are your 20?
 3 Project onto products: two products are linked when a customer bought both. Name your top pair, look at who bought
   it, and say whether a web shopper would react to it as a cross-sell. Project onto products, not customers: that is a few
   thousand pairs instead of up to 183 million.
  In KNIME
  The graph is a table: GroupBy on CustomerID (Sum LineTotal) → Top k Row Filter (20) → Reference Row Filter (ﬂat table on
  top) → GroupBy on CustomerID + ProductID = the edge list; count nodes and edges, density in a Math Formula; degree = GroupBy
  on CustomerID of the edge list. Pairs: Joiner of the edge list with itself on CustomerID, Rule-based Row Filter $ProductID$ <
  $ProductID (Right)$ => TRUE, GroupBy on both product columns, Sorter.

⃝ Extra: (a) Find the category with the highest degree (customers who bought in it). Is it also the highest-revenue category?
Report both rankings. Try betweenness on the 20-customer graph. (b) At home: the same graph with the KNIME Network
Mining extension (Network Creator, Object Inserter, Feature Inserter, Network Viewer); compare the counts. Kit:
Scripts/awc_graph_build.py, awc_graph_analysis.py.




Unit 05 · Data Science · exercise sheet                                                                                               1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit05_Exercises_en.pdf#page=2)

<a id="ds-u05-ex-t04"></a>

**DS-U05-EX-T04 — Cypher**

<a id="ds-u05-ex-t05"></a>

**DS-U05-EX-T05 — Which Model for Which Question?**

~~~~text
Exercise 4 — Cypher stop B · ▶ 20 min · or Exercise 3
 1 Open the graph that came with the unit. Scripts/awc_graph_schema.cypher shows its node and edge types.
       import ladybug as lb
       db = lb.Database("Scripts/awc_graph.ladybug", read_only=True)    # cannot damage the file
       con = lb.Connection(db)
       print(con.execute("MATCH (c:Customer) RETURN count(c)").get_as_df())   # 19119

 2 Write two queries — one single hop (follow one edge), one with an aggregate (count(), sum() or collect(DISTINCT
   . . . ) in the RETURN, like GROUP BY). Put the SQL you would have written next to each.
  Example — a single hop, and how to read it
  MATCH (p:Product {productId: 711})-[:IN_SUBCAT]->(s:SubCategory) RETURN s.subCategoryName
  (p:Product) is a node with label Product, named p; -[:IN_SUBCAT]-> an edge of that type and direction; {productId: 711} keeps
  one node; RETURN works like SELECT. More examples, each with its result: Scripts/awc_graph_queries.cypher.
⃝ Extra: write one query with a variable-length path (*1..n), then the SQL that does the same: which was easier to get
right? Note every place Ladybug’s Cypher surprised you. One to start: a plain count(x) written after a count(DISTINCT y)
in the same RETURN comes back as 0.
Exercise 5 — Which Model for Which Question? ⃝ Extra · the judgement call
 1 Write down ﬁve business questions about AWC. For each: table, time series or graph — and why?
 2 Find one question that is easy as a graph and painful in SQL. Implement both; compare lines of code and how sure you
   are of each.
 3 Find one question that is easy in SQL and awkward as a graph (think aggregation).

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: your monthly series before and after the date ﬁx, with max/min for both
• Ex 2: two months with no orders, and what you decided each one was
• Ex 3: nodes, edges, density, and your top co-purchase pair
• Ex 4: two Cypher queries beside the SQL you would have written




Unit 05 · Data Science · exercise sheet                                                                                           2
~~~~
