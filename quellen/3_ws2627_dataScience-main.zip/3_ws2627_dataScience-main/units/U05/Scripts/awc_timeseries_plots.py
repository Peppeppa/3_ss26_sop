"""
Unit 05 — the figures for the time-series half.

A time series is a picture before it is a table: the month-boundary defect is
almost invisible in a column of numbers and unmissable in a line. This script
draws its figures straight from awc_timeseries.py, so the plots and the
slides cannot drift apart.

    python3 awc_timeseries_plots.py        -> ../Images/fig_ts_*.pdf  (en + de)
    python3 awc_timeseries_plots.py month_day -> only fig_ts_month_day (en + de)
    python3 awc_timeseries_plots.py naive  -> only fig_ts_naive (en + de)
    python3 awc_timeseries_plots.py days   -> only fig_ts_days  (en + de)
    python3 awc_timeseries_plots.py fix    -> only fig_ts_fix   (en + de)
    python3 awc_timeseries_plots.py source -> only fig_ts_source (en + de)
    python3 awc_timeseries_plots.py smooth -> only fig_ts_smooth (en + de)
    python3 awc_timeseries_plots.py kpi    -> only fig_ts_kpi    (en + de)

Each figure is written twice, `fig_ts_x.pdf` and `fig_ts_x_de.pdf`, because a
German slide with an English y axis is sloppy. Only prose is translated: node
labels, category names and column names stay as they are in the data, since
they are identifiers rather than words.

  fig_ts_month_day orders per day of the month, resellers (export) next to online
                   (database): five bars against thirty-one. Day 1 is grey with
                   a "?" -- it does not look like month end, and the diagnosis
                   slide answers it. Online day 30/31 are lower only because not
                   every month has them.
  fig_ts_naive     the naive series alone, as the export gives it: one bar per
                   calendar month, the empty months marked, the two extremes
                   labelled. Nothing corrected yet -- the source comes later.
  fig_ts_days      the raw order dates of Dec 2013 - Apr 2014 on a day axis, the
                   calendar months as bands: batches on day 28-31, or on the 1st
                   -- one day later and already in the next month.
  fig_ts_fix       the same slots and scale as fig_ts_naive, after the workaround
                   (day 1 -> previous month): the three empty months filled,
                   May 2014 emptied, because its only batch moved to April.
  fig_ts_source    the same batches twice, source above and export below, one
                   arrow per batch: every date one day later, and the month-end
                   batches cross into the next month.
  fig_ts_disaster  (not in the deck) the naive monthly series, the workaround
                   and the database in one plot: 4,301x becomes 8.6x.
  fig_ts_smooth    the corrected series with a 3- and 6-month rolling mean, and
                   what each window removes.
  fig_ts_kpi       the same series as a dashboard would show it: revenue,
                   order count and average order value on a shared time axis.
                   Three KPIs, one x-axis -- and the point that the shape of a
                   KPI depends on which one you picked.
"""
import datetime
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MaxNLocator

from awc_timeseries import load_orders, load_orders_export, monthly, rolling

IMG = Path(__file__).resolve().parent.parent / "Images"
IMG.mkdir(exist_ok=True)

# Only the prose. Anything that names a column or a value is left alone.
STR = {
    "en": dict(kpi_rev="net revenue\n(M USD)", kpi_ord="orders\n(count)",
               kpi_aov="avg order value\n(k USD)",
               mres="resellers (export): {n:,} orders on {d} dates",
               monl="online (database): {n:,} orders on {d:,} dates",
               mday="day of month", mord="orders", m31="day 31 exists in\n7 of 12 months",
               src="source (database)", exp="export", plus1="+1 day",
               frev="net revenue per business month: day 1 counted in the previous month (M USD, sum)",
               refill="was empty", moved="batch moved\nto April",
               drev="net revenue per order date (M USD, sum)", d1="dated on the 1st",
               d28="dated on day 28-31", dn="{n} orders",
               nb=("no batch", "one batch", "two batches"),
               nrev="net revenue per calendar month (M USD, sum)",
               nogap="no orders", tiny="orders, but almost no revenue", nx="{v:,.0f} USD",
               revenue="revenue", orders="orders", avgvalue="avg value",
               monthly="net revenue per business month",
               roll="{w}-month rolling mean (trailing)",
               under="12-month mean: +{pct:.0f}% from first to last value",
               truth="the source database (ground truth)",
               naive="naive calendar month  ({s:,.0f}x spread)",
               fixed="day 1 -> previous month  ({s:.1f}x, exact to the cent)",
               empty="$\\circ$  {n} months the calendar month nearly empties out"),
    "de": dict(kpi_rev="Nettoumsatz\n(Mio. USD)", kpi_ord="Bestellungen\n(Anzahl)",
               kpi_aov="Ø Bestellwert\n(Tsd. USD)",
               mres="Reseller (Export): {n:,} Bestellungen an {d} Daten",
               monl="Online (Datenbank): {n:,} Bestellungen an {d:,} Daten",
               mday="Tag im Monat", mord="Bestellungen", m31="Tag 31 gibt es in\n7 von 12 Monaten",
               src="Quelle (Datenbank)", exp="Export", plus1="+1 Tag",
               frev="Nettoumsatz je Geschäftsmonat: Tag 1 zählt zum Vormonat (Mio. USD, Summe)",
               refill="war leer", moved="Batch in den\nApril verschoben",
               drev="Nettoumsatz je Bestelldatum (Mio. USD, Summe)", d1="datiert auf den 1.",
               d28="datiert auf Tag 28-31", dn="{n} Bestellungen",
               nb=("kein Batch", "ein Batch", "zwei Batches"),
               nrev="Nettoumsatz je Kalendermonat (Mio. USD, Summe)",
               nogap="keine Bestellung", tiny="Bestellungen, aber fast kein Umsatz", nx="{v:,.0f} USD",
               revenue="Umsatz", orders="Bestellungen", avgvalue="Ø Wert",
               monthly="Nettoumsatz je Geschäftsmonat",
               roll="gleitendes {w}-Monats-Mittel (rückblickend)",
               under="12-Monats-Mittel: +{pct:.0f}% vom ersten zum letzten Wert",
               truth="die Quelldatenbank (Referenz)",
               naive="naiver Kalendermonat  (Spanne {s:,.0f}x)",
               fixed="Tag 1 -> Vormonat  ({s:.1f}x, exakt auf den Cent)",
               empty="$\\circ$  {n} Monate, die der Kalendermonat fast leert"),
}


def out(name, lang):
    return IMG / (f"{name}.pdf" if lang == "en" else f"{name}_de.pdf")


# Month names, number format and the million unit are prose, so they follow the
# language: "1 Mar", "2.74 M USD" in English; "1. Mär", "2,74 Mio. USD" in German.
MON_DE = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"]


def mon(d, lang):
    return f"{d:%b}" if lang == "en" else MON_DE[d.month - 1]


def dm(d, lang):
    return f"{d.day} {d:%b}" if lang == "en" else f"{d.day}. {MON_DE[d.month - 1]}"


def num(x, spec, lang):
    s = format(x, spec)
    return s if lang == "en" else s.replace(",", "_").replace(".", ",").replace("_", ".")


def musd(lang):
    return "M USD" if lang == "en" else "Mio. USD"

# The validated deck palette (thwsbeamertheme.sty). Blue carries the correct
# series, orange the defective one -- orange is the alert colour everywhere else
# in these decks, so the reader already knows which line is the problem.
BLUE, ORANGE, PETROL, GREY = "#2A78D6", "#EB6834", "#005564", "#8A8A8A"
plt.rcParams.update({
    "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 150, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})


def as_dates(series):
    keys = sorted(series)
    return [datetime.date(y, m, 1) for y, m in keys], [series[k] for k in keys]


def eur(x, _=None):
    return f"{x/1e6:.0f}M" if x >= 1e6 else f"{x/1e3:.0f}k"


def fig_month_day(orders, online, lang="en"):
    """Orders per day of the month: resellers batch, the web shop does not.

    Every day 1-31 gets a slot, so the reseller panel shows the empty days as
    empty. Day 1 is grey and marked "?": it is not month end, and nothing on
    this slide explains it yet -- the diagnosis slide does.
    """
    t = STR[lang]
    def per_day(o):
        c = [0] * 32
        for d, _ in o.values():
            c[d.day] += 1
        return c, len({d for d, _ in o.values()})
    fig, axes = plt.subplots(1, 2, figsize=(6.8, 1.55))
    days = list(range(1, 32))
    for ax, o, title in ((axes[0], orders, t["mres"]), (axes[1], online, t["monl"])):
        c, nd = per_day(o)
        cols = [GREY if (o is orders and d == 1) else BLUE for d in days]
        ax.bar(days, [c[d] for d in days], width=0.75, color=cols, lw=0)
        head = title.format(n=len(o), d=nd)
        ax.set_title(head.replace(",", ".") if lang == "de" else head, fontsize=7.5)
        ax.set_xlim(0.2, 31.8); ax.set_xticks([1, 7, 14, 21, 28, 31])
        ax.tick_params(labelsize=7); ax.set_xlabel(t["mday"], fontsize=7)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
        ax.margins(y=0.22)
    c, _ = per_day(orders)
    axes[0].text(1, c[1], "?", ha="center", va="bottom", fontsize=10,
                 color=GREY, fontweight="bold")
    axes[0].set_ylabel(t["mord"], fontsize=7)
    c, _ = per_day(online)
    top = max(c)
    axes[1].set_ylim(0, top * 1.5)
    axes[1].annotate(t["m31"], xy=(31, c[31] + top * 0.03), xytext=(31.2, top * 1.1),
                     fontsize=6, ha="right", va="bottom", color=GREY,
                     arrowprops=dict(arrowstyle="-", color=GREY, lw=0.7, relpos=(0.97, 0)))
    fig.tight_layout(w_pad=1.5)
    fig.savefig(out("fig_ts_month_day", lang)); plt.close(fig)


def fig_naive(orders, lang="en"):
    """The export, summed per calendar month -- and nothing else.

    Every calendar month of the export's span gets a slot, so the empty months
    are visible as missing bars instead of being silently skipped by the axis.
    """
    t = STR[lang]
    ser = monthly(orders)
    first, last = min(ser), max(ser)
    slots, (y, m) = [], first
    while (y, m) <= last:
        slots.append((y, m)); y, m = (y + (m == 12), m % 12 + 1)
    vals = [ser.get(k, 0.0) for k in slots]
    x = list(range(len(slots)))
    fig, ax = plt.subplots(figsize=(6.8, 1.6))
    ax.bar(x, [v / 1e6 for v in vals], width=0.75, color=ORANGE)
    # Two kinds of "nothing visible": a month with NO orders (x), and a month
    # with orders whose bar is too small to see on a linear axis (o). They must
    # not look alike -- only the first is a gap.
    top = max(ser.values())
    for i, k in enumerate(slots):
        if k not in ser:
            ax.plot(i, 0.12, "x", color=ORANGE, ms=5, mew=1.4)
        elif ser[k] < 0.01 * top:
            ax.plot(i, 0.12, "o", mfc="none", mec=ORANGE, ms=5, mew=1.2)
            ax.text(i, 0.45, num(ser[k], ",.0f", lang) + " USD", fontsize=6.5, rotation=90,
                    ha="center", va="bottom")
    ax.plot(0.3, 6.3, "x", color=ORANGE, ms=5, mew=1.4)
    ax.text(0.9, 6.3, t["nogap"], fontsize=7, va="center")
    ax.plot(0.3, 5.5, "o", mfc="none", mec=ORANGE, ms=5, mew=1.2)
    ax.text(0.9, 5.5, t["tiny"], fontsize=7, va="center")
    mx = max(ser, key=ser.get)
    i = slots.index(mx)                             # largest: label above its bar
    ax.text(i + 0.4, ser[mx] / 1e6 + 0.25,
            f"{mx[0]}-{mx[1]:02d}: {num(ser[mx] / 1e6, '.2f', lang)} {musd(lang)}",
            fontsize=7, ha="right", va="bottom")
    ticks = [i for i, k in enumerate(slots) if k[1] in (1, 7)]
    ax.set_xticks(ticks)
    ax.set_xticklabels([f"{slots[i][0]}-{slots[i][1]:02d}" for i in ticks], fontsize=7)
    ax.set_xlim(-0.8, len(slots) - 0.2); ax.set_ylim(0, 7.0)
    ax.set_yticks(range(0, 7))
    ax.set_ylabel(musd(lang)); ax.set_title(t["nrev"], fontsize=8)
    fig.savefig(out("fig_ts_naive", lang)); plt.close(fig)


def fig_fix(orders, lang="en"):
    """The workaround, on exactly the slots and scale of fig_ts_naive."""
    t = STR[lang]
    naive, ser = monthly(orders), monthly(orders, shift_day_one=True)
    first, last = min(naive), max(naive)            # the naive span, for comparison
    slots, (y, m) = [], first
    while (y, m) <= last:
        slots.append((y, m)); y, m = (y + (m == 12), m % 12 + 1)
    fig, ax = plt.subplots(figsize=(6.8, 1.6))
    ax.bar(range(len(slots)), [ser.get(k, 0.0) / 1e6 for k in slots], width=0.75, color=BLUE)
    for i, k in enumerate(slots):
        if k not in naive and k in ser:
            ax.text(i, ser[k] / 1e6 + 0.15, t["refill"], rotation=90, fontsize=6.5,
                    ha="center", va="bottom", color=BLUE)
        if k in naive and k not in ser:
            ax.plot(i, 0.12, "x", color=GREY, ms=5, mew=1.4)
            ax.annotate(t["moved"], xy=(i, 0.35), xytext=(i - 1.5, 5.2), fontsize=6.5,
                        ha="right", va="center", color=GREY,
                        arrowprops=dict(arrowstyle="-", color=GREY, lw=0.7))
    ticks = [i for i, k in enumerate(slots) if k[1] in (1, 7)]
    ax.set_xticks(ticks)
    ax.set_xticklabels([f"{slots[i][0]}-{slots[i][1]:02d}" for i in ticks], fontsize=7)
    ax.set_xlim(-0.8, len(slots) - 0.2); ax.set_ylim(0, 7.0); ax.set_yticks(range(0, 7))
    ax.set_ylabel(musd(lang)); ax.set_title(t["frev"], fontsize=8)
    fig.savefig(out("fig_ts_fix", lang)); plt.close(fig)


def fig_source(orders, db_orders, lang="en"):
    """Source above, export below, same day axis: each batch moves one day."""
    t = STR[lang]
    lo, hi = datetime.date(2014, 2, 12), datetime.date(2014, 5, 9)
    def per_day(o):
        day = {}
        for d, v in o.values():
            if lo <= d <= hi:
                n, tot = day.get(d, (0, 0.0)); day[d] = (n + 1, tot + v)
        return day
    src, exp = per_day(db_orders), per_day(orders)
    fig, ax = plt.subplots(figsize=(6.8, 1.6))
    starts = [datetime.date(2014, m, 1) for m in range(2, 7)]
    for a, b in zip(starts, starts[1:]):
        a0, b0 = max(a, lo), min(b, hi)
        if a.month % 2 == 0:
            ax.axvspan(a0, b0, color=GREY, alpha=0.13, lw=0)
        ax.text(a0 + (b0 - a0) / 2, 2.72, mon(a, lang), ha="center", fontsize=8.5, color=GREY)
    Y_SRC, Y_EXP, H = 1.35, 0.0, 0.75
    for row, day, y in ((t["src"], src, Y_SRC), (t["exp"], exp, Y_EXP)):
        for d, (n, tot) in day.items():
            if n < 10:
                continue                            # stragglers: not the story
            ax.add_patch(plt.Rectangle((d, y), datetime.timedelta(days=1), H,
                         color=ORANGE if d.day == 1 else BLUE, lw=0))
            ax.text(d + datetime.timedelta(hours=12), y + H + 0.05,
                    f"{dm(d, lang)} ({n})", ha="center", fontsize=8)
        ax.text(lo - datetime.timedelta(days=1), y + H / 2, row, ha="right", va="center",
                fontsize=8.5)
    for d, (n, _) in src.items():
        if n >= 10:
            e = d + datetime.timedelta(days=1)
            ax.annotate("", xy=(e + datetime.timedelta(hours=12), Y_EXP + H + 0.28),
                        xytext=(d + datetime.timedelta(hours=12), Y_SRC - 0.02),
                        arrowprops=dict(arrowstyle="-|>", color=GREY, lw=0.9))
    first = min(d for d, (n, _) in src.items() if n >= 10)
    ax.text(first - datetime.timedelta(days=2), (Y_SRC + Y_EXP + H) / 2 + 0.1, t["plus1"],
            ha="right", va="center", fontsize=8, color=GREY)
    ax.set_xlim(lo, hi); ax.set_ylim(-0.05, 2.95)
    ax.set_yticks([]); ax.spines["left"].set_visible(False)
    ticks = [m for m in starts if lo <= m <= hi]
    ax.set_xticks(ticks); ax.set_xticklabels([dm(m, lang) for m in ticks], fontsize=8)
    fig.savefig(out("fig_ts_source", lang)); plt.close(fig)


def fig_days(orders, lang="en"):
    """The raw dates, not yet aggregated: where each batch lands on the calendar.

    Each calendar month is a band carrying the total the naive series reports
    for it (slide before), so the link from symptom to cause is on the picture:
    March holds two batches, February and April none.
    """
    t = STR[lang]
    lo, hi = datetime.date(2014, 1, 14), datetime.date(2014, 5, 12)
    day, month = {}, {}
    for d, v in orders.values():
        if d.year == 2014:
            month[d.month] = month.get(d.month, 0.0) + v
        if lo <= d <= hi:
            n, tot = day.get(d, (0, 0.0)); day[d] = (n + 1, tot + v)
    fig, ax = plt.subplots(figsize=(6.8, 2.15))
    starts = [datetime.date(2014, m, 1) for m in range(1, 7)]
    for a, b in zip(starts, starts[1:]):
        a0, b0 = max(a, lo), min(b, hi)
        if a.month % 2 == 0:
            ax.axvspan(a0, b0, color=GREY, alpha=0.13, lw=0)
        tot = month[a.month]
        val = (f"{num(tot / 1e6, '.2f', lang)} {musd(lang)}" if tot >= 1e5
               else f"{num(tot, ',.0f', lang)} USD")
        odd = tot < 1e5 or tot > 5e6
        # The cut-off months at either edge (Jan, May) carry only their name: their
        # partial totals are not the story, and the long label would hit the axis.
        whole = a0 == a and b0 == b
        ax.text(a0 + (b0 - a0) / 2, 4.95, f"{mon(a, lang)}: " + val if whole else mon(a, lang),
                ha="center", va="top",
                fontsize=7, color=ORANGE if odd else "black",
                fontweight="bold" if odd else "normal")
        nb = sum(1 for d, (n, _) in day.items() if n > 10 and a <= d < b)
        if a0 == a and b0 == b:                     # whole months only
            ax.text(a0 + (b0 - a0) / 2, 4.45, t["nb"][min(nb, 2)], ha="center", va="top",
                    fontsize=6.5, color=ORANGE if odd else GREY)
    big = {d: nt for d, nt in day.items() if nt[0] > 10}
    for d, (n, tot) in sorted(day.items()):
        # a day is the interval [00:00, 24:00): drawn that way, a bar lies
        # inside the month it is counted in, never on the boundary
        ax.bar(d, tot / 1e6, width=1.0, align="edge",
               color=ORANGE if d.day == 1 else BLUE, lw=0)
    for d, (n, tot) in big.items():
        ax.text(d + datetime.timedelta(hours=12), tot / 1e6 + 0.1, dm(d, lang),
                ha="center", fontsize=6.5)
    feb = datetime.date(2014, 2, 28)
    ax.annotate(f"{dm(feb, lang)}: " + t["dn"].format(n=day[feb][0]), xy=(feb, 0.04),
                xytext=(feb - datetime.timedelta(days=11), 1.2), fontsize=6.5, ha="center",
                arrowprops=dict(arrowstyle="-", color=GREY, lw=0.7))
    ax.plot([], [], color=BLUE, lw=2.4, label=t["d28"])
    ax.plot([], [], color=ORANGE, lw=2.4, label=t["d1"])
    ax.legend(frameon=False, fontsize=7, ncol=2, loc="lower center",
              bbox_to_anchor=(0.5, 1.0))
    ax.set_xlim(lo, hi); ax.set_ylim(0, 5.0)
    ticks = [m for m in starts if lo <= m <= hi]
    ax.set_xticks(ticks); ax.set_xticklabels([dm(m, lang) for m in ticks], fontsize=7)
    ax.set_yticks(range(0, 5)); ax.set_ylabel(musd(lang))
    ax.set_title(t["drev"], fontsize=8, pad=17)
    fig.savefig(out("fig_ts_days", lang)); plt.close(fig)


def fig_disaster(orders, db, lang="en"):
    """Three lines: the fiction, the workaround, and the truth.

    The workaround line and the database line coincide exactly, which is the
    whole argument -- so the database is drawn thick and pale underneath and the
    fix on top of it, and you can see the fix land on the source.
    """
    naive_x, naive_y = as_dates(monthly(orders))
    fix_x, fix_y = as_dates(monthly(orders, shift_day_one=True))
    db_x, db_y = as_dates(db)
    fig, ax = plt.subplots(figsize=(6.6, 2.3))
    t = STR[lang]
    ax.plot(db_x, db_y, "-", lw=5, color=BLUE, alpha=0.22,
            label=t["truth"], solid_capstyle="round")
    ax.plot(naive_x, naive_y, "-o", ms=3, lw=1.2, color=ORANGE,
            label=t["naive"].format(s=max(naive_y) / min(naive_y)))
    ax.plot(fix_x, fix_y, "-o", ms=3, lw=1.4, color=BLUE,
            label=t["fixed"].format(s=max(fix_y) / min(fix_y)))
    # Ring the months the calendar month nearly empties out. No leader lines and no
    # in-figure prose: the legend names them and the slide explains them, which
    # keeps the data area clear.
    lo = [i for i in range(len(naive_y)) if naive_y[i] < 0.10 * max(naive_y)]
    ax.plot([naive_x[i] for i in lo], [naive_y[i] for i in lo], "o", ms=8,
            mfc="none", mec=ORANGE, mew=1.2,
            label=t["empty"].format(n=len(lo)))
    ax.set_ylabel(t["revenue"]); ax.yaxis.set_major_formatter(FuncFormatter(eur))
    ax.legend(frameon=False, fontsize=7, loc="upper left")
    fig.savefig(out("fig_ts_disaster", lang)); plt.close(fig)


def fig_smooth(orders, lang="en"):
    x, y = as_dates(monthly(orders, shift_day_one=True))
    fig, ax = plt.subplots(figsize=(6.8, 1.55))
    t = STR[lang]
    ax.plot(x, y, lw=0.9, color=GREY, label=t["monthly"])
    # 3 and 12 months, because those are the two the slide argues about: one
    # smooths the month-boundary jitter, the other shows the trend underneath.
    r12 = None
    for w, c in ((3, PETROL), (12, BLUE)):
        r = rolling(y, w)
        ax.plot(x, r, lw=1.8, color=c, label=t["roll"].format(w=w))
        if w == 12:
            r12 = r
    # The +123% is stated on the slide, not in the figure: a label here covers the lines.
    ax.set_ylabel(musd(lang)); ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v/1e6:.0f}"))
    ax.legend(frameon=False, fontsize=7, loc="upper left")
    fig.savefig(out("fig_ts_smooth", lang)); plt.close(fig)


def fig_kpi(orders, lang="en"):
    """Three KPIs off one series -- what a dashboard would actually show."""
    rev = monthly(orders, shift_day_one=True)
    cnt, tot = {}, {}
    for date, total in orders.values():
        if date.day == 1:
            date -= datetime.timedelta(days=1)
        k = (date.year, date.month)
        cnt[k] = cnt.get(k, 0) + 1
        tot[k] = tot.get(k, 0.0) + total
    keys = sorted(rev)
    x = [datetime.date(y, m, 1) for y, m in keys]
    t = STR[lang]
    # Units on every axis, in the unit the slide quotes: M USD, a count, k USD.
    panels = ((t["kpi_rev"], [rev[k] / 1e6 for k in keys], BLUE, lambda v, _=None: f"{v:.0f}"),
              (t["kpi_ord"], [cnt[k] for k in keys], PETROL, lambda v, _=None: f"{v:.0f}"),
              (t["kpi_aov"], [tot[k] / cnt[k] / 1e3 for k in keys], ORANGE, lambda v, _=None: f"{v:.0f}"))
    fig, axes = plt.subplots(3, 1, figsize=(6.8, 2.7), sharex=True)
    for ax, (name, series, colour, fmt) in zip(axes, panels):
        ax.plot(x, series, "-o", ms=2.5, lw=1.3, color=colour)
        ax.set_ylabel(name, fontsize=7.5)
        # whole-number ticks: with a rounding formatter, a tick at 2.5 would read "2"
        ax.yaxis.set_major_locator(MaxNLocator(nbins=4, integer=True))
        ax.yaxis.set_major_formatter(FuncFormatter(fmt))
        ax.margins(y=0.18)
    fig.align_ylabels(axes)
    fig.savefig(out("fig_ts_kpi", lang)); plt.close(fig)

    # The divergence is the point, so state it in numbers too: a revenue-only
    # dashboard tile reports unambiguous success here, and the third panel is
    # the one that says customers are buying smaller baskets.
    import statistics
    print("\n  first 6 months -> last 6 months")
    for name, series in (("revenue", [rev[k] for k in keys]),
                         ("orders", [cnt[k] for k in keys]),
                         ("avg order value", [tot[k] / cnt[k] for k in keys])):
        a, b = statistics.mean(series[:6]), statistics.mean(series[-6:])
        print(f"    {name:<18}{a:>12,.0f} -> {b:>12,.0f}   x{b/a:.2f}")
    print("    -> revenue doubles while value-per-order FALLS 14%. Same series,")
    print("       opposite headlines, depending on which tile you put on the wall.")


if __name__ == "__main__":
    import sys
    # The defect lives in the export; the database is the reference line.
    orders = load_orders_export()
    only = {"month_day": lambda o, lang: fig_month_day(o, load_orders(online=1), lang),
            "naive": fig_naive, "days": fig_days, "fix": fig_fix, "smooth": fig_smooth,
            "kpi": fig_kpi,
            "source": lambda o, lang: fig_source(o, load_orders(online=0), lang)}
    if sys.argv[1:] and all(a in only for a in sys.argv[1:]):
        for name in sys.argv[1:]:
            for lang in ("en", "de"):
                only[name](orders, lang)
            print(f"  wrote fig_ts_{name}.pdf, fig_ts_{name}_de.pdf")
        sys.exit()
    db = monthly(load_orders(online=0))
    print(f"{len(orders):,} reseller orders from the export")
    for lang in ("en", "de"):
        fig_month_day(orders, load_orders(online=1), lang)
        fig_naive(orders, lang); fig_days(orders, lang); fig_fix(orders, lang)
        fig_source(orders, load_orders(online=0), lang); fig_disaster(orders, db, lang); fig_smooth(orders, lang); fig_kpi(orders, lang)
    naive = monthly(orders); fixed = monthly(orders, shift_day_one=True)
    print(f"naive : {len(naive)} months, spread {max(naive.values())/min(naive.values()):,.1f}x")
    print(f"fixed : {len(fixed)} months, spread {max(fixed.values())/min(fixed.values()):,.1f}x")
    for p in sorted(IMG.glob("fig_ts_*.pdf")):
        print(f"  wrote {p.name}  {p.stat().st_size:,} B")
