"""
Unit 05 — AWC as a graph, with no graph database required.

Runs on ../Data/awc_basket.json (997 orders). Standard library only, so the
graph half of this unit works before anyone installs anything.

Verified on the shipped data:

    997 orders -> 888 customers, 59 products, 3,187 distinct edges, density 0.061
    customer degree: min 1, median 1, max 35, mean 3.6
    715 customers bought 1 product (709 a bike); the other 173: median 12
    highest-degree product: 749, bought by 155 distinct customers
    top-6 by order LINES vs top-6 by DEGREE overlap only 4 of 6
    connected components: 1 (all 947 nodes); any two customers <= 6 hops apart
    without the 173 multi-product customers (all resellers): 59 components
    (the sample has 194 resellers; removing all 194 also gives 59)
    co-purchase pairs: 1,061 distinct; strongest 712+715 with 94 shared orders

The two results worth arguing about:

  * "Best selling" is not "most broadly bought". Two of the top six differ
    depending on which you measure. Revenue ranks products by depth; degree
    ranks them by reach. A cross-selling campaign wants reach.

  * One single component, and only because of the resellers: without the 173
    multi-product customers it falls into one piece per product. Community
    detection here is about DENSITY, not connectivity.
"""
import itertools
import json
from collections import Counter, defaultdict, deque
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "Data" / "awc_basket.json"


def load_bipartite(path=DATA):
    """Customers and products are the two node sets; 'bought' is the edge.

    Note the packed value "Mountain Bikes-771": category and product id in one
    string (U01's tidy violation, U03's flattening exercise). We unpack it here.
    """
    doc = json.loads(path.read_text(encoding="utf-8"))
    cust_prod, prod_cust, prod_cat = defaultdict(set), defaultdict(set), {}
    lines = Counter()
    for order in doc["root"]:
        c = order["customer_id"]
        for packed in order["products_bought_SplitResultList"]:
            category, _, pid = packed.rpartition("-")
            pid = int(pid)
            cust_prod[c].add(pid)
            prod_cust[pid].add(c)
            prod_cat[pid] = category
            lines[pid] += 1
    return doc["root"], cust_prod, prod_cust, prod_cat, lines


def components(cust_prod):
    """Breadth-first flood fill. 'Is the graph connected?' is a question a table
    cannot answer without a recursive query."""
    adj = defaultdict(set)
    for c, products in cust_prod.items():
        for p in products:
            adj[("c", c)].add(("p", p))
            adj[("p", p)].add(("c", c))
    seen, sizes = set(), []
    for start in adj:
        if start in seen:
            continue
        queue, size = deque([start]), 0
        seen.add(start)
        while queue:
            node = queue.popleft()
            size += 1
            for nxt in adj[node]:
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        sizes.append(size)
    return sorted(sizes, reverse=True), len(adj)


def max_customer_distance(cust_prod):
    """Largest number of hops between two customers: one BFS from each customer."""
    adj = defaultdict(set)
    for c, products in cust_prod.items():
        for p in products:
            adj[("c", c)].add(("p", p))
            adj[("p", p)].add(("c", c))
    worst = 0
    for start in (n for n in adj if n[0] == "c"):
        dist, queue = {start: 0}, deque([start])
        while queue:
            node = queue.popleft()
            for nxt in adj[node]:
                if nxt not in dist:
                    dist[nxt] = dist[node] + 1
                    queue.append(nxt)
        worst = max(worst, max(d for n, d in dist.items() if n[0] == "c"))
    return worst


def co_purchase(orders):
    """One-mode projection: connect two products that share an order.

    In SQL this is a self-join of the order-line table on SalesOrderID with
    a < b to avoid duplicates. As a graph operation it is one sentence.
    """
    pairs = Counter()
    for order in orders:
        products = sorted({int(x.rpartition("-")[2])
                           for x in order["products_bought_SplitResultList"]})
        for a, b in itertools.combinations(products, 2):
            pairs[(a, b)] += 1
    return pairs


if __name__ == "__main__":
    orders, cust_prod, prod_cust, prod_cat, lines = load_bipartite()
    edges = sum(len(v) for v in cust_prod.values())
    print(f"orders={len(orders)}  customers={len(cust_prod)}  products={len(prod_cust)}")
    print(f"distinct edges={edges:,}  density={edges / (len(cust_prod) * len(prod_cust)):.3f}")

    degrees = sorted(len(v) for v in cust_prod.values())
    print(f"\ncustomer degree (distinct products bought):")
    print(f"  min={degrees[0]}  median={degrees[len(degrees) // 2]}  "
          f"max={degrees[-1]}  mean={sum(degrees) / len(degrees):.1f}")
    # Median 1 and max 35 are not one skewed group but two groups: in 2011 the
    # web shop sold only bikes, so web customers bought one bike each.
    ones = [c for c, v in cust_prod.items() if len(v) == 1]
    bikes = sum(prod_cat[next(iter(cust_prod[c]))].endswith("Bikes") for c in ones)
    rest = sorted(len(v) for v in cust_prod.values() if len(v) > 1)
    print(f"  {len(ones)} customers bought exactly 1 product ({bikes} of them a bike)")
    print(f"  the other {len(rest)}: median={rest[len(rest) // 2]}  max={rest[-1]}")
    print("  -> two groups, and the mean 3.6 describes neither of them.")

    print("\ndegree centrality — products reaching the most distinct customers:")
    by_degree = sorted(prod_cust.items(), key=lambda kv: -len(kv[1]))
    for pid, custs in by_degree[:5]:
        print(f"  product {pid} ({prod_cat[pid]:<16}) {len(custs):>4} customers")

    print("\nis that the same ranking as 'most order lines'?")
    top_lines = [p for p, _ in lines.most_common(6)]
    top_degree = [p for p, _ in by_degree[:6]]
    print(f"  by order lines: {top_lines}")
    print(f"  by degree     : {top_degree}")
    print(f"  overlap       : {len(set(top_lines) & set(top_degree))} of 6")
    print("  -> NO. Depth and reach are different questions with different answers.")

    sizes, n_nodes = components(cust_prod)
    print(f"\nconnected components: {len(sizes)}  largest={sizes[0]} of {n_nodes} nodes")
    # What holds it together: drop every customer who bought more than one
    # product (all resellers) and the graph falls apart into one piece per product.
    singles = {c: v for c, v in cust_prod.items() if len(v) == 1}
    pieces, _ = components(singles)
    print(f"  without the {len(cust_prod) - len(singles)} multi-product customers: "
          f"{len(pieces) + len(prod_cust) - len({p for v in singles.values() for p in v})} components")
    print(f"  any two customers: at most {max_customer_distance(cust_prod)} hops apart")
    print("  -> a single component, held together by the resellers. Clustering here")
    print("     has to be about density, not about connectivity.")

    pairs = co_purchase(orders)
    print(f"\nco-purchase projection: {len(pairs):,} distinct product pairs")
    for (a, b), n in pairs.most_common(5):
        print(f"  {a} ({prod_cat[a]}) + {b} ({prod_cat[b]}): {n} shared orders")
    print("\n  This projection is the recommendation question — 'customers who bought X")
    print("  also bought Y' — and it is a two-hop walk: product -> order -> product.")
