// ═══════════════════════════════════════════════════════════════════════════
// AWC graph queries for Scripts/awc_graph.ladybug — the schema is
// Scripts/awc_graph_schema.cypher. Every query below was run against the
// shipped database with Ladybug 0.20.2 (2026-09-22); the first result row is
// noted under each one.
//
// The pedagogical spine: queries 5-7 are the ones that are painful in SQL.
// Everything above them a join could also do — say so, or the graph model
// looks like decoration.
// ═══════════════════════════════════════════════════════════════════════════

// ── 1. Products per category: two hops and an aggregate ───────────────────
// Ladybug 0.20.2 bug: a plain count(x) AFTER a count(DISTINCT y) in the same
// RETURN comes back as 0 (count(DISTINCT s), count(p) -> 14, 0). Reversing the
// order, or writing count(DISTINCT p) as here, gives the right numbers.
MATCH (p:Product)-[:IN_SUBCAT]->(s:SubCategory)-[:IN_CAT]->(c:Category)
RETURN c.categoryName AS category,
       count(DISTINCT s) AS subCategories,
       count(DISTINCT p) AS products
ORDER BY products DESC;
// rows: Components 14 / 111, Bikes 3 / 97, Clothing 8 / 34, Accessories 10 / 24

// ── 2. Units of one product bought per customer ────────────────────────────
MATCH (c:Customer)-[:PURCHASED]->(:SalesOrder)-[l:CONTAINS]->
      (:Product {productName: 'Sport-100 Helmet, Black'})
RETURN c.fullName AS customer, sum(l.quantity) AS unitsBought
ORDER BY unitsBought DESC LIMIT 5;
// first row: Rewarding Activities Company, 93 units

// ── 3. Units bought per customer within one subcategory ────────────────────
MATCH (c:Customer)-[:PURCHASED]->(:SalesOrder)-[l:CONTAINS]->(p:Product),
      (p)-[:IN_SUBCAT]->(:SubCategory {subCategoryName: 'Mountain Bikes'})
RETURN c.fullName AS customer, sum(l.quantity) AS unitsBought
ORDER BY unitsBought DESC LIMIT 5;
// first row: Brakes and Gears, 823 units

// ── 4. Same, one level further up the hierarchy ────────────────────────────
MATCH (c:Customer)-[:PURCHASED]->(:SalesOrder)-[l:CONTAINS]->(p:Product),
      (p)-[:IN_SUBCAT]->(:SubCategory)-[:IN_CAT]->
      (:Category {categoryName: 'Components'})
RETURN c.fullName AS customer, sum(l.quantity) AS unitsBought
ORDER BY unitsBought DESC LIMIT 5;
// first row: Vigorous Exercise Company, 876 units

// ═══ From here on, a join would hurt ═══════════════════════════════════════

// ── 5. Bought together: two products, one customer ─────────────────────────
// The projection of the lecture. In SQL: the order lines joined to themselves
// through the customer. Ladybug lets both PURCHASED edges be the same edge
// (two products in one order); Neo4j would not, and counts only pairs bought
// in different orders.
MATCH (p1:Product)<-[:CONTAINS]-(:SalesOrder)<-[:PURCHASED]-(c:Customer)
      -[:PURCHASED]->(:SalesOrder)-[:CONTAINS]->(p2:Product)
WHERE p1.productId < p2.productId
RETURN p1.productName, p2.productName, count(DISTINCT c) AS customers
ORDER BY customers DESC LIMIT 5;
// first row: Water Bottle - 30 oz. + Mountain Bottle Cage, 1,704 customers

// ── 6. How far is every customer from one customer? ────────────────────────
// Variable-length path: any number of edges, the shortest one per customer.
// In SQL this needs WITH RECURSIVE. Name the edge types: an untyped * also
// walks through the catalogue (bike -> SubCategory -> bike).
MATCH (a:Customer {customerId: 13595})
      -[e:PURCHASED|CONTAINS* SHORTEST 1..16]-(b:Customer)
RETURN length(e) AS edges, count(*) AS customers
ORDER BY edges;
// rows: 4 edges 8,892 customers; 6 edges 10,226 customers

// ── 6b. Fixed length only, for comparison ──────────────────────────────────
// The customers who share a product with 13595: exactly the 4-edge row of 6.
// Run 6 and 6b side by side: the difference is what the * adds.
MATCH (a:Customer {customerId: 13595})-[:PURCHASED]->(:SalesOrder)
      -[:CONTAINS]->(:Product)<-[:CONTAINS]-(:SalesOrder)<-[:PURCHASED]-(b:Customer)
WHERE b.customerId <> 13595
RETURN count(DISTINCT b) AS customersSharingAProduct;
// result: 8,892

// ── 7. Shortest path between two customers ─────────────────────────────────
// Neo4j writes shortestPath((a)-[*]-(b)); Ladybug puts SHORTEST in the pattern.
MATCH p = (a:Customer {customerId: 13595})
          -[:PURCHASED|CONTAINS* SHORTEST 1..16]-(b:Customer {customerId: 11000})
RETURN length(p) AS edges,
       properties(nodes(p), 'fullName')    AS customers,
       properties(nodes(p), 'productName') AS products,
       properties(nodes(p), 'orderId')     AS orders;
// result: 6 edges, Cole Stewart -> order 59204 -> Sport-100 Helmet, Blue ->
//         order 43659 (Better Bike Shop) -> Mountain-100 Silver, 38 ->
//         order 43793 -> Jon Yang
