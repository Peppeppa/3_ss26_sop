"""
Build the AWC property graph in Ladybug — no server, no account, no desktop app.

    pip install ladybug pandas

SOURCE: the canonical extract, AWC/awc_flat.csv + awc_customers.csv +
awc_products.csv. Nothing else. An earlier version of this script read a
third-party Neo4j bundle; building from the same extract every other unit uses
means the graph carries the same provenance as every other number in the course.

Ladybug is SCHEMA-ON-WRITE: node and relationship tables are declared with
types before any data is loaded. Neo4j would accept `CREATE (:Product {x: 1})`
straight away. That contrast is the point — it is U03's schema-on-write vs.
schema-on-read distinction, on a dataset the students already know.

The flat table is one row per order LINE, so SalesOrder nodes and PURCHASED
edges must be de-duplicated; only the PRODUCT edge is genuinely per-line.
Neo4j hid that behind MERGE. A schema-on-write store makes you decide it.

    python3 awc_graph_build.py            -> awc_graph.ladybug/
    python3 awc_graph_build.py --stats     rebuild and print the node/edge census
"""
import argparse
import shutil
from pathlib import Path

import pandas as pd

try:
    import ladybug as lb
except ImportError:                       # frozen fallback, near-identical API
    import kuzu as lb

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir()
DB = Path(__file__).resolve().parent / "awc_graph.ladybug"

SCHEMA_FILE = Path(__file__).resolve().parent / "awc_graph_schema.cypher"


def frames():
    flat = pd.read_csv(AWC / "awc_flat.csv")
    cust = pd.read_csv(AWC / "awc_customers.csv")
    prod = pd.read_csv(AWC / "awc_products.csv")

    # One row per ORDER, not per line — the U04 grain lesson, applied.
    orders = (flat.drop_duplicates("SalesOrderID")
                  [["SalesOrderID", "OrderDate", "TotalDue", "OnlineOrderFlag"]]
                  .rename(columns={"SalesOrderID": "orderId", "OrderDate": "orderDate",
                                   "TotalDue": "totalDue", "OnlineOrderFlag": "online"}))
    orders["orderDate"] = pd.to_datetime(orders.orderDate).dt.date
    orders["online"] = orders.online.astype(bool)

    # Only customers that actually appear in an order: a node with no edge is
    # not a modelling error, but it makes every centrality figure meaningless.
    used = set(flat.CustomerID.unique())
    customers = (cust[cust.CustomerID.isin(used)]
                 [["CustomerID", "CustomerName", "City", "CountryName"]]
                 .rename(columns={"CustomerID": "customerId", "CustomerName": "fullName",
                                  "City": "city", "CountryName": "country"}))

    products = (prod[prod.ProductID.isin(set(flat.ProductID.unique()))]
                [["ProductID", "ProductName", "ListPrice"]]
                .rename(columns={"ProductID": "productId", "ProductName": "productName",
                                 "ListPrice": "listPrice"}))

    purchased = flat[["CustomerID", "SalesOrderID"]].drop_duplicates()
    contains = (flat.groupby(["SalesOrderID", "ProductID"], as_index=False)
                    .agg(quantity=("OrderQty", "sum"),
                         unitPrice=("UnitPrice", "max"),
                         lineTotal=("LineTotal", "sum")))
    subcat = flat[["SubCategory"]].drop_duplicates().dropna()
    cat = flat[["Category"]].drop_duplicates().dropna()
    in_subcat = flat[["ProductID", "SubCategory"]].drop_duplicates().dropna()
    in_cat = flat[["SubCategory", "Category"]].drop_duplicates().dropna()
    return dict(customers=customers, orders=orders, products=products,
                subcat=subcat, cat=cat, purchased=purchased, contains=contains,
                in_subcat=in_subcat, in_cat=in_cat)


def build(stats=False):
    for stale in (DB, Path(str(DB) + ".wal"), Path(str(DB) + ".tmp")):
        if stale.is_dir():
            shutil.rmtree(stale)
        elif stale.exists():
            stale.unlink()
    f = frames()
    db = lb.Database(str(DB))
    con = lb.Connection(db)
    # The schema lives in awc_graph_schema.cypher, not in this file: one copy,
    # so the .cypher a student reads is exactly what was executed.
    ddl = "\n".join(l for l in SCHEMA_FILE.read_text(encoding="utf-8").splitlines()
                     if not l.lstrip().startswith("//"))
    for stmt in filter(str.strip, ddl.split(";")):
        con.execute(stmt + ";")

    # COPY FROM a DataFrame: the reason this needs no CSV round-trip at all.
    for table, df in (("Customer", f["customers"]), ("SalesOrder", f["orders"]),
                      ("Product", f["products"]), ("SubCategory", f["subcat"]),
                      ("Category", f["cat"]), ("PURCHASED", f["purchased"]),
                      ("CONTAINS", f["contains"]), ("IN_SUBCAT", f["in_subcat"]),
                      ("IN_CAT", f["in_cat"])):
        con.execute(f'COPY {table} FROM df', {"df": df})
        print(f"  loaded {table:<12} {len(df):>8,} rows")

    if stats:
        print("\n  census, straight from the graph:")
        for label in ("Customer", "SalesOrder", "Product", "SubCategory", "Category"):
            n = con.execute(f"MATCH (n:{label}) RETURN count(n);").get_next()[0]
            print(f"    {label:<14}{n:>9,} nodes")
        for rel in ("PURCHASED", "CONTAINS", "IN_SUBCAT", "IN_CAT"):
            n = con.execute(f"MATCH ()-[r:{rel}]->() RETURN count(r);").get_next()[0]
            print(f"    {rel:<14}{n:>9,} edges")
    return con


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stats", action="store_true")
    a = ap.parse_args()
    print(f"building {DB.name} from {AWC}")
    build(stats=a.stats)
    size = (sum(p.stat().st_size for p in DB.rglob("*")) if DB.is_dir()
            else DB.stat().st_size)
    print(f"\n  {DB.name} is {size/1e6:.1f} MB")
