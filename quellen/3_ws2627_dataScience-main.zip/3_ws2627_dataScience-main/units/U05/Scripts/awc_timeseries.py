"""
Unit 05 — the AWC revenue time series, and how its timestamps lie to you.

TWO sources, and the whole lesson is in the difference:

  ../Data/orders.csv   the third-party export. CR-only line endings, dates as
                       M/D/YYYY, one row per order LINE. This is where the
                       defect lives, so this is what the "naive series" slides
                       are computed from.
  ../../AWC/awc_flat.csv  the canonical extract from the database. Clean.

THE HEADLINE RESULT, from the EXPORT (net revenue = SubTotal, once per order):

    naive calendar month   : 34 months of 37  min=      1,285  max=  5,526,352  max/min = 4,301.4x  gaps: 3
    shifted business month : 36 months of 36  min=    489,329  max=  4,220,928  max/min =     8.6x  gaps: none

Month-end batches dated on the 1st land in the next month; attributing day 1
to the previous month removes the gaps and the swing.

AND THE PART THAT PROVES IT: the shifted export series is identical to the
database series -- same 36 months, max absolute difference 0.00, to the cent.
The workaround was exactly right, but only the source can show that.

WHAT DIFFERS: every export date is the database date +1 day. In the database
resellers order on days 27-31 and never on the 1st; in the export a batch on
the last day of a month lands on the 1st of the next, splitting months in two.
"""
import csv
import datetime
import io
import statistics
from collections import defaultdict
from pathlib import Path

def awc_dir() -> Path:
    """AWC/ in the current folder, beside this script, or in any folder above either."""
    for start in (Path.cwd(), Path(__file__).resolve().parent):
        for base in (start, *start.parents):
            if (base / "AWC").is_dir():
                return base / "AWC"
    return Path("AWC")


AWC = awc_dir() / "awc_flat.csv"
EXPORT = Path(__file__).resolve().parent.parent / "Data" / "orders.csv"


def load_orders(path=AWC, online=None):
    """One record per ORDER from the canonical extract. Header fields repeat on
    every line (U04's grain lesson).

    online=None -> all 31,465 orders;  0 -> reseller only;  1 -> online only.
    """
    orders = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if online is not None and int(r["OnlineOrderFlag"]) != online:
                continue
            orders.setdefault(r["SalesOrderID"], (
                datetime.date.fromisoformat(r["OrderDate"]),
                float(r["SubTotal"]),   # net revenue: no tax, no freight
            ))
    return orders


def load_orders_export(path=EXPORT, ):
    """One record per ORDER from the THIRD-PARTY EXPORT -- the defective file.

    Three separate pathologies have to be handled just to read it, and each one
    is U03 material: CR-only line endings (the whole file is one physical line),
    US M/D/YYYY dates, and one row per order line rather than per order.
    """
    text = path.read_bytes().decode("utf-8", "replace")
    text = text.replace("\r\n", "\n").replace("\r", "\n")   # bare CR: one line otherwise
    orders = {}
    for r in csv.DictReader(io.StringIO(text)):
        m, d, y = r["OrderDate"].split("/")                    # M/D/YYYY, not ISO
        orders.setdefault(r["SalesOrderID"], (
            datetime.date(int(y), int(m), int(d)),
            float(r["SubTotal"]),   # net revenue: no tax, no freight
        ))
    return orders


def monthly(orders, shift_day_one=False):
    """Aggregate to months. With shift_day_one, a date on the 1st counts as the
    previous month (the business-month workaround)."""
    out = defaultdict(float)
    for date, total in orders.values():
        if shift_day_one and date.day == 1:
            date -= datetime.timedelta(days=1)
        out[(date.year, date.month)] += total
    return out


def find_gaps(series):
    """A month with no rows is not automatically a month with no business."""
    keys = sorted(series)
    span, present = [], set(keys)
    y, m = keys[0]
    while (y, m) <= keys[-1]:
        span.append((y, m))
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return [k for k in span if k not in present], len(span)


def rolling(values, window):
    return [None] * (window - 1) + [
        sum(values[i - window + 1:i + 1]) / window for i in range(window - 1, len(values))
    ]


def relative_spread(values):
    """stdev/mean — a scale-free measure of how noisy a series looks."""
    v = [x for x in values if x is not None]
    return statistics.stdev(v) / statistics.mean(v)


if __name__ == "__main__":
    print("=" * 74)
    print("A. the RESELLER orders, read from the THIRD-PARTY EXPORT")
    print("   -- this is the file with the month-boundary problem")
    print("=" * 74)
    orders = load_orders_export()
    print(f"{len(orders):,} reseller orders from Data/orders.csv\n")

    # ── 1. resampling, done naively and done correctly ──────────────────────
    for label, shift in [("naive calendar month", False), ("shifted business month", True)]:
        s = monthly(orders, shift_day_one=shift)
        v = [s[k] for k in sorted(s)]
        gaps, span = find_gaps(s)
        print(f"{label:<24} {len(v)} months of {span}  "
              f"min={min(v):>12,.0f}  max={max(v):>12,.0f}  max/min={max(v) / min(v):>8,.1f}x")
        print(f"{'':<24} gaps: {[f'{y}-{m:02d}' for y, m in gaps] or 'none'}")

    print("\n  -> Ask what a gap MEANS before filling it. Here the 'missing' months")
    print("     are an artefact of the dating, not months without trade. Interpolating")
    print("     them would have invented business that the shift simply recovers.")

    # ── 1b. the fix, checked against the source ─────────────────────────────
    # The shift was a workaround for a cause we did not know. The database says
    # whether the workaround was right -- and it is right to the cent.
    db = monthly(load_orders(online=0))
    fixed = monthly(orders, shift_day_one=True)
    if set(db) == set(fixed):
        worst = max(abs(db[k] - fixed[k]) for k in db)
        print(f"\n  vs the DATABASE ({len(db)} months): same months, "
              f"max absolute difference {worst:,.2f}")
        print("  The patched export equals the source to the cent. The workaround was")
        print("  exactly right -- and only the source could tell us that.")
    else:
        print("\n  vs the DATABASE: month sets DIFFER -- investigate before trusting either.")

    # ── 2. smoothing: what a rolling mean reveals ───────────────────────────
    s = monthly(orders, shift_day_one=True)
    keys = sorted(s)
    values = [s[k] for k in keys]
    r3, r12 = rolling(values, 3), rolling(values, 12)

    print(f"\n{'series':<14}{'min':>13}{'max':>13}{'stdev/mean':>13}")
    for label, v in [("raw monthly", values), ("3-month mean", r3), ("12-month mean", r12)]:
        vv = [x for x in v if x is not None]
        print(f"{label:<14}{min(vv):>13,.0f}{max(vv):>13,.0f}{relative_spread(v):>13.2f}")

    print(f"\n  The 12-month mean climbs {min(x for x in r12 if x):,.0f} -> "
          f"{r12[-1]:,.0f} across the series.")
    print("  That growth is invisible in the raw plot, which is dominated by")
    print("  month-to-month noise. Smoothing does not add information — it removes")
    print("  variation you had already decided was not the question.")

    # ── 3. seasonality, with the honest caveat ──────────────────────────────
    by_month = defaultdict(list)
    for (y, m), v in s.items():
        by_month[m].append(v)
    grand = statistics.mean(values)
    names = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()
    print(f"\n  month-of-year index (1.00 = overall mean):")
    for m in sorted(by_month):
        print(f"    {names[m - 1]}  n={len(by_month[m])}  "
              f"index={statistics.mean(by_month[m]) / grand:.2f}")
    print("\n  CAVEAT: n=3 observations per calendar month. Nov reads 0.55 and Jun 1.40,")
    print("  but with three points each you cannot separate seasonality from noise.")
    print("  Reporting these as 'seasonal effects' would be overclaiming.")
