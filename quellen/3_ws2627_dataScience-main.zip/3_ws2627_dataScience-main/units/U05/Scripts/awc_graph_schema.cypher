// ═══════════════════════════════════════════════════════════════════════════
// AWC as a property graph — the schema, and the only copy of it.
//
// Executed by Scripts/awc_graph_build.py, which reads THIS file: the schema
// lives in one place so it cannot drift from what the database contains.
// Source: the canonical extract, AWC/awc_flat.csv + awc_customers.csv +
// awc_products.csv. Nothing else.
//
// Verified sizes after loading:
//   19,119 Customer · 31,465 SalesOrder · 266 Product · 35 SubCategory · 4 Category
//   31,465 PURCHASED · 121,317 CONTAINS · 266 IN_SUBCAT · 35 IN_CAT
//
// Ladybug is SCHEMA-ON-WRITE: node and relationship tables must be declared
// with types before any data is loaded, and a relationship's FROM/TO pair is
// fixed at declaration time. Neo4j would have accepted `CREATE (:Product
// {anything: 1})` straight away. That contrast is the point — it is U03's
// schema-on-write vs. schema-on-read distinction, on a dataset you know.
//
// `SalesOrder`, not `Order`: ORDER is a Cypher keyword.
// ═══════════════════════════════════════════════════════════════════════════

// ── Node tables ────────────────────────────────────────────────────────────
CREATE NODE TABLE Customer(
    customerId INT64 PRIMARY KEY,
    fullName   STRING,
    city       STRING,
    country    STRING
);

CREATE NODE TABLE SalesOrder(
    orderId   INT64 PRIMARY KEY,
    orderDate DATE,
    totalDue  DOUBLE,
    online    BOOLEAN
);

CREATE NODE TABLE Product(
    productId   INT64 PRIMARY KEY,
    productName STRING,
    listPrice   DOUBLE
);

// The name IS the key here: AWC has no stable subcategory id in the extract,
// and inventing a surrogate would be a modelling decision with no source.
CREATE NODE TABLE SubCategory(subCategoryName STRING PRIMARY KEY);
CREATE NODE TABLE Category(categoryName STRING PRIMARY KEY);

// ── Relationship tables ────────────────────────────────────────────────────
// CONTAINS carries the line properties, so the edge is the order line. That is
// the U04 grain lesson expressed in the model: PURCHASED is per order (3 hops
// de-duplicated), CONTAINS is per line.
CREATE REL TABLE PURCHASED(FROM Customer TO SalesOrder);
CREATE REL TABLE CONTAINS(FROM SalesOrder TO Product,
                          quantity INT64, unitPrice DOUBLE, lineTotal DOUBLE);
CREATE REL TABLE IN_SUBCAT(FROM Product TO SubCategory);
CREATE REL TABLE IN_CAT(FROM SubCategory TO Category);
