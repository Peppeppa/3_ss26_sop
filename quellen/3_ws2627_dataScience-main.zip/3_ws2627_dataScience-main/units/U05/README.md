# U05 – Zeitreihen und Graphen

**Kurskontext:** Daten jenseits einzelner Tabellen.

## Originalunterlagen

Hier die zugehörigen, tatsächlich verfügbaren Folien und Übungsblätter ablegen. Fehlende Quellen nicht durch Vermutungen ersetzen.

## Lernmaterial

Auf Anforderung ein deutsches Lernskript und ein kompaktes Cheatsheet auf Basis der offiziellen PDF erstellen.

## Übungen und Findings

Aufgabenstellungen verständlich aufbereiten, reproduzierbaren Python-/SQL-Code und überprüfte Ergebnisse dokumentieren. Eigene Zusatz-Erklärungen klar von den Folien unterscheiden.

## Portfolio-Bezug

Relevante Erkenntnisse mit der passenden Portfolio-Dokumentation verknüpfen; keine unbelegten Messwerte oder Abgabeaussagen eintragen.
