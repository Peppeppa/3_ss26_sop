"""
Unit 07 — PCA on the AWC customer matrix, from first principles.

VERIFIED OUTPUT (reproduce with: python3 awc_pca.py), on the full
Adventureworks2019 extract -- 19,119 customers who ordered:

    PC1: 46.7%   cumulative  46.7%
    PC2: 20.2%   cumulative  66.9%
    PC3: 12.3%   cumulative  79.2%
    PC4: 10.3%   cumulative  89.5%
    PC5:  7.3%   cumulative  96.7%

    components for 90% of variance: 5 of 9
    PC1 + PC2 together: 66.9%   <- everything a 2D PCA plot can possibly show

Both leading components are interpretable, which is the reason to prefer PCA
when it works:

    PC1: n_products -0.46  revenue -0.45  total_qty -0.45  avg_order_value -0.44
         n_orders -0.33
         -> all five SIZE features, same sign. PC1 is "how big a customer is".
    PC2: share_Bikes +0.71  share_Accessories -0.62  share_Clothing -0.24
         -> PC2 is the product MIX, bikes against accessories.

The ninth eigenvalue is about 1e-15 -- numerically zero. The four share_* columns
always sum to 1, so the matrix has rank 8, not 9. PCA found a redundancy in our
own feature construction; nobody told it about the constraint.
"""
import numpy as np

from awc_features import load, write_dat


def pca(X, n_components=None):
    """Eigendecomposition of the covariance matrix.

    X is assumed already centred (awc_features standardises). Then
    C = X^T X / (n-1), and eigh gives eigenvalues ascending, so we reverse.
    Eigenvalues ARE the variance along each eigenvector -- that is the whole
    content of PCA, and the reason 'explained variance' is just a normalised
    eigenvalue.
    """
    C = np.cov(X, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(C)      # eigh: symmetric matrices
    order = np.argsort(eigenvalues)[::-1]
    eigenvalues, eigenvectors = eigenvalues[order], eigenvectors[:, order]
    if n_components:
        eigenvalues, eigenvectors = eigenvalues[:n_components], eigenvectors[:, :n_components]
    return eigenvalues, eigenvectors, eigenvalues / np.cov(X, rowvar=False).trace()


if __name__ == "__main__":
    X, ids, names = load()
    values, vectors, ratio = pca(X)

    print(f"{X.shape[0]} customers x {X.shape[1]} features\n")
    print(f"{'':>5}{'eigenvalue':>13}{'explained':>11}{'cumulative':>12}")
    cumulative = np.cumsum(ratio)
    for i, (v, r, c) in enumerate(zip(values, ratio, cumulative), 1):
        print(f"  PC{i}{v:>12.4f}{r:>10.1%}{c:>12.1%}")

    for target in (0.80, 0.90, 0.95):
        k = int(np.searchsorted(cumulative, target)) + 1
        print(f"\n  components needed for {target:.0%} of the variance: {k}")
    print(f"\n  PC1 + PC2 = {cumulative[1]:.1%}  <- all a 2D PCA plot can show")
    print(f"  so {1 - cumulative[1]:.1%} of the variance is INVISIBLE in that plot.")

    print("\n=== loadings: what each component is made of ===")
    for pc in (0, 1, 2):
        top = sorted(zip(names, vectors[:, pc]), key=lambda t: -abs(t[1]))[:5]
        print(f"  PC{pc + 1}: " + "  ".join(f"{n}={v:+.2f}" for n, v in top))

    # Project and emit for the slides. Colour by dominant category (mix, not size).
    # The PCA itself uses all 19,119 customers; the PLOT uses the same
    # 2,000-customer sample as the t-SNE plot, so the two are directly
    # comparable -- and because pgfplots cannot hold 19,119 marks.
    Y = X @ vectors[:, :2]
    # colour = the largest RAW share; z-scored shares would name the category
    # most above average instead
    dominant = np.argmax(load(standardise=False)[0][:, 5:9], axis=1)
    rng = np.random.default_rng(0)
    idx = np.sort(rng.choice(len(Y), size=min(2000, len(Y)), replace=False))
    write_dat("pca_coords.dat", Y[idx], dominant[idx])
    print(f"\n  PCA computed on all {len(Y):,} customers; "
          f"wrote ../Data/pca_coords.dat with the same {len(idx):,}-customer sample "
          f"the t-SNE plot uses")

    print("\n=== PCA found a bug in our own feature construction ===")
    print(f"  PC9 eigenvalue = {values[-1]:.2e}  -- exactly zero.")
    print("  Why: share_Accessories + share_Bikes + share_Clothing + share_Components")
    print("  always equals 1, so those four columns are linearly DEPENDENT. The matrix")
    print("  has rank 8, not 9, and PCA reports that as a zero-variance direction.")
    print("  Nine columns, eight of them independent. PCA is also a diagnostic.")

    print("\n=== a caution about the sign ===")
    print("  Eigenvectors are only defined up to sign: -v is as valid as v. So PC1")
    print("  loadings being all NEGATIVE means large customers get NEGATIVE PC1")
    print("  scores here. Flip the axis and nothing changes. Never interpret the")
    print("  direction of a principal axis as 'more' or 'less' without checking.")
