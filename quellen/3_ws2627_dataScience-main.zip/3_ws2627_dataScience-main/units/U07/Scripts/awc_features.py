"""
Unit 07 — the customer feature matrix, shared by every script in this unit.

Nine features per customer, standardised (U06 measured what happens when you
skip that step) -- the matrix of the exercise sheet's "Before you start" block.

It reads the order-line extract AWC/awc_flat.csv, looking upward from this
folder as the portfolio templates do. In the course repository that is the
canonical extract (AWC/extract.sh); in a group's work it is the extract the
group's own script builds.
"""
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path(__file__).resolve().parents[1] / "Data"     # the 2D maps, ../Data/*.dat

FEATURES = ["revenue", "n_orders", "n_products", "total_qty", "avg_order_value",
            "share_Accessories", "share_Bikes", "share_Clothing", "share_Components"]


def find_extract():
    """AWC/awc_flat.csv in this folder or any folder above it."""
    here = Path(__file__).resolve()
    for base in here.parents:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    raise SystemExit("AWC/awc_flat.csv not found above this folder. This kit runs on the "
                     "order-line extract your group's script builds -- put it there, or "
                     "edit find_extract().")


def read_flat():
    """One row per order line."""
    return pd.read_csv(find_extract())


def load(standardise=True, online=None):
    """Return (X, customer_ids, feature_names).

    online=None  -> all 19,119 customers who ordered
    online=0/1   -> reseller only / online only
    """
    flat = read_flat()
    if online is not None:
        flat = flat[flat.OnlineOrderFlag == online]
    g = flat.groupby("CustomerID")
    feat = pd.DataFrame({
        "revenue": g.LineTotal.sum(),
        "n_orders": g.SalesOrderID.nunique(),
        "n_products": g.ProductID.nunique(),
        "total_qty": g.OrderQty.sum(),
    })
    feat["avg_order_value"] = feat.revenue / feat.n_orders
    share = flat.pivot_table(index="CustomerID", columns="Category",
                             values="LineTotal", aggfunc="sum", fill_value=0)
    share = share.div(share.sum(axis=1).replace(0, 1), axis=0)
    share.columns = [f"share_{c}" for c in share.columns]
    feat = feat.join(share).fillna(0.0)
    feat = feat[[c for c in FEATURES if c in feat.columns]]
    X = feat.values.astype(float)
    if standardise:
        X = (X - X.mean(0)) / X.std(0, ddof=1)
    return X, feat.index.to_numpy(), list(feat.columns)


def pairwise_sq(X):
    s = (X ** 2).sum(1)
    D = s[:, None] + s[None, :] - 2 * X @ X.T
    np.fill_diagonal(D, 0.0)
    return np.maximum(D, 0.0)


def write_dat(name, Y, labels=None):
    """Write a 2D map to ../Data/<name>, whichever folder the script runs from."""
    DATA.mkdir(exist_ok=True)
    with open(DATA / name, "w") as f:
        f.write("x y c\n")
        for i, row in enumerate(Y):
            f.write(f"{row[0]:.4f} {row[1]:.4f} {labels[i] if labels is not None else 0}\n")


def write_csv(name="awc_features.csv"):
    """The unscaled matrix with CustomerID, for KNIME: ../Data/awc_features.csv."""
    X, ids, names = load(standardise=False)
    DATA.mkdir(exist_ok=True)
    df = pd.DataFrame(X, columns=names)
    df.insert(0, "CustomerID", ids)
    df.to_csv(DATA / name, index=False, float_format="%.6f")
    return DATA / name


if __name__ == "__main__":
    print(f"  wrote {write_csv()} (unscaled, for KNIME)")
    X, ids, names = load()
    print(f"{X.shape[0]:,} customers x {X.shape[1]} features (standardised)")
    print(f"  source: {find_extract()}")
    print(f"  max |mean|: {abs(X.mean(0)).max():.1e}   max |sd-1|: {abs(X.std(0,ddof=1)-1).max():.1e}")
