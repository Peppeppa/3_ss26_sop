"""Unit 07 — the classical multivariate toolkit, on AWC's own feature matrix.

    python3 awc_multivariate.py          (about 5 seconds)

The numbers behind the section "Before and After PCA: the Classical Toolkit":
redundant columns (R^2), the sphericity test and KMO (footnote only), the three
rules for how many components, Mahalanobis distance against U04's 1.5 x IQR
rule, and classical MDS, which on Euclidean distances is PCA.

They share one assumption the AWC matrix breaks -- FULL RANK. The four category
shares add up to 1 for every customer, so 9 columns hold only 8 independent
ones. Bartlett and Mahalanobis need an invertible matrix, so they run on 8
features (share_Components dropped); everything else uses all 9.

The figures of this section (fig_u07_corr_blocks, fig_u07_mahal) come from
u07_figures.py.
"""

import numpy as np
from scipy import stats

from awc_features import load, read_flat

RNG = np.random.default_rng(0)


def bartlett_sphericity(R, n):
    """H0: the correlation matrix is the identity -- nothing to reduce."""
    p = R.shape[0]
    sign, logdet = np.linalg.slogdet(R)
    chi2 = -(n - 1 - (2 * p + 5) / 6) * logdet
    df = p * (p - 1) / 2
    return float(chi2), df, float(stats.chi2.sf(chi2, df))


def kmo(R):
    """Kaiser-Meyer-Olkin: how much of the correlation is NOT partial."""
    Ri = np.linalg.inv(R)
    d = np.sqrt(np.outer(np.diag(Ri), np.diag(Ri)))
    P = -Ri / d
    np.fill_diagonal(P, 0.0)
    Roff = R.copy()
    np.fill_diagonal(Roff, 0.0)
    return float((Roff ** 2).sum() / ((Roff ** 2).sum() + (P ** 2).sum()))


def broken_stick(p):
    """The null model for a scree plot: p random pieces of a unit stick."""
    return np.array([sum(1.0 / j for j in range(k, p + 1)) / p
                     for k in range(1, p + 1)])


def r_squared(X):
    """R^2 of each column, predicted from all the others by least squares.
    lstsq instead of inv(R): it also works when a column is fully redundant."""
    out = []
    for j in range(X.shape[1]):
        A = np.column_stack([np.ones(len(X)), np.delete(X, j, axis=1)])
        coef, *_ = np.linalg.lstsq(A, X[:, j], rcond=None)
        res = X[:, j] - A @ coef
        out.append(1 - res.var() / X[:, j].var())
    return np.array(out)


def classical_mds(D):
    """Torgerson: double-centre the squared distances, then eigendecompose."""
    n = D.shape[0]
    J = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * J @ (D ** 2) @ J
    w, V = np.linalg.eigh(B)
    o = np.argsort(w)[::-1]
    w, V = w[o], V[:, o]
    return V[:, :2] * np.sqrt(w[:2])


def main():
    X9, ids, names = load(standardise=True)
    n, p9 = X9.shape
    print(f"AWC customer matrix: {n:,} customers x {p9} features (z-scored)\n")

    print("-- 1. are the 9 columns independent? --")
    print(f"  rank {np.linalg.matrix_rank(X9)} of {p9}")
    r2 = r_squared(X9)
    print("  R^2 of each column from the other 8: "
          + ", ".join(f"{f}={v:.3f}" for f, v in zip(names, r2)))
    print("  -> every share has R^2 = 1: the four shares add up to 1\n")

    ev = np.linalg.eigvalsh(np.corrcoef(X9, rowvar=False))[::-1]
    share = ev / ev.sum()
    cum = np.cumsum(share)
    bs = broken_stick(p9)
    print("-- 2. how many components? three rules, the same 9 eigenvalues --")
    print("  explained %:    " + ", ".join(f"{s * 100:.2f}" for s in share))
    print("  broken stick %: " + ", ".join(f"{b * 100:.2f}" for b in bs))
    print(f"  Kaiser (eigenvalue > 1) -> {int((ev > 1).sum())}")
    print(f"  90 % of the variance    -> {int(np.argmax(cum >= 0.90) + 1)}")
    print(f"  broken stick            -> {int(np.argmax(share <= bs))}"
          f"   (PC2 has {share[1] * 100:.2f} %, the stick asks for {bs[1] * 100:.2f} %)\n")

    keep = [i for i, f in enumerate(names) if f != "share_Components"]
    X = X9[:, keep]
    p = X.shape[1]
    R = np.corrcoef(X, rowvar=False)
    chi2, df, pval = bartlett_sphericity(R, n)
    print(f"-- 3. worth reducing at all? (share_Components dropped, p = {p}) --")
    print(f"  Bartlett sphericity: chi2 = {chi2:,.0f}, df = {df:.0f}, p = {pval:.3g}")
    print(f"  KMO = {kmo(R):.3f}\n")

    print(f"-- 4. Mahalanobis distance against U04's 1.5 x IQR rule (p = {p}) --")
    d = X - X.mean(0)
    d2 = np.einsum("ij,jk,ik->i", d, np.linalg.inv(np.cov(X, rowvar=False)), d)
    cut = stats.chi2.ppf(0.975, p)
    maha = d2 > cut
    flat = read_flat()
    web = flat.groupby("CustomerID").OnlineOrderFlag.max().reindex(ids).to_numpy() == 1
    print(f"  cut-off chi2_{p},0.975 = {cut:.2f}")
    print(f"  flagged: {maha.sum():,} customers -- {(maha & ~web).sum()} resellers "
          f"(of {(~web).sum()}), {(maha & web).sum()} web")
    print(f"  median d^2 = {np.median(d2):.2f}, the chi2_{p} median = "
          f"{stats.chi2.median(p):.2f}  -> the customers do not follow the curve")
    q1, q3 = np.percentile(X, [25, 75], axis=0)
    f = 1.5 * (q3 - q1)
    iqr = ((X < q1 - f) | (X > q3 + f)).any(axis=1)
    print(f"  1.5 x IQR, column by column: {iqr.sum():,} customers with >= 1 value flagged")
    print(f"  found only by Mahalanobis: {(maha & ~iqr).sum()} customers\n")

    print("-- 5. classical MDS on Euclidean distances IS PCA (Torgerson) --")
    Xs = X9[RNG.choice(n, 400, replace=False)]
    D = np.sqrt(((Xs[:, None, :] - Xs[None, :, :]) ** 2).sum(-1))
    Y = classical_mds(D)
    U, S, _ = np.linalg.svd(Xs - Xs.mean(0), full_matrices=False)
    P = U[:, :2] * S[:2]
    print(f"  400 random customers, all 9 features, distances only")
    print(f"  max | |MDS coordinate| - |PCA score| | over two axes: "
          f"{np.abs(np.abs(Y) - np.abs(P)).max():.1e}")


if __name__ == "__main__":
    main()
