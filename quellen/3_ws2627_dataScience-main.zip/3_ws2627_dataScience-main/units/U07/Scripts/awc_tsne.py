"""
Unit 07 — t-SNE from first principles, and a measurement of what it preserves.

Roughly 40 lines of numpy. Written out rather than imported so you can see that
t-SNE is a cost function plus gradient descent, not magic.

VERIFIED OUTPUT (reproduce with: python3 awc_tsne.py, about 3.5 minutes).
2,000-customer sample (an N x N matrix at full size would be 2.9 GB); measured
on its 1,082 distinct rows, because 58 % of the sample have an exact twin and a
tie would count a twin as a kept neighbour.

  neighbours kept (of the k nearest in 9-D, still among the k nearest on the map)
  embedding                    k=1    k=10    k=30   k=200  dist corr
  PCA (2D)                   60.9%   60.0%   64.8%   77.0%      0.908
  t-SNE perplexity=5         80.3%   66.7%   47.5%   27.3%     -0.079
  t-SNE perplexity=30        72.2%   81.9%   75.2%   59.0%     -0.028
  t-SNE perplexity=50        69.6%   81.0%   78.6%   70.0%      0.038
  t-SNE perplexity=100       65.2%   80.8%   82.9%   77.1%      0.082

What the table says (slide "Measured: What Each Method Preserves"):

  * t-SNE(30) keeps 82 % of each point's 10 nearest neighbours; PCA keeps 60 %.
  * Only PCA keeps distances: correlation 0.91, t-SNE between -0.08 and 0.08.
  * Perplexity sets how local "local" is: 5 is best at k = 1, 100 at k = 30.

So a t-SNE map shows WHICH POINTS LIE TOGETHER. Distances between groups,
group sizes (t-SNE spreads dense groups and shrinks sparse ones; Wattenberg et
al. 2016) and the number of groups all come from the layout.

Writes ../Data/tsne_p{5,30,50,100}.dat, the maps u07_figures.py draws.
"""
import numpy as np

from awc_features import load, pairwise_sq, write_dat


def conditional_P(D, perplexity=30.0, tol=1e-5, max_iter=60):
    """For each point, find the Gaussian width sigma_i giving the target perplexity.

    Perplexity is 2^H where H is the entropy of the neighbour distribution -- read
    it as "the effective number of neighbours each point pays attention to". There
    is no closed form for sigma_i, so we binary-search it per point.
    """
    n = D.shape[0]
    P = np.zeros((n, n))
    log_target = np.log(perplexity)
    for i in range(n):
        lo, hi, beta = -np.inf, np.inf, 1.0          # beta = 1 / (2 sigma^2)
        Di = np.delete(D[i], i)
        for _ in range(max_iter):
            Pi = np.exp(-Di * beta)
            total = Pi.sum() or 1e-12
            entropy = np.log(total) + beta * (Di * Pi).sum() / total
            diff = entropy - log_target
            if abs(diff) < tol:
                break
            if diff > 0:                              # too much entropy -> narrower
                lo = beta
                beta = beta * 2 if hi == np.inf else (beta + hi) / 2
            else:
                hi = beta
                beta = beta / 2 if lo == -np.inf else (beta + lo) / 2
        P[i, np.arange(n) != i] = Pi / total
    return P


def tsne(X, perplexity=30.0, n_iter=500, learning_rate=200.0, seed=0):
    """Minimise KL(P || Q) by gradient descent.

    P: neighbour probabilities in the ORIGINAL space (Gaussian).
    Q: neighbour probabilities in the MAP (Student-t, one degree of freedom).

    The heavy-tailed Q is the 't' in t-SNE and the reason it separates clusters:
    a moderate distance in high-D can be rendered as a large distance in 2D at
    little cost, so crowded regions get room to spread out.
    """
    rng = np.random.default_rng(seed)
    n = X.shape[0]

    P = conditional_P(pairwise_sq(X), perplexity)
    P = P + P.T
    P /= P.sum()
    P = np.maximum(P, 1e-12)

    Y = rng.normal(0.0, 1e-2, (n, 2))
    velocity = np.zeros_like(Y)
    gains = np.ones_like(Y)

    for step in range(n_iter):
        num = 1.0 / (1.0 + pairwise_sq(Y))            # Student-t kernel
        np.fill_diagonal(num, 0.0)
        Q = np.maximum(num / num.sum(), 1e-12)

        # "Early exaggeration": inflate P for the first 100 steps so clusters
        # separate before fine structure is negotiated.
        PQ = (P * 4.0 if step < 100 else P) - Q
        grad = 4.0 * (((PQ * num).sum(1)[:, None] * Y) - (PQ * num) @ Y)

        momentum = 0.5 if step < 250 else 0.8
        gains = np.where((grad > 0) != (velocity > 0), gains + 0.2, gains * 0.8).clip(0.01)
        velocity = momentum * velocity - learning_rate * gains * grad
        Y += velocity
        Y -= Y.mean(0)

    return Y, float((P * np.log(P / Q)).sum())


# ── measuring what an embedding preserved ────────────────────────────────────

def distinct(X):
    """Indices of one row per group of identical rows. Many customers are exact
    twins (same one $4.99 item, ...); with twins at distance 0, "the k nearest
    neighbours" is an arbitrary pick among ties, so we measure on distinct rows."""
    _, first = np.unique(X.round(6), axis=0, return_index=True)
    return np.sort(first)


def knn_sets(D, k):
    D = D.copy()
    np.fill_diagonal(D, np.inf)                  # a point is not its own neighbour
    return [set(row) for row in np.argsort(D, axis=1, kind="stable")[:, :k]]


def knn_retention(D_high, D_low, k=10):
    """Fraction of each point's k nearest neighbours that are still among its k
    nearest in the map -- Q_NX(k) in Mokbel et al. (2013). Small k = LOCAL quality."""
    a, b = knn_sets(D_high, k), knn_sets(D_low, k)
    return float(np.mean([len(x & y) / k for x, y in zip(a, b)]))


def distance_correlation(D_high, D_low):
    """Correlation between all pairwise distances before and after.
    This is the GLOBAL quality of an embedding."""
    iu = np.triu_indices(D_high.shape[0], 1)
    return float(np.corrcoef(np.sqrt(D_high[iu]), np.sqrt(D_low[iu]))[0, 1])


SAMPLE = 2000   # see the note in the docstring: O(N^2) memory

if __name__ == "__main__":
    X_all, ids, names = load()
    # A from-scratch t-SNE holds an N x N matrix. At N = 19,119 that is
    # 19,119^2 x 8 bytes = 2.9 GB per matrix, and the gradient needs several.
    # So we sample -- and that limit is exactly why Barnes-Hut exists.
    rng_s = np.random.default_rng(0)
    idx = np.sort(rng_s.choice(len(X_all), size=min(SAMPLE, len(X_all)), replace=False))
    X = X_all[idx]
    print(f"t-SNE on a {len(X):,}-customer sample of {len(X_all):,} "
          f"(an N x N matrix at full size would be "
          f"{len(X_all)**2*8/1e9:.1f} GB)\n")
    # colour = the largest RAW share; z-scored shares would name the category
    # most above average instead
    dominant = np.argmax(load(standardise=False)[0][idx, 5:9], axis=1)

    # PCA fitted on all customers, as on the PCA slides (Data/pca_coords.dat)
    w, V = np.linalg.eigh(np.cov(X_all, rowvar=False))
    Y_pca = X @ V[:, np.argsort(w)[::-1][:2]]

    rows = [("PCA (2D)", Y_pca)]
    for perplexity in (5, 30, 50, 100):
        Y, kl = tsne(X, perplexity=perplexity, n_iter=500, seed=0)
        rows.append((f"t-SNE perplexity={perplexity}", Y))
        write_dat(f"tsne_p{perplexity}.dat", Y, dominant)

    rep = distinct(X)
    D_rep = pairwise_sq(X[rep])
    print(f"measured on the {len(rep):,} distinct customers of the sample\n")
    print(f"{'embedding':<24}{'k=1':>8}{'k=10':>8}{'k=30':>8}{'k=200':>8}{'dist corr':>11}")
    for label, Y in rows:
        D_low = pairwise_sq(Y[rep])
        print(f"{label:<24}" + "".join(f"{knn_retention(D_rep, D_low, k):>8.1%}"
                                       for k in (1, 10, 30, 200))
              + f"{distance_correlation(D_rep, D_low):>11.3f}")
    print("\n  t-SNE preserves NEIGHBOURS. PCA preserves DISTANCES.")
    print("  Read a t-SNE plot for which points group together --")
    print("  never for how far apart the groups are, or how big they look.")
    print("\n  wrote ../Data/tsne_p{5,30,50,100}.dat for the slides")
