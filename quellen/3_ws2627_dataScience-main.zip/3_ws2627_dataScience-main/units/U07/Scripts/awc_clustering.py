"""
Unit 07 — k-means, and the mistake this unit exists to prevent.

VERIFIED OUTPUT (reproduce with: python3 awc_clustering.py, under 10 seconds):

  the elbow: all 19,119 customers x 9 features, 20 k-means++ starts per k
    total sum of squares: 172,062
    k=2: best   111,661   single runs   111,661 ..   151,357
    k=3: best    74,553   single runs    74,553 ..   114,552   drop 33.2%
    k=4: best    56,561   single runs    56,561 ..    76,570   drop 24.1%
    k=5: best    39,398   single runs    39,398 ..    63,949   drop 30.3%
    k=6: best    29,799   single runs    29,799 ..    59,155   drop 24.4%
    k=7: best    25,013   single runs    25,013 ..    57,547   drop 16.1%
    k=8: best    22,110   single runs    22,110 ..    55,740   drop 11.6%
    a single run is worse than the best run at k-1 for k = [3, 4, 5, 6, 7, 8]

  the headline: k-means (k=4, best of 20) on the 2,000-customer sample
    9 features vs PCA map   : ARI = 0.985
    9 features vs t-SNE map : ARI = 0.217
    PCA map    vs t-SNE map : ARI = 0.217

Two measurements, each on the data the slides use:

  1. The elbow, on all 19,119 customers x 9 standardised features. For each k,
     20 k-means runs from 20 k-means++ starts. The best run per k is the elbow
     curve -- and it has no clear elbow. The spread of the single runs is the
     reason you restart. (With plain random starts even the best of 20 misses
     the optimum at k = 2 and k = 6: kmeans_once(..., init="random").)

  2. The headline, on the 2,000-customer sample of the t-SNE slides (the same
     rng(0) sample as awc_tsne.py and awc_pca.py). k-means with k = 4 is run
     three times -- on the 9 features, on the PCA map, on the t-SNE map -- and
     the three labelings are compared by the adjusted Rand index. The two maps
     are read from ../Data/pca_coords.dat and ../Data/tsne_p30.dat, written by
     awc_pca.py and awc_tsne.py. A missing map is built here the same way
     (the t-SNE one takes about a minute) and written for the next run.

Clustering the PICTURE is not clustering the DATA: cluster in the feature space,
use the map only to look at the result.
"""

import numpy as np

from awc_features import DATA, load, write_dat
N_STARTS = 20
K_RANGE = range(2, 9)
SAMPLE = 2000


def cross_sq(A, B):
    return np.maximum((A ** 2).sum(1)[:, None] + (B ** 2).sum(1)[None, :] - 2 * A @ B.T, 0.0)


def plus_plus(X, k, rng):
    """k-means++ starts (Arthur & Vassilvitskii 2007): each new centre is a row
    drawn with probability proportional to its squared distance to the nearest
    centre so far -- so the starts are spread out instead of random."""
    centres = [X[rng.integers(len(X))]]
    for _ in range(k - 1):
        d2 = cross_sq(X, np.array(centres)).min(1)
        centres.append(X[rng.choice(len(X), p=d2 / d2.sum())])
    return np.array(centres)


def kmeans_once(X, k, seed, init="++", n_iter=100):
    """Lloyd's algorithm from k-means++ starts, or from k random rows (init="random")."""
    rng = np.random.default_rng(seed)
    centres = plus_plus(X, k, rng) if init == "++" else X[rng.choice(len(X), k, replace=False)]
    for _ in range(n_iter):
        labels = np.argmin(cross_sq(X, centres), axis=1)
        new = np.array([X[labels == j].mean(0) if (labels == j).any() else centres[j]
                        for j in range(k)])
        if np.allclose(new, centres):
            break
        centres = new
    labels = np.argmin(cross_sq(X, centres), axis=1)
    inertia = float(cross_sq(X, centres)[np.arange(len(X)), labels].sum())
    return labels, centres, inertia


def kmeans(X, k, n_starts=N_STARTS, seed=0):
    """The best of n_starts runs by inertia -- the only k-means worth reporting."""
    return min((kmeans_once(X, k, seed + s) for s in range(n_starts)), key=lambda r: r[2])


def elbow(X, init="++"):
    """Inertia of every single run, per k. Row = k, column = start."""
    return np.array([[kmeans_once(X, k, s, init)[2] for s in range(N_STARTS)] for k in K_RANGE])


def adjusted_rand_index(a, b):
    """Agreement between two labelings, corrected for chance. 0 = chance, 1 = identical."""
    _, a = np.unique(a, return_inverse=True)
    _, b = np.unique(b, return_inverse=True)
    table = np.zeros((a.max() + 1, b.max() + 1))
    np.add.at(table, (a, b), 1)
    pairs = lambda x: (x * (x - 1) / 2).sum()
    both, rows, cols, total = pairs(table), pairs(table.sum(1)), pairs(table.sum(0)), pairs(np.array([len(a)]))
    expected = rows * cols / total
    return (both - expected) / ((rows + cols) / 2 - expected)


def make_map(name, idx):
    """Build a missing map exactly as awc_pca.py / awc_tsne.py write it."""
    from awc_pca import pca
    from awc_tsne import tsne
    X = load()[0]
    dominant = np.argmax(load(standardise=False)[0][idx, 5:9], axis=1)
    print(f"  ../Data/{name} is missing -- building it now")
    if name == "pca_coords.dat":
        Y = X[idx] @ pca(X)[1][:, :2]
    else:
        Y = tsne(X[idx], perplexity=30, n_iter=500, seed=0)[0]
    write_dat(name, Y, dominant)


def read_map(name, idx):
    if not (DATA / name).exists():
        make_map(name, idx)
    d = np.genfromtxt(DATA / name, names=True)
    return np.column_stack([d["x"], d["y"]])


def headline(k=4):
    """k-means in three spaces on the 2,000-customer sample. Returns the labelings."""
    X, _, _ = load()
    idx = np.sort(np.random.default_rng(0).choice(len(X), size=SAMPLE, replace=False))
    spaces = {"9 features": X[idx], "PCA map": read_map("pca_coords.dat", idx),
              "t-SNE map": read_map("tsne_p30.dat", idx)}
    return {name: kmeans(Z, k)[0] for name, Z in spaces.items()}


if __name__ == "__main__":
    X, _, _ = load()
    print(f"=== the elbow: all {len(X):,} customers x {X.shape[1]} features, "
          f"{N_STARTS} k-means++ starts per k ===")
    print(f"  total sum of squares: {(X ** 2).sum():,.0f}")
    runs = elbow(X)
    best = runs.min(1)
    for i, k in enumerate(K_RANGE):
        drop = "" if i == 0 else f"   drop {100 * (best[i - 1] - best[i]) / best[i - 1]:4.1f}%"
        print(f"  k={k}: best {best[i]:9,.0f}   single runs {runs[i].min():9,.0f} .. "
              f"{runs[i].max():9,.0f}{drop}")
    worse = [k for i, k in enumerate(K_RANGE) if i and runs[i].max() > best[i - 1]]
    print(f"  a single run is worse than the best run at k-1 for k = {worse}")

    print(f"\n=== the headline: k-means (k=4, best of {N_STARTS}) on the {SAMPLE:,}-customer sample ===")
    lab = headline()
    names = list(lab)
    for i in range(3):
        for j in range(i + 1, 3):
            print(f"  {names[i]:10s} vs {names[j]:10s}: ARI = "
                  f"{adjusted_rand_index(lab[names[i]], lab[names[j]]):.3f}")
    print("\n  Clustering the PICTURE is not clustering the DATA.")
    print("  Cluster in the feature space; use the map only to LOOK at the result.")
