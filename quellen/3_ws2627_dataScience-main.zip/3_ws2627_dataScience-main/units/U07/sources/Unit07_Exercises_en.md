---
source_id: DS-U07-EX
original_file: Unit07_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: ccb243c20aa97a25b237eee9c9018c0fbdc05433780439ce4e33d0c8556a277d
verification: partial
---
# Unit07_Exercises_en

[Original PDF](../../../quellen/Unit07_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit07_Exercises_en.pdf#page=1)

<a id="ds-u07-ex-t01"></a>

**DS-U07-EX-T01 — PCA on the Matrix**

~~~~text
  Unit 07 — Exercises                                                                          PCA, t-SNE and Clusters
Make one projection, and work out how much of it you are allowed to believe.
▶ In the room        what ﬁts the stop — all that is expected. The room splits at stop A: take one of the two exercises; you
                     hear the other one in the discussion.
⃝ Extra              voluntary, at home.
Stop A, 20 min       Exercise 1 or 2      Stop B, 20 min: Exercise 3
Asynchronous         the same sheet, before your weekly slot; bring what did not run.
You need             the lecture’s matrix: all 19,119 customers × 9 features, z-scored. Build it once, before the ﬁrst stop
                     (below).
Before the ﬁrst stop — the matrix. In Python, copy this block as it is:
   import os
   from urllib.parse import quote_plus
   import pandas as pd
   from sqlalchemy import create_engine

   engine = create_engine("mysql+mysqlconnector://sqladmin:"
                           f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019")
   flat = pd.read_sql("""
       SELECT h.CustomerID, d.SalesOrderID, d.ProductID, d.OrderQty,
              CAST(d.LineTotal AS DOUBLE) AS LineTotal, cat.Name AS Category
       FROM Sales_SalesOrderDetail d
       JOIN Sales_SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
       JOIN Production_Product p ON p.ProductID = d.ProductID
       JOIN Production_ProductSubcategory sc ON sc.ProductSubcategoryID = p.ProductSubcategoryID
       JOIN Production_ProductCategory cat ON cat.ProductCategoryID = sc.ProductCategoryID
   """, engine)

   g = flat.groupby("CustomerID")
   feat = pd.DataFrame({"revenue":    g.LineTotal.sum(),
                        "n_orders":   g.SalesOrderID.nunique(),
                        "n_products": g.ProductID.nunique(),
                        "total_qty": g.OrderQty.sum()})
   feat["avg_order_value"] = feat.revenue / feat.n_orders
   share = flat.pivot_table(index="CustomerID", columns="Category",
                            values="LineTotal", aggfunc="sum", fill_value=0)
   feat = feat.join(share.div(share.sum(axis=1), axis=0).add_prefix("share_"))
   X = ((feat - feat.mean()) / feat.std()).to_numpy()    # z-scored, as in U06
   print(X.shape)                                        # (19119, 9)

  In KNIME
  The kit ships the matrix, unscaled: Data/awc_features.csv (one row per customer, CustomerID + 9 features). CSV Reader →
  Normalizer (z-score, CustomerID left out) — that is X.

Kit: Scripts/awc_features.py builds the same matrix from                     your   own   AWC/awc_flat.csv       (and   rewrites
Data/awc_features.csv); awc_pca.py and awc_tsne.py import it.

Exercise 1 — PCA on the Matrix stop A · ▶ 20 min · or Exercise 2
 1 Run PCA. Report the explained variance per component and the cumulative total. How many components for 90 %?
 2 What percentage does a 2D plot show? Write that number into the caption of every PCA plot you make.
 3 The lecture named PC1 and PC2. Look at the loadings of PC3 and give it a name in business language — or say why
   you cannot.
  Example — where the numbers are

  pca = PCA().fit(X)
  pca.explained_variance_ratio_.cumsum()                         # steps 1-2
  pd.Series(pca.components_[2], index=feat.columns)              # step 3: loadings of PC3

⃝ Extra:   run PCA without scaling: which feature does PC1 point at, and how much does it claim? Then drop
share_Components and run the scaled PCA again: what happens to the 2D percentage and to the count for 90 %? Kit:
Scripts/awc_pca.py.




Unit 07 · Data Science · exercise sheet                                                                                        1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit07_Exercises_en.pdf#page=2)

<a id="ds-u07-ex-t02"></a>

**DS-U07-EX-T02 — t-SNE and the Perplexity Sweep**

<a id="ds-u07-ex-t03"></a>

**DS-U07-EX-T03 — Clusters, Honestly**

<a id="ds-u07-ex-t04"></a>

**DS-U07-EX-T04 — What You May and May Not Claim**

~~~~text
Exercise 2 — t-SNE and the Perplexity Sweep stop A · ▶ 20 min · or Exercise 1
 1 Compute t-SNE at perplexity 5, 30 and 50. Put the three plots on one page.
 2 Which shapes appear in all three? Those are your candidate ﬁndings. Which appear in only one?
  Sample ﬁrst, about 2,000 customers: one run takes about 5 s there, about 17 s at 5,000 — on all 19,119 three runs do not ﬁt the stop.
  Sampling changes the picture; noticing that is part of the exercise.
⃝ Extra: add perplexity 100, then re-run one perplexity with three random seeds: what changes? Put a PCA and a t-
SNE plot of the same data side by side: one thing each shows that the other hides. Kit: Scripts/awc_tsne.py; KNIME:
t-SNE (L. Jonsson).

Exercise 3 — Clusters, Honestly stop B · ▶ 20 min
 1 Run k-means for k = 2 . . . 8 on the full matrix, at least 5 restarts each (KMeans(n_clusters=k, n_init=5).inertia_).
   Plot the elbow. Is there one? “No” is a legitimate and common answer.
 2 Take your best clustering and describe 2–3 clusters by their original feature values (dollars, counts, shares). Give each
   a name — or state that they are not distinguishable.
  In KNIME
  k-Means reports clusters, not their spread, so compute it: within a cluster the summed squared distance to the centre is (n − 1)×
  variance, feature by feature (KNIME primer, pages 6–7).
  1 Counting Loop Start (8 loops)
  2 Variable Expression: $$["currentIteration"] + 1, named k
  3 k-Means, Number of clusters from k (wire the variable before opening the dialog)
  4 GroupBy on Cluster: Variance of each feature, Count of CustomerID
  5 Math Formula: ($Count*(CustomerID)$ - 1) * ($Variance(revenue)$ + . . . ), every feature written out
  6 GroupBy, no group, Sum
  7 Loop End
  8 Line Plot.
  Check: k = 1 must give (customers −1) × number of features. Restarts: run the loop once per random seed (set in k-Means) and
  keep the lowest total per k.
⃝ Extra: on your 2,000-customer sample, run k-means with the same k three times: on the 9 features, on the 2D PCA
coordinates, on the 2D t-SNE coordinates. Compare each map’s labels with the feature labels by the adjusted Rand index
(sklearn.metrics.adjusted_rand_score). Which map may you cluster on? Kit: Scripts/awc_clustering.py.
Exercise 4 — What You May and May Not Claim ⃝ Extra · a quiet hour
Write down two statements you can defend from your t-SNE plot and two you cannot. Back each with a number from
Exercise 1 or 3.

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: your explained-variance numbers, components for 90 %, the 2D percentage, PC3 named (or why not)
• Ex 2: three t-SNE plots on one page, and what survived all three
• Ex 3: the elbow (or its honest absence), and 2–3 clusters described in real feature values




Unit 07 · Data Science · exercise sheet                                                                                                   2
~~~~
