---
source_id: DS-U07-L-EN
original_file: Unit07_slides_en.pdf
source_type: lecture
language: en
page_count: 45
source_sha256: bd293a2e873015e641908c4e4738dbd9ba346bac8c7c6768a7f6612c7a5f79bf
verification: partial
---
# Unit07_slides_en

[Original PDF](../../../quellen/Unit07_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit07_slides_en.pdf#page=1)

~~~~text
Data Science

DIMENSIONALITY REDUCTION:
PCA, T-SNE & CLUSTERS


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit07_slides_en.pdf#page=2)

~~~~text
                                                                                   LEARNING GOALS

     • Explain why a space with many columns is almost empty, and what that does to
       “nearest neighbours”
     • Explain intrinsic dimension with a sheet of paper and a line in 3D, and why it is the
       reason reduction works at all
     • Explain what an eigenvector is: a direction the matrix only stretches, never turns
     • Run PCA, read the scree plot and the loadings, and name the rule you used to choose k
     • Find rows that are unusual only as a combination (Mahalanobis distance)
     • Say what t-SNE keeps (neighbours), what it does not (distances, sizes, the number of
       groups), and which reduction you can apply to a new point
     • Cluster with k-means, restart it, and explain why clustering a 2D map is not clustering
       the data

    Where this unit sits. U06 built a matrix and a measure; this one asks whether the same objects ﬁt in fewer
    columns. Pictures as evidence: U08.
2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit07_slides_en.pdf#page=3)

~~~~text
                                                     THE QUESTION OF THIS UNIT


                     Your data have many columns. When can you trust
                   a model, a 2D picture or a set of groups built on them?


                     Space          Flat sheet       Curved sheet           Groups

                                      1 Many columns: neighbours and models may fail
          Example: all 19,119 AWC     2 PCA: a few ﬂat directions you can reuse as a step in a
           customers, 9 features      model
             each. A model? A         3 t-SNE: a 2D map you may read only in part
            picture? Segments?
                                      4 Groups: found in the data, not in the picture


    The key: real data may need far fewer dimensions than they have columns. AWC is the
    example; the lessons hold for any table with many columns.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit07_slides_en.pdf#page=4)

~~~~text
                                                 WHY THIS MATTERS AT WORK


            Look               Embeddings                Monitor                 Model
     Marketing wants        A text or product      A machine has          Many columns, few
     a picture of its       embedding (U06)        hundreds of            rows: a model can
     customers, with        has hundreds of        sensors, but runs in   learn the noise —
     dozens of columns      columns. A map         a few states. Fewer    ﬁts the old data,
     each, to ﬁnd           shows what lies        columns, same          fails on new ones
     segments.              near what.             story.                 (overﬁtting).


    Tools: scikit-learn PCA and TSNE, KNIME PCA and t-SNE nodes. Single-cell biology papers
    show such maps routinely.

    A model or a 2D picture always gives an answer
    No error message tells you it is unreliable. This unit shows how to check.

4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit07_slides_en.pdf#page=5)

~~~~text
      STEP 1: HOW EMPTY IS THE SPACE?


    Space    Flat sheet   Curved sheet   Groups




5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit07_slides_en.pdf#page=6)

~~~~text
                                                       NINE FEATURES, ONE FLAT PAGE

    U06’s 40 × 4 matrix at full size: all 19,119 AWC          revenue
    customers × 9 features.
                                                                    orders
     • 5 about size: revenue, orders, products, quantity,
       avg order value                                                    products
      • 4 about mix: share of revenue per category                               quantity
    (9)
     2
        = 36 pairwise plots. Each shows 2 features and
    hides 7 — a group that shows only in a combination                                 avg order
    of three or more features can hide in all 36.                                                  Acc.
    Many panels are nearly lines: four of the size features
                                                                                                          Bikes
    correlate at r ≥ 0.8. Nine columns, fewer ideas.
                                                                                                                  Cloth.
    The goal
                                                                                                                           Comp.
    A 2D picture of the customers that keeps as much of
    the 9D distances as possible. As much as possible          2,000 customers; colour = largest share; size on log axes
    is not all.

6
                    Space                  Flat sheet         Curved sheet                     Groups
~~~~

## Page 007

[Original page 7](../../../quellen/Unit07_slides_en.pdf#page=7)

~~~~text
                                                                    MORE COLUMNS, EMPTIER SPACE
        1 feature: 10 boxes
            all 10 filled                        2 features: 100 boxes                                  100 %
                                                  67 filled, 33 empty




                                                                              share of boxes filled
                                                                                                          1%

                                                                                                        0.01 %


                                   feature 2 →
       feature 1 (10 ranges) →                                                                                                        0.002 %
                                                                                                      0.0001 %        100 points
                                                                         one box:                    19,119 points (AWC size)
                                                                         1 range of feature 1
             filled: ≥ 1 point inside                                    × 1 range of feature 2 1 2 3 4 5 6 7 8 9
                                                      feature 1 →
             empty: no point                                                                           number of features d (10 boxes per axis)
    Each feature’s range split into 10 parts; a box = one part of every feature, ﬁlled if ≥ 1 point lies in it.
    Nine features: 109 boxes — 19,119 random points (synthetic; AWC’s size) ﬁll at most 0.002 %.

    Each new column: 10× the boxes, same data — the curse of dimensionality
    Almost all of the space is empty; there, a model guesses.

7
                    Space                                Flat sheet                                    Curved sheet                Groups
~~~~

## Page 008

[Original page 8](../../../quellen/Unit07_slides_en.pdf#page=8)

~~~~text
                      IN MANY DIMENSIONS, NEIGHBOURS CAN BE FAR
                                                                                                 share of each feature's range
         1 feature: 10 % of the range                                                            needed for the nearest 10 %
                                           2 features: 32 % of each                         1        10 %




                                                                      number of features
                     you                                                                                    32 %
                                                                                            2
                                                                                            3                  46 %




                                    feature 2 →
                 feature 1 →                                                                9                          77 %
                                                                                           100                         98 %
                                                                                             0%              50 %           100 %
                                                   feature 1 →
    Random points (synthetic); orange = the 10 % nearest to you (⋆), i.e. the most similar (U06). Per
    feature they span 10 % of the range in 1-D, 32 % in 2-D, 77 % in 9-D (Hastie et al., 2009). Were
    customers spread like this, a “similar” one could have almost any revenue.

    In random data, “neighbours” differ in almost every feature
    Nearest ≈ farthest (Beyer et al., 1999): k-nearest neighbours, clustering and t-SNE suffer.

8
                   Space                          Flat sheet          Curved sheet                                 Groups
~~~~

## Page 009

[Original page 9](../../../quellen/Unit07_slides_en.pdf#page=9)

~~~~text
                                     DATA DO NOT HAVE TO FILL THEIR SPACE
                  cloud: needs 3 numbers         flat sheet: needs 2              curved line: needs 1




              z                            z                                  z

                    x            y               x              y                 x             y


                                            each point: 3 columns (x, y, z)
    Each set has 3 columns. How many numbers say where a point is? That number is the intrinsic
    dimension. A table can behave like this: net price, VAT and gross price are 3 columns, but at a ﬁxed
    tax rate one number is enough — a straight line in 3-D.

    On the sheet, the points are close together again
    The space is empty; the sheet is not. If the data lie on such a sheet, models and 2D pictures
    can be reliable despite many columns. So we check.

9
                   Space                   Flat sheet                  Curved sheet             Groups
~~~~

## Page 010

[Original page 10](../../../quellen/Unit07_slides_en.pdf#page=10)

~~~~text
                                                                                         IS OUR MATRIX CURSED? MEASURED

                                           nearest = farthest                                                Nearest ÷ farthest distance (U06). Close to
                                      1
     nearest / farthest distance



                                                                                                             1: every point is equally far — “nearest”
                                                                    0.280                                    means nothing.
                                     0.1
                                                                                                             Random data climb towards 1 as columns
                                                                                  the curse lives here:
                                                                                  every point equally far    grow. At 9 columns: random 0.28, AWC
                                    0.01                                                                     0.006 (half of it exact twins at distance 0;
                                                                    0.006                                    distinct rows: 0.009).
                                                                         synthetic: uniform random points
                                   0.001                                 AWC: first d of our 9 features      Why? Locally, the customers lie on lines and
                                                                                                             thin sheets: about 1.4 dimensions, not 9. We
                                           1    2        5      9           25         100             500
                                                                    dimensions                               measured it with the TwoNN estimator
                                                                                                             (Facco et al., 2017).

                         So neighbours still mean something here                                               NOT CURS
                                                                                                                                                      ED
                         We still reduce: nobody can look at 9 columns, and they repeat each other (next slide).


10
                                                    Space                              Flat sheet               Curved sheet            Groups
~~~~

## Page 011

[Original page 11](../../../quellen/Unit07_slides_en.pdf#page=11)

~~~~text
                               WHERE THE SHEET COMES FROM: COLUMNS REPEAT EACH OTHER


      If two columns rise and fall together, the points lie near a line in their plot: one column too many.
      Look before you reduce: do the features correlate at all?
                  random column order                reordered: blocks appear   1.0      How to reorder: take 1 − |r| as the
      products                             Comp.                                         distance between two features, join the
         Bikes                             orders                               0.8
      quantity                          avg order                                        closest ones step by step into groups
        Comp.                            products                               0.6      (hierarchical clustering) and list them in
      revenue                            revenue




                                                                                  |r|
           Acc.                          quantity                               0.4      joining order
     avg order                              Cloth.                                       (seriation, Hahsler et al., 2008).
         Cloth.                               Acc.                              0.2
        orders                              Bikes                                        scipy: linkage, leaves_list; seaborn:
                                                                                0.0      clustermap; KNIME: Hierarchical Clustering.
                   products




                  avg order




                                                     avg order
                   quantity
                      Bikes
                     Comp.
                   revenue
                        Acc.
                      Cloth.
                     orders




                                                        Comp.
                                                        orders
                                                      products
                                                      revenue
                                                      quantity
                                                         Cloth.
                                                           Acc.
                                                         Bikes
                                                                     Size block: ﬁve features, mean
                                                                     |r| = 0.73 — almost one idea: how big.
                                                                     Mix block: Accessories vs Bikes,
                                                                     r = −0.83. Between blocks: 0.16.
      Predict one column from all the others (R2 = share of its variance explained): revenue 0.92; each
      category share: exactly 1 — the four shares add up to 1, so one of them adds nothing.

11
                            Space                             Flat sheet                Curved sheet           Groups
~~~~

## Page 012

[Original page 12](../../../quellen/Unit07_slides_en.pdf#page=12)

~~~~text
             STEP 2: A FLAT SHEET — PCA


     Space        Flat sheet   Curved sheet   Groups




12
~~~~

## Page 013

[Original page 13](../../../quellen/Unit07_slides_en.pdf#page=13)

~~~~text
                                                                         FIND THE SHEET: TURN THE AXES

     Two of our columns, correlated (r = 0.55): the customers lie near a tilted line. Turn the axes so that
     the ﬁrst follows the longest spread.
     19,119 customers (700 drawn), U01 ﬂat table; log revenue, log #products; z-scored.

                                         PC2 (worst axis)                         PC1 (best axis)
                                       variance 0.45 = 23%                     variance 1.55 = 77%



                               log #products (z)



                                                   log revenue (z)   →          log revenue (z)   →


                                     projected onto the axis                   projected onto the axis


     PC1 (principal component 1) keeps 77 % of the variance. Keep both: a pure rotation, no distance
     changes. Drop PC2: one column instead of two. But how do we ﬁnd these directions in 9
     dimensions, where we cannot look?
13
                     Space                                      Flat sheet        Curved sheet           Groups
~~~~

## Page 014

[Original page 14](../../../quellen/Unit07_slides_en.pdf#page=14)

~~~~text
                                         THE TOOL: EIGENVECTORS DO NOT TURN

     A matrix A turns and stretches most                   an ordinary vector turns         eigenvectors do not turn
     vectors. An eigenvector is a
     direction that A does not turn; it only                                                                 Av1 = 1.5 v1
     stretches it by the eigenvalue λ.                                                        v2
                                                                          Av
                    Av = λv
                                                                                         Av2 = 0.5 v2        v1
                           ( 1 0.5 )                                           v
     In the picture: A =    0.5 1   ,
     λ1 = 1.5, λ2 = 0.5 — close to the
     cloud’s covariance.                              unit circle          after A



      The answer: PCA
      Take A = the covariance matrix: its eigenvectors are the turned axes PC1, PC2, . . . — in any number
      of dimensions. Eigenvalue = variance along the axis (cloud: 1.55 + 0.45).
      Why covariance? It holds the inner products of the centred columns: the Euclidean view of similarity (U06), the
      usual choice. Other similarities give other matrices and axes (Extra: maps from distances).

14
                      Space                     Flat sheet                Curved sheet                  Groups
~~~~

### DS-U07-L-EN-P014-D01 — Rekonstruktion

$Av=\lambda v$; $A=\begin{pmatrix}1&0.5\\0.5&1\end{pmatrix}$; eigenvalues 1.5 and 0.5. Circle transforms into ellipse; ordinary vector turns, eigenvectors preserve directions.

## Page 015

[Original page 15](../../../quellen/Unit07_slides_en.pdf#page=15)

~~~~text
                                                                          THE RECIPE: FIVE STEPS

           step                                            scikit-learn                  KNIME

     1     centre and scale every column (U06)             StandardScaler                Normalizer (z-score)
     2     covariance matrix: how the columns
           vary together                                   PCA().fit(X)                  PCA Compute
     3     its eigenvectors and eigenvalues
     4     sort by eigenvalue, largest ﬁrst
     5     project: keep the ﬁrst k directions             .transform(X)                 PCA Apply

         • Centring is required: without it, PC1 points at the mean
         • Scaling is a decision: unscaled, PC1 follows the biggest unit, not the most variation
                                            ∑
         • Explained variance of PCi = λi / j λj : its share of the total spread

     Scripts/awc_pca.py runs the same steps on all 9 features; the code for “Find the Sheet: Turn the
     Axes” is in the Extra section (PCA: The Recipe in Code).

15
                      Space                   Flat sheet                  Curved sheet           Groups
~~~~

## Page 016

[Original page 16](../../../quellen/Unit07_slides_en.pdf#page=16)

~~~~text
                                                                                                      MEASURED: HOW MUCH FITS IN 2D?

                              100
                                                                                               90 %
                                                                                                                PC1 + PC2 = 66.9 %
     explained variance (%)




                                                                                               80 %
                               75                   cumulative
                                                                                          broken stick
                                                                                                                A 2D plot shows 67 % and hides 33 %.
                               50                  a 2D plot shows 66.9 %
                                    46.7                                        exactly 0:                      Report it with every plot.
                                                                             shares sum to 1
                               25          20.2                                                                 How many axes to keep? Kaiser (λ > 1)
                                                  12.3 10.3
                                                              7.3   1.8     0.9                Kaiser: λ > 1
                                                                                  0.5                           → 3, 90 % of the variance → 5, broken
                                0
                                    PC1 PC2 PC3 PC4 PC5 PC6 PC7 PC8 PC9                                         stick → 1. Name yours (Jackson, 1993).
           Scree plot: variance per axis; 19,119 customers, 9 features.
           Contrast, AWC order amounts (SubTotal, TaxAmt, Freight,
           TotalDue): PC1 holds 99.9 % — almost a straight line.


                         Flat: 5 axes for 90 % — yet locally about 1.4 dimensions (step 1)
                         So the sheet is probably curved, or in pieces: step 3.


16
                                                     Space                                     Flat sheet      Curved sheet         Groups
~~~~

### DS-U07-L-EN-P016-D01 — Rekonstruktion

Scree plot: x=PC1–PC9, y=explained variance %, bars plus cumulative curve; 80% and 90% thresholds, Kaiser λ>1, broken-stick curve.

| PC | Explained variance % (rounded) |
|---|---:|
|1|46.7|
|2|20.2|
|3|12.3|
|4|10.3|
|5|7.3|
|6|1.8|
|7|0.9|
|8|0.5|
|9|0|

PC1+PC2=66.9%; 90% rule → 5; Kaiser → 3; broken stick → 1.

## Page 017

[Original page 17](../../../quellen/Unit07_slides_en.pdf#page=17)

~~~~text
                                                             MEASURED: WHAT THE AXES MEAN

                                PC1 loadings: size               PC2 loadings: mix                          99 % of 2,000 customers
                  revenue    -0.45                                      -0.13
                    orders      -0.33                                             +0.02            1
                  products   -0.46                                       -0.11
                  quantity   -0.45                                      -0.16
           avg order value    -0.44                                       -0.02                    0




                                                                                             PC2
                                                                                                              Accessories
         share Accessories                      +0.14           -0.62                                         Bikes
               share Bikes         -0.14                                                   +0.71 −1           Clothing
                                                                                                              Components
            share Clothing                     +0.06                -0.24
        share Components          -0.19                               -0.06
                               -0.5        0           0.5          -0.5 0           0.5               −8      −6     −4     −2      0
                                                                                                            PC1 (left = bigger customer)
     • Loadings = the entries of the eigenvector. A customer’s PC1 value is −0.45·revenue
       −0.33·orders − . . . (z-scored). Long bar: this feature matters most for the axis.
     • PC1: long bars for the ﬁve size features, short ones for the shares ⇒ size. Signs are arbitrary:
       here bigger customers sit further left.
     • PC2: share Bikes +0.71 vs share Accessories −0.62 ⇒ bikes vs accessories. Colour = the
       largest of the four shares PCA used; PC2 is built from them, so bike buyers sit at the top.

17
                   Space                           Flat sheet                              Curved sheet                     Groups
~~~~

## Page 018

[Original page 18](../../../quellen/Unit07_slides_en.pdf#page=18)

~~~~text
                                                 OFF THE SHEET: MAHALANOBIS DISTANCE

     Why: some rows are unusual only as a combination — 190 cm and 50 kg: each value normal,
     together rare. They lie off the sheet; U04’s rule and Euclidean distance can miss them (used in fraud
     checks, sensor monitoring).
                                                           A, B: same distance from the centre µ, both pass
                                                           U04’s rule. But B sits where nobody is:
                   1.5×IQR on each axis                                                            Euclidean       Mahalanobis
                         B
                                                       A                     A along the cloud     1.6             1.5
                                                                             B across it           1.6             4.1

                                                                                      dM (x)2 = (x − µ)⊤ S−1 (x − µ)
                                      µ
                                                                            S: covariance matrix. In words: turn to the PCA
                                                                            axes, divide by the spread along each, measure
                                                                            Euclidean (Mahalanobis, 1936): a step across the
                                                                            cloud counts more.
               a drawn example: 46 made-up points, two features;
                                                                                                                2
                    distances from their mean and covariance                Real AWC: 555 of 19,119 far off (dM   > 17.53,
        ellipses: dM = 1 and 2; dashed circle: same Euclidean distance
                                                                            Extra), 516 resellers. U04’s rule ﬂags
                                                                            527 of them too; 28 only Mahalanobis ﬁnds.
18
                         Space                                 Flat sheet           Curved sheet               Groups
~~~~

### DS-U07-L-EN-P018-D01 — Rekonstruktion

Elongated scatter cloud; equal Euclidean distances of A along cloud and B across it (1.6), Mahalanobis 1.5 vs 4.1. Ellipses show Mahalanobis contours. $d_M(x)^2=(x-\mu)^\top S^{-1}(x-\mu)$.

## Page 019

[Original page 19](../../../quellen/Unit07_slides_en.pdf#page=19)

~~~~text
            Break
          10 minutes




Then: Step 3: A Curved Sheet — t-SNE
~~~~

## Page 020

[Original page 20](../../../quellen/Unit07_slides_en.pdf#page=20)

~~~~text
         STEP 3: A CURVED SHEET — T-SNE


     Space      Flat sheet   Curved sheet   Groups




20
~~~~

## Page 021

[Original page 21](../../../quellen/Unit07_slides_en.pdf#page=21)

~~~~text
                                                                                             A ROLLED-UP SHEET

     Roll the sheet of paper from step 1 and look at it from the side: a spiral. Each point still needs only
     one number here — how far along the curve. But PCA measures in straight lines, and straight lines
     cut across the layers.

                      A to B: short in a straight line,
                           long along the spiral                        PCA to 1D: the order is lost
                                                             rank correlation with position: 0.11
                                           PC1

                            B
                                   A
                                                              −15     −10       −5       0       5      10   15
                                                                                      PC1
                                along the spiral: 79.2                      position along the spiral
                                straight line: 6.3



     A ﬂat ﬁt cannot unroll it
     A and B are 6.3 apart in a straight line but 79.2 along the curve. PC1 keeps 54 % of the variance,
     and the order along the spiral is gone. Keep neighbours instead of distances — that is t-SNE.

21
                    Space                            Flat sheet                   Curved sheet                Groups
~~~~

## Page 022

[Original page 22](../../../quellen/Unit07_slides_en.pdf#page=22)

~~~~text
                                                                   T-SNE IN THREE STEPS

     Goal: each point keeps its neighbours on a 2D page                                           Gaussian N(0, 1)
                                                                                                  Student-t, ν = 1 (Cauchy)
     (van der Maaten & Hinton, 2008).                                                  0.4

     1. In the 9 features: who are each point’s neighbours,                            0.3




                                                                             density
     weighted by a bell curve (dashed, right)? The perplexity                          0.2
     sets roughly how many count.                                                      0.1

     2. On the map: the same, but with a curve with heavy tails                        0.0

     (it stays high far out), which gives room: a 9-D                                  100

     neighbourhood does not ﬁt into 2D (step 1).




                                                                    density (log)
                                                                                    10−2

     3. Move the map points in small steps until both lists of                                                             at x = 5: t is
                                                                                    10−4
                                                                                                                           8,000× higher
     neighbours agree.
                                                                                    10−6
                                                                                             −5            0           5
                                                                                                           x

      What a mistake costs
      Neighbours put far apart: expensive. Strangers put close: cheap. So t-SNE protects neighbourhoods
      — and the heavy tails make gaps between groups look wider.

22
                     Space                  Flat sheet            Curved sheet                                 Groups
~~~~

## Page 023

[Original page 23](../../../quellen/Unit07_slides_en.pdf#page=23)

~~~~text
                                                                           THE REAL AWC T-SNE MAP

                                                         Accessories
                                                    60   Bikes
                                                         Clothing
                                                    40   Components

                                                    20




                                     dimension 2
                                                     0
                                                   −20
                                                   −40
                                                   −60                     50 identical
                                                                           customers
                                                         −50    −25    0     25     50
                                                         t-SNE dimension 1 (no units)

     The same 2,000-customer sample, 9 features, perplexity 30. Colour: the category with the largest
     share of the customer’s revenue. The axes have no meaning and no units — unlike PCA, where PC1
     was “size”. You may read which points are together, not where they are. A very small, dense group
     can be one row repeated: 58 % of the sample have an exact twin. Large data: Extra, fast t-SNE.

23
                   Space                           Flat sheet                     Curved sheet   Groups
~~~~

## Page 024

[Original page 24](../../../quellen/Unit07_slides_en.pdf#page=24)

~~~~text
                                            MEASURED: WHAT EACH METHOD PRESERVES

                                    100 %



                  neighbours kept
                                     75 %
                                     50 %        PCA (distance corr. 0.91)
                                                 t-SNE, perplexity 5 (distance corr. −0.08)
                                     25 %        t-SNE, perplexity 30 (distance corr. −0.03)
                                                 t-SNE, perplexity 100 (distance corr. 0.08)
                                      0%
                                             1                           10                          100      500
                                                         k: how many nearest neighbours we ask about
     Real AWC customers, 9 features. Neighbours kept: of each point’s k nearest neighbours, the share
     still among its k nearest on the map — a standard quality measure (Mokbel et al., 2013). Distance
     corr.: do the distances on the map match the true ones?

     Perplexity sets how local “local” is
     t-SNE wins for near neighbours, PCA for far ones, and only PCA keeps the distances. So
     never show one t-SNE plot: try 3–4 perplexities and trust what stays the same.

24
                     Space                                  Flat sheet                         Curved sheet    Groups
~~~~

## Page 025

[Original page 25](../../../quellen/Unit07_slides_en.pdf#page=25)

~~~~text
                             A T-SNE MAP: THREE WRONG CONCLUSIONS

     Wrong conclusion                  Why it is wrong                     What our data show
     “These clusters are far apart,    distances between clusters are      distances correlate at
     so they are very different”       not kept                            −0.03: no relation
     “This cluster is big, so it has   t-SNE makes dense groups            Accessories: smallest
     more variation”                   larger and sparse groups            spread in the data,
                                       smaller (Wattenberg et al., 2016)   largest on the map
     “There are exactly 26 groups”     the count changes with              26 groups at
                                       perplexity and with the random      perplexity 30, 9 at 100
                                       start

     What the map does show
     Which points are neighbours: 82 % of the 10 nearest neighbours are kept (perplexity 30).
     Distances, sizes and gaps between groups are not reliable.


25
                  Space                 Flat sheet          Curved sheet         Groups
~~~~

## Page 026

[Original page 26](../../../quellen/Unit07_slides_en.pdf#page=26)

~~~~text
                           NEW DATA: PCA CAN PLACE IT, T-SNE CANNOT

     A new customer signs up next month. Where does this customer go on the map?
                 the new customer             use it as                         in the tools
     PCA         same formula, same           a step in a model: learn it       transform()
                 map: the loadings give       on old data, apply it to new      KNIME: PCA Apply
                 the place                    data
     t-SNE       no place for new             a picture of these points         only fit_transform()
                 points: a new run gives      only                              KNIME: a t-SNE node,
                 a whole new map                                                but no Apply node
     New points on the map? Variants such as kernel t-SNE (Gisbrecht et al., 2015) learn a formula for
     them.

     The rule
     PCA can be part of a model; plain t-SNE is only for looking.


26
                   Space                  Flat sheet             Curved sheet          Groups
~~~~

## Page 027

[Original page 27](../../../quellen/Unit07_slides_en.pdf#page=27)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit07_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit07_slides_en.pdf#page=28)

~~~~text
    Break
  10 minutes




Then: Step 4: Groups
~~~~

## Page 029

[Original page 29](../../../quellen/Unit07_slides_en.pdf#page=29)

~~~~text
             STEP 4: GROUPS IN THE DATA


     Space        Flat sheet   Curved sheet   Groups




29
~~~~

## Page 030

[Original page 30](../../../quellen/Unit07_slides_en.pdf#page=30)

~~~~text
                                            K-MEANS: HOW MANY GROUPS? NO CLEAR ELBOW

                             9 single runs, each from different random start centres   k-means: pick k centres, give each point
     mean squared distance

                                                                                       to the nearest centre, move each centre
                               best of 20 runs
                                                                                       to the mean of its points, repeat.
         to the centre



                             6                            a bad run at k = 4           Y-axis: mean squared distance of the
                                                          is worse than the            points to their centre. We look for a bend
                                                          best run at k = 3            (the elbow): after it, more groups help
                             3                                                         little.
                                                                                       Real AWC: 19,119 customers, 9 features; 20
                                                                                       runs per k with k-means++ starts
                             0                                                         (Arthur & Vassilvitskii, 2007). sklearn:
                                  1     2       3     4      5      6      7     8     inertia_ is the sum of these squared
                                                k: number of clusters                  distances.


             k-means always returns k clusters
             Groups or not. From k = 2 to 6, each step removes 24–33 %: no clear elbow. And one run is
             not an answer — keep the best of many.

30
                                        Space                     Flat sheet           Curved sheet            Groups
~~~~

## Page 031

[Original page 31](../../../quellen/Unit07_slides_en.pdf#page=31)

~~~~text
                                                             THE MAIN MISTAKE TO AVOID

     k-means on the 9 features            k-means on the map         Same customers, same k-means, k = 4.
                                                                     On the 9 features: two large groups, two
                                                                     tiny ones (15 and 44). On the map: four
                                                                     pieces of similar size.
                                                                     Agreement with the 9-feature groups:
                                                                     PCA map 0.99, t-SNE map 0.22.
                                                                     ARI: agreement of two groupings, 0 = chance,
                                                                     1 = identical (Hubert & Arabie, 1985).



                        agreement: ARI = 0.22
     Real AWC: 2,000 customers on their t-SNE map (perplexity 30);
     k = 4, best of 20 runs. Colours = clusters, not categories.

      Clustering the picture is not clustering the data
      Cluster in the feature space; use the map only to look at the result. Do not draw groups by hand.

31
                      Space                    Flat sheet            Curved sheet           Groups
~~~~

## Page 032

[Original page 32](../../../quellen/Unit07_slides_en.pdf#page=32)

~~~~text
       Break
      10 minutes




Then: Hands On — Exercise 3
~~~~

## Page 033

[Original page 33](../../../quellen/Unit07_slides_en.pdf#page=33)

~~~~text
          HANDS ON — EXERCISE 3
                          20 minutes
       Sheet on Moodle: Unit07_Exercises_en.pdf

     Exercise 4 is voluntary: what you may claim from the picture.




33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit07_slides_en.pdf#page=34)

~~~~text
                                                                 KEY MESSAGES

     • Many columns, empty space: the nearest neighbours may be far away, and a
       model guesses where it saw no data
     • Data may lie on sheets and lines (intrinsic dimension). Where they do, reducing
       works; AWC: about 1.4 locally, not 9 — measure it, do not assume it
     • PCA ﬁnds a ﬂat sheet: a rotation you can reuse on new rows. Report what the
       2D plot shows (67 %) and name your rule for k
     • Mahalanobis ﬁnds rows that are unusual only as a combination: off the sheet
     • t-SNE follows a curved sheet: it keeps neighbours — not distances, sizes or the
       number of groups — and its map is only a picture
     • Cluster in the feature space; use the map only to look at the result. k-means
       always returns k groups: restart it and name your k
     • Next: U08 — Exploratory Data Analysis: Statistics & Visualisation

34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit07_slides_en.pdf#page=35)

~~~~text
                   EXTRA: DETAILS FOR READING
     The recipe in code · the Mahalanobis cut-off · maps from distances · fast t-SNE




35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit07_slides_en.pdf#page=36)

~~~~text
                                                                     PCA: THE RECIPE IN CODE

     The slide “Find the Sheet: Turn the Axes”, in full. flat is your U01 ﬂat table:

      1   g = ﬂat.groupby("CustomerID")
      2   X = np.log1p(np.c_[g.LineTotal.sum(), g.ProductID.nunique()]) # 19,119 x 2
      3   X = (X - X.mean(0)) / X.std(0)        # 1. centre and scale (U06)
      4   C = np.cov(X, rowvar=False)            # 2. covariance matrix
      5   values, vectors = np.linalg.eigh(C) # 3. eigendecomposition
      6   order = np.argsort(values)[::-1]      # 4. sort by variance, descending
      7   values, vectors = values[order], vectors[:, order]
      8   Y = X @ vectors[:, :1]           # 5. project onto PC1
      9   print(values, values / values.sum()) # [1.547 0.454] [0.773 0.227]


      • eigh, not eig: C is symmetric — real eigenvalues, orthogonal eigenvectors
      • Centring is required: without it, PC1 points at the mean
      • Scaling is a decision: unscaled, PC1 follows the biggest unit, not the most variation
                                         ∑
      • Explained variance of PCi is λi / j λj — the last line

     Scripts/awc_pca.py runs the same steps on all 9 features.
36
~~~~

## Page 037

[Original page 37](../../../quellen/Unit07_slides_en.pdf#page=37)

~~~~text
                                         MAHALANOBIS: HOW FAR IS “FAR OFF”? THE CUT-OFF 17.53



                                                       cut-off 17.53                                  17.53: for normal data, only 2.5 % lie
                                                                             flagged: 555
                                                                             516 resellers, 39 web    beyond it (black curve). The 2.5 % is
                       103
                                                                                                      our choice, like U04’s 1.5.
     customers (log)




                                                                                                      scipy.stats.chi2.ppf(0.975, 8)
                       102
                                                                                                      Our customers do not follow the
                       101                                                                            curve: only a rough guide.
                                                                                                      516 of the 555 are resellers: a
                       100                                                                            second kind of customer. Consider
                                                                                                      one PCA per group.
                             100               101                     102                    103
                                         squared Mahalanobis distance dM2 (log)
                              web customers    resellers     χ82 curve: what normal data would give


         Real AWC: all 19,119 customers, 8 features (one share dropped).



37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit07_slides_en.pdf#page=38)

~~~~text
                                   MDS: A MAP OUT OF A TABLE OF DISTANCES

      U06’s dynamic time warping (DTW) and edit distance say only how far apart two things are — no
      column to plot. Five cities, as nothing but distances:

      km             HH       B      K     WÜ          M                             Hamburg

      Hamburg         —     255    356    418     612                                               Berlin




                                                                                           612 km
      Berlin                  —    477    387     504                       Cologne
      Cologne                        —    248     456                        Wuerzburg
      Wuerzburg                             —     219
      Munich                                        —
                                                                                         Munich
     Real great-circle distances between the cities.
                                                           The map, from the table alone: every distance within
     No latitude, no longitude, no north. Each
                                                           0.09 km. We rotated it so that north is up; distances alone
     city is a row of 5 numbers — yet 2 sufﬁce.
                                                           do not say where north is.

      How: classical multidimensional scaling (MDS)
      Turn the distance table into coordinates by an eigendecomposition (next slide); keep the top two
      (Torgerson, 1952). On Euclidean distances this is PCA (checked on 400 AWC customers).

38
~~~~

## Page 039

[Original page 39](../../../quellen/Unit07_slides_en.pdf#page=39)

~~~~text
                         PSEUDO-EUCLIDEAN EMBEDDING: ANY DISTANCE TABLE TO VECTORS

      DTW or edit distance (U06) give only a table D of distances. PCA and k-means need vectors, so ﬁrst
      turn D into vectors (Pękalska & Duin, 2005):

     1. Square and double-centre: G = − 21 JD(2) J         D Euclidean: all λ ≥ 0. X reproduces D exactly; its
     with J = I − n1 11⊤ . D(2) : every entry squared. G   ﬁrst two columns are classical MDS = PCA.
     holds inner products (similarities, U06).             D not Euclidean (DTW, edit distance): usually
     2. Eigendecompose: G = UΛU⊤ .                         some λ < 0. X lives in a pseudo-Euclidean space:
     3. Coordinates: X = U |Λ|1/2 , one row per             d2 (x, y) = λk >0 (xk − yk )2 −                   2
                                                                       ∑                    ∑
                                                                                             λk <0 (xk − yk )
     object.
                                                           Keep it, or correct it: drop the negative part (clip)
                                                           or use |λ| (ﬂip). Then any vector method.

      Large n: the Nyström approximation
      Exact: all n2 distances, about n3 time. Nyström: pick m ≪ n landmark rows, compute only n · m
      distances, eigendecompose the small m × m part and extend — linear in n (Williams & Seeger, 2001;
      Gisbrecht & Schleif, 2015).

39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit07_slides_en.pdf#page=40)

~~~~text
                                                       FAST T-SNE: BARNES–HUT

                                             Plain t-SNE compares every pair of points: 10×
                                             the rows means 100× the time and memory.
                                      m̄
                                             customers            2,000                         19,119
                                             plain t-SNE           49 s   est. 75 min, 2.9 GB/matrix
                                             Barnes–Hut             6s                         73 s
                     i
                                             Barnes–Hut (Barnes & Hut, 1986): far points are
                                             grouped, each group counts as one point: N log N
                                             instead of N2 (van der Maaten, 2014).
            near: sum          far: one
           point by point   centre of mass



     Before you run it on a bigger matrix
     Check the method ﬁrst: sklearn’s TSNE uses Barnes–Hut by default. A faster tool
     needs an install: openTSNE. In KNIME: sample ﬁrst.

40
~~~~

## Page 041

[Original page 41](../../../quellen/Unit07_slides_en.pdf#page=41)

~~~~text
                                                SOURCES & FURTHER READING (1/5)

     • Mardia, Kent & Bibby (1979), Multivariate Analysis, Academic Press — the standard reference for
       Mahalanobis and MDS
     • Torgerson (1952), Multidimensional scaling: I. Theory and method, Psychometrika 17(4):401–419 — classical
       MDS
       doi.org/10.1007/BF02288916
     • Jackson (1993), Stopping rules in principal components analysis, Ecology 74(8):2204–2214 — where the
       broken-stick comparison comes from
       doi.org/10.2307/1939574
     • Bartlett (1950), Tests of signiﬁcance in factor analysis, British Journal of Statistical Psychology 3(2):77–85 —
       the test of sphericity
       doi.org/10.1111/j.2044-8317.1950.tb00285.x
     • Kaiser (1974), An index of factorial simplicity, Psychometrika 39(1):31–36 — the KMO measure and its scale
       doi.org/10.1007/BF02291575
     • Jolliffe & Cadima (2016), Principal component analysis: a review and recent developments, Phil. Trans. R. Soc.
       A 374:20150202 — PCA at the level this unit condenses
       doi.org/10.1098/rsta.2015.0202
     • Golub & Van Loan (2013), Matrix Computations, 4th ed., Johns Hopkins University Press — the SVD numerics
       behind every PCA implementation

41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit07_slides_en.pdf#page=42)

~~~~text
                                            SOURCES & FURTHER READING (2/5)


     • Mahalanobis (1936), On the generalised distance in statistics, Proc. Natl. Inst. Sci. India
       2(1):49–55
     • van der Maaten (2009), Learning a Parametric Embedding by Preserving Local Structure,
       AISTATS, PMLR 5:384–391 — out-of-sample t-SNE, by learning the mapping with a network
       proceedings.mlr.press/v5/maaten09a
     • Gisbrecht, Schulz & Hammer (2015), Parametric nonlinear dimensionality reduction using kernel
       t-SNE, Neurocomputing 147:71–82 — t-SNE with a formula for new points
       doi.org/10.1016/j.neucom.2013.11.045
     • Mokbel, Lueks, Gisbrecht & Hammer (2013), Visualizing the quality of dimensionality reduction,
       Neurocomputing 112:109–123 — neighbourhood-based quality curves
       doi.org/10.1016/j.neucom.2012.11.046
     • Shlens (2014), A Tutorial on Principal Component Analysis — an easy start
       arxiv.org/abs/1404.1100



42
~~~~

## Page 043

[Original page 43](../../../quellen/Unit07_slides_en.pdf#page=43)

~~~~text
                                          SOURCES & FURTHER READING (3/5)

     • Barnes & Hut (1986), A hierarchical O(N log N) force-calculation algorithm, Nature 324:446–449
       — the astrophysics trick
       doi.org/10.1038/324446a0
     • van der Maaten (2014), Accelerating t-SNE using Tree-Based Algorithms, JMLR 15:3221–3245 —
       Barnes–Hut for t-SNE
       www.jmlr.org/papers/v15/vandermaaten14a.html
     • van der Maaten & Hinton (2008) — the original t-SNE paper
       www.jmlr.org/papers/v9/vandermaaten08a.html
     • Wattenberg, Viégas & Johnson (2016), How to Use t-SNE Effectively (distill.pub) — interactive,
       and the best cure for over-reading a plot
       distill.pub/2016/misread-tsne
     • Arthur & Vassilvitskii (2007), k-means++: The Advantages of Careful Seeding, Proc. 18th
       ACM-SIAM Symposium on Discrete Algorithms (SODA), 1027–1035 — the spread-out starts
     • Hubert & Arabie (1985), Comparing partitions, Journal of Classiﬁcation 2:193–218 — the adjusted
       Rand index
       doi.org/10.1007/BF01908075

43
~~~~

## Page 044

[Original page 44](../../../quellen/Unit07_slides_en.pdf#page=44)

~~~~text
                                           SOURCES & FURTHER READING (4/5)


     • Hastie, Tibshirani & Friedman (2009), The Elements of Statistical Learning, 2nd ed., Springer, Sec.
       2.5 — the box that must cover most of every range
       doi.org/10.1007/978-0-387-84858-7
     • Beyer, Goldstein, Ramakrishnan & Shaft (1999), When Is “Nearest Neighbor” Meaningful?, ICDT,
       LNCS 1540:217–235 — nearest and farthest become equally far
       doi.org/10.1007/3-540-49257-7_15
     • Facco, d’Errico, Rodriguez & Laio (2017), Estimating the intrinsic dimension of datasets by a
       minimal neighborhood information, Scientiﬁc Reports 7:12140 — TwoNN
       doi.org/10.1038/s41598-017-11873-y
     • Hahsler, Hornik & Buchta (2008), Getting Things in Order: An Introduction to the R Package
       seriation, Journal of Statistical Software 25(3) — reordering rows and columns
       doi.org/10.18637/jss.v025.i03




44
~~~~

## Page 045

[Original page 45](../../../quellen/Unit07_slides_en.pdf#page=45)

~~~~text
                                           SOURCES & FURTHER READING (5/5)



     • Pękalska & Duin (2005), The Dissimilarity Representation for Pattern Recognition: Foundations
       and Applications, World Scientiﬁc — pseudo-Euclidean embedding
       doi.org/10.1142/5965
     • Williams & Seeger (2001), Using the Nyström Method to Speed Up Kernel Machines, Advances in
       Neural Information Processing Systems 13 — Nyström
       papers.nips.cc/paper/1866
     • Gisbrecht & Schleif (2015), Metric and non-metric proximity transformations at linear costs,
       Neurocomputing 167:643–657 — Nyström for any distance table
       doi.org/10.1016/j.neucom.2015.04.017




45
~~~~
