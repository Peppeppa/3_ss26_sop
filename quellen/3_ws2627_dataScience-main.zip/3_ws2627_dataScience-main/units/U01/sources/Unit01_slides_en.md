---
source_id: DS-U01-L-EN
original_file: Unit01_slides_en.pdf
source_type: lecture
language: en
page_count: 29
source_sha256: 59048243f96fe07c35e5316db76a4c3ac487d2c571378ae6399bfb24a58405fa
verification: partial
---
# Unit01_slides_en

[Original PDF](../../../quellen/Unit01_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit01_slides_en.pdf#page=1)

~~~~text
Data Science

TABULAR DATA, TIDY DATA &
JOINS


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit01_slides_en.pdf#page=2)

~~~~text
                                                             LEARNING GOALS



    • Say for any table what one row is — and recognise a table that breaks the tidy
      rules
    • Predict from the cardinality whether a join keeps, multiplies or drops rows —
      and check it by the row count
    • Choose INNER or LEFT by the purpose of the join
    • Build the AWC ﬂat table — one row per order item — in SQL, Python or KNIME
    • Change the row with pivot, go back with melt, and say what the round trip loses




2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit01_slides_en.pdf#page=3)

~~~~text
                        FROM MANY TABLES TO ONE ANALYSIS TABLE

    The task of this unit
    Data lives in many linked tables. Analysis needs one table with one row per thing
    you ask about.

    Example in this unit (AWC, 71 tables): which customers buy which product categories, and
    for how much?
    Four steps get there; orange = the typical mistake of each.



          1 One row               2 Join              3 Flat table               4 Pivot
         decide what           combine ta-       build it once, freeze it    change the row
          one row is           bles by keys                                 to ﬁt the question
          a table no         rows multiply or        every query at         wrong aggregation;
         tool can use         vanish, silently       its own grain           empty read as 0

3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit01_slides_en.pdf#page=4)

~~~~text
              STEP 1: WHAT IS ONE ROW?


    One row         Join     Flat table   Pivot




4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit01_slides_en.pdf#page=5)

~~~~text
                              TIDY DATA: ONE ROW IS ONE OBSERVATION

                                                  Reseller                      Month        SubTotal
                                                  Roadway Bicycle Supply        2013-09       122,286
    Three rules (Wickham, 2014)                   Roadway Bicycle Supply        2013-12       108,184
                                                  Field Trip Store              2013-09       112,045
    1. Each observation is a row                 row = one observation: one reseller in one month
    2. Each variable is a column                 column = one variable: the month
    3. Each value is a cell                      cell = one value: the SubTotal of that order
                                                 Real AWC: SubTotal of reseller orders; these stores order once
                                                 per quarter.


     Rule 1 is a decision: one row = one what?
     The answer is the table’s grain: here one reseller-month. A join must keep the grain (step
     2); a pivot changes it on purpose (step 4).

5                         One row         Join                  Flat table        Pivot
~~~~

## Page 006

[Original page 6](../../../quellen/Unit01_slides_en.pdf#page=6)

~~~~text
                         THREE WAYS TO BREAK THE RULES — AND THE REPAIR

    pattern                 example                                                           repair
    1. Variable in the      Reseller                    2013-09    2013-12       2014-03      melt: headers
    headers (wide):         Roadway Bicycle Supply      122,286    108,184        112,313     become values of a
    the month is a          Field Trip Store            112,045    104,325        82,062      column Month (step
    column name                                                                               4)
    2. Several              Location:      "Würzburg, Bavaria, DE"                            split into city, state,
    variables in one                                                                          country
    cell
    3. Variables            Product              Metric             Value                     pivot: each metric its
    stored in rows          Road-150 Red, 44     ListPrice        3578.27                     own column (step 4)
                            Road-150 Red, 44     StandardCost     2171.29
    Real AWC values (reseller SubTotal, product list); the address is made up.

    ⇒ Tidy depends on the question. One column per category is wide if the observation is a
    purchase, tidy if it is a customer (step 4). The hard part is the observation; reshaping is
    mechanical.
6                            One row             Join                Flat table             Pivot
~~~~

## Page 007

[Original page 7](../../../quellen/Unit01_slides_en.pdf#page=7)

~~~~text
   Break
 10 minutes




Then: Step 2: Joins
~~~~

## Page 008

[Original page 8](../../../quellen/Unit01_slides_en.pdf#page=8)

~~~~text
    STEP 2: JOIN TABLES WITHOUT BREAKING THE
                       ROW


       One row    Join     Flat table   Pivot




8
~~~~

## Page 009

[Original page 9](../../../quellen/Unit01_slides_en.pdf#page=9)

~~~~text
                                        RECAP DATABASE I: FOUR JOIN TYPES

    Every join ﬁrst pairs the rows whose keys match. The join type only decides what happens
    to the rest: rows without a match. Shaded = kept:


           L         R          L         R               L          R             L         R



             INNER                   LEFT                     RIGHT                FULL OUTER
          matches only     all of L, matches of R    all of R, matches of L   everything, gaps empty

     Python pd.merge(L, R, on=’key’, how=’inner’) — or ’left’, ’right’, ’outer’
     KNIME Joiner: tick matching, left unmatched, right unmatched

    What the picture cannot show
    A Venn diagram shows which rows are kept, never how many. On a 1:n join one kept row comes back
    once per match. That is where the analysis errors live.

9                          One row            Join               Flat table       Pivot
~~~~

### DS-U01-L-EN-P009-D01 — Rekonstruktion

Four Venn diagrams: INNER shades overlap only; LEFT shades all L; RIGHT shades all R; FULL OUTER shades both. Diagrams express retention, not multiplicity.

## Page 010

[Original page 10](../../../quellen/Unit01_slides_en.pdf#page=10)

~~~~text
                                A JOIN CAN CHANGE THE NUMBER OF ROWS


     Ask before every join
     How many rows on the other side match one row of my table?

     a row of my table has          AWC example                                 rows after the join
     exactly one match (n:1)        order item → its product                    same: 121,317 → 121,317
     several matches (1:n)          order → its order items                     more: 31,465 → 121,317
     no match, joined INNER         product → subcategory: 209 of               fewer: 504 → 295
                                    504 products have none
     no match, joined LEFT          the same 209 products                       same, with empty columns
     Real AWC row counts. Through a bridge table (m:n) rows can explode.

     ⇒ Golden rule: say the expected row count before the join, check it after.


10                           One row            Join               Flat table        Pivot
~~~~

## Page 011

[Original page 11](../../../quellen/Unit01_slides_en.pdf#page=11)

~~~~text
                                                      MORE ROWS: SUMS GO WRONG

     After a 1:n join, every value of the one side repeats once per match:

                SalesOrderID   ProductName                    LineTotal (item)      SubTotal (order)
                       51178   Mountain-200 Silver, 38                2,319.99               2,334.97
                       51178   Mountain Bottle Cage                       9.99               2,334.97
                       51178   Water Bottle - 30 oz.                      4.99               2,334.97
                         Real AWC: one online order after joining its header to its items.


      • Sum of SubTotal: 7,004.91 instead of 2,334.97. Over all orders: 2.60 billion instead of
        109.8 million.
      • Rule: sum only values of the table’s own grain (LineTotal). Aggregate the others
        before the join.


11                        One row             Join                 Flat table          Pivot
~~~~

## Page 012

[Original page 12](../../../quellen/Unit01_slides_en.pdf#page=12)

~~~~text
                   FEWER ROWS: INNER DROPS ROWS WITHOUT A MATCH

     Products joined to their subcategory — four real AWC products, two of them have none:
                    LEFT: 4 rows                                          INNER: 2 rows

        ProductName                SubCategory             ProductName                    SubCategory
        Sport-100 Helmet, Red      Helmets                 Sport-100 Helmet, Red          Helmets
        Mountain Bike Socks, M     Socks                   Mountain Bike Socks, M         Socks
        Thin-Jam Hex Nut 9         empty
        LL Grip Tape               empty

                  all 504 products: 295 with subcategory         209 without (41%)

      • The 209: hex nuts (screw nuts), washers, grip tape — never sold. Their subcategory key
        is NULL (allowed). INNER drops them silently.
      • Measure: lost = rows(LEFT) − rows(INNER) = 209. See them: KNIME left unmatched
        rows; SQL LEFT JOIN + WHERE r.key IS NULL.

12                       One row             Join            Flat table         Pivot
~~~~

## Page 013

[Original page 13](../../../quellen/Unit01_slides_en.pdf#page=13)

~~~~text
                      RESTRICT OR ENRICH? THAT DECIDES THE JOIN TYPE



     So which join type? Ask what the join is for:

      the join is a                example                                               type    row loss is
      restriction (like a WHERE)   order items of German resellers only                  INNER   the point
                                   (exercises)
      enrichment (a lookup)        add product, category, customer, territory (step      LEFT    a bug
                                   3)
     ⇒ Restricting by join works only if the key is unique on the other side — otherwise you

     ﬁlter and multiply.
     KNIME left unmatched rows unticked = INNER, ticked = LEFT.




13                           One row           Join              Flat table           Pivot
~~~~

## Page 014

[Original page 14](../../../quellen/Unit01_slides_en.pdf#page=14)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit01_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




14
~~~~

## Page 015

[Original page 15](../../../quellen/Unit01_slides_en.pdf#page=15)

~~~~text
       Break
      10 minutes




Then: Step 3: The Flat Table
~~~~

## Page 016

[Original page 16](../../../quellen/Unit01_slides_en.pdf#page=16)

~~~~text
     STEP 3: THE FLAT TABLE — ONE ROW PER ORDER
                         ITEM


        One row     Join     Flat table   Pivot




16
~~~~

## Page 017

[Original page 17](../../../quellen/Unit01_slides_en.pdf#page=17)

~~~~text
                                                    WHY ONE FROZEN TABLE?




     The database answers every query — so why extract a table?

      • Tools want one rectangle. pandas, KNIME, plots, models: one table, one row
        per observation.
      • The grain is decided once — not again, and differently, in every query.
      • Results need a ﬁxed reference. The database changes; a frozen extract does
        not.




17                      One row        Join          Flat table     Pivot
~~~~

## Page 018

[Original page 18](../../../quellen/Unit01_slides_en.pdf#page=18)

~~~~text
                                   THE JOIN CHAIN: START AT THE MANY SIDE


                                                                   Detail
                                   SalesOrderID         one row per order item           ProductID
                                                               121,317

                            Header                                                              Product
                           OrderDate,                                                         ProductName,
                          SubTotal, . . .                                                      ListPrice, . . .
        CustomerID                               TerritoryID                                           ProductSubcategoryID
          Customer                              Territory                                     Subcategory
      PersonID, StoreID                     TerritoryName, . . .                               SubCategory
                                                                                                     ProductCategoryID
      ⇒ Seen from Detail, every join is an n:1                                                  Category
      lookup: it only adds columns. The row                                                     Category
      count must stay 121,317 after each one.

     Real AWC; grey = columns each lookup adds. Short names: Detail = Sales_SalesOrderDetail, and so on.
18                             One row                 Join                 Flat table           Pivot
~~~~

### DS-U01-L-EN-P018-D01 — Rekonstruktion

```mermaid
flowchart TD
 D[Detail: 121317 order items] -->|SalesOrderID| H[Header]
 D -->|ProductID| P[Product]
 H -->|CustomerID| C[Customer]
 H -->|TerritoryID| T[Territory]
 P -->|ProductSubcategoryID| S[Subcategory]
 S -->|ProductCategoryID| K[Category]
```
Each arrow is an n:1 lookup seen from Detail; the grain stays one order item, 121,317 rows.

## Page 019

[Original page 19](../../../quellen/Unit01_slides_en.pdf#page=19)

~~~~text
                                                      SQL: THE CHAIN, DECLARATIVELY



     The FROM table sets the grain. Four of the seven tables, for one customer:
      1   SELECT c.CustomerID, h.SalesOrderID, DATE(h.OrderDate) AS OrderDate,
      2      p.Name AS ProductName, d.OrderQty, d.UnitPrice, d.LineTotal
      3   FROM Sales_SalesOrderDetail d       -- the many side: it sets the grain
      4   JOIN Sales_SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
      5   JOIN Sales_Customer      c ON c.CustomerID = h.CustomerID
      6   JOIN Production_Product p ON p.ProductID = d.ProductID
      7   WHERE c.CustomerID = 29825      -- Better Bike Shop: 359 items, 12 orders
      8   ORDER BY h.SalesOrderID, d.SalesOrderDetailID;

     Without the WHERE: 121,317 rows, the row count of Detail. Revenue = SUM(d.LineTotal);
     SUM(h.SubTotal) is 30.7× too high (step 2).




19                             One row            Join                Flat table      Pivot
~~~~

## Page 020

[Original page 20](../../../quellen/Unit01_slides_en.pdf#page=20)

~~~~text
                                        PYTHON AND KNIME: THE SAME SIX JOINS

     Python                                                                          KNIME
      1   q = lambda t: pd.read_sql(f"SELECT * FROM {t}", engine)                    • 1 MySQL Connector feeds all
     2    lookups = [("Sales_SalesOrderHeader", "SalesOrderID"),                       readers
     3     ("Production_Product", "ProductID"),
                                                                                     • 7 × DB Table Selector → DB
     4     ("Production_ProductSubcategory", "ProductSubcategoryID"),
     5     ("Production_ProductCategory", "ProductCategoryID"),                        Reader
     6     ("Sales_Customer", "CustomerID"),                                         • 6 × Joiner in a chain, Detail
     7     ("Sales_SalesTerritory", "TerritoryID")]                                    on top; matching + left
     8
     9    ﬂat = q("Sales_SalesOrderDetail")         # the grain
                                                                                       unmatched ticked
     10   for table, key in lookups:                                                 • rename duplicate Name
     11     ﬂat = ﬂat.merge(q(table), on=key, how="left",                              columns
     12                 sufﬁxes=("", "_" + table))
     13     print(table, len(ﬂat))           # 121317 each time                      • Extract Table Dimension
                                                                                       after each Joiner: 121,317?
                                                                       • CSV Writer →
                                                                         AWC/awc_flat.csv
     engine = the database connection (U02). The sufﬁx keeps duplicate names such as Name apart.

20                                One row              Join             Flat table           Pivot
~~~~

## Page 021

[Original page 21](../../../quellen/Unit01_slides_en.pdf#page=21)

~~~~text
                           THE FLAT TABLE, OPENED IN A SPREADSHEET




     awc_pivot_play.csv: the ﬂat table with 11 of its columns, 121,317 rows. One row = one order item,
     so customer 29825 and its order date repeat once per item. Tidy for purchases — not yet the answer
     about customers.
21                         One row          Join              Flat table       Pivot
~~~~

## Page 022

[Original page 22](../../../quellen/Unit01_slides_en.pdf#page=22)

~~~~text
   Break
 10 minutes




Then: Step 4: Pivot
~~~~

## Page 023

[Original page 23](../../../quellen/Unit01_slides_en.pdf#page=23)

~~~~text
     STEP 4: PIVOT — CHANGE THE ROW TO ANSWER
                    THE QUESTION


        One row    Join     Flat table   Pivot




23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit01_slides_en.pdf#page=24)

~~~~text
                      PIVOT AND MELT: A ROUND TRIP THAT DOES NOT RETURN

            long: row = purchase                wide: row = customer                         long again
            Cust Category Rev           pivot                              melt      Cust Category          Rev
              17   Bikes      400
                                    −→          Cust Bikes Clothing       −→            17   Bikes          500
              17   Bikes      100                 17    500      20                     17   Clothing        20
              17   Clothing    20                 18    300                             18   Bikes          300
              18   Bikes      300                                                       18   Clothing     empty
                   made up                                                          4 rows — not the original 4


      • Pivot: the values of Category become columns; one row is now a customer, no longer
        a purchase.
      • Blue: two rows, one cell — pivot must aggregate (400 + 100 = 500). Melt cannot split
        the 500 again.
      • Grey: a pair that never happened still gets a cell: empty, not 0. Melt turns it into a row
        — drop it.
     ⇒ Melt undoes the shape, never the aggregation. Keep the long table.
24                            One row            Join                  Flat table            Pivot
~~~~

## Page 025

[Original page 25](../../../quellen/Unit01_slides_en.pdf#page=25)

~~~~text
                                                   ONE OPERATION, THREE TOOLS

     Every pivot needs the same three choices — typed, conﬁgured or dragged:
     choice                   pandas                   KNIME                  Calc / Excel: Insert
                                                                              → Pivot Table
     what becomes a row       index=’CustomerID’       Pivot: Group columns   Row Fields
     what becomes a           columns=’Category’       Pivot columns          Column Fields
     column
     what ﬁlls a cell, and    values=, aggfunc=’sum’   Aggregation            Data Fields: Sum of
     how                                                                      ...
     back to long (melt) —    .melt(id_vars=...)       Unpivot                Calc: none; Excel:
     wide is easy to make,                                                    Power Query, Unpivot
     hard to undo                                                             Columns

     ⇒ Always name the aggregation. Without aggfunc, pivot_table silently takes the mean:
     customer 17’s 400 and 100 show 250, not 500. df.pivot refuses outright (ValueError).


25                           One row       Join            Flat table     Pivot
~~~~

## Page 026

[Original page 26](../../../quellen/Unit01_slides_en.pdf#page=26)

~~~~text
                         EXAMPLE ANSWER: ONE ROW PER CUSTOMER


     The ﬂat table, pivoted: rows = CustomerID, columns = Category, cells = sum of LineTotal:

            customer                   Accessories            Bikes        Clothing     Components
            11000                             90.95       8,104.05         53.99
            11001                             85.93       6,234.97         62.98
            29825 (Better Bike Shop)       3,683.85     365,895.16     14,180.00              38,947.60
            ...                                  ...            ...           ...                    ...
                          Real AWC: all 19,119 customers who ordered, three shown.

      • 19,119 × 4 = 76,476 cells, 57% empty: customer–category pairs that never happened.
      • Empty = never bought: 0 is right for a sum, wrong for an average.
      • Next use: U07 groups customers by these four columns (as shares of their revenue).



26                       One row           Join               Flat table              Pivot
~~~~

## Page 027

[Original page 27](../../../quellen/Unit01_slides_en.pdf#page=27)

~~~~text
        HANDS ON — EXERCISES 3 AND 4
                                  20 minutes
               Sheet on Moodle: Unit01_Exercises_en.pdf

     Exercise 3 pivots your exercise 2 result; exercise 4 builds the full ﬂat table.




27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit01_slides_en.pdf#page=28)

~~~~text
                                 SUMMARY: FOUR STEPS, FOUR CHECKS


     • 1 One row: decide the grain — one row = one what?
     • 2 Join: expect a row count, check it. More rows: never sum a repeated value.
       Fewer rows: lost = LEFT − INNER.
     • INNER restricts, LEFT enriches.
     • 3 Flat table: start at the many side; lookups only add columns. Built once,
       frozen, used all semester.
     • 4 Pivot: changes the row and must aggregate. Melt undoes the shape, not the
       aggregation. Empty is not 0.
     • Next: Unit 02 — from the SQL console to a program.



28                     One row       Join           Flat table     Pivot
~~~~

## Page 029

[Original page 29](../../../quellen/Unit01_slides_en.pdf#page=29)

~~~~text
                                                                               REFERENCES


     • H. Wickham: Tidy Data, J. of Statistical Software, Vol. 59(10), 2014.
       Free (open access)

     • W. McKinney: Python for Data Analysis, Ch. 8 (Data Wrangling: Join, Combine,
       Reshape).
       Free online

     • pandas documentation: Merge, join, concatenate.
       https://pandas.pydata.org/docs/user_guide/merging.html

     • KNIME documentation: Joiner, Pivot, Unpivot nodes.
       https://docs.knime.com/

     • S. Skiena: The Data Science Design Manual, Ch. 3 (Data Munging).
       Free via THWS/SpringerLink



29
~~~~
