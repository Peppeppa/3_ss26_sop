---
source_id: DS-U01-EX
original_file: Unit01_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: 41c47d73f01f5eff1ac040dc32674fd603cf88d9f62f98207ce49ddb01a4b1da
verification: partial
---
# Unit01_Exercises_en

[Original PDF](../../../quellen/Unit01_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit01_Exercises_en.pdf#page=1)

<a id="ds-u01-ex-t01"></a>

**DS-U01-EX-T01 — The First Join**

<a id="ds-u01-ex-t02"></a>

**DS-U01-EX-T02 — Add Product Information**

<a id="ds-u01-ex-t03"></a>

**DS-U01-EX-T03 — Pivot Round-Trip**

~~~~text
  Unit 01 — Exercises                                                                             Joins and the Flat-Table
One join, done slowly enough to see what it did — then the whole chain.
▶ In the room what ﬁts the stop — all that is expected.
⃝ Extra       voluntary, at home.
Stop A, 20 minExercises 1 and 2       Stop B, 20 min: Exercises 3 and 4
Asynchronous  the same sheet, before your weekly slot; bring what did not run.
You need      the running Adventureworks2019, and Python (pandas + sqlalchemy) or KNIME. Stay in one route, so the
              row counts mean something.
Warm-up slice Exercises 1–3 use only Germany, resellers: ﬁlter the header table ﬁrst, then join. It must have 139 orders ·
              1,903 order lines · 32 customers · 4 categories — if not, ﬁnd the cause ﬁrst.

Exercise 1 — The First Join stop A · ▶ 10 min
 1 Load Sales_SalesOrderHeader and Sales_SalesOrderDetail, ﬁlter the header, inner join on SalesOrderID. How many
   rows? (1,903; 139 or 121,317 means the ﬁlter or the join is wrong.)
      Example — the ﬁlter and the join in pandas

      h = header[(header.TerritoryID == 8) & (header.OnlineOrderFlag == 0)]            # Germany, resellers
      m = detail.merge(h, on="SalesOrderID", how="inner")
      print(len(h), len(m))                                                           # 139   1903

 2 Why does the count match Detail, not Header? What is the cardinality?
 3 Compute sum(SubTotal) (75,811,524) and sum(LineTotal) (2,021,095) on the joined table. Which is the revenue — and
   why is the other 37.5× too big?
  In KNIME
  One MySQL Connector feeds every reader (DB Table Selector → DB Reader). Header reader → Row Filter; Joiner with Detail on
  top, ﬁltered Header below, key SalesOrderID, only matching rows; Extract Table Dimension for the count; GroupBy without a
  group column, Sum of SubTotal and LineTotal.
⃝ Extra:on the unﬁltered tables, left join Detail to Header and look for an order line without a header. AWC has none;
what would one mean? (On the slice this does not work: every line outside Germany has “no header”.)
Exercise 2 — Add Product Information stop A · ▶ 10 min
 1 Join Production_Product to your Exercise 1 result via ProductID — now on your own, like the example above.
 2 Compare inner with left: both give 1,903. What does a difference of zero prove? One sentence.
 3 Add Production_ProductSubcategory and Production_ProductCategory. All three tables have a column Name: rename
   them (ProductName, SubCategory, Category).
 4 Now start from Production_Product alone, unﬁltered, and join the subcategory with inner and with left: 295 against
   504. Why does the Germany ﬁlter belong on the sales side only?
  In KNIME
  Each lookup is one Joiner: your table on top, the lookup below. Left = matching + left unmatched rows; inner = only matching.
  Rename in the Joiner’s sufﬁx setting or with Column Rename. Step 4: Product reader on top, Subcategory below, two Joiners, an
  Extract Table Dimension after each.
⃝ Extra:   ﬁnd the 209 products that drop out. What do they have in common — a data-quality problem, or a business fact?
Exercise 3 — Pivot Round-Trip stop B · ▶ 10 min
 1 On your Exercise 2 result, build a pivot: rows CustomerID, columns Category, values sum(LineTotal):
       piv = t.pivot_table(index="CustomerID", columns="Category", values="LineTotal", aggfunc="sum")

 2 This is wide format: 32 × 4 = 128 cells, 29 of them NaN. What does a NaN mean here — is it a missing value?
 3 Melt it back (piv.reset_index().melt(id_vars="CustomerID")): 128 rows; without the NaNs 99. Where did the other
   29 come from?
  In KNIME
  Pivot (group CustomerID, pivot Category, Sum of LineTotal); back with Unpivot, the four category columns as value columns, the
  retained list empty — the customer comes back in RowIDs. Run it once without and once with Skip rows containing missing cells.
⃝ Extra: do step 1 in Calc or Excel on Data/awc_pivot_play.csv from the unit zip, then try to melt it there. Why is melt
missing from a spreadsheet’s pivot dialog?




Unit 01 · Data Science · exercise sheet                                                                                            1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit01_Exercises_en.pdf#page=2)

<a id="ds-u01-ex-t04"></a>

**DS-U01-EX-T04 — Your Flat Table**

~~~~text
Exercise 4 — Your Flat Table stop B · ▶ 10 min, ﬁnish after the unit
 1 Run the join chain from the slides without the Germany ﬁlter, starting at Sales_SalesOrderDetail. After every join:
   121,317 rows. If a number changes, ﬁnd the join that did it.
 2 Keep these 25 columns, under these names — the later units’ scripts look for them:
    Detail: SalesOrderID, SalesOrderDetailID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount, LineTotal; Header:
    OrderDate, ShipDate (date only), OnlineOrderFlag, CustomerID, TerritoryID, SalesPersonID, SubTotal, TaxAmt, Freight,
    TotalDue; Product: ProductName, StandardCost, ListPrice; SubCategory; Category; Territory: TerritoryName,
    CountryRegionCode, TerritoryGroup.
    Four tables have a column Name; it becomes ProductName, SubCategory, Category, TerritoryName.
 3 Save it as AWC/awc_flat.csv — every later unit starts from it. Unit 02’s Scripts/awc_extract.py writes the same ﬁle in
   one go.
  In KNIME
  The six Joiners of the slide, then Column Filter to the 25 columns, Column Rename for the four Name columns, CSV Writer →
  AWC/awc_flat.csv.



What to have ready
Show it and talk it through — in the room or in your weekly slot:
• the row counts and what each proved: 1,903 (Ex 1), 1,903 = 1,903 (Ex 2, inner vs left), 295 vs 504 (Ex 2, catalogue)
• the two sums, and which one is the revenue
• the pivot’s 29 NaN, and what they are
• your awc_flat.csv: 121,317 rows, and the row count after each join




Unit 01 · Data Science · exercise sheet                                                                                       2
~~~~
