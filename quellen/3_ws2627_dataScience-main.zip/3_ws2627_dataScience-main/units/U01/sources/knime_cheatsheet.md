---
source_id: DS-U01-R-KNIME-CHEATSHEET
original_file: "Scripts/knime_cheatsheet.pdf"
source_type: reference
language: en
page_count: 1
source_sha256: eaf4a7a701ef75152c9043da6c74384e095a790ad05a50dd32a4596f160d87f7
verification: partial
---

# knime_cheatsheet

> Automatische Layout-Textfassung; Seitenbilder sind als visuelle Referenz beigefügt. Tabellen, Code, Formeln und Diagrammsemantik sind noch nicht vollständig manuell normalisiert oder geprüft.

## Page 001

![Originalseite 1](assets/DS-U01-R-KNIME-CHEATSHEET/p001.png)

~~~~text
  KNIME — U01 cheat sheet                                                                                     which nodes, and what bites


The KNIME counterpart to awc_full_join.py and join_chain.sql. Nodes and pitfalls only — the wiring, the keys and
the join types are the exercise.

The nodes you need
  database         reshape      check            in/out

   MySQL Connector           one is enough                                     Row Filter                     keep some rows
   DB Table Selector         pick a table                                      Pivot / Unpivot                long ↔ wide
   DB Reader                 the boundary                                      GroupBy                        aggregate in KNIME
   DB Query Reader           your own SQL, rows back                           Extract Table Dim.             the row count
   DB SQL Executor           SQL that returns nothing                          Statistics                     per-column stats too
   Joiner                    join two tables                                   CSV Writer                     write the ﬂat table

Connection: localhost · 3306 · Adventureworks2019

Six things that cost time


 Join type = three checkboxes                                         1      Unpivot: scroll down!                                           4
 Matching rows only = inner. Add left unmatched = left. Which                The value and retained lists are below the fold. Default ̸= what
 one? → the Restrict or Enrich? slide.                                       you want. This one eats afternoons.
 Four tables have a Name column                                       2      The group column becomes a row key                              5
 Default handling gives you Name (Right) (Right). Set a suf-                 After Pivot it is gone as a column; it returns from Unpivot as
 ﬁx per Joiner — or Column Rename after.                                     RowIDs — a key, not a number.

 Pivot adds a totals column                                           3      DB SQL Executor: one statement                                  6
 Columns come out as Accessories+Sum(...). Feed the totals                   No START TRANSACTION; ...ROLLBACK;. And comment out
 column into Unpivot and your row count is silently too high.                every line — a wrapped – becomes live SQL.




  . Nothing warns you
  • The Joiner does not ﬂag lost rows. Neither does pd.merge. Put a row count after every join — it is the only way
  to see multiplication or loss.
  • Never ﬁlter the long table on “all columns not missing”. Each row carries the whole group’s proﬁle, so that is a
  group-level test on row-level data. Use Unpivot’s own skip rows with missing cells.


The one idea worth carrying
Everything left of DB Reader runs in the database. In KNIME that border is a wire you can see — in Python it is invisible.



    in the database                                                                                                               in KNIME
       MySQL Connector       DB Table Selector            DB Reader                Joiner           GroupBy               CSV Writer




                                                                 rows cross here




             Every exercise states the number you must reach. If you miss it, that number is the bug report.
~~~~
