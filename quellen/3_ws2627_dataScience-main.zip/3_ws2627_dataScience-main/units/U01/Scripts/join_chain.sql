-- ─────────────────────────────────────────────────────────────────────────────
-- U01 — the four-table join chain from the slides, in SQL.
--
--   Sales_Customer ⋈ Sales_SalesOrderHeader ⋈ Sales_SalesOrderDetail ⋈ Production_Product
--
--   mysql -u sqladmin -p Adventureworks2019 < join_chain.sql
--
-- Everything below is one lesson: the FROM table sets the grain, and the grain
-- decides which columns you are allowed to SUM.
-- ─────────────────────────────────────────────────────────────────────────────

-- ── 1. The chain itself: one row per ORDER LINE ──────────────────────────────
-- FROM starts at Detail, the many side. Starting at Sales_Customer returns the
-- identical rows, but starting here says out loud what one row of the result is.
SELECT c.CustomerID, c.AccountNumber,
       h.SalesOrderID, DATE(h.OrderDate) AS OrderDate,
       p.Name AS ProductName,
       d.OrderQty, d.UnitPrice, d.UnitPriceDiscount, d.LineTotal
FROM Sales_SalesOrderDetail d
JOIN Sales_SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
JOIN Sales_Customer         c ON c.CustomerID   = h.CustomerID
JOIN Production_Product     p ON p.ProductID    = d.ProductID
WHERE c.CustomerID = 29825          -- Better Bike Shop
ORDER BY h.SalesOrderID, d.SalesOrderDetailID;
-- 359 rows across 12 orders. Drop the WHERE and it is 121,317 rows — the row
-- count of Sales_SalesOrderDetail, unchanged by three joins.

-- ── 2. The trap, made visible ────────────────────────────────────────────────
-- Two SUMs over the same 359 rows. One is revenue, the other is nonsense.
SELECT ROUND(SUM(d.LineTotal), 2) AS LineTotal_correct,   --    422,706.60
       ROUND(SUM(h.SubTotal),  2) AS SubTotal_wrong       -- 12,970,351.60
FROM Sales_SalesOrderDetail d
JOIN Sales_SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
JOIN Sales_Customer         c ON c.CustomerID   = h.CustomerID
JOIN Production_Product     p ON p.ProductID    = d.ProductID
WHERE c.CustomerID = 29825;
-- SubTotal is a HEADER measure. After the 1:n join it appears once per line, so
-- summing it multiplies by the SubTotal-weighted average number of lines per
-- order — 30.7x here (the plain mean is 359 / 12 = 29.9).

-- ── 3. Aggregating at the right grain ────────────────────────────────────────
-- GROUP BY down to header grain: now LineSum and SubTotal must agree, and they
-- do, to the cent. That agreement is a free consistency check on the join.
SELECT h.SalesOrderID, DATE(h.OrderDate) AS OrderDate,
       COUNT(*) AS OrderLines, SUM(d.OrderQty) AS Units,
       ROUND(SUM(d.LineTotal), 2) AS LineSum, h.SubTotal
FROM Sales_SalesOrderDetail d
JOIN Sales_SalesOrderHeader h ON h.SalesOrderID = d.SalesOrderID
JOIN Sales_Customer         c ON c.CustomerID   = h.CustomerID
JOIN Production_Product     p ON p.ProductID    = d.ProductID
WHERE c.CustomerID = 29825
GROUP BY h.SalesOrderID, h.OrderDate, h.SubTotal
ORDER BY h.SalesOrderID;
-- Order 43659: 12 lines, 26 units, LineSum 20565.62 = SubTotal 20565.6206.

-- ── 4. Referential integrity, the SQL way ────────────────────────────────────
-- The LEFT JOIN + IS NULL idiom: rows on the left with no partner on the right.
SELECT COUNT(*) AS orphan_lines
FROM Sales_SalesOrderDetail d
LEFT JOIN Production_Product p ON p.ProductID = d.ProductID
WHERE p.ProductID IS NULL;                                  -- 0

-- One level up it is not 0 — the same query shape, a different grain:
SELECT COUNT(*) AS products_without_subcategory
FROM Production_Product p
LEFT JOIN Production_ProductSubcategory sc
       ON sc.ProductSubcategoryID = p.ProductSubcategoryID
WHERE sc.ProductSubcategoryID IS NULL;                      -- 209 of 504

-- ── 5. Naming the customer needs a FIFTH table ───────────────────────────────
-- Sales_Customer is (CustomerID, PersonID, StoreID, TerritoryID, AccountNumber).
-- There is no name in it. Resellers are named in Sales_Store, online buyers in
-- Person_Person, and a customer account may point at either.
SELECT c.CustomerID, c.AccountNumber, s.Name AS StoreName,
       CONCAT(pe.FirstName, ' ', pe.LastName) AS PersonName
FROM Sales_Customer c
LEFT JOIN Sales_Store  s  ON s.BusinessEntityID  = c.StoreID
LEFT JOIN Person_Person pe ON pe.BusinessEntityID = c.PersonID
WHERE c.CustomerID = 29825;
-- 29825 -> Better Bike Shop, contact James Hendergart (the U03 order 43659).
