"""U01 -- the full join chain from the slide "Python: The Full Join Chain".

Seven tables, six LEFT joins, one row per order line: prints 121,317 rows. It only
prints the shape. Your AWC/awc_flat.csv keeps 25 of these columns under the names the
exercise sheet, Exercise 4, lists (Name -> ProductName, Name_sc -> SubCategory,
Name_cat -> Category, Name_t -> TerritoryName). Your group's slice extract is a
different file: M1_sheet.pdf, Task 1.
"""
import os
import sys
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine

# The password comes from the environment, never from this file.
pw = os.environ.get("AWC_DB_PW")
if not pw:
    sys.exit("AWC_DB_PW is not set. First run:  export AWC_DB_PW='...'")
engine = create_engine(
  f"mysql+mysqlconnector://sqladmin:{quote_plus(pw)}@localhost/Adventureworks2019")

header  = pd.read_sql("SELECT * FROM Sales_SalesOrderHeader", engine)
detail  = pd.read_sql("SELECT * FROM Sales_SalesOrderDetail", engine)
product = pd.read_sql("SELECT * FROM Production_Product", engine)
subcat  = pd.read_sql("SELECT * FROM Production_ProductSubcategory", engine)
cat     = pd.read_sql("SELECT * FROM Production_ProductCategory", engine)
cust    = pd.read_sql("SELECT * FROM Sales_Customer", engine)
terr    = pd.read_sql("SELECT * FROM Sales_SalesTerritory", engine)

# how='left': these joins are lookups, and a lookup must not drop order lines.
flat = (detail
  .merge(header,  on='SalesOrderID',         how='left', suffixes=('','_h'))
  .merge(product, on='ProductID',            how='left', suffixes=('','_p'))
  .merge(subcat,  on='ProductSubcategoryID', how='left', suffixes=('','_sc'))
  .merge(cat,     on='ProductCategoryID',    how='left', suffixes=('','_cat'))
  .merge(cust,    on='CustomerID',           how='left', suffixes=('','_c'))
  .merge(terr,    on='TerritoryID',          how='left', suffixes=('','_t')))

print(f"Flat table: {flat.shape[0]} rows, {flat.shape[1]} columns")
