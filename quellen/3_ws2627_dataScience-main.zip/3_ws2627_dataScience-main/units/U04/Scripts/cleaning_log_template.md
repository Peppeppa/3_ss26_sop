# Cleaning Log — AWC  *(template; the core of Milestone 1)*

One row per decision. A decision with no **Alternative** and no **Risk** is not a
decision, it is a reflex — and it will be marked as one.

**Mechanism** — what happens to the record: `annotate` (original kept, a status column
beside it) · `quarantine` (row moved to a reject table, not deleted) · `correct at source`
(the owning system changes) · `fix in the layer` (the reading step or a view rewrites on
read) · `escalate` (nothing changes; the problem gets a name and an owner).

**Effect on target** — what the decision does to the one number your slice is meant to
answer (`M1_sheet.pdf`, Task 2). The worked rows use **total revenue of real AWC** as the target. Most
say *none*, and that is the lesson: annotating changes no number. Where the number would
move is usually the **rejected alternative** (row 7) — which is why the decision that moves
your target furthest gets both of its alternatives carried out in M1.

**Status**: `applied` · `deferred` · `rejected` · `unresolved`.
**`unresolved` is a valid and respectable status.** Undocumented is not.

**Class** — as in the deck (Kemper, Baars & Mehanna 2010): syntactic or semantic, and
1st (detected and corrected automatically), 2nd (detected automatically, corrected by
hand) or 3rd (detected and corrected by hand).

The rows below are worked examples from the course data. *The export* = the third-party
AWC export in `Data/` (3,806 reseller orders); *real AWC* = `AWC/awc_flat.csv` (31,465
orders). Your own log is about **your** slice.

| # | Column / scope | Problem (observed, with a number) | Class | Action | Mechanism | Alternative rejected | Why this one | Risk it creates | Effect on target | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | export: `employees.ManagerID`, `.Territory`, `.Country`, `.Group` | The **text** `NULL` in 3 of 17 rows (17.6 %), 12 cells. KNIME's CSV Reader counts **0 missing**; pandas' defaults count 3 — the file does not say which is meant. | semantic, 1st | Declare `NULL` as missing when reading (pandas: `na_values=['NULL']`, `keep_default_na=False`) | fix in the layer | Leave the text and filter on `!= 'NULL'` everywhere downstream | One declaration at reading serves every consumer; a sentinel that only some code knows about is a trap | A genuine value spelled `NULL` would be lost — none exists here (checked) | — (not on the revenue path) | applied |
| 2 | export: `employees.ManagerID` (same 3 rows) | The three are the regional sales managers (`OrganizationLevel = 2`). Missing because they are the top — or because their manager was not exported? The export cannot tell. **The source can:** `HumanResources_Employee` has id 273, *Vice President of Sales*, level 1; the export starts at 274. A **selection artefact**. | semantic, 3rd | Keep empty; add `is_export_root`, record that the real parent is 273 | annotate | Invent a synthetic "VP of Sales" row | The person exists, just not in this file; the empty cell is the honest representation | "Management depth" is one level too low; `Territory` on the same rows is genuinely *not applicable* — a different verdict on the same row | — (not on the revenue path) | applied |
| 3 | export: `orders.OrderDate` | Reseller orders fall on only **40 dates**, days {1, 28–31}. In the database the same orders fall on days 27–31 (the export is one day later — U05). Monthly batches, not daily orders. | — (real behaviour, not a defect) | None on the batching; document it | annotate | "Spread" the orders across the month | Invented within-month variation would produce exactly the signal a weekday analysis looks for | No weekday analysis **for resellers**; online orders (1,124 dates) support it | None: the same orders, the same revenue | applied |
| 4 | export: `orders.OrderDate` | Text in the form `M/D/YYYY`. As text, `1/1/2012` sorts **before** `5/31/2011`. | syntactic, 1st | Parse to a date when reading | fix in the layer | Sort the text and hope | A mis-ordered time series breaks every trend and every time-based split | None | None on the total; trends now run in the right order | applied |
| 5 | export: `vendorproduct.ProductID` | **182 of 265** products missing from `products.csv`; **357 of 460** vendor–product pairs (78 %) have no product. | semantic, 2nd | Keep them, flag them; no inner join | quarantine | Inner join (drops 357 pairs without a warning) | The orphans are evidence about the *export*, not about the business | Any "vendors per product" figure rests on 103 pairs for 83 products | — (not on the revenue path) | applied |
| 6 | export: `products.SubCategoryID` | 295 products, **0 missing**. The database has **504 products, 209 without a subcategory** (all internal parts, `FinishedGoodsFlag` 0): 504 − 209 = 295. | semantic, 3rd | Take products from the database; name the filter (`WHERE ProductSubcategoryID IS NOT NULL`) | correct at source | Assume the catalogue is complete | 0 missing here is not cleanliness, it is somebody's filter | Order lines are unaffected (the 209 are never sold); product counts from the export were 41 % too low | None: the 209 are never sold | applied |
| 7 | real AWC: order value (`TotalDue`) | Pooled: **2,127 of 31,465 orders (6.8 %)** above the IQR fence, holding **70.9 %** of revenue — all reseller orders. Per channel: **0** of 27,659 online, 137 of 3,806 reseller. | semantic, 2nd | Keep all; fence within each channel | annotate (`outlier_in_channel`) | Drop everything above the pooled fence (6,444, below the reseller median 9,282) | It would delete 70.9 % of the revenue — the reseller business | Means stay dominated by resellers; report medians beside them | None: all kept. The rejected drop would remove **70.9 %** of revenue | applied |
| 8 | real AWC: `LineTotal` | At **line** grain 10,737 of 121,317 lines (8.9 %) are above the fence, holding 49.8 % — vs 6.8 % / 70.9 % at order grain. | — (a question of grain) | State the grain in every outlier claim | — | Pick whichever grain gives the nicer number | "Outlier" belongs to the question, not to the number | None | None: a statement, not a change | applied |
| 9 | export: `customers.FullName` | Same surname + same first initial: **14 groups** (12 pairs, 2 of three) among 635 customers, e.g. `Mary` / `Michelle Alexander`. | semantic, 2nd | **No merge.** Different first names, different customer IDs | annotate (`name_group`) | Fuzzy-match and merge above a similarity threshold | A wrong merge makes a customer disappear without an error message | Real typo duplicates, if any, remain | None | rejected |
| 10 | subcategories | Export (resellers): Tires and Tubes is the **rarest** (163 lines, rank 33 of 33). Real AWC: **second most frequent** (17,495 lines). Forks: 200 lines in both. | semantic, 2nd | Keep separate for reporting; group into `Other` only for a model | fix in the layer | Merge rare categories everywhere | Rarity depends on the population; a report and a model want different things | A model on grouped data says nothing about Forks | None on the total | applied |
| 11 | export: `customers.csv`, `employees.csv` | Not valid UTF-8; the non-ASCII bytes (`François`, `Jésus`, `José`, `Mart¡nez`) decode consistently as **cp1252**. | syntactic, 2nd | Read as cp1252, declared in the metadata | fix in the layer | Replace undecodable bytes silently (`errors="replace"`) | A declared encoding is a decision; a replaced byte is a hidden defect | cp1252 is a guess checked on four names only | None | applied |
| 12 | export and database: `Mart¡nez` | The inverted `¡` is in the **database itself** (`Person_Person`), not an encoding error — probably `Martínez`, but the source says `¡`. | semantic, 3rd | Leave the value; report it to the data owner | escalate | "Correct" it to `Martínez` ourselves | The true spelling is the owner's to decide, not ours | Name searches for `Martínez` miss this customer | None | unresolved |
| 13 | real AWC: `Status` | All 31,465 orders have status 5 (*shipped*); the codes 4 (*rejected*) and 6 (*cancelled*) never occur. | semantic, 3rd | None possible; state it in every revenue claim | annotate (in `known_issues`) | Treat the data as all orders ever placed | Cancelled orders are not in AWC at all — this **cannot be found out here** | "Revenue" means shipped revenue; cancellation rates are unknowable | Unknown, and unknowable here: the revenue is shipped revenue only | unresolved |

> **Note on statuses.** Rows 2 and 6 were unanswerable while we had only the export; the database
> resolved both — *we could not find out* is about our access and ends with the next login.
> Rows 12 and 13 stay `unresolved` for other reasons: 12 is not ours to decide, and 13 **cannot be
> found out here** — AWC keeps no cancelled orders. Say which kind yours is.
>
> Row 2 is the clearest case. "Not applicable" and "selection artefact" both fit the export
> perfectly, and no amount of profiling separates them; one query against the source does. If your
> own log has a row like that, say which of the two it is and how you know.

## Defect classes

After Kemper, Baars & Mehanna (2010), *Business Intelligence*, ETL step "filtering".

| Class | detected | corrected | syntactic (examples above) | semantic (examples above) |
|---|---|---|---|---|
| **1st** | automatically | automatically | #4 dates as text | #1 the text `NULL` |
| **2nd** | automatically | by hand | #11 file not UTF-8 | #5 orphans, #7 outliers, #9 name groups, #10 rare categories |
| **3rd** | by hand | by hand | — | #2 why `ManagerID` is missing, #6 the filtered products, #12 `Mart¡nez`, #13 no cancelled orders |

Syntactic defects can always be detected automatically — syntax is machine-checkable — so
**3rd class is semantic only**, and it is where the findings that change your conclusions live.

## What profiling did *not* find

`SubTotal + TaxAmt + Freight == TotalDue` and `sum(LineTotal) == SubTotal` hold for every
order — the 3,806 of the export and all 31,465 of real AWC — exactly, to the cent. There are
no exact duplicate rows in any table of the export.

**Clean arithmetic is not clean data.** Every finding above survived a dataset whose sums add
up perfectly.

And one finding survived the *profiler itself*: the first version of `awc_profile.py` decoded
with `errors="replace"`, which silently replaced the non-UTF-8 bytes with U+FFFD and reported
nothing. **A profiler whose own tolerance hides a defect is worse than no profiler.** It now
names the encoding problem and says out loud that its fallback is a guess. Row 11 exists
because of that fix.
