"""
Unit 04 — a profiling report that documents and does not repair.

Runs on the AWC CSV export in ../Data (the subset shipped with the graph bundle).
Deliberately written with the standard library only, so it runs anywhere and so
that nothing is hidden inside a library's guesses. That is the point of profiling:
you want to SEE the guesses, not inherit them.

Verified findings on the shipped data (reproduce with: python3 awc_profile.py):

  employees.csv   ManagerID / Group / Territory contain the STRING 'NULL' (3 rows).
                  pandas .isna() reports 0% missing for these columns.
  orders.csv      60,919 rows but only 3,806 orders and only 40 distinct OrderDates,
                  all on days {1, 28, 29, 30, 31} of the month.
  vendorproduct   182 of 265 ProductIDs (69%) do not exist in products.csv.
  products.csv    295 rows, 0 missing SubCategoryID -> products without a
                  subcategory were dropped from the export.
  plausibility    SubTotal + TaxAmt + Freight == TotalDue for all 3,806 orders,
                  and sum(LineTotal) == SubTotal for all 3,806. Exactly.
  encoding        customers.csv and employees.csv are NOT valid UTF-8. Their
                  non-ASCII bytes (Francois 0xe7, Jesus/Jose 0xe9, Mart?nez 0xa1)
                  decode consistently as cp1252 -- and the database itself spells
                  the last one 'Mart\u00a1nez' (an inverted !), so that is a value in
                  the source, not a second encoding.
"""
import csv
import io
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "Data"

# Values that mean "absent" but are not absent. Extend this list per dataset;
# there is no universal set, which is exactly why it must be a decision you record.
SENTINELS = {"NULL", "null", "N/A", "NA", "n/a", "-", "?", "none", "None", "", "unknown"}
NUMERIC = re.compile(r"^-?\d+(\.\d+)?$")


def check_encoding(path: Path, raw: bytes) -> str:
    """Report undecodable bytes instead of papering over them.

    The first version of this profiler decoded with errors="replace" and so
    SILENTLY MASKED a real defect: customers.csv and employees.csv are not UTF-8.
    A profiler whose own tolerance hides a finding is worse than no profiler, so
    it now names the encoding problem and picks a fallback out loud.
    """
    non_ascii = sum(1 for b in raw if b >= 0x80)
    try:
        raw.decode("utf-8-sig")
        return "utf-8-sig"
    except UnicodeDecodeError as exc:
        print(f"  ! {path.name}: NOT valid UTF-8 "
              f"({non_ascii} non-ASCII byte(s); first failure at offset {exc.start})")
        for encoding in ("cp1252", "latin-1"):
            try:
                raw.decode(encoding)
                print(f"    falling back to {encoding} -- RECORD THIS, it is a guess")
                return encoding
            except UnicodeDecodeError:
                continue
        return "latin-1"


def read_csv_any_lineending(path: Path) -> list[dict]:
    """orders.csv uses bare CR. Normalise, and say so, rather than silently coping."""
    raw = path.read_bytes()
    if b"\n" not in raw:
        print(f"  ! {path.name}: CR-only line endings "
              f"({raw.count(bytes([13])):,} CR, {raw.count(bytes([10])):,} LF)")
        raw = raw.replace(b"\r", b"\n")
    encoding = check_encoding(path, raw)
    return list(csv.DictReader(io.StringIO(raw.decode(encoding))))


def quantile(values, p):
    v = sorted(values)
    k = (len(v) - 1) * p
    f = int(k)
    return v[f] if f + 1 >= len(v) else v[f] + (v[f + 1] - v[f]) * (k - f)


def profile_column(name, values, n_rows):
    """One row of a profiling table. Flags, never fixes."""
    blank = sum(1 for v in values if v.strip() == "")
    sentinel = sum(1 for v in values if v.strip() in SENTINELS and v.strip() != "")
    present = [v for v in values if v.strip() != "" and v.strip() not in SENTINELS]
    whitespace = sum(1 for v in present if v != v.strip())
    numeric = sum(1 for v in present if NUMERIC.match(v.strip()))

    kind = "num" if present and numeric == len(present) else \
           "mixed" if 0 < numeric < len(present) else "str"

    flags = []
    if blank:
        flags.append(f"BLANK {blank / n_rows:.1%}")
    if sentinel:
        # The important one: this is missing data that no null-check will find.
        flags.append(f"SENTINEL {sentinel} ({sentinel / n_rows:.1%})")
    if whitespace:
        flags.append(f"UNTRIMMED {whitespace}")
    if kind == "mixed":
        flags.append(f"MIXED {numeric}/{len(present)} numeric")
    if len(set(present)) == n_rows and n_rows > 1:
        flags.append("candidate key")

    row = {"column": name, "kind": kind, "distinct": len(set(present)),
           "missing_total": blank + sentinel, "flags": flags}
    if kind == "num" and present:
        nums = [float(v) for v in present]
        row.update(min=min(nums), max=max(nums), median=statistics.median(nums))
    else:
        common = Counter(present).most_common(1)
        row["most_frequent"] = common[0] if common else None
    return row


def profile_file(path: Path):
    rows = read_csv_any_lineending(path)
    if not rows:
        return
    cols = [c for c in rows[0] if c is not None]
    print(f"\n{'=' * 78}\n{path.name}  —  {len(rows):,} rows x {len(cols)} columns")
    for c in cols:
        r = profile_column(c, [row.get(c) or "" for row in rows], len(rows))
        extra = (f"min={r['min']:,.2f} max={r['max']:,.2f}" if "min" in r
                 else f"top={r['most_frequent'][0]!r}x{r['most_frequent'][1]}" if r.get("most_frequent")
                 else "")
        print(f"   {r['column']:<22}{r['kind']:<6}distinct={r['distinct']:<7}{extra:<34}"
              f"{'  '.join(r['flags'])}")
    return rows


# ── Checks that a per-column table cannot express ───────────────────────────

def check_grain(orders):
    """A row is not an order. Getting the grain wrong invalidates every average."""
    per_order = {r["SalesOrderID"] for r in orders}
    print(f"\n  grain: {len(orders):,} rows describe {len(per_order):,} orders "
          f"({len(orders) / len(per_order):.1f} lines per order)")
    dates = Counter(r["OrderDate"] for r in orders)
    days = sorted({int(d.split("/")[1]) for d in dates})
    print(f"  OrderDate: {len(dates)} distinct values, days-of-month present {days}")
    if set(days) <= {1, 28, 29, 30, 31}:
        print("  ! every order falls on a month boundary: this is BATCHED data.")
        print("    A weekday-effect analysis is IMPOSSIBLE on this export.")


def check_referential_integrity(orders, products, customers, vendorproduct):
    pid = {r["ProductID"] for r in products}
    cid = {r["CustomerID"] for r in customers}
    print("\n  referential integrity (orphans = children with no parent):")
    for label, child, parent in [
        ("orders.ProductID -> products", {r["ProductID"] for r in orders}, pid),
        ("orders.CustomerID -> customers", {r["CustomerID"] for r in orders}, cid),
        ("vendorproduct.ProductID -> products", {r["ProductID"] for r in vendorproduct}, pid),
    ]:
        orphans = child - parent
        pct = f" ({len(orphans) / len(child):.0%})" if child else ""
        print(f"    {label:<38} {len(orphans):>4} orphan(s){pct}")


def check_plausibility(orders):
    """2nd-class deficiency detection: arithmetic that must hold, checked."""
    seen, header_bad = {}, 0
    lines = defaultdict(float)
    for r in orders:
        oid = r["SalesOrderID"]
        lines[oid] += float(r["LineTotal"])
        if oid not in seen:
            seen[oid] = float(r["SubTotal"])
            s, t, f, d = (float(r[k]) for k in ("SubTotal", "TaxAmt", "Freight", "TotalDue"))
            if abs(s + t + f - d) > 0.01:
                header_bad += 1
    line_bad = sum(1 for oid, total in lines.items() if abs(total - seen[oid]) > 0.01)
    print(f"\n  plausibility over {len(seen):,} orders:")
    print(f"    SubTotal + TaxAmt + Freight == TotalDue : {header_bad} violation(s)")
    print(f"    sum(LineTotal) == SubTotal              : {line_bad} violation(s)")
    if not header_bad and not line_bad:
        print("    -> the arithmetic is exact. Clean arithmetic is NOT clean data:")
        print("       the sentinels, the batching and the orphans are all still there.")


def check_outliers(orders):
    """Same measure, two grains, two verdicts."""
    print("\n  IQR outliers (fence = Q3 + 1.5 x IQR):")
    per_order = {r["SalesOrderID"]: float(r["TotalDue"]) for r in orders}
    for label, values in [("TotalDue, per ORDER", list(per_order.values())),
                          ("LineTotal, per LINE", [float(r["LineTotal"]) for r in orders])]:
        q1, q3 = quantile(values, .25), quantile(values, .75)
        fence = q3 + 1.5 * (q3 - q1)
        out = [v for v in values if v > fence]
        print(f"    {label:<22} n={len(values):>7,}  median={statistics.median(values):>10,.2f}  "
              f"mean={statistics.mean(values):>10,.2f}  fence={fence:>10,.2f}  "
              f"outliers={len(out):>5,} ({len(out) / len(values):.1%})  "
              f"holding {sum(out) / sum(values):.1%} of the total")
    print("    -> the SAME data gives 3.6% or 10.9% outliers depending on the grain.")
    print("       'Outlier' is not a property of a number; it is a property of a question.")


def check_fuzzy_duplicates(customers):
    """The dangerous direction of fuzzy matching: false positives."""
    norm = lambda s: re.sub(r"[^a-z]", "", s.lower())
    groups = defaultdict(set)
    for r in customers:
        groups[(norm(r["LastName"]), norm(r["FirstName"])[:1])].add(r["FullName"])
    near = {k: v for k, v in groups.items() if len(v) > 1}
    print(f"\n  fuzzy duplicate CANDIDATES (same surname + same first initial): "
          f"{len(near)} groups, {sum(len(v) for v in near.values())} customers")
    for names in list(near.values())[:5]:
        print(f"    {sorted(names)}")
    print("    -> different first names, different IDs: nothing suggests one person.")
    print("       A looser rule catches more real duplicates and merges more different")
    print("       people -- and a wrong merge makes a customer silently disappear.")


def check_rare_categories(orders, products, subcategories):
    sname = {r["SubCategoryID"]: r["SubCategoryName"] for r in subcategories}
    psub = {r["ProductID"]: r["SubCategoryID"] for r in products}
    counts = Counter(sname.get(psub.get(r["ProductID"], ""), "?") for r in orders)
    rare = [(k, v) for k, v in counts.items() if v / len(orders) < 0.005]
    print(f"\n  subcategories: {len(counts)} of {len(subcategories)} ever sold; "
          f"{len(rare)} below 0.5% of order lines")
    print(f"    rarest: {sorted(rare, key=lambda x: x[1])[:4]}")
    print(f"    never sold at all: {len(subcategories) - len(counts)}")


if __name__ == "__main__":
    print("PROFILING THE AWC EXPORT — documenting only, repairing nothing")
    tables = {}
    for name in ["customers", "employees", "orders", "products",
                 "productcategories", "productsubcategories", "vendorproduct", "vendors"]:
        path = DATA / f"{name}.csv"
        if path.exists():
            tables[name] = profile_file(path)

    print(f"\n{'=' * 78}\nCROSS-COLUMN AND CROSS-TABLE CHECKS")
    if "orders" in tables:
        check_grain(tables["orders"])
        check_plausibility(tables["orders"])
        check_outliers(tables["orders"])
        if {"products", "customers", "vendorproduct"} <= tables.keys():
            check_referential_integrity(tables["orders"], tables["products"],
                                        tables["customers"], tables["vendorproduct"])
        if "productsubcategories" in tables:
            check_rare_categories(tables["orders"], tables["products"],
                                  tables["productsubcategories"])
    if "customers" in tables:
        check_fuzzy_duplicates(tables["customers"])

    print(f"\n{'=' * 78}")
    print("NOTHING ABOVE HAS BEEN REPAIRED. Repair decisions go in the cleaning")
    print("log (Scripts/cleaning_log_template.md) with a reason and a rejected")
    print("alternative for each one.")
