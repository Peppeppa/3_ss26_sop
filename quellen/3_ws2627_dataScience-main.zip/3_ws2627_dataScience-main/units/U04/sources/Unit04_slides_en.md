---
source_id: DS-U04-L-EN
original_file: Unit04_slides_en.pdf
source_type: lecture
language: en
page_count: 42
source_sha256: 9b33bfec5421a1315ef2812835904e9ee8f62efa5862b60d1f30c827f8fb2add
verification: partial
---
# Unit04_slides_en

[Original PDF](../../../quellen/Unit04_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit04_slides_en.pdf#page=1)

~~~~text
Data Science
DATA QUALITY: PROFILING,
THEN CLEANING WITH
REASONS
Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit04_slides_en.pdf#page=2)

~~~~text
LEARNING GOALS
• Profile a dataset: type, missing values, distinct values and grain of every column, then
checks across tables
• Tell MCAR, MAR, MNAR and not applicable apart — and find missing values that no
count of empty cells shows
• Name the selection and survivorship bias in a concrete export
• Find outliers with the IQR rule and judge them against the business
• Classify a defect: syntactic or semantic, and 1st/2nd/3rd class by how it is found and
fixed
• Write a cleaning log in which every decision names its action, its rejected alternative
and its effect
2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit04_slides_en.pdf#page=3)

~~~~text
THE QUESTION OF THIS UNIT
Your extract runs without an error message.
Can you trust the numbers it gives — and if not, what do you do?
Profile Missing Outliers Decide
the export — Data/*.csv
third-party, 8 tables, only the 3,806 reseller
orders: the file under suspicion
real AWC — AWC/awc_flat.csv
your extract from U02, all 31,465 orders:
what your own data look like
Every slide names which of the two it uses. Each step answers one part of the question:
look at every column, find what is missing, judge what is unusual, then decide and write it
down.
3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit04_slides_en.pdf#page=4)

~~~~text
WHY THIS MATTERS AT WORK
Analysts profile a table
before every analysis.
Data engineers write checks
into the pipeline.
A data owner (data steward)
decides fixes in the source
system.
Profiling: KNIME
Data Explorer, pandas
describe(), SQL GROUP BY.
Checks on every load: row
counts against the source,
key checks, database
constraints.
EU AI Act, Art. 10, for
high-risk AI: training,
validation and test data
are examined for “possible
biases” and “data gaps”, and
should be “free of errors
and complete” as far as
possible.
Who does it With what Who demands it
Clean is relative to a use
Quality is fitness for use (Wang & Strong 1996): the export fits reseller revenue per month,
not online customers. So name the use as one target number — the number your analysis
reports, e.g. the median helmet price. Every decision is judged by its effect on it.
Sources: Regulation (EU) 2024/1689, Art. 10(2)(f), (h) and 10(3).
4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit04_slides_en.pdf#page=5)

~~~~text
STEP 1: LOOK AT EVERY COLUMN — PROFILING
Profile Missing Outliers Decide
5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit04_slides_en.pdf#page=6)

~~~~text
PROFILING ASKS SIX QUESTIONS — AND FIXES NOTHING
A checklist, so you also find the defects you did not expect. Find what is wrong, change
nothing: a defect fixed before it is understood can no longer be seen. Every repair comes
in step 4.
Dimension The question example: the export
á Completeness is all data the use needs present? ? 3 of 17 employees: no territory
£ Uniqueness does each thing appear only once? ? 14 groups of similar names
D Validity expected format, type and range? ✗ OrderDate is text
¤ Consistency do values agree within a record and
across data sets?
✓ sums add up, all 3,806 orders
◎ Accuracy does the data reflect reality? ✗ dates one day after the
database
/ Timeliness available when expected and needed? ✗ real AWC: last order June 2014
✓ passes ✗ defect ? suspect, decided later in this unit. The six dimensions of DAMA UK (Data Management
Association), as published by the UK Government Data Quality Hub (2021). A profiling report measures most of
them per column; accuracy needs a second source.
6 Profile Missing Outliers Decide
~~~~

## Page 007

[Original page 7](../../../quellen/Unit04_slides_en.pdf#page=7)

~~~~text
WHAT A PROFILING REPORT CONTAINS
One row per column of the file — here 4 of the 12 columns of employees.csv (the export):
column type empty cells distinct range / top value flag
EmployeeID number 0 17 274–290 unique
JobTitle text 0 4 Sales Representative ×14 —
ManagerID number + text 0 3 274–287 NULL in 3 rows
Territory text 0 10 Northwest ×3 NULL in 3 rows
Scripts/awc_profile.py; KNIME Data Explorer gives the same table, pandas describe(include="all") most
of it. number + text: numbers and the text NULL in one column; distinct and top value leave NULL out. Grain (U01):
a column unique in every row says what one row is — here one employee.
0 empty cells — and still 3 values missing
A sentinel is a stand-in value that means “missing” but is not empty: NULL, N/A, -1,
1900-01-01. Here the text NULL sits in the same three rows of four columns.
7 Profile Missing Outliers Decide
~~~~

## Page 008

[Original page 8](../../../quellen/Unit04_slides_en.pdf#page=8)

~~~~text
A DATE STORED AS TEXT SORTS WRONGLY — SILENTLY
The export writes OrderDate as text, month/day/year. The same four dates, sorted twice:
sorted as text 1/1/2012 1/28/2014 5/31/2011 7/1/2011
sorted as dates 5/31/2011 7/1/2011 1/1/2012 1/28/2014
“the first order”
No error message anywhere: a date filter keeps the wrong rows, and “the latest orders” are not the
latest. U03 showed that a reader guesses types; this is what a wrong guess does.
Check the type of every column before you sort, filter or sum
Same shape: numbers as text, units in the value ("3.5 kg"), yes/no as Y/1/true. KNIME: String to
Date&Time; pandas: pd.to_datetime(..., format="%m/%d/%Y").
8 Profile Missing Outliers Decide
~~~~

### DS-U04-L-EN-P008-D01 — Rekonstruktion

Text order: 1/1/2012 → 1/28/2014 → 5/31/2011 → 7/1/2011. Date order: 5/31/2011 → 7/1/2011 → 1/1/2012 → 1/28/2014. Crossing lines connect identical dates.

## Page 009

[Original page 9](../../../quellen/Unit04_slides_en.pdf#page=9)

~~~~text
DUPLICATES: HOW LOOSE MAY THE RULE BE?
strict rule loose rule
×2
M. Alexander M. Alexander
Muller! ? Mueller!
identical row
the export: 0
in all 8 tables
same surname,
same first initial
the export: 14 groups,
30 of 635 customers
sounds alike
Soundex: Muller,
Mueller — and
Miller: all M460
Too strict → a missed duplicate: one
customer is counted twice.
Too loose → a wrong merge: a
customer disappears, with no error
message.
The 14 groups, e.g. Mary / Michelle Alexander, Marjorie / Mark / Michael Lee: different first names
and IDs — none looks like one person. Soundex codes a name by its sound (MySQL SOUNDEX()); a
language model (LLM) can propose pairs too. Both only propose; a person decides.
9 Profile Missing Outliers Decide
~~~~

## Page 010

[Original page 10](../../../quellen/Unit04_slides_en.pdf#page=10)

~~~~text
FIVE CHECKS PASS — TWO FAIL
The export, checked across tables (Scripts/awc_profile.py):
Check rule Result
✓ every order item points to an existing product ¤ 0 orphans
✓ every order item points to an existing customer ¤ 0 orphans
✓ per order: SubTotal+TaxAmt+Freight=TotalDue 
 0 violations
✓ the item totals add up to SubTotal 
 0 violations
✓ exact duplicate rows, all 8 tables ¤ 0
✗ every vendor–product pair has its product ¤ 357 of 460 pairs
✗ every file reads as UTF-8 (U03) q customers, employees: cp1252
Orphan: a row whose key the other table does not have. products.csv holds 295 of the database’s
504 products; an inner join would drop 357 pairs (78 %) without a warning. Not UTF-8: a UTF-8 reader
fails or garbles names (François). Rule: ¤ keys (U02), 
 business rule, q file format; a profile can
suggest more (value ranges).
A check finds only what it was written to look for
Five green rows — and the text NULL and the text dates pass all five.
10 Profile Missing Outliers Decide
~~~~

## Page 011

[Original page 11](../../../quellen/Unit04_slides_en.pdf#page=11)

~~~~text
RARE CATEGORIES: NOISE OR NICHE?
Why it matters: few rows give shaky shares and averages and clutter every chart — so rare
categories are often merged or dropped. But rare where?
the export (resellers) real AWC (all orders)
subcategory items rank items rank
Road Bikes 12,876 1 20,944 1
Tires and Tubes 163 33 of 33 17,495 2
Fenders 0 — 2,121 13
Forks 200 32 200 35
Lights, Panniers (in the catalogue, never sold) 0 — 0 —
Tires and Tubes is the rarest in the export and the second most frequent in real AWC: online
customers buy it, resellers hardly do. “Rare” describes the rows you have, not the business.
Merge the rare ones into Other? It depends on who uses the table
An overview chart: probably yes — 200 items of Forks are a sliver next to 20,944 Road Bikes. A
report: no — Forks is a real product line with an owner. Either way: log the decision (step 4).
11 Profile Missing Outliers Decide
~~~~

## Page 012

[Original page 12](../../../quellen/Unit04_slides_en.pdf#page=12)

~~~~text
Break
10 minutes
Then: Missing Values
~~~~

## Page 013

[Original page 13](../../../quellen/Unit04_slides_en.pdf#page=13)

~~~~text
STEP 2: WHAT IS MISSING — CELLS, ROWS,
GROUPS
Profile Missing Outliers Decide
13
~~~~

## Page 014

[Original page 14](../../../quellen/Unit04_slides_en.pdf#page=14)

~~~~text
IS NULL MISSING? THE READER DECIDES
employees.csv
ManagerID = NULL
in 3 rows
KNIME CSV Reader, defaults
pandas read_csv, defaults
+ encoding="cp1252"
pandas, as above
+ keep_default_na=False
0 missing, text
3 missing, number
0 missing, text
Without the encoding, pandas stops: the file is not UTF-8 (step 1). KNIME counts only empty cells as
missing; pandas also a fixed list of words (NULL, NA, N/A, ... ). Right here, but by a guess: in AWC, NA is
the country code of Namibia.
Same file, 3 missing or 0
Decide what counts as missing, once, at reading time — and write the decision into the report. A
count of missing values means nothing without it.
14 Profile Missing Outliers Decide
~~~~

## Page 015

[Original page 15](../../../quellen/Unit04_slides_en.pdf#page=15)

~~~~text
WHY A VALUE IS MISSING DECIDES WHAT YOU MAY DO
a value
is missing:
why?
pure chance — a questionnaire page
is lost in the mail
something you did record — older
customers leave the phone field
empty; age is recorded
the missing value itself — high earn￾ers skip the income question
the question does not apply — real
AWC: an online order has no sales￾person
MCAR
MAR
MNAR
not
applicable
drop the rows: no bias, just
fewer rows
fill within each group (age
group)
not from the data alone —
say so
leave it empty: filling invents
a value
missing because of ... what you may do
Missing Completely At Random · Missing At Random · Missing Not At Random — Little & Rubin (2019);
textbook examples in italics. Not applicable is the fourth case.
Fill the MNAR income with the average, and the data hold fewer rich people than the population they
describe — no tool warns you.
15 Profile Missing Outliers Decide
~~~~

## Page 016

[Original page 16](../../../quellen/Unit04_slides_en.pdf#page=16)

~~~~text
DRAW THE SOURCE BEHIND THE EXPORT, THEN ASK IT
All twelve NULL cells sit with the same three people, at the edge of the export. MCAR would scatter
them.
? above them
274 Jiang
North America
285 Abbas
Pacific
287 Alberts
Europe
10 sales reps
275–284
1 sales rep
286
3 sales reps
288–290
employees.csv: 17 rows
ManagerID, Territory, Country, Group = NULL both filled
Where the columns come from
EmployeeID, JobTitle
← HumanResources_Employee
ManagerID ← the parent in
OrganizationNode: a path in the
org chart, /6/1/ sits below /6/
Territory, Country, Group ←
TerritoryID in Sales_SalesPerson
Two questions only the source can answer
Is TerritoryID empty there too, or lost by the export? Is anyone in the ? box: the top, or a manager
left out? Next: one query each.
16 Profile Missing Outliers Decide
~~~~

## Page 017

[Original page 17](../../../quellen/Unit04_slides_en.pdf#page=17)

~~~~text
LIVE: LET THE SOURCE ANSWER
MySQL Workbench, Adventureworks2019. Does the database have the three gaps?
1 SELECT COUNT(*) AS n_rows, COUNT(TerritoryID) AS non_null,
2 SUM(TerritoryID IS NULL) AS real_nulls
3 FROM Sales_SalesPerson; -- 17 14 3
Yes: three real NULLs in TerritoryID — not applicable, as expected. Now: is anyone above the three
managers?
1 SELECT BusinessEntityID AS id, JobTitle, OrganizationNode
2 FROM HumanResources_Employee
3 WHERE OrganizationNode = '/6/'; -- id 273: Vice President of Sales
OrganizationNode is the path in the org chart: the three managers are /6/1/, /6/2/, /6/3/, directly
below /6/. 273 exists; the export starts at 274. The missing ManagerID was made by the export, not
by the business.
Avoid it, not just fix it
A text file has no NULL type: the export must say how it writes one. A hierarchy is exported with its
top.
17 Profile Missing Outliers Decide
~~~~

## Page 018

[Original page 18](../../../quellen/Unit04_slides_en.pdf#page=18)

~~~~text
NOT APPLICABLE IS NOT MISSING
0 20,000 40,000 60,000 80,000 100,000 120,000
reseller only
online only
all items
60,398
60,398
60,919
60,919
order items
SalesPersonID filled SalesPersonID = NULL
Real AWC, awc_flat.csv. The NULLs are not scattered: they are exactly the online orders. An online
order has no salesperson — the cell is not missing, the question does not apply.
Split a gap by another column before you call it “missing”
50 % missing in SalesPersonID sounds alarming. Split by OnlineOrderFlag, it is 0 % where it
applies. Filling it in would invent a salesperson. Finding the column: the missing share per value of
every other column (numbers cut into quartiles); 0 % next to 100 % marks a rule.
18 Profile Missing Outliers Decide
~~~~

## Page 019

[Original page 19](../../../quellen/Unit04_slides_en.pdf#page=19)

~~~~text
HANDS ON — EXERCISES 1 AND 2
20 minutes
Sheet on Moodle: Unit04_Exercises_en.pdf
Work at your machine — I am in the room. We go through it right after.
19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit04_slides_en.pdf#page=20)

~~~~text
Break
10 minutes
Then: Missing Rows, Missing Groups
~~~~

## Page 021

[Original page 21](../../../quellen/Unit04_slides_en.pdf#page=21)

~~~~text
LIVE: MISSING ROWS — NAME THE FILTER
A profile counts gaps only in the rows that arrived: products.csv shows 0 % missing.
the database 295 with subcategory 209 without
the export 295 not in the file
Ask the source, in Workbench: which rows are the 209?
1 SELECT FinishedGoodsFlag, COUNT(*), SUM(ProductSubcategoryID IS NULL) AS no_sub
2 FROM Production_Product GROUP BY FinishedGoodsFlag; -- rows: (0, 209, 209), (1, 295, 0)
Two filters give exactly the 295: ProductSubcategoryID IS NOT NULL, or FinishedGoodsFlag = 1
(salable only). Selection bias: rows chosen by a rule the file does not tell you; it also made the 357
orphan pairs of step 1.
0 % missing where gaps belong is a red flag
Which filter was it? Only the query behind the extract can say: never accept an extract without it, and
compare row counts with the source on every delivery.
21 Profile Missing Outliers Decide
~~~~

## Page 022

[Original page 22](../../../quellen/Unit04_slides_en.pdf#page=22)

~~~~text
WHO IS MISSING ENTIRELY?
visited the shop
not recorded
put in a cart
3 rows in the
cart table
ordered
31,465 orders,
19,119 customers
shipped
all 31,465 orders
rejected, cancelled
not one order
selection bias: who
looked and did not buy?
survivorship bias: only
orders that made it
Real AWC, column Status (5 shipped, 4 rejected, 6 cancelled); your extract inherits both gaps.
Closed: why do people not buy? how often are orders cancelled? Time has gaps too: reseller orders
carry only month-end dates.
A profile hints at bias — only a reference shows it
A missing group leaves no rows, only traces: a Status with one value, 0 % missing where gaps
belong. Check who could be there and is not against the source, the catalogue or the population.
22 Profile Missing Outliers Decide
~~~~

## Page 023

[Original page 23](../../../quellen/Unit04_slides_en.pdf#page=23)

~~~~text
STEP 3: WHAT IS UNUSUAL — OUTLIERS
Profile Missing Outliers Decide
23
~~~~

## Page 024

[Original page 24](../../../quellen/Unit04_slides_en.pdf#page=24)

~~~~text
THE 1.5 × IQR RULE, BY HAND: TWELVE NUMBERS
Why: an outlier rule needs a ruler that the outliers themselves cannot stretch. Real AWC, the 12 items
of order 43659, in Workbench:
1 SELECT LineTotal FROM Sales_SalesOrderDetail WHERE SalesOrderID = 43659 ORDER BY LineTotal;
lower 6 values 10.37 28.84 34.20 80.75 86.52 2,024.99
upper 6 values 2,024.99 2,039.99 2,039.99 2,039.99 4,079.99 6,074.98
→ Q1 = 57.48
→ Q3 = 2,039.99
Q1
, Q3 = the median of each half: (34.20 + 80.75)/2 and (2,039.99 + 2,039.99)/2
IQR (interquartile range) Q3 − Q1 = 2,039.99 − 57.48 = 1,982.51 — the middle half of the values
upper fence Q3 + 1.5 × IQR = 2,039.99 + 2,973.77 = 5,013.76 → 6,074.98 is
above: 1 outlier
lower fence Q1 − 1.5 × IQR = 57.48 − 2,973.77 < 0 → none
pandas and KNIME interpolate between neighbours: Q1 = 69.11, fence 4,996.32 — other numbers, the same
single outlier. Twelve numbers to learn the steps; this fence holds for this one order only.
24 Profile Missing Outliers Decide
~~~~

## Page 025

[Original page 25](../../../quellen/Unit04_slides_en.pdf#page=25)

~~~~text
THE SAME RULE ON ALL 31,465 ORDERS
0 2,000 4,000 6,000 8,000
order value TotalDue, real AWC, one row per order
→ 187,488
Q1 median Q3
IQR = 2,553
fence = Q3 + 1.5 × IQR = 6,444
Quartiles: 25 % of the values lie below Q1, 75 % below Q3. Lower fence below 0, so no low outliers.
Tools compute quartiles slightly differently — name yours. More: statistics primer.
Workbench: number the sorted rows (ROW_NUMBER() OVER (ORDER BY TotalDue)), take rows 0.25 n
and 0.75 n. pandas: s.quantile([.25, .75]); KNIME: Numeric Outliers. Beyond IQR:
Boukerche et al. (2020).
Why not the z-score (> 3 standard deviations from the mean)?
Outliers raise the mean and the standard deviation, so they widen the ruler that measures them: the
z-score flags 857 orders, the IQR rule 2,127.
25 Profile Missing Outliers Decide
~~~~

## Page 026

[Original page 26](../../../quellen/Unit04_slides_en.pdf#page=26)

~~~~text
SAME DATA, TWO GRAINS, TWO ANSWERS
Real AWC, awc_flat.csv per order (TotalDue) per item (LineTotal)
rows 31,465 121,317
upper fence 6,444 2,764
outliers 2,127 (6.8 %) 10,737 (8.9 %)
their share of the revenue 70.9 % 49.8 %
Order 43659 (23,153) is an outlier as an order; as items, only 2 of its 12 items are above the item
fence. Say the grain with every outlier count.
KNIME: GroupBy on SalesOrderID, then Numeric Outliers; pandas: quantile([.25, .75]).
6.8 % of the orders hold 70.9 % of the revenue
Before you delete “a few outliers”, compute what share of the total they carry.
26 Profile Missing Outliers Decide
~~~~

## Page 027

[Original page 27](../../../quellen/Unit04_slides_en.pdf#page=27)

~~~~text
THE FENCE FLAGS A WHOLE POPULATION
0
2,000
4,000
6,000 online: 27,659 orders — own fence 5,950: 0 above
orders
pooled fence 6,444
100
101
102
103
104
105
0
100
200
300
400
reseller: 3,806 orders own fence
93,528
order value, TotalDue (log scale)
orders
Real AWC, one row per order. All 2,127 pooled “outliers” are reseller orders — 56 % of all reseller
orders. With a fence per channel: 0 online, 137 reseller orders (3.6 %).
The rule worked correctly
It found a second population, not errors. The problem is the pooled data, not the rule.
27 Profile Missing Outliers Decide
~~~~

## Page 028

[Original page 28](../../../quellen/Unit04_slides_en.pdf#page=28)

~~~~text
LIVE: ONE COLUMN EXPLAINS IT
Before deciding about 2,127 “outliers”: one query in Workbench.
1 SELECT OnlineOrderFlag, COUNT(*) AS orders,
2 ROUND(AVG(TotalDue)) AS avg_due, ROUND(MAX(TotalDue)) AS max_due
3 FROM Sales_SalesOrderHeader GROUP BY OnlineOrderFlag;
1 OnlineOrderFlag orders avg_due max_due
2 0 3806 23851 187488 <- resellers
3 1 27659 1173 3954 <- online
The online maximum (3,954) is below the reseller average (23,851): two populations, named by one
column. KNIME: GroupBy on OnlineOrderFlag.
Avoid it, not just fix it
Look at the distribution before any outlier rule: two humps mean two populations. Then put the
fence within each group. No guarantee: a mixture can also hide in a combination of columns (U07).
28 Profile Missing Outliers Decide
~~~~

## Page 029

[Original page 29](../../../quellen/Unit04_slides_en.pdf#page=29)

~~~~text
ERROR OR REAL?
Impossible — an error Extreme — possibly real
quantity ≤ 0, price 0.00 on a bicycle real AWC: one reseller order of 187,488
shipped before it was ordered one customer who dominates a territory
a discount of 100 % or more zero sales in a product’s first month
decided by a rule you can write down — real AWC:
0 such items
decided by someone who knows the business
A statistical outlier is a question, not a verdict: the rule says where to look.
Flag, do not drop
Report the median beside the mean (real AWC per order: 865 and 3,916). Run the analysis with and
without the flagged rows, and report both if they disagree. A deleted row cannot argue back.
29 Profile Missing Outliers Decide
~~~~

## Page 030

[Original page 30](../../../quellen/Unit04_slides_en.pdf#page=30)

~~~~text
HANDS ON — EXERCISES 3 AND 4
20 minutes
Sheet on Moodle: Unit04_Exercises_en.pdf
Outliers or bias — the room splits; both end in a decision you write down.
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit04_slides_en.pdf#page=31)

~~~~text
Break
10 minutes
Then: Decide and Write It Down
~~~~

## Page 032

[Original page 32](../../../quellen/Unit04_slides_en.pdf#page=32)

~~~~text
STEP 4: DECIDE — AND WRITE IT DOWN
Profile Missing Outliers Decide
32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit04_slides_en.pdf#page=33)

~~~~text
DEFECT CLASSES: WHO HAS TO ACT?
OrderDate is text (5/31/2011)
a parser converts every row by one
rule
the text NULL in ManagerID
means “no value”: declared once at
reading
the file is not UTF-8
the reader stops by itself; a person
picks cp1252
357 vendor–product pairs, no
product
a key check finds them; a person
decides
none: a machine can always check
form
the export starts at employee 274
no check fires; a person sees it and
asks
syntactic defects
(form: format, type, encoding)
semantic defects
(content: values, meaning)
1st class
detected: automatically
corrected: automatically
2nd class
detected: automatically
corrected: by hand
3rd class
detected: by hand
corrected: by hand
Why classify? The class says who has to act: your code (1st), a person once (2nd), someone who
knows the business (3rd). Findings that change a conclusion are semantic, 3rd class.
Classes after Kemper, Baars & Mehanna (2010), Business Intelligence, ETL step “filtering”.
33 Profile Missing Outliers Decide
~~~~

## Page 034

[Original page 34](../../../quellen/Unit04_slides_en.pdf#page=34)

~~~~text
CORRECTING IS NOT OVERWRITING
a problem
you found
annotate: a flag column beside the value
flag the 2,127 pooled outliers, keep them all
quarantine: rows move to a reject table
the 357 vendor–product pairs without their product
fix when reading: the file stays as delivered
declare NULL as missing; parse the text dates
ask the owner: nothing changes yet
who decided the export starts at employee 274?
the original value survives in all four
UPDATE and DELETE are rarely yours to run
Other tables reference the row, and someone will later ask what it said. A destructive fix also
destroys the evidence that it was needed. Your extract must stay reconstructible.
34 Profile Missing Outliers Decide
~~~~

## Page 035

[Original page 35](../../../quellen/Unit04_slides_en.pdf#page=35)

~~~~text
KEEP EVERY VERSION: DATA, CODE, MODEL
Why: correcting without overwriting needs every earlier version to stay findable; a number or a model
can be rebuilt only from its exact data.
what changes tool how it keeps versions
/ code, scripts, workflows Git; KNIME Hub every change is a commit you can compare (diff) and go
back to; KNIME Hub numbers workflow versions
q data files (CSV, ... ) DVC the file goes to a storage; Git keeps a small pointer file
with its hash (U02) — so a commit names the exact data
 large shared tables Delta Lake, Iceberg “time travel”: query the table as it was at an earlier version
 experiments, models MLflow logs per run: parameters, metrics, input data; a model
registry numbers the model versions
For M1 and M2 you need none of these tools — three habits are enough
1. Never change the delivered file: your script reads it and writes a new file.
2. The metadata (U03) say which script made the new file, when, and who ran it.
3. Every change is one row of the cleaning log (next slide).
35 Profile Missing Outliers Decide
~~~~

## Page 036

[Original page 36](../../../quellen/Unit04_slides_en.pdf#page=36)

~~~~text
THE CLEANING LOG: ONE DECISION, WRITTEN DOWN
target number mean order value, all orders: 3,916 (raw extract, chosen before cleaning)
problem TotalDue: 2,127 of 31,465 orders (6.8 %) above the pooled fence, 70.9 % of
revenue
action annotate: column outlier_in_channel, fence per channel (137 reseller, 0
online)
rejected alternative drop every order above the pooled fence
why the pooled fence flags a population, not errors
effect on target mean stays 3,916, 0 rows removed (pooled drop: 1,221)
status applied (or deferred, rejected, unresolved)
Target number: the one number your analysis reports (M1, task 2). Rejected alternative and effect
turn a list of things you did into decisions a reader can disagree with. Worked rows:
Scripts/cleaning_log_template.md.
“Unresolved” is a valid status — say which kind
“We could not find out” ends with better access (the managers’ manager: open with the export,
solved with the database). “It cannot be found out” is permanent: cancelled orders — AWC keeps
none.
36 Profile Missing Outliers Decide
~~~~

## Page 037

[Original page 37](../../../quellen/Unit04_slides_en.pdf#page=37)

~~~~text
CAN WE IGNORE IT? RANDOM NOISE YES, BIAS NO
Real AWC: draw n orders, compute the mean order value — 100 times per row. Blue: random orders.
Orange: online orders only, a filter like the export’s.
0 2,000 4,000 6,000 8,000
n = 10,000
n = 1,000
n = 100
true mean, all orders: 3,916
mean order value of one sample (TotalDue)
More rows narrow the blue cloud onto 3,916 (noise shrinks). The orange cloud is tight from the start,
on 1,173: more rows only make the wrong answer look surer (Meng 2018).
Every defect today was systematic — ignoring one is still a decision
Often fine: random noise in a value you only average. Not fine: sentinel, filter, wrong grain, mixed
populations. Ignored? Log it as deferred.
Noise added on purpose protects people in published numbers: differential privacy (Dwork & Roth 2014; IT
security modules).
37 Profile Missing Outliers Decide
~~~~

## Page 038

[Original page 38](../../../quellen/Unit04_slides_en.pdf#page=38)

~~~~text
MILESTONE 1
Data Quality
20 % of the module · one archive M1_G<nn>.zip
Due date: see the course overview in Moodle
One upload, four parts (the task: M1_sheet.pdf):
1. your own observation, the question it raises, one target
number
2. the metadata you built in U03
3. the profiling report from today
4. the cleaning log (≥4 decisions) and the decision that
matters most
Graded on: is the diagnosis complete, are the decisions defensible?
— not on how clean the data ended up.
~~~~

## Page 039

[Original page 39](../../../quellen/Unit04_slides_en.pdf#page=39)

~~~~text
KEY MESSAGES
• Profile: look at every column before you touch one — type, gaps, distinct
values, grain; a check finds only what it was written to look for
• Missing: what counts as missing is decided when reading; why a value is
missing decides whether you may fill it — and whole rows and groups can be
missing without a trace
• Outliers: the IQR rule says where to look, not what is wrong; on mixed
populations it flags a population — here 70.9 % of the revenue
• Decide: annotate, quarantine, fix when reading or ask the owner — never
overwrite; every decision names its rejected alternative and its effect
• Next: U05 — Beyond Tables: Time Series & Graphs
39 Profile Missing Outliers Decide
~~~~

## Page 040

[Original page 40](../../../quellen/Unit04_slides_en.pdf#page=40)

~~~~text
SOURCES & FURTHER READING (1/3)
• Kemper, Baars & Mehanna (2010), Business Intelligence — Grundlagen und praktische
Anwendungen, 3rd ed., Vieweg+Teubner — the defect classes (ETL step “filtering”)
doi.org/10.1007/978-3-8348-9727-5
• Government Data Quality Hub (2021), Meet the data quality dimensions — the six DAMA UK
dimensions
gov.uk/government/news/meet-the-data-quality-dimensions
• Rahm & Do (2000), Data Cleaning: Problems and Current Approaches, IEEE Data Eng. Bull.
23(4):3–13 — the standard problem taxonomy
sites.computer.org/debull/A00dec/issue1.htm
• Kim et al. (2003), A Taxonomy of Dirty Data, Data Min. Knowl. Discov. 7(1):81–99 — in detail
doi.org/10.1023/A:1021564703268
• Tukey (1977), Exploratory Data Analysis, Addison-Wesley — where the 1.5×IQR fence comes from
• Boukerche et al. (2020), Outlier Detection: Methods, Models, and Classification — beyond IQR
ACM Computing Surveys 53(3):55, doi.org/10.1145/3381028
40
~~~~

## Page 041

[Original page 41](../../../quellen/Unit04_slides_en.pdf#page=41)

~~~~text
SOURCES & FURTHER READING (2/3)
• Wang & Strong (1996), Beyond Accuracy: What Data Quality Means to Data Consumers, J. Manag.
Inf. Syst. 12(4):5–33 — quality as fitness for use, the reason “clean enough” needs a purpose
doi.org/10.1080/07421222.1996.11518099
• Meng (2018), Statistical paradises and paradoxes in big data (I), Ann. Appl. Stat. 12(2):685–726 —
why large n does not cancel bias
doi.org/10.1214/18-AOAS1161SF
• Regulation (EU) 2024/1689 (AI Act), Art. 10 Data and data governance — what high-risk AI must
check in its data
eur-lex.europa.eu/eli/reg/2024/1689/oj
• Dwork & Roth (2014), The Algorithmic Foundations of Differential Privacy, Found. Trends Theor.
Comput. Sci. 9(3–4) — noise added on purpose
doi.org/10.1561/0400000042
• Sculley et al. (2015), Hidden Technical Debt in Machine Learning Systems, Advances in Neural
Information Processing Systems 28, 2503–2511 — why the “one-off” table you did not clean
becomes somebody’s source
proceedings.neurips.cc/paper/2015 (Sculley et al.)
41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit04_slides_en.pdf#page=42)

~~~~text
SOURCES & FURTHER READING (3/3)
• Breunig, Kriegel, Ng & Sander (2000), LOF: Identifying Density-Based Local Outliers, SIGMOD —
outliers relative to their neighbours, not to one fence
doi.org/10.1145/342009.335388
• Little & Rubin (2019), Statistical Analysis with Missing Data, 3rd ed., Wiley — MCAR/MAR/MNAR
doi.org/10.1002/9781119482260
• DVC, MLflow, Delta Lake, Apache Iceberg documentation — versions of data, models and tables
dvc.org/doc · mlflow.org/docs · docs.delta.io · iceberg.apache.org/docs
• pandas documentation — automate the per-column table, never the judgement
pandas.pydata.org/docs (DataFrame.describe)
• KNIME Analytics Platform user guide — the Data Explorer node does the same job in a workflow
docs.knime.com/latest/analytics_platform_user_guide
42
~~~~
