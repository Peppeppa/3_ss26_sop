---
source_id: DS-U04-R-CLEANING-LOG-TEMPLATE
original_file: "Scripts/cleaning_log_template.pdf"
source_type: reference
language: en
page_count: 5
source_sha256: 1a39538a72b05b658fe0e1e204221316048e5385bbd7690b5289d5b6d54aa90b
verification: partial
---

# cleaning_log_template

> Automatische Layout-Textfassung; Seitenbilder sind als visuelle Referenz beigefügt. Tabellen, Code, Formeln und Diagrammsemantik sind noch nicht vollständig manuell normalisiert oder geprüft.

## Page 001

![Originalseite 1](assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p001.png)

~~~~text
                       Cleaning Log — AWC (template; the core of Milestone 1)
                                              VL_4_DS/Scripts/cleaning_log_template.md




                                                             2026-10-09 19:04


Cleaning Log — AWC (template; the core of Milestone 1)
One row per decision. A decision with no Alternative and no Risk is not a decision, it is a reflex — and it will be marked as one.
Mechanism — what happens to the record: annotate (original kept, a status column beside it) · quarantine (row moved to a reject table, not
deleted) · correct at source (the owning system changes) · fix in the layer (the reading step or a view rewrites on read) · escalate (nothing
changes; the problem gets a name and an owner).
Effect on target — what the decision does to the one number your slice is meant to answer (M1_sheet.pdf, Task 2). The worked rows use total
revenue of real AWC as the target. Most say none, and that is the lesson: annotating changes no number. Where the number would move is
usually the rejected alternative (row 7) — which is why the decision that moves your target furthest gets both of its alternatives carried out
in M1.
Status: applied · deferred · rejected · unresolved. unresolved is a valid and respectable status. Undocumented is not.
Class — as in the deck (Kemper, Baars & Mehanna 2010): syntactic or semantic, and 1st (detected and corrected automatically), 2nd (detected
automatically, corrected by hand) or 3rd (detected and corrected by hand).
The rows below are worked examples from the course data. The export = the third-party AWC export in Data/ (3,806 reseller orders); real AWC
= AWC/awc_flat.csv (31,465 orders). Your own log is about your slice.




                                                                       1
~~~~

## Page 002

![Originalseite 2](assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p002.png)

~~~~text
Cleaning Log — AWC (template; the core of Milestone 1)                                                                                        VL_4_DS/Scripts/cleaning_log_template.md




         Column /       Problem (observed, with a                                                Alternative                                                    Effect on
#        scope          number)                         Class        Action            Mechanism rejected             Why this one        Risk it creates       target          Status

1        export: empl   The text NULL in 3 of 17        semantic,    Declare NULL as   fix in the   Leave the         One declaration     A genuine value       — (not on       applied
         oyees.Manag    rows (17.6 %), 12 cells.        1st          missing when      layer        text and filter   at reading          spelled NULL would    the revenue
         erID, .Terri   KNIME's CSV Reader counts                    reading                        on != 'NULL'      serves every        be lost — none        path)
         tory, .Count   0 missing; pandas'                           (pandas: na_va                 everywhere        consumer; a         exists here
         ry, .Group     defaults count 3 — the file                  lues=['NULL'],                 downstream        sentinel that       (checked)
                        does not say which is                        keep_default_n                                   only some code
                        meant.                                       a=False)                                         knows about is
                                                                                                                      a trap
2        export: empl   The three are the regional      semantic,    Keep empty;       annotate     Invent a          The person          ”Management           — (not on       applied
         oyees.Manag    sales managers (Organizati      3rd          add is_export                  synthetic ”VP     exists, just not    depth” is one         the revenue
         erID (same     onLevel = 2). Missing                        _root, record                  of Sales” row     in this file; the   level too low; Terr   path)
         3 rows)        because they are the top —                   that the real                                    empty cell is       itory on the same
                        or because their manager                     parent is 273                                    the honest          rows is genuinely
                        was not exported? The                                                                         representation      not applicable — a
                        export cannot tell. The                                                                                           different verdict
                        source can: HumanResource                                                                                         on the same row
                        s_Employee has id 273, Vice
                        President of Sales, level 1;
                        the export starts at 274. A
                        selection artefact.
3        export: orde   Reseller orders fall on only    — (real      None on the       annotate     ”Spread” the      Invented            No weekday            None: the       applied
         rs.OrderDat    40 dates, days {1, 28–31}.      be-          batching;                      orders across     within-month        analysis for          same orders,
         e              In the database the same        haviour,     document it                    the month         variation would     resellers; online     the same
                        orders fall on days 27–31       not a                                                         produce exactly     orders (1,124         revenue
                        (the export is one day later    defect)                                                       the signal a        dates) support it
                        — U05). Monthly batches,                                                                      weekday
                        not daily orders.                                                                             analysis looks
                                                                                                                      for
4        export: orde   Text in the form M/D/YYYY. As   syntactic,   Parse to a date   fix in the   Sort the text     A mis-ordered       None                  None on the     applied
         rs.OrderDat    text, 1/1/2012 sorts before     1st          when reading      layer        and hope          time series                               total; trends
         e              5/31/2011.                                                                                    breaks every                              now run in
                                                                                                                      trend and every                           the right
                                                                                                                      time-based split                          order
5        export: vend   182 of 265 products             semantic,    Keep them,        quarantine Inner join          The orphans are     Any ”vendors per      — (not on       applied
         orproduct.P    missing from products.csv;      2nd          flag them; no                (drops 357          evidence about      product” figure       the revenue
         roductID       357 of 460                                   inner join                   pairs without       the export, not     rests on 103 pairs    path)
                        vendor–product pairs (78                                                  a warning)          about the           for 83 products
                        %) have no product.                                                                           business




                                                                                         2
~~~~

## Page 003

![Originalseite 3](assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p003.png)

~~~~text
Cleaning Log — AWC (template; the core of Milestone 1)                                                                                         VL_4_DS/Scripts/cleaning_log_template.md




         Column /       Problem (observed, with a                                                 Alternative                                                    Effect on
#        scope          number)                         Class        Action             Mechanism rejected            Why this one         Risk it creates       target         Status

6        export: prod   295 products, 0 missing.        semantic,    Take products      correct      Assume the       0 missing here       Order lines are       None: the      applied
         ucts.SubCat    The database has 504            3rd          from the           at           catalogue is     is not               unaffected (the       209 are
         egoryID        products, 209 without a                      database;          source       complete         cleanliness, it is   209 are never         never sold
                        subcategory (all internal                    name the filter                                  somebody's           sold); product
                        parts, FinishedGoodsFlag 0):                 (WHERE ProductS                                  filter               counts from the
                        504 − 209 = 295.                             ubcategoryID I                                                        export were 41 %
                                                                     S NOT NULL)                                                           too low
7        real AWC:      Pooled: 2,127 of 31,465         semantic,    Keep all; fence    annotate     Drop             It would delete      Means stay            None: all      applied
         order value    orders (6.8 %) above the        2nd          within each        (outlier     everything       70.9 % of the        dominated by          kept. The
         (TotalDue)     IQR fence, holding 70.9 %                    channel            _in_chan     above the        revenue — the        resellers; report     rejected
                        of revenue — all reseller                                       nel)         pooled fence     reseller             medians beside        drop would
                        orders. Per channel: 0 of                                                    (6,444, below    business             them                  remove
                        27,659 online, 137 of 3,806                                                  the reseller                                                70.9 % of
                        reseller.                                                                    median                                                      revenue
                                                                                                     9,282)
8        real AWC: L    At line grain 10,737 of         — (a         State the grain    —            Pick             ”Outlier”            None                  None: a        applied
         ineTotal       121,317 lines (8.9 %) are       question     in every outlier                whichever        belongs to the                             statement,
                        above the fence, holding        of grain)    claim                           grain gives      question, not to                           not a change
                        49.8 % — vs 6.8 % / 70.9 %                                                   the nicer        the number
                        at order grain.                                                              number
9        export: cust   Same surname + same first       semantic,    No merge.          annotate     Fuzzy-match      A wrong merge        Real typo             None           rejected
         omers.FullN    initial: 14 groups (12 pairs,   2nd          Different first    (name_gr     and merge        makes a              duplicates, if any,
         ame            2 of three) among 635                        names,             oup)         above a          customer             remain
                        customers, e.g. Mary / Miche                 different                       similarity       disappear
                        lle Alexander.                               customer IDs                    threshold        without an error
                                                                                                                      message
10       subcategories Export (resellers): Tires and    semantic,    Keep separate      fix in the   Merge rare       Rarity depends       A model on            None on the    applied
                       Tubes is the rarest (163         2nd          for reporting;     layer        categories       on the               grouped data says     total
                       lines, rank 33 of 33). Real                   group into Othe                 everywhere       population; a        nothing about
                       AWC: second most                              r only for a                                     report and a         Forks
                       frequent (17,495 lines).                      model                                            model want
                       Forks: 200 lines in both.                                                                      different things
11       export: cust  Not valid UTF-8; the             syntactic,   Read as            fix in the   Replace          A declared           cp1252 is a guess     None           applied
         omers.csv, e  non-ASCII bytes (François, J     2nd          cp1252,            layer        undecodable      encoding is a        checked on four
         mployees.cs   ésus, José, Mart¡nez) decode                  declared in the                 bytes silently   decision; a          names only
         v             consistently as cp1252.                       metadata                        (errors="repla   replaced byte is
                                                                                                     ce")             a hidden defect




                                                                                            3
~~~~

## Page 004

![Originalseite 4](assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p004.png)

~~~~text
Cleaning Log — AWC (template; the core of Milestone 1)                                                                                           VL_4_DS/Scripts/cleaning_log_template.md




          Column /        Problem (observed, with a                                                 Alternative                                                    Effect on
#         scope           number)                          Class       Action             Mechanism rejected              Why this one       Risk it creates       target          Status

12        export and      The inverted ¡ is in the         semantic,   Leave the          escalate    ”Correct” it to     The true           Name searches         None            unresolved
          database: M     database itself (Person_Pe       3rd         value; report it               Martínez            spelling is the    for Martínez miss
          art¡nez         rson), not an encoding error                 to the data                    ourselves           owner's to         this customer
                          — probably Martínez, but                     owner                                              decide, not ours
                          the source says ¡.
13        real AWC: S     All 31,465 orders have           semantic,   None possible;     annotate    Treat the data      Cancelled          ”Revenue” means       Unknown,        unresolved
          tatus           status 5 (shipped); the          3rd         state it in        (in known   as all orders       orders are not     shipped revenue;      and
                          codes 4 (rejected) and 6                     every revenue      _issues)    ever placed         in AWC at all —    cancellation rates    unknowable
                          (cancelled) never occur.                     claim                                              this cannot be     are unknowable        here: the
                                                                                                                          found out                                revenue is
                                                                                                                          here                                     shipped
                                                                                                                                                                   revenue only


    Note on statuses. Rows 2 and 6 were unanswerable while we had only the export; the database resolved both — we could not find out is
    about our access and ends with the next login. Rows 12 and 13 stay unresolved for other reasons: 12 is not ours to decide, and 13 cannot
    be found out here — AWC keeps no cancelled orders. Say which kind yours is.
    Row 2 is the clearest case. ”Not applicable” and ”selection artefact” both fit the export perfectly, and no amount of profiling separates them;
    one query against the source does. If your own log has a row like that, say which of the two it is and how you know.

Defect classes
After Kemper, Baars & Mehanna (2010), Business Intelligence, ETL step ”filtering”.

Class               detected                   corrected                     syntactic (examples above)                 semantic (examples above)

1st                 automatically              automatically                 #4 dates as text                           #1 the text NULL
2nd                 automatically              by hand                       #11 file not UTF-8                         #5 orphans, #7 outliers, #9 name groups, #10 rare categories
3rd                 by hand                    by hand                       —                                          #2 why ManagerID is missing, #6 the filtered products, #12 Mart¡ne
                                                                                                                        z, #13 no cancelled orders




Syntactic defects can always be detected automatically — syntax is machine-checkable — so 3rd class is semantic only, and it is where the
findings that change your conclusions live.


                                                                                            4
~~~~

## Page 005

![Originalseite 5](assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p005.png)

~~~~text
Cleaning Log — AWC (template; the core of Milestone 1)                                                          VL_4_DS/Scripts/cleaning_log_template.md




What profiling did not find
SubTotal + TaxAmt + Freight == TotalDue and sum(LineTotal) == SubTotal hold for every order — the 3,806 of the export and all 31,465 of real AWC
— exactly, to the cent. There are no exact duplicate rows in any table of the export.
Clean arithmetic is not clean data. Every finding above survived a dataset whose sums add up perfectly.
And one finding survived the profiler itself : the first version of awc_profile.py decoded with errors="replace", which silently replaced the non-
UTF-8 bytes with U+FFFD and reported nothing. A profiler whose own tolerance hides a defect is worse than no profiler. It now names
the encoding problem and says out loud that its fallback is a guess. Row 11 exists because of that fix.




                                                                        5
~~~~
