---
source_id: DS-U04-EX
original_file: Unit04_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: 818d868ba449bd8c0b2e2b5adf91d45f7fcf1fbda57de18268a8335580c7deac
verification: partial
---
# Unit04_Exercises_en

[Original PDF](../../../quellen/Unit04_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit04_Exercises_en.pdf#page=1)

<a id="ds-u04-ex-t01"></a>

**DS-U04-EX-T01 — Proﬁle Your Own Flat-Table**

<a id="ds-u04-ex-t02"></a>

**DS-U04-EX-T02 — Classify, Do Not Fix**

<a id="ds-u04-ex-t03"></a>

**DS-U04-EX-T03 — Outliers, and What You Decide About Them**

~~~~text
  Unit 04 — Exercises                                                                       Data Quality: Proﬁle, Then Decide
Diagnose your table. Repair comes later — today you only ﬁnd and classify.
▶ In the room        what ﬁts the stop — all that is expected. The room splits at stop B: take one of the two exercises; you
                     hear the other one in the discussion.
⃝ Extra              voluntary, at home.
Stop A, 20 min       Exercises 1 and 2         Stop B, 20 min: Exercise 3 or 4
Asynchronous         the same sheet, before your weekly slot; bring what did not run.
You need             your ﬂat table AWC/awc_flat.csv, as it is. How to build a proﬁle in SQL, pandas or KNIME: Primer –
                     Proﬁling, in this unit’s folder.

Exercise 1 — Proﬁle Your Own Flat-Table stop A · ▶ 10 min
 1 Proﬁle eight columns you would report on: type, % missing, distinct values, min, max, most frequent value. Kit:
   Scripts/awc_profile.py.
 2 Hunt for sentinels: values that mean “missing” but are not empty — the text NULL or N/A, -1, 0 where zero is impossible,
   1900-01-01. How many does your tool’s missing count miss? Write down how you read the ﬁle ﬁrst: KNIME’s CSV Reader
   counts only empty cells as missing; pandas also turns words like NULL, NA, N/A into missing.
      Example — the two counts for one column

      col = "SalesPersonID"
      print(df[col].isna().sum())                                      # what the tool calls missing
      print(df[col].isin(["NULL", "N/A", -1, 0]).sum())                # the suspects, cell by cell
      The difference is the miss. 0 is a valid result — if you say which values you looked for.
 3 State the grain: what is one row? Prove it with one column that is unique and one that is not.
  In KNIME
  Data Explorer or Statistics for the proﬁle; Rule-based Row Filter for the suspects, then compare with the missing count.

⃝ Extra:   proﬁle every column. Then compute the mean order value per row and per order: how far apart are they?
Exercise 2 — Classify, Do Not Fix stop A · ▶ 10 min
 1 How       many      of   your     lines   have
                                          no SalesPersonID? Split the count by OnlineOrderFlag (pandas:
    pd.crosstab(df.OnlineOrderFlag,    df.SalesPersonID.isna())). Classify the gap in one sentence: MCAR, MAR,
    MNAR or not applicable. Do the same for every other column with gaps. No gaps at all? Then say why SalesPersonID
    is complete in your table.
 2 Find one case where two different explanations ﬁt the same missing value, as with the three sales managers. Which
   evidence would decide — and does your table hold it?
  In KNIME
  Crosstab (or GroupBy) of OnlineOrderFlag against a “is missing” column from Rule Engine.

⃝ Extra: check referential integrity along your join chain: any orphans, and how many rows would an inner join have dropped
without telling you?
Exercise 3 — Outliers, and What You Decide About Them stop B · ▶ 20 min · or Exercise 4
 1 Make one row per SalesOrderID, then apply the IQR rule (fence = Q3 + 1.5 × IQR). How many outliers, and what share
   of revenue do they hold? Then apply it within each value of OnlineOrderFlag, if your table has both. What changes?
      Which order value? TotalDue is the whole order (tax, freight and products outside your table included); the sum of your
      LineTotal per order counts only your table. Either is ﬁne — say which you used and why.

 2 Repeat on order lines, using LineTotal. Put both grains side by side and explain why they differ.
 3 Take your single most extreme order. Error or real? Argue it as a business person would.
  Example — the rule in pandas, for one column

  q1, q3 = s.quantile([.25, .75]); fence = q3 + 1.5 * (q3 - q1)
  out = s > fence; print(out.sum(), s[out].sum() / s.sum())    # count, share of the total

  In KNIME
  GroupBy on SalesOrderID for the order grain, then Numeric Outliers (it shows the fences); Row Splitter or GroupBy for the shares.

⃝ Extra:  compare IQR with z > 3 (scipy.stats.zscore) on the same column: which ﬁnds fewer, and why is that the
direction you should expect? Then judge your top three orders and write down what you did with each.




Unit 04 · Data Science · exercise sheet                                                                                               1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit04_Exercises_en.pdf#page=2)

<a id="ds-u04-ex-t04"></a>

**DS-U04-EX-T04 — Find the Bias**

~~~~text
Exercise 4 — Find the Bias stop B · ▶ 20 min · or Exercise 3
 1 Name two groups that are systematically absent from AWC. For each: why are they absent, and which question does
   that close?
 2 Look at your OrderDate values: count the distinct dates and the days of the month they fall on. Which time questions
    does your source support, and which does it rule out?
⃝ Extra: (a) Find a column with suspiciously few missing values. Should it have gaps — and if yes, where did they go?
(b) Put every ﬁnding of this sheet into its defect class: syntactic or semantic, 1st / 2nd / 3rd class. Which box holds your
most serious problem? (c) If a text column has variants (Bothell / BOTHELL, trailing spaces): trim, unify the case, map the
known variants — and record each value you changed and how many rows it touched (pandas .str.strip().str.title(),
.replace(mapping); KNIME String Manipulation, Cell Replacer).


What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: your eight-column proﬁle, how you read the ﬁle, the sentinels your missing count missed, and the grain with its two
  columns
• Ex 2: SalesPersonID and every other column with gaps, classiﬁed with a reason
• Ex 3: the outlier numbers at both grains, their share of revenue, and what the split by channel changed
• Ex 4: two absent groups and the question each one closes




Unit 04 · Data Science · exercise sheet                                                                                   2
~~~~
