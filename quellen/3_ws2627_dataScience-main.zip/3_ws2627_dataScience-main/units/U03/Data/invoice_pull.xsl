<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:inv="http://example.com/invoice" exclude-result-prefixes="inv">
  <xsl:output method="html" indent="yes"/>
  <xsl:template match="/inv:Invoice">                    <!-- match the root -->
    <h1>Invoice <xsl:value-of select="@invoiceNo"/></h1>  <!-- read an attribute -->
    <p><xsl:value-of select="inv:Customer/inv:Name"/></p>
    <table>
      <xsl:for-each select="inv:Items/inv:Item">          <!-- pull: walk it yourself -->
        <xsl:sort select="inv:LineTotal" data-type="number" order="descending"/>
        <tr><td><xsl:value-of select="inv:ProductName"/></td>
            <td><xsl:value-of select="inv:LineTotal"/></td></tr>
      </xsl:for-each>
    </table>
    <p>Lines: <xsl:value-of select="count(inv:Items/inv:Item)"/>,
       sum: <xsl:value-of select="sum(inv:Items/inv:Item/inv:LineTotal)"/></p>
  </xsl:template>
</xsl:stylesheet>
