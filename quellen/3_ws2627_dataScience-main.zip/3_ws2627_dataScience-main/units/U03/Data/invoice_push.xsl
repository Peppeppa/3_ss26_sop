<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:inv="http://example.com/invoice" exclude-result-prefixes="inv">
  <xsl:output method="html" indent="yes"/>
  <xsl:template match="/inv:Invoice">
    <h1>Invoice <xsl:value-of select="@invoiceNo"/></h1>
    <table><xsl:apply-templates select="inv:Items/inv:Item"/></table>
  </xsl:template>
  <xsl:template match="inv:Item">
    <tr><td><xsl:value-of select="inv:ProductName"/></td></tr>
  </xsl:template>
</xsl:stylesheet>
