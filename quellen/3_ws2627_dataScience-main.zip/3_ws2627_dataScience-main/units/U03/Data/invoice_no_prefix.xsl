<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" indent="yes"/>
  <xsl:template match="/Invoice">
    <h1>Invoice <xsl:value-of select="@invoiceNo"/></h1>
    <table><xsl:apply-templates select="Items/Item"/></table>
  </xsl:template>
  <xsl:template match="Item">
    <tr><td><xsl:value-of select="ProductName"/></td></tr>
  </xsl:template>
</xsl:stylesheet>
