#!/bin/bash
# Unit 03: the validation calls from the slides. Run from anywhere.
cd "$(dirname "$0")" || exit 1
set -x
xmllint --noout --schema invoice.xsd invoice_43659.xml     # valid
xmllint --noout --dtdvalid invoice.dtd invoice_43659.xml   # valid: prints nothing
xmllint --noout --dtdvalid invoice.dtd bad_date.xml        # the DTD accepts it
xmllint --noout --schema invoice.xsd bad_date.xml          # a German-style date
xmllint --noout --schema invoice.xsd bad_money.xml         # five decimals
true    # the two failures above are the point; the script itself succeeded
