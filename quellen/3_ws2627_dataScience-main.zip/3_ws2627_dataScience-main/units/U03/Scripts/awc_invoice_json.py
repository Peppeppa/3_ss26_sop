"""
Unit 03 — the same invoice as JSON: Data/invoice_43659.xml -> Data/invoice_43659.json.

    python3 awc_invoice_json.py            # reads ../Data/invoice_43659.xml

What the conversion has to decide, because JSON has only six types:
  * the attributes invoiceNo / invoiceDate become ordinary keys (JSON has no attributes);
  * the date stays a string --- JSON has no date type;
  * money becomes a JSON number, which every common parser reads as a float:
    "6074.9820" in the XML comes back as 6074.982, the four-decimal money type is gone.
"""
import json
import xml.etree.ElementTree as ET
from pathlib import Path

def _data_dir():
    """Data/ next to Scripts/: one level up, or two when shipped under optional/."""
    here = Path(__file__).resolve().parent
    for d in (here.parent / "Data", here.parent.parent / "Data"):
        if (d / "invoice_43659.xml").exists():
            return d
    raise SystemExit("Data/ not found next to or above this script")


DATA = _data_dir()
NS = {"i": "http://example.com/invoice"}


def convert(xml_path: Path) -> dict:
    inv = ET.parse(xml_path).getroot()
    text = lambda path: inv.find(path, NS).text
    return {
        "invoiceNo": inv.get("invoiceNo"),
        "invoiceDate": inv.get("invoiceDate"),
        "seller": text("i:Seller"),
        "customer": {"name": text("i:Customer/i:Name"), "address": text("i:Customer/i:Address")},
        "items": [{"productName": it.find("i:ProductName", NS).text,
                   "quantity": int(it.find("i:Quantity", NS).text),
                   "unitPrice": float(it.find("i:UnitPrice", NS).text),
                   "lineTotal": float(it.find("i:LineTotal", NS).text)}
                  for it in inv.findall("i:Items/i:Item", NS)],
        **{k[0].lower() + k[1:]: float(text(f"i:{k}"))
           for k in ("SubTotal", "TaxAmt", "Freight", "TotalDue")},
    }


if __name__ == "__main__":
    doc = convert(DATA / "invoice_43659.xml")
    out = DATA / "invoice_43659.json"
    out.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
    print(f"{len(doc['items'])} items -> {out}")
    print("  XML <LineTotal>6074.9820</LineTotal> -> JSON", doc["items"][1]["lineTotal"])
    s = 0.0
    for row in doc["items"]:
        s += row["lineTotal"]
    print(f"  sum of the 12 lineTotal floats: {s!r}  (subTotal {doc['subTotal']!r})")
