"""
Unit 03 — four ways a CSV misleads you, on real files.

Trap 2 is not invented: orders.csv from the third-party AWC export for Neo4j
(AWC/ext_graph/orders.csv; also VL_4_DS/Data/orders.csv) has CR-only line endings:

    wc -l orders.csv                     ->      0     (counts LF)
    tr -cd '\\r' < orders.csv | wc -c    ->  60919
    head -n 3 orders.csv | wc -c         -> 6982415   (the whole file is "line 1")

pandas and the csv module accept bare CR and read all 60,919 order lines; line-based
shell tools do not. products.csv and customers.csv in the same export are CRLF, and
customers.csv is Latin-1, not UTF-8.

    python3 awc_csv_traps.py [path/to/orders.csv]
"""
import io
from pathlib import Path

import pandas as pd


# ── Trap 1: encoding ────────────────────────────────────────────────────────
def trap_encoding():
    """Latin-1 bytes read as UTF-8 raise; UTF-8 read as Latin-1 succeeds WRONGLY."""
    utf8 = "City\nWürzburg\n".encode("utf-8")
    latin1 = "City\nWürzburg\n".encode("latin-1")

    print("  Latin-1 file, pandas default (UTF-8):", end=" ")
    try:
        pd.read_csv(io.BytesIO(latin1))
    except UnicodeDecodeError as e:
        print(f"UnicodeDecodeError, byte {latin1[e.start]:#x}: {e.reason}   <- loud")

    # The dangerous direction: Latin-1 accepts every byte, so it never raises.
    city = pd.read_csv(io.BytesIO(utf8), encoding="latin-1").City[0]
    print(f"  UTF-8 file, encoding='latin-1'     : City = {city!r}   <- silent")

    # A BOM: pandas removes it, Python's own open()/csv module do not.
    bom = "City\nWürzburg\n".encode("utf-8-sig")
    first = io.TextIOWrapper(io.BytesIO(bom), encoding="utf-8").readline().rstrip("\n")
    print(f"  BOM, open(encoding='utf-8')        : first header {first!r}")
    print(f"  BOM, open(encoding='utf-8-sig')    : first header "
          f"{io.TextIOWrapper(io.BytesIO(bom), encoding='utf-8-sig').readline().rstrip()!r}")
    print(f"  BOM, pd.read_csv (default)         : columns {list(pd.read_csv(io.BytesIO(bom)).columns)}")


# ── Trap 3: the delimiter is inside the data ────────────────────────────────
def trap_delimiter():
    csv = 'ProductID,Name,Price\n771,"Mountain-100 Silver, 38",3399.99\n'
    good = pd.read_csv(io.StringIO(csv))
    print(f"  quoted comma, quoting honoured -> {good.shape[1]} columns: {list(good.columns)}")
    print(f"    Name = {good.Name[0]!r}")
    # German CSV exports use ';' as separator and ',' as decimal mark.
    de = "ProductID;Name;Price\n771;Mountain-100;3399,99\n"
    wrong = pd.read_csv(io.StringIO(de))
    right = pd.read_csv(io.StringIO(de), sep=";", decimal=",")
    print(f"  German export, default sep -> {wrong.shape[1]} column(s): everything in one")
    print(f"  German export, sep=';' decimal=',' -> Price dtype {right.Price.dtype}")


# ── Trap 2: line endings (the real orders.csv case) ─────────────────────────
def trap_line_endings(path: Path | None = None):
    if path and path.exists():
        raw = path.read_bytes()
    else:
        raw = b"ProductID,Name\r771,Mountain-100\r772,Mountain-200\r"   # bare CR
    cr, lf = raw.count(b"\r"), raw.count(b"\n")
    print(f"  CR={cr:,}  LF={lf:,}  ->", "bare CR (classic Mac)" if lf == 0 else
          "CRLF" if cr == lf else "mixed")
    if lf == 0:
        lines = raw.split(b"\n")                       # what wc, head and grep see
        rows = len(pd.read_csv(io.BytesIO(raw)))
        print(f"  split on LF (wc/head/grep) -> {len(lines)} line(s)  |  pd.read_csv -> {rows:,} rows")


# ── Trap 4: the parser guesses types from the values it sees ────────────────
# Three real German customers from AWC (Person_Address via AWC/awc_customers.csv).
DE_ROWS = ("CustomerID,City,CountryRegionCode,PostalCode\n"
           "482,Eilenburg,DE,04838\n500,Dresden,DE,01071\n615,Leipzig,DE,04139\n")


def trap_dtypes():
    """The same column is text in one file and a number in the next."""
    for d in [Path.cwd(), *Path.cwd().parents]:
        full = d / "AWC" / "awc_customers.csv"
        if full.exists():
            cust = pd.read_csv(full)
            print(f"  {full}: PostalCode {cust.PostalCode.dtype} (UK/CA codes contain letters)")
            de = cust[cust.CountryRegionCode == "DE"].to_csv(index=False)
            break
    else:
        de = DE_ROWS                      # no customer file around: the three real rows
    guessed = pd.read_csv(io.StringIO(de))
    declared = pd.read_csv(io.StringIO(de), dtype={"PostalCode": "string"})
    lost = (declared.PostalCode.str[0] == "0").sum()
    print(f"  Germany only, guessed : PostalCode {guessed.PostalCode.dtype}, "
          f"{lost} of {len(de.splitlines()) - 1} codes lose their leading zero "
          f"(Leipzig '04139' -> {guessed.PostalCode[declared.PostalCode == '04139'].iloc[0]})")
    print(f"  Germany only, declared: PostalCode {declared.PostalCode.dtype}, '04139' stays "
          f"{declared.PostalCode[declared.PostalCode == '04139'].iloc[0]!r}")


if __name__ == "__main__":
    import sys
    orders = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    for title, fn in [("1. ENCODING", trap_encoding),
                      ("2. LINE ENDINGS", lambda: trap_line_endings(orders)),
                      ("3. DELIMITER & QUOTING", trap_delimiter),
                      ("4. TYPE INFERENCE", trap_dtypes)]:
        print(f"\n=== TRAP {title} ===")
        fn()
    print("\nRule: read defensively. State encoding, sep, decimal, dtype and\n"
          "lineterminator explicitly. A default is a guess you did not make.")
