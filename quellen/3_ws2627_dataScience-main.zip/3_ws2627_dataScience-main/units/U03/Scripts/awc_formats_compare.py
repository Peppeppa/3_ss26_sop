"""
Unit 03 — the same data in six encodings, then the same test at real scale.
Measure, do not guess.

    python3 awc_formats_compare.py          # writes into Scripts/formats/

Part 1: Data/awc_basket.json flattened to 4,029 rows x 4 columns and written as CSV
(also gzipped), JSON (flat and nested), Parquet (snappy, zstd), XML, YAML and HDF5.
Sizes are exact. Every reader ends in the same DataFrame, so the read times compare
like with like; they are best-of-n and differ between machines, the ratios do not.

Part 2: the group's own AWC/awc_flat.csv (found in this folder or above it) as CSV
vs Parquet: size, read time, one column vs all, and which column types survive the
round trip (dates come back from CSV as text).

What to argue about (slides "All Six, Side by Side" and "Parquet and HDF5"):
  * flat JSON is larger than CSV: it repeats every key on every record;
  * YAML's safe_load is pure Python and hundreds of times slower than CSV;
  * at 4,029 rows Parquet is no faster than CSV, at the flat table's size it is;
  * HDF5 loses to Parquet on a table: a table is Parquet's shape, an array HDF5's.
"""
import json
import time
from pathlib import Path

import pandas as pd

def _data_dir():
    """Data/ next to Scripts/: one level up, or two when shipped under optional/."""
    here = Path(__file__).resolve().parent
    for d in (here.parent / "Data", here.parent.parent / "Data"):
        if (d / "invoice_43659.xml").exists():
            return d
    raise SystemExit("Data/ not found next to or above this script")


DATA = _data_dir() / "awc_basket.json"
OUT = Path("formats"); OUT.mkdir(exist_ok=True)


def tidy_basket(path=DATA) -> pd.DataFrame:
    """Nested baskets -> one row per (order, product). Cf. U01: this is the tidy form.

    Note the packed value: "Mountain Bikes-771" holds TWO variables in one string
    (category and product id). U01 called that a tidy-data violation; JSON makes
    it easy to ship. We split it here.
    """
    doc = json.loads(path.read_text(encoding="utf-8"))
    records = []
    for order in doc["root"]:
        for packed in order["products_bought_SplitResultList"]:
            subcategory, _, product_id = packed.rpartition("-")
            records.append({
                "customer_id": order["customer_id"],
                "sales_order_id": order["sales_order_id"],
                "subcategory": subcategory,
                "product_id": int(product_id),
            })
    return pd.DataFrame.from_records(records)


def find_extract():
    """AWC/awc_flat.csv in the current folder, this script's folder, or any folder above."""
    for base in [Path.cwd(), *Path.cwd().parents, *Path(__file__).resolve().parents]:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    return None


def best_of(fn, n=20):
    """Best-of-n, not mean: we want the floor, not the scheduler's noise."""
    return min(_timed(fn) for _ in range(n)) * 1000


def _timed(fn):
    start = time.perf_counter(); fn(); return time.perf_counter() - start


if __name__ == "__main__":
    df = tidy_basket()
    print(f"{len(df):,} tidy rows from {DATA.name}\n")

    # The nested original, re-serialised minified, so it is compared on the same
    # terms as the flat records (Data/awc_basket.json on disk is pretty-printed;
    # quoting that size would be measuring the indentation, not the format).
    nested = json.loads(DATA.read_text(encoding="utf-8"))

    writers = {
        "basket.csv":       lambda p: df.to_csv(p, index=False),
        "basket.csv.gz":    lambda p: df.to_csv(p, index=False, compression="gzip"),
        "basket.json":      lambda p: df.to_json(p, orient="records"),
        "basket.nested.json": lambda p: p.write_text(
            json.dumps(nested, separators=(",", ":")), encoding="utf-8"),
        "basket.snappy.parquet": lambda p: df.to_parquet(p, compression="snappy"),
        "basket.zstd.parquet":   lambda p: df.to_parquet(p, compression="zstd"),
    }
    readers = {
        "basket.csv":       lambda p: pd.read_csv(p),
        "basket.csv.gz":    lambda p: pd.read_csv(p),
        "basket.json":      lambda p: pd.read_json(p),
        "basket.nested.json": lambda p: json.loads(p.read_text(encoding="utf-8")),
        "basket.snappy.parquet": lambda p: pd.read_parquet(p),
        "basket.zstd.parquet":   lambda p: pd.read_parquet(p),
    }

    base = None
    print(f"{'file':<24}{'size':>11}{'vs CSV':>9}{'read':>11}")
    for name, write in writers.items():
        path = OUT / name
        write(path)
        size = path.stat().st_size
        base = base or size
        print(f"{name:<24}{size:>10,}B{size / base:>8.2f}x{best_of(lambda: readers[name](path)):>8.2f}ms")

    # The columnar argument: a column store reads only the columns you ask for.
    p = OUT / "basket.snappy.parquet"
    one = best_of(lambda: pd.read_parquet(p, columns=["product_id"]))
    allc = best_of(lambda: pd.read_parquet(p))
    print(f"\nParquet, 1 of 4 columns: {one:.2f} ms | all 4: {allc:.2f} ms")

    # ── all six formats the unit promises to compare, same rows ─────────────
    # CSV/JSON/Parquet are above; XML, YAML and HDF5 are written here so the
    # six-format table on the slide is measured, not asserted.
    import xml.etree.ElementTree as ET

    import h5py
    import numpy as np
    import yaml

    xml_root = ET.Element("lines")
    for row in df.itertuples(index=False):
        e = ET.SubElement(xml_root, "line")
        for k, v in zip(df.columns, row):
            ET.SubElement(e, k).text = str(v)
    p_xml = OUT / "basket.xml"
    ET.ElementTree(xml_root).write(p_xml, encoding="utf-8", xml_declaration=True)

    p_yml = OUT / "basket.yaml"
    p_yml.write_text(yaml.safe_dump(df.to_dict("records"), sort_keys=False),
                     encoding="utf-8")

    p_h5 = OUT / "basket.h5"
    with h5py.File(p_h5, "w") as f:
        for c in df.columns:
            v = df[c].to_numpy()
            if v.dtype == object:
                v = np.array(v, dtype=h5py.string_dtype())
            f.create_dataset(c, data=v, compression="gzip")

    def read_h5(p):
        with h5py.File(p) as f:
            return pd.DataFrame({c: f[c][:] for c in df.columns})

    # Every reader ends in the same DataFrame, so the times compare like with like.
    csv_size = (OUT / "basket.csv").stat().st_size
    base = best_of(lambda: pd.read_csv(OUT / "basket.csv"), 20)
    print(f"\nall six, the same {len(df):,} rows x {df.shape[1]} columns, read into a DataFrame")
    print(f"{'format':<16}{'size':>11}{'vs CSV':>9}{'read':>11}{'vs CSV':>9}")
    for name, path, reader, reps in (
            ("CSV", OUT / "basket.csv", lambda p: pd.read_csv(p), 20),
            ("XML", p_xml, lambda p: pd.read_xml(p), 5),
            ("JSON", OUT / "basket.json", lambda p: pd.read_json(p), 5),
            ("YAML", p_yml, lambda p: pd.DataFrame(yaml.safe_load(p.read_text(encoding="utf-8"))), 2),
            ("YAML, C loader", p_yml, lambda p: pd.DataFrame(yaml.load(p.read_text(encoding="utf-8"),
                                                                        Loader=yaml.CSafeLoader)), 3),
            ("Parquet", OUT / "basket.snappy.parquet", lambda p: pd.read_parquet(p), 20),
            ("HDF5", p_h5, read_h5, 5)):
        sz = path.stat().st_size
        t = best_of(lambda: reader(path), reps)
        print(f"{name:<16}{sz:>10,}B{sz / csv_size:>8.2f}x{t:>9.2f}ms{t / base:>8.0f}x")
    print("  YAML is the outlier: safe_load is pure Python (the C loader, if PyYAML was\n"
          "  built with libyaml, is faster but still far behind). HDF5 loses to Parquet on a\n"
          "  4-column table -- that shape is what Parquet is for. HDF5 wins on arrays.")

    # Same test at real scale. At 4,029 rows the per-call overhead swamps the
    # I/O and the columnar advantage does not show; the flat table is where it
    # does. This is the honest version of "columns beat rows".
    flat = find_extract()
    if flat is None:
        print("\nAWC/awc_flat.csv not found in this folder or above it: the real-scale test"
              " is skipped. Put your group's extract there to run it.")
    else:
        big = pd.read_csv(flat)
        bigpq = OUT / "flat.snappy.parquet"
        big.to_parquet(bigpq, compression="snappy")
        cs, ps = flat.stat().st_size, bigpq.stat().st_size
        print(f"\n{flat.name}: {len(big):,} rows x {big.shape[1]} columns")
        print(f"  CSV     {cs:>11,}B  1.00x  {best_of(lambda: pd.read_csv(flat), 5):>7.1f}ms")
        print(f"  Parquet {ps:>11,}B  {ps / cs:.2f}x  "
              f"{best_of(lambda: pd.read_parquet(bigpq), 5):>7.1f}ms")
        one = best_of(lambda: pd.read_parquet(bigpq, columns=["LineTotal"]), 5)
        allc = best_of(lambda: pd.read_parquet(bigpq), 5)
        print(f"  1 of {big.shape[1]} columns: {one:.1f} ms | all: {allc:.1f} ms "
              f"({allc / one:.1f}x less work)")

        # Types survive Parquet; CSV hands back text for whatever it cannot guess.
        dated = pd.read_csv(flat, parse_dates=["OrderDate", "ShipDate"])
        dated.to_csv(OUT / "flat_dated.csv", index=False)
        dated.to_parquet(OUT / "flat_dated.parquet")
        back_csv = pd.read_csv(OUT / "flat_dated.csv").dtypes
        back_pq = pd.read_parquet(OUT / "flat_dated.parquet").dtypes
        print("\n  columns whose type differs after the round trip (CSV vs Parquet):")
        for col in dated.columns:
            if str(back_csv[col]) != str(back_pq[col]):
                print(f"    {col:<12} CSV -> {back_csv[col]}   Parquet -> {back_pq[col]}")
