"""
Unit 03 — JSON: hierarchy, JSONPath, and the road back to a tidy table.

Data/awc_basket.json is AWC market-basket data: the first 997 orders of the database
(SalesOrderID 43659-44655), each with a nested list of purchased products, labelled
"SubCategory-ProductID". Verified against AWC/awc_flat.csv. Shape:

    orders: 997      basket size: min 1, max 35, mean 4.04

Two lessons live in this one file:

  1. HIERARCHY. One order with n products is one JSON object, not n rows. JSON
     represents that naturally; a table cannot without either repetition
     (long form) or a list-in-a-cell (which U01 forbade).

  2. A PACKED VALUE. "Mountain Bikes-771" holds a subcategory AND a product id in
     one string. That is U01's "several variables in one cell", shipped in a
     format that made it easy. Splitting it is the first thing we do.
"""
import json
from collections import Counter
from pathlib import Path

def _data_dir():
    """Data/ next to Scripts/: one level up, or two when shipped under optional/."""
    here = Path(__file__).resolve().parent
    for d in (here.parent / "Data", here.parent.parent / "Data"):
        if (d / "invoice_43659.xml").exists():
            return d
    raise SystemExit("Data/ not found next to or above this script")


DATA = _data_dir() / "awc_basket.json"


def describe(doc):
    orders = doc["root"]
    sizes = [len(o["products_bought_SplitResultList"]) for o in orders]
    print(f"orders           : {len(orders):,}")
    print(f"basket size      : min {min(sizes)}, max {max(sizes)}, "
          f"mean {sum(sizes) / len(sizes):.2f}")
    print(f"total order lines: {sum(sizes):,}")
    return orders


def flatten(orders):
    """Nested -> tidy: one row per (order, product). Splits the packed value."""
    rows = []
    for order in orders:
        for packed in order["products_bought_SplitResultList"]:
            subcategory, sep, product_id = packed.rpartition("-")   # the id is the last token
            if not sep:                      # defend: not every value may be packed
                subcategory, product_id = "UNKNOWN", packed
            rows.append({
                "customer_id": order["customer_id"],
                "sales_order_id": order["sales_order_id"],
                "subcategory": subcategory,
                "product_id": int(product_id),
            })
    return rows


def jsonpath_demo(doc):
    """The same idea as XPath, a second syntax. pip install jsonpath-ng"""
    from jsonpath_ng.ext import parse
    queries = {
        "orders of customer 676":      "$.root[?(@.customer_id==676)].sales_order_id",
        "first five customer ids":     "$.root[0:5].customer_id",
        "all products of order 43661": "$.root[?(@.sales_order_id==43661)]"
                                       ".products_bought_SplitResultList[*]",
    }
    for label, expr in queries.items():
        hits = [m.value for m in parse(expr).find(doc)]
        print(f"  {label:<30} {len(hits):>3} hit(s)  {hits if len(hits) <= 5 else hits[:3] + ['...']}")


if __name__ == "__main__":
    doc = json.loads(DATA.read_text(encoding="utf-8"))
    orders = describe(doc)

    print("\n=== flattened to tidy form ===")
    rows = flatten(orders)
    print(f"rows: {len(rows):,}   columns: {list(rows[0])}")
    print(f"sample: {rows[0]}")

    print("\n=== top subcategories by order lines ===")
    for subcategory, n in Counter(r["subcategory"] for r in rows).most_common(6):
        print(f"  {subcategory:<20} {n:>5,}")

    print("\n=== JSONPath ===")
    jsonpath_demo(doc)

    print("\nNote: flattening is lossy in one direction and lossless in the other.\n"
          "You can always rebuild the nesting by grouping on sales_order_id —\n"
          "because the key survived. Drop the key and the hierarchy is gone.")
