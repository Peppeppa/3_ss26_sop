"""
Unit 03 — is the AWC customer-demographics survey anonymous?

Reads AWC/awc_demographics.csv (found in this folder or above it): 19,972 rows straight
from Person_Person.Demographics. 18,484 of them carry a full IndividualSurvey; the rest
hold only TotalPurchaseYTD. The 18,484 are the individual (online) customers.

Output (slide "Where the Personal Data Hides"):

  exact birth date ALONE                     k=1  classes= 8,252 singletons= 2,901 (15.7%)
  exact birth date + 5 others                k=1  classes=17,711 singletons=16,972 (91.8%)
  birth YEAR      + 5 others                 k=1  classes= 2,320 singletons=   442 ( 2.4%)
  birth DECADE    + 5 others                 k=1  classes=   738 singletons=   100 ( 0.5%)
  birth DECADE, drop education+occupation    k=1  classes=   135 singletons=     9 ( 0.0%)
  birth DECADE + gender + income only        k=1  classes=    70 singletons=     4 ( 0.0%)
  birth DECADE + gender only                 k=8  classes=    16 singletons=     0 ( 0.0%)

The five others: gender, marital status, yearly income, education, occupation. No single
attribute is the identifier; the COMBINATION identifies (Sweeney 2002). Coarsening one
high-cardinality attribute (date -> year) buys the biggest drop, 91.8% to 2.4%, without
dropping a column --- but k stays 1 until four of the six are gone.

Run it on the full survey, not on a 100-record sample: in 100 people birthdays rarely
collide, in 18,484 they do, and the small sample would suggest "birth date alone makes
everyone unique".
"""
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

def find_demographics():
    """AWC/awc_demographics.csv in the current folder, this script's folder, or above."""
    for base in [Path.cwd(), *Path.cwd().parents, *Path(__file__).resolve().parents]:
        if (base / "AWC" / "awc_demographics.csv").exists():
            return base / "AWC" / "awc_demographics.csv"
    raise SystemExit("AWC/awc_demographics.csv not found in this folder or above it. Export it "
                     "from the database: SELECT BusinessEntityID, Demographics FROM Person_Person")
NS = "{http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey}"


def load(path=None):
    """One dict per customer that actually answered the survey."""
    import csv

    rows = []
    with open(path or find_demographics(), newline="", encoding="utf-8") as fh:
        for rec in csv.DictReader(fh):
            blob = rec.get("Demographics") or ""
            if not blob:
                continue
            try:
                survey = ET.fromstring(blob)
            except ET.ParseError:
                continue
            # .strip(): the source has trailing spaces, e.g. "Bachelors ".
            get = lambda tag: (survey.findtext(NS + tag) or "").strip()
            if not get("BirthDate"):
                continue  # 1,488 rows carry only TotalPurchaseYTD
            rows.append({
                "birthDate": get("BirthDate"),
                "gender": get("Gender"),
                "maritalStatus": get("MaritalStatus"),
                "income": get("YearlyIncome"),
                "education": get("Education"),
                "occupation": get("Occupation"),
            })
    return rows


def k_anonymity(rows, key):
    """k = size of the smallest equivalence class over the quasi-identifiers."""
    classes = Counter(key(r) for r in rows)
    singletons = sum(1 for n in classes.values() if n == 1)
    return min(classes.values()), len(classes), singletons


def report(rows):
    decade = lambda d: d[:3] + "0s"
    strategies = [
        # The control: the single most distinctive attribute, on its own.
        ("exact birth date ALONE", lambda r: (r["birthDate"],)),
        ("exact birth date + 5 others",
         lambda r: (r["birthDate"], r["gender"], r["maritalStatus"], r["income"],
                    r["education"], r["occupation"])),
        ("birth YEAR      + 5 others",
         lambda r: (r["birthDate"][:4], r["gender"], r["maritalStatus"], r["income"],
                    r["education"], r["occupation"])),
        ("birth DECADE    + 5 others",
         lambda r: (decade(r["birthDate"]), r["gender"], r["maritalStatus"], r["income"],
                    r["education"], r["occupation"])),
        ("birth DECADE, drop education+occupation",
         lambda r: (decade(r["birthDate"]), r["gender"], r["maritalStatus"], r["income"])),
        ("birth DECADE + gender + income only",
         lambda r: (decade(r["birthDate"]), r["gender"], r["income"])),
        ("birth DECADE + gender only",
         lambda r: (decade(r["birthDate"]), r["gender"])),
    ]
    print(f"{len(rows)} records\n")
    for label, key in strategies:
        k, classes, singles = k_anonymity(rows, key)
        print(f"  {label:<42} k={k:<3} classes={classes:>6,} "
              f"singletons={singles:>6,} ({singles / len(rows):5.1%})")


if __name__ == "__main__":
    report(load())
