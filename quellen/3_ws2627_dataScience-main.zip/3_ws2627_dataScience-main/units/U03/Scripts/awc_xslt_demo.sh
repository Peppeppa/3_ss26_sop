#!/usr/bin/env bash
# Unit 03 — XSLT on the AWC invoice (Data/invoice_43659.xml), the three XSLT slides.
#
# The stylesheets are in Data/. xsltproc implements XSLT 1.0, the version the
# slides show. The invoice's elements live in the namespace http://example.com/invoice,
# so every working stylesheet binds it to the prefix inv: and uses it in every path.
#
#   1  push style  (invoice_push.xsl)      -> <h1>Invoice INV-43659</h1> + 12 rows
#   2  the trap    (invoice_no_prefix.xsl) -> the same file without the prefix: no rule
#      matches, so the BUILT-IN rules print all 55 text values; no <h1>, no error
#   3  pull style  (invoice_pull.xsl)      -> 12 rows sorted by LineTotal,
#                                             "Lines: 12, sum: 20565.6206" (= SubTotal)
set -euo pipefail
# Data/ sits next to Scripts/ -- one level up, or two when this script ships under optional/.
for d in "$(dirname "$0")/../Data" "$(dirname "$0")/../../Data"; do
  [ -f "$d/invoice_43659.xml" ] && cd "$d" && break
done
[ -f invoice_43659.xml ] || { echo "Data/ not found next to or above this script" >&2; exit 1; }
X=.

echo "== 1. push style: apply-templates, one rule per node type =="
xsltproc $X/invoice_push.xsl invoice_43659.xml | head -3

echo; echo "== 2. THE TRAP: the same rules without the namespace prefix =="
xsltproc $X/invoice_no_prefix.xsl invoice_43659.xml | grep -v '^\s*$' | head -4
echo "   ... non-blank lines in total: $(xsltproc $X/invoice_no_prefix.xsl invoice_43659.xml | grep -vc '^\s*$')"
echo "   ^ no <h1>, no error: nothing matched, so the built-in rules copied the text."

echo; echo "== 3. pull style: for-each, sort, count(), sum() =="
xsltproc $X/invoice_pull.xsl invoice_43659.xml | head -5
xsltproc $X/invoice_pull.xsl invoice_43659.xml | tail -2
