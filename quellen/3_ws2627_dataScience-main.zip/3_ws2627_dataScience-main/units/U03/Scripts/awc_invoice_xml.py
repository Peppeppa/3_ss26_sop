"""
Unit 03 — from relational rows to a hierarchical document.

Generates the invoice XML for one AWC order straight from the database, in the
shape Data/invoice.xsd and Data/invoice.dtd describe:

    export AWC_DB_PW='...'
    python3 awc_invoice_xml.py 43659          # writes invoice_43659.xml
    xmllint --noout --schema ../Data/invoice.xsd invoice_43659.xml

Data/invoice_43659.xml is this script's output for order 43659.

Why this exists: an invoice is the canonical case where a table is the wrong
shape. One order = one header + n lines + the totals. In the relational model
that is several tables; as a document it is one nested object.

Three choices, all deliberate:
  * Customer/Name is the store for a reseller order and the person otherwise.
  * Money keeps the database's decimals: four (decimal(19,4)), and up to six for
    LineTotal (decimal(38,6)). Rounding each line to cents would make the lines no
    longer add up to SubTotal.
  * invoiceDate is DATE(OrderDate) exactly as the database stores it, the same
    value the course extract carries.
"""
import os
import sys
import xml.etree.ElementTree as ET
from decimal import Decimal
from pathlib import Path
from urllib.parse import quote_plus

NS = "http://example.com/invoice"          # must match targetNamespace in invoice.xsd

HEADER_SQL = """
    SELECT h.SalesOrderID,
           DATE(h.OrderDate)                                    AS OrderDate,
           COALESCE(s.Name, CONCAT(pp.FirstName, ' ', pp.LastName)) AS CustomerName,
           CONCAT(a.AddressLine1, ', ', a.City, ', ', sp.Name)  AS Address,
           h.SubTotal, h.TaxAmt, h.Freight, h.TotalDue
    FROM Sales_SalesOrderHeader   h
    JOIN Sales_Customer           c  ON c.CustomerID        = h.CustomerID
    LEFT JOIN Sales_Store         s  ON s.BusinessEntityID  = c.StoreID
    LEFT JOIN Person_Person       pp ON pp.BusinessEntityID = c.PersonID
    JOIN Person_Address           a  ON a.AddressID         = h.BillToAddressID
    JOIN Person_StateProvince     sp ON sp.StateProvinceID  = a.StateProvinceID
    WHERE h.SalesOrderID = :order_id
"""

LINES_SQL = """
    SELECT p.Name AS ProductName, d.OrderQty AS Quantity, d.UnitPrice, d.LineTotal
    FROM Sales_SalesOrderDetail d
    JOIN Production_Product     p ON p.ProductID = d.ProductID
    WHERE d.SalesOrderID = :order_id
    ORDER BY d.SalesOrderDetailID
"""


def fetch(order_id):
    if "AWC_DB_PW" not in os.environ:
        raise SystemExit("Set the password first:  export AWC_DB_PW='...'")
    from sqlalchemy import create_engine, text
    engine = create_engine("mysql+mysqlconnector://sqladmin:"
                           f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019")
    with engine.connect() as conn:
        header = conn.execute(text(HEADER_SQL), {"order_id": order_id}).mappings().first()
        if header is None:
            raise SystemExit(f"SalesOrderID {order_id} not found")
        lines = conn.execute(text(LINES_SQL), {"order_id": order_id}).mappings().all()
    return header, lines


def money(x) -> str:
    return f"{Decimal(str(x)):.4f}"    # decimal(19,4) in the database: four decimals


def line_money(x) -> str:
    """LineTotal is decimal(38,6): keep all six decimals where the value has them."""
    d = Decimal(str(x))
    return f"{d:.4f}" if d == d.quantize(Decimal("0.0001")) else f"{d:.6f}"


def build(header, lines) -> ET.ElementTree:
    ET.register_namespace("", NS)
    q = lambda tag: f"{{{NS}}}{tag}"

    invoice = ET.Element(q("Invoice"), {
        "invoiceNo": f"INV-{header['SalesOrderID']}",
        # xs:date demands ISO 8601. A locale-formatted date fails validation,
        # which is the schema doing its job.
        "invoiceDate": str(header["OrderDate"])[:10],
    })
    ET.SubElement(invoice, q("Seller")).text = "Adventure Works Cycles"

    customer = ET.SubElement(invoice, q("Customer"))
    ET.SubElement(customer, q("Name")).text = header["CustomerName"]
    ET.SubElement(customer, q("Address")).text = header["Address"]

    items = ET.SubElement(invoice, q("Items"))
    for line in lines:
        item = ET.SubElement(items, q("Item"))
        ET.SubElement(item, q("ProductName")).text = line["ProductName"]
        ET.SubElement(item, q("Quantity")).text = str(int(line["Quantity"]))
        ET.SubElement(item, q("UnitPrice")).text = money(line["UnitPrice"])
        ET.SubElement(item, q("LineTotal")).text = line_money(line["LineTotal"])

    for tag in ("SubTotal", "TaxAmt", "Freight", "TotalDue"):
        ET.SubElement(invoice, q(tag)).text = money(header[tag])
    return ET.ElementTree(invoice)


def write(tree: ET.ElementTree, out: Path) -> None:
    ET.indent(tree, space="  ")
    tree.write(out, encoding="utf-8", xml_declaration=True)
    with out.open("a", encoding="utf-8") as f:
        f.write("\n")


if __name__ == "__main__":
    order_id = int(sys.argv[1]) if len(sys.argv) > 1 else 43659
    header, lines = fetch(order_id)
    out = Path(f"invoice_{order_id}.xml")
    write(build(header, lines), out)
    print(f"{len(lines)} line(s) -> {out}")
    print(f"validate: xmllint --noout --schema ../Data/invoice.xsd {out}")
