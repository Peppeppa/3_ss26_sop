"""
Unit 03 — HDF5 as a container: one file, several shapes.

Parquet is a *table* format: rows and columns, one logical table per file.
Plenty of real data is not a table. This script builds three genuinely
differently-shaped things out of the same AWC flat-table and puts all three
into ONE HDF5 file, each with its own metadata attached in-file:

    /features/customer_subcategory   19,119 x 35   int32     a matrix
    /reporting/revenue_cube          10 x 4 x 38   float64   a 3-D cube
    /similarity/distance             N x N         float32   a big square

The last one is the point. A customer-vs-customer distance matrix (the U06
question, "who is similar to whom") is O(N^2): for all 19,119 customers that
is 366 million cells. It is not a table, it does not fit in memory, and you
almost never want all of it -- you want one row. HDF5 stores it chunked, so
reading one customer's row touches a few chunks instead of the whole array.

Every HDF5 number on the slide `Parquet and HDF5: the Core Ideas` is printed here.

    python3 awc_hdf5_container.py            # N = 5000 (default)
    python3 awc_hdf5_container.py --full     # all 19,119 -- writes ~1.4 GB

Docs: https://support.hdfgroup.org/documentation/hdf5/latest/
"""
import argparse
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd

def find_extract():
    """AWC/awc_flat.csv in the current folder, this script's folder, or any folder above."""
    for base in [Path.cwd(), *Path.cwd().parents, *Path(__file__).resolve().parents]:
        if (base / "AWC" / "awc_flat.csv").exists():
            return base / "AWC" / "awc_flat.csv"
    raise SystemExit("AWC/awc_flat.csv not found in this folder or above it. This script runs "
                     "on the order-line extract your group's script builds -- put it there.")


OUT = Path("formats"); OUT.mkdir(exist_ok=True)
H5 = OUT / "awc.h5"


def best_of(fn, n=5):
    """Best-of-n, not mean: we want the floor, not the scheduler's noise."""
    out = []
    for _ in range(n):
        t0 = time.perf_counter(); fn(); out.append(time.perf_counter() - t0)
    return min(out) * 1000


def main(n_sub: int | None) -> None:
    df = pd.read_csv(find_extract())
    month = df.OrderDate.str[:7]

    # ── shape 1: a matrix (customers x subcategories) ────────────────────────
    mat = df.pivot_table(index="CustomerID", columns="SubCategory",
                         values="OrderQty", aggfunc="sum", fill_value=0)
    feats = mat.to_numpy(dtype=np.int32)

    # ── shape 2: a 3-D cube (territory x category x month) ───────────────────
    terr = sorted(df.TerritoryName.unique())
    cats = sorted(df.Category.unique())
    mons = sorted(month.unique())
    cube = np.zeros((len(terr), len(cats), len(mons)), dtype=np.float64)
    g = df.groupby([df.TerritoryName, df.Category, month]).LineTotal.sum()
    for (t, c, m), v in g.items():
        cube[terr.index(t), cats.index(c), mons.index(m)] = v

    # ── shape 3: the big square (customers x customers) ──────────────────────
    n = len(feats) if n_sub is None else min(n_sub, len(feats))
    x = feats[:n].astype(np.float32)
    # Euclidean distance the memory-frugal way, one block of rows at a time.
    sq = (x * x).sum(axis=1)
    BLOCK = 512

    with h5py.File(H5, "w") as f:
        f.attrs["source"] = "AWC/awc_flat.csv"
        f.attrs["built_by"] = "Scripts/awc_hdf5_container.py"

        d = f.create_dataset("features/customer_subcategory", data=feats,
                             compression="gzip", chunks=True)
        d.attrs["units"] = "OrderQty, summed"
        d.attrs["rows"] = "CustomerID, ascending"
        d.attrs["columns"] = list(mat.columns)

        d = f.create_dataset("reporting/revenue_cube", data=cube,
                             compression="gzip", chunks=True)
        d.attrs["units"] = "LineTotal, USD"
        d.attrs["dim_0_territory"] = terr
        d.attrs["dim_1_category"] = cats
        d.attrs["dim_2_month"] = mons

        # Chunked so a single row can be read without touching the rest.
        dist = f.create_dataset("similarity/distance", shape=(n, n),
                                dtype=np.float32, chunks=(256, 256),
                                compression="gzip")
        dist.attrs["metric"] = "euclidean on customer_subcategory"
        dist.attrs["note"] = "symmetric; stored dense on purpose, see the slide"
        for i in range(0, n, BLOCK):
            blk = x[i:i + BLOCK]
            d2 = sq[i:i + BLOCK, None] + sq[None, :] - 2.0 * (blk @ x.T)
            dist[i:i + BLOCK] = np.sqrt(np.maximum(d2, 0.0), dtype=np.float32)

    size = H5.stat().st_size
    print(f"{H5}: {size:,} B  ({size/1e6:.1f} MB)\n")

    with h5py.File(H5, "r") as f:
        print("the file is a filesystem: groups, datasets, attributes")
        f.visititems(lambda name, o: print(
            f"  {name:<34} {getattr(o, 'shape', '')} {getattr(o, 'dtype', '')}"))
        print()
        for path in ("features/customer_subcategory", "reporting/revenue_cube",
                     "similarity/distance"):
            d = f[path]
            print(f"  {path:<34} on disk {d.id.get_storage_size():>12,} B  "
                  f"raw {d.size * d.dtype.itemsize:>12,} B")
        print()

        # The whole point: partial I/O. One row, not the array.
        one = best_of(lambda: f["similarity/distance"][7, :])
        allr = best_of(lambda: f["similarity/distance"][:], n=2)
        print(f"  read 1 of {n:,} rows: {one:.2f} ms   |   read all {n:,}: "
              f"{allr:.1f} ms   ({allr/one:.0f}x)")

        # What a CSV of the same square would cost.
        row = f["similarity/distance"][0, :]
        csv_bytes = n * len(",".join(f"{v:.4f}" for v in row).encode()) + n
        print(f"  the same square as CSV: ~{csv_bytes:,} B "
              f"({csv_bytes/size:.0f}x the HDF5 file)")

    print(f"\nAll {len(feats):,} customers would be "
          f"{len(feats)**2:,} cells = {len(feats)**2*4/1e9:.1f} GB raw float32.")

    # ── the lesson chunking actually teaches ─────────────────────────────────
    # A chunk is the unit of I/O and of compression: reading one cell costs one
    # whole chunk. So the chunk shape has to match how the data will be read,
    # and getting it wrong is the difference between 0.2 ms and 22 ms.
    print("\nsame square, three chunk shapes -- the read pattern decides:")
    with h5py.File(H5, "r") as f:
        arr = f["similarity/distance"][:]
    probe = OUT / "probe.h5"
    for label, chunks in (("square  256 x 256", (256, 256)),
                          ("row     1 x N", (1, n)),
                          ("band    64 x N", (64, n))):
        with h5py.File(probe, "w") as f:
            f.create_dataset("d", data=arr, chunks=chunks, compression="gzip")
        with h5py.File(probe, "r") as f:
            one = best_of(lambda: f["d"][7, :])
            allr = best_of(lambda: f["d"][:], n=2)
        print(f"  {label:<20} {probe.stat().st_size/1e6:6.1f} MB   "
              f"1 row {one:7.2f} ms   all {allr:7.1f} ms")
    probe.unlink()
    print("  -> chunk by the axis you read. Row chunks cost ~30% more space and\n"
          "     make a single-customer lookup about 100x cheaper.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="all customers, ~1.4 GB")
    ap.add_argument("--n", type=int, default=5000)
    a = ap.parse_args()
    main(None if a.full else a.n)
