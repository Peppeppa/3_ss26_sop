"""
Unit 03 — the XPath teaching sample, Data/records_simplified.xml, rebuilt from the database.

    export AWC_DB_PW='...'
    python3 awc_demographics_sample.py            # writes records_simplified.xml here

What it is: the customer survey of AWC customers 11000-11099 (the first 100 individual, i.e. online,
customers), from Person_Person.Demographics, linked to the customer by
Sales_Customer.PersonID. Every element is the database value, with three changes that
keep the XPath exercises simple, and the file says so in its header:

  * the survey namespace is removed (XPath without a prefix binding);
  * the time-zone marker "Z" is removed from DateFirstPurchase and BirthDate;
  * TotalPurchaseYTD is the customer's revenue in our orders (SUM of LineTotal), because
    the survey's own value does not match the orders (customer 11000: 4751.05 in the
    survey, 8248.99 ordered).

Education keeps its trailing space ("Bachelors "), exactly as stored; that is the point
of the "silent zero" slide.
"""
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import quote_plus

NS = "{http://schemas.microsoft.com/sqlserver/2004/07/adventure-works/IndividualSurvey}"
FIRST, LAST = 11000, 11099

SQL = """
    SELECT c.CustomerID, p.Demographics, SUM(d.LineTotal) AS Revenue
    FROM Sales_Customer c
    JOIN Person_Person p           ON p.BusinessEntityID = c.PersonID
    JOIN Sales_SalesOrderHeader h  ON h.CustomerID = c.CustomerID
    JOIN Sales_SalesOrderDetail d  ON d.SalesOrderID = h.SalesOrderID
    WHERE c.CustomerID BETWEEN :first AND :last
    GROUP BY c.CustomerID, p.Demographics
    ORDER BY c.CustomerID
"""

HEADER = f"""<?xml version="1.0"?>
<!-- AWC customers {FIRST}-{LAST}: their survey from Person_Person.Demographics (joined
     via Sales_Customer.PersonID). Simplified for XPath: namespace removed, the "Z" removed
     from the two dates, TotalPurchaseYTD = the customer's summed LineTotal. Built by
     Scripts/awc_demographics_sample.py. -->
<records xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="records_simplified.xsd">
"""


def fetch():
    if "AWC_DB_PW" not in os.environ:
        raise SystemExit("Set the password first:  export AWC_DB_PW='...'")
    from sqlalchemy import create_engine, text
    engine = create_engine("mysql+mysqlconnector://sqladmin:"
                           f"{quote_plus(os.environ['AWC_DB_PW'])}@localhost/Adventureworks2019")
    with engine.connect() as conn:
        return conn.execute(text(SQL), {"first": FIRST, "last": LAST}).all()


def record(customer_id: int, demographics: str, revenue) -> str:
    survey = ET.fromstring(demographics)
    lines = [f'<Record id="{customer_id}">', "  <IndividualSurvey>"]
    for el in survey:
        tag, value = el.tag.removeprefix(NS), el.text
        if tag == "TotalPurchaseYTD":
            value = f"{float(revenue):.2f}"
        elif tag in ("DateFirstPurchase", "BirthDate"):
            value = value.removesuffix("Z")
        lines.append(f"    <{tag}>{value}</{tag}>")
    lines += ["  </IndividualSurvey>", "</Record>", ""]
    return "\n".join(lines) + "\n"


def build(rows) -> str:
    return HEADER + "".join(record(*r) for r in rows) + "</records>\n"


if __name__ == "__main__":
    rows = fetch()
    if len(rows) != LAST - FIRST + 1:
        sys.exit(f"expected {LAST - FIRST + 1} customers, got {len(rows)}")
    out = Path("records_simplified.xml")
    out.write_text(build(rows), encoding="ascii")
    print(f"{len(rows)} records -> {out}")
    print(f"validate: xmllint --noout --schema ../Data/records_simplified.xsd {out}")
