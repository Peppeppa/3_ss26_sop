#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Unit 03 — the jq half of the "JSONPath and jq" slide, runnable.
#
#   ./awc_jq_demo.sh          (needs jq; on Ubuntu: sudo apt install jq)
#
# jq is to JSON what XPath is to XML: path, predicate, function. The slide's jq
# lines are here, plus two more; the expected result is in each comment, and
# was produced from Data/awc_basket.json (997 baskets).
# The Python/JSONPath counterpart is awc_json_flatten.py.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
# Data/ sits next to Scripts/ -- one level up, or two when this script ships under optional/.
for d in "$(dirname "$0")/../Data" "$(dirname "$0")/../../Data"; do
  [ -f "$d/invoice_43659.xml" ] && cd "$d" && break
done
[ -f invoice_43659.xml ] || { echo "Data/ not found next to or above this script" >&2; exit 1; }
F=awc_basket.json

echo "== how many baskets? =="
jq '.root | length' "$F"                                         # 997

echo "== total order lines across all baskets =="
jq '[.root[].products_bought_SplitResultList | length] | add' "$F"   # 4029

echo "== orders of customer 676  (path + predicate) =="
jq -c '[.root[] | select(.customer_id==676) | .sales_order_id]' "$F" # [43659,44305]

echo "== first five customer ids  (slice) =="
jq -c '[.root[0:5][].customer_id]' "$F"                          # [676,117,442,227,510]

echo "== the three biggest baskets  (map, sort, slice) =="
jq -c '.root
       | map({sales_order_id, n: (.products_bought_SplitResultList|length)})
       | sort_by(.n) | reverse | .[0:3]' "$F"
# [{"sales_order_id":44538,"n":35},{"sales_order_id":44520,"n":34},{"sales_order_id":44288,"n":34}]

echo
echo "Same three ideas as XPath and JSONPath: path, predicate, function."
