#!/usr/bin/env bash
# Unit 03 — querying XML with XPath, on the AWC customer-demographics survey.
#
# Data/records_simplified.xml: the survey of AWC customers 11000-11099, from the XML
# column Person_Person.Demographics (built by awc_demographics_sample.py) --
# demographic data stored INSIDE a relational table.
#
# All counts below are verified against the shipped file.
set -euo pipefail
# Data/ sits next to Scripts/ -- one level up, or two when this script ships under optional/.
for d in "$(dirname "$0")/../Data" "$(dirname "$0")/../../Data"; do
  [ -f "$d/invoice_43659.xml" ] && cd "$d" && break
done
[ -f invoice_43659.xml ] || { echo "Data/ not found next to or above this script" >&2; exit 1; }
F=records_simplified.xml

echo "== slide 'XPath in One Slide' =="
for q in '/records/Record' '//BirthDate' '//BirthDate/parent::*'; do
  printf '  %-32s -> %s nodes\n' "$q" "$(xmllint --xpath "count($q)" $F)"
done
printf '  %-32s -> %s\n' '/records/Record[1]/@id' "$(xmllint --xpath '/records/Record[1]/@id' $F)"
printf '  %-32s -> %s node\n' '//Record[@id="11000"]//BirthDate' \
  "$(xmllint --xpath 'count(//Record[@id="11000"]//BirthDate)' $F)"
printf '  %-32s -> %s\n' 'count(//Record[.//TotalChildren>=3])' \
  "$(xmllint --xpath 'count(//Record[.//TotalChildren>=3])' $F)"

echo; echo "== how many records? =="
xmllint --xpath 'count(/records/Record)' $F; echo            # 100

echo; echo "== married customers =="
xmllint --xpath 'count(/records/Record[IndividualSurvey/MaritalStatus="M"])' $F; echo   # 57

echo; echo "== families with 3 or more children =="
xmllint --xpath 'count(/records/Record[IndividualSurvey/TotalChildren >= 3])' $F; echo  # 21

echo; echo "== THE TRAP: string equality is exact =="
echo -n '  Education="Bachelors"            -> '
xmllint --xpath 'count(/records/Record[IndividualSurvey/Education="Bachelors"])' $F; echo
echo -n '  Education="Bachelors " (trailing) -> '
xmllint --xpath 'count(/records/Record[IndividualSurvey/Education="Bachelors "])' $F; echo
echo -n '  normalize-space(...)="Bachelors"  -> '
xmllint --xpath 'count(/records/Record[normalize-space(IndividualSurvey/Education)="Bachelors"])' $F; echo
echo '  The source has a trailing space. The first query returns 0 and raises no'
echo '  error whatsoever. A silent zero is the worst kind of wrong answer.'

echo; echo "== ids of high earners who are professionals =="
xmllint --xpath '/records/Record[
    normalize-space(IndividualSurvey/Occupation)="Professional"
    and (IndividualSurvey/YearlyIncome="75001-100000"
         or IndividualSurvey/YearlyIncome="greater than 100000")]/@id' $F | head -c 300; echo

echo; echo "== validate against the schema (schema-on-write) =="
xmllint --noout --schema records_simplified.xsd $F
