---
source_id: DS-U03-L-EN
original_file: Unit03_slides_en.pdf
source_type: lecture
language: en
page_count: 44
source_sha256: 12ff10f9ab2ea0f72f6da8fc63241bc205d83a57155cc4a47946c9065a66e337
verification: partial
---
# Unit03_slides_en

[Original PDF](../../../quellen/Unit03_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit03_slides_en.pdf#page=1)

~~~~text
Data Science

FORMATS, SERIALISATION &
METADATA


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit03_slides_en.pdf#page=2)

~~~~text
                                                                   LEARNING GOALS


    • Say where CSV, XML, JSON, YAML, Parquet and HDF5 are used, and what each ﬁle
      guarantees
    • Diagnose the classic CSV traps — encoding, separator, line endings, guessed types —
      and read defensively
    • Validate an XML document against a schema, query a tree, and turn XML into a report
      with XSLT
    • Flatten nested JSON back to a tidy table
    • Justify a format choice for a given reader and data volume
    • Write a metadata ﬁle — data dictionary, provenance, known issues, FAIR — and judge
      whether data are personal



2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit03_slides_en.pdf#page=3)

~~~~text
                                                THE QUESTION OF THIS UNIT



                      Your data leave your hands as a ﬁle.
      What must the ﬁle carry so that the next reader reads it as you meant?



           Text table             Tree                Binary              Meaning


    Example: your extract awc_flat.csv from U02. Next week a group member opens
    it in KNIME, a grader reads it for M1, in a year you read it again. Nobody can ask you
    what a column means, which separator you used, or where the data came from.
    Each step closes a gap the previous one leaves open.

3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit03_slides_en.pdf#page=4)

~~~~text
                                 SIX FORMATS YOU WILL MEET AT WORK

    Structured = a table · semistructured = a tree whose branches vary · unstructured = text,
    images. This unit: the ﬁrst two.
     Format    Shape   Where you meet it                     What the ﬁle guarantees
     CSV       table   exports, Excel, every tool            nothing — every reader guesses
     XML       tree    e-invoices, bank statements           a contract, if a schema is checked
     JSON      tree    web APIs, app data                    a tree; the rules are up to you
     YAML      tree    conﬁguration, metadata ﬁles           JSON’s tree, written for people
     Parquet   table   data lakes, cloud warehouses          typed columns, stored to be
                                                             queried
     HDF5      array   science, MATLAB, climate data         typed arrays, read in pieces


    The point of this unit
    A format decides which questions stay cheap to ask — and which mistakes the next reader
    can make. It is a modelling decision, not packaging.

4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit03_slides_en.pdf#page=5)

~~~~text
      STEP 1: A TABLE AS PLAIN TEXT — CSV


    Text table   Tree      Binary    Meaning




5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit03_slides_en.pdf#page=6)

~~~~text
                                            A CSV LINE SAYS LESS THAN YOU THINK

    Everything around the values is a guess the reader must make:
         header line —
        or already data?        ProductID;Name;ListPrice
                                                                                            line end: LF,
                                771 ; "Mountain-100 Silver, 38" ; 3399,99 ←-                  CRLF or a
                                                                                              bare CR?
              a number or                       quotes keep
                                                                                       decimal
              text? the ﬁle                    the comma —
                                                                                     mark: point
              has no types                      if the reader
                                                                                     or comma?
                                               honours them         separator:
                                                                    , ; or tab?


    Consequence
    And one guess you cannot see at all: the character encoding of the bytes. A CSV ﬁle is not
    self-describing; even its RFC 4180 only describes common practice.

    spec: rfc-editor.org/rfc/rfc4180

6                              Text table      Tree             Binary            Meaning
~~~~

### DS-U03-L-EN-P006-D01 — Rekonstruktion

CSV annotation: header vs data, semicolon/comma/tab field separator, LF/CRLF/CR line ends, decimal comma vs point, quotes protecting internal comma, unknown types and encoding.

## Page 007

[Original page 7](../../../quellen/Unit03_slides_en.pdf#page=7)

~~~~text
                            ENCODING: LOUD ONE WAY, SILENT THE OTHER

    A ﬁle stores bytes. The encoding says which bytes mean which character — and the ﬁle
    does not record it. The same city, written and read with different encodings:

           written as UTF-8                    read as Latin-1                        WÃ¼rzburg
           W C3 BC rzburg                     one char per byte                    no error — silent

          written as Latin-1                   read as UTF-8                       UnicodeDecodeError
             W FC rzburg                      FC is invalid there                      0xfc — loud


    Which direction should frighten you
    The error is the good case: you ﬁnd out at once. Latin-1 never raises — every byte is a valid
    Latin-1 character — so the ﬁle loads and has wrong city names in it. Name the encoding:
    pandas encoding="utf-8"; KNIME CSV Reader, setting File encoding.
    A BOM (byte order mark, three invisible bytes at the start of some UTF-8 ﬁles) can stick to the ﬁrst column name:
    encoding="utf-8-sig". Script: Scripts/awc_csv_traps.py
7                         Text table            Tree                 Binary             Meaning
~~~~

### DS-U03-L-EN-P007-D01 — Rekonstruktion

UTF-8 bytes W C3 BC rzburg → Latin-1 decoding → WÃ¼rzburg, silent. Latin-1 bytes W FC rzburg → UTF-8 decoding → UnicodeDecodeError, loud.

## Page 008

[Original page 8](../../../quellen/Unit03_slides_en.pdf#page=8)

~~~~text
                                              LINE ENDINGS — A REAL AWC FILE

    orders.csv from a third-party AWC export for the graph database Neo4j. Every line ends
    with a bare CR (carriage return, the classic Mac OS convention) — no LF (line feed). What
    different tools see:
    Tool                            Sees
    wc -l (counts LF)               0 lines
    head -n 3                       the whole ﬁle, 6,982,415 bytes, instead of three lines
    pandas, Python’s csv module     60,919 rows, 16 columns — correct

    The same export’s products.csv and customers.csv use CRLF — and the second is
    Latin-1. One source, three conventions.

    Diagnosis before repair
    Count the bytes before you blame a tool: CR and no LF → bare CR; as many CR as LF →
    CRLF (Windows); LF only → LF (Linux, macOS since OS X).

8                      Text table      Tree            Binary           Meaning
~~~~

## Page 009

[Original page 9](../../../quellen/Unit03_slides_en.pdf#page=9)

~~~~text
                   SEPARATORS AND TYPES: SAY THEM, DO NOT LET THE READER GUESS


    The reader’s defaults ﬁt an English export. A German one breaks them — some loudly,
    some silently:
    The ﬁle has                     Default reading gives          Say it explicitly (pandas · KNIME CSV
                                                                   Reader)
    ; as separator                  one single column              sep=";" · Column delimiter
    3399,99                         text, not a number             decimal="," · Decimal separator
    "Mountain-100 Silver,           correct: quotes keep the       nothing — the default follows RFC 4180
    38"                             comma
    PostalCode 04139, only          4139, a number                 dtype={"PostalCode": "string"} ·
    German rows                                                    type String in the column settings

    Read defensively
    Type guessing looks at the values: in the full customer ﬁle PostalCode is text (UK and
    Canadian codes contain letters). Keep only Germany and it becomes a number — 95
    codes lose their leading zero, without a warning. A default is a guess you did not make.

9                      Text table          Tree                Binary           Meaning
~~~~

## Page 010

[Original page 10](../../../quellen/Unit03_slides_en.pdf#page=10)

~~~~text
     STEP 2: WHEN THE DATA IS A TREE — XML AND
                       JSON


       Text table   Tree     Binary    Meaning




10
~~~~

## Page 011

[Original page 11](../../../quellen/Unit03_slides_en.pdf#page=11)

~~~~text
                                             WHEN A TABLE IS THE WRONG SHAPE

     An invoice is a hierarchy: a header, n lines, the totals. A ﬂat table repeats the header on every line
     (U01: the total n times, n chances to disagree). An XML (Extensible Markup Language) document
     keeps it as one object:

       1   <Invoice xmlns="http://example.com/invoice" invoiceNo="INV-43659" invoiceDate="2011-05-30">
      2     <Seller>Adventure Works Cycles</Seller>
      3     <Customer><Name>Better Bike Shop</Name>
      4            <Address>42525 Austell Road, Austell, Georgia</Address></Customer>
      5     <Items>
      6      <Item><ProductName>Mountain-100 Black, 42</ProductName><Quantity>1</Quantity>
      7           <UnitPrice>2024.9940</UnitPrice><LineTotal>2024.9940</LineTotal></Item>
      8      <!-- 11 more Item elements --> </Items>
      9     <SubTotal>20565.6206</SubTotal><TaxAmt>1971.5149</TaxAmt>
      10    <Freight>616.0984</Freight><TotalDue>23153.2339</TotalDue>
      11   </Invoice>
     Elements (<Customer>) hold content, can repeat and get children; attributes (invoiceNo="...") hold
     one text value about the element. Generated from the database (Scripts/awc_invoice_xml.py): a
     document to exchange one nested object, a table to query across many.

11                           Text table         Tree               Binary            Meaning
~~~~

## Page 012

[Original page 12](../../../quellen/Unit03_slides_en.pdf#page=12)

~~~~text
                           A CONTRACT THE FILE CAN ENFORCE: DTD AND XSD

     invoice.xsd (excerpt): types and value rules           A DTD ﬁxes the structure only; every value is text.
       1   <xs:element name="Quantity" type="
                                                            An XSD (XML Schema Deﬁnition) adds types and
                 xs:positiveInteger"/>                      value rules. One value broken per ﬁle:
      2    <xs:attribute name="invoiceDate" type="xs:date
                 "/>
                                                            File                                 DTD       XSD
      3    <xs:simpleType name="Money">                     the invoice                          valid     valid
      4    <xs:restriction base="xs:decimal">               date 30.05.2011                      valid   rejected
      5     <xs:minInclusive value="0"/>
                                                            price 2024.99999                     valid   rejected
      6     <xs:fractionDigits value="4"/>
      7    </xs:restriction></xs:simpleType>                ’30.05.2011’ is not a valid value of the atomic
                                                            type ’xs:date’.

      Schema-on-write vs. schema-on-read
      XML checked against an XSD is schema-on-write: a bad value is rejected before it is
      stored or sent. CSV and JSON are schema-on-read: anything goes in, and every reader
      guesses the rules again. Run it: xmllint –schema, Python lxml (Data/validate.sh).

      spec: w3.org/TR/xmlschema11-1

12                               Text table         Tree           Binary            Meaning
~~~~

## Page 013

[Original page 13](../../../quellen/Unit03_slides_en.pdf#page=13)

~~~~text
                                                     READING A TREE: DOM OR STREAMING?

              DOM: the whole tree in memory                                            SAX: a stream of events
                                              @invoiceNo="INV-43659"         startDocument()
                             Invoice                                         startElement("Invoice", {..., invoiceNo=...,
                                              @invoiceDate="2011-05-30"      . . Seller, Customer . . .
                                                                            ....})
                                                                             startElement("Name")
                          + Seller,
      Customer            4 totals
                                           Items                             characters("Better Bike Shop")
                                                                             endElement("Name")
                                                           + 11 more        . . . Address, Items, Item . . .
         Name                               Item              Item           startElement("ProductName")
                                                                             characters("Mountain-100 Black, 42")
     Better Bike Shop     ProductName                LineTotal               endElement("ProductName")
                                                                            . . . 11 more Item, 4 totals . . .
                                                                             endElement("Invoice")
                        Mountain-100 Black, 42       2024.9940
                                                                             endDocument()

          element          attribute          text
      DOM (Document Object Model): memory grows with the ﬁle, any node reachable — to edit and query;
      XPath and XSLT work on this tree. SAX (Simple API for XML): memory grows with the depth only, no
      going back — to extract from huge ﬁles, like reading a big CSV in pieces.

13                                    Text table           Tree           Binary                       Meaning
~~~~

## Page 014

[Original page 14](../../../quellen/Unit03_slides_en.pdf#page=14)

~~~~text
        Break
      10 minutes




Then: XPath: Querying a Tree
~~~~

## Page 015

[Original page 15](../../../quellen/Unit03_slides_en.pdf#page=15)

~~~~text
                                                     XML INSIDE A RELATIONAL TABLE
     AWC keeps a customer survey as one XML document per row in
     Person_Person.Demographics, linked to the customer by Sales_Customer.PersonID:
       1   <Record id="11000">
      2     <IndividualSurvey>
      3      <TotalPurchaseYTD>8248.99</TotalPurchaseYTD>
      4      <DateFirstPurchase>2001-07-22</DateFirstPurchase>
      5      <BirthDate>1966-04-08</BirthDate>
      6      <MaritalStatus>M</MaritalStatus>
      7      <YearlyIncome>75001-100000</YearlyIncome>
      8      <Gender>M</Gender>
      9      <TotalChildren>2</TotalChildren>
      10     <NumberChildrenAtHome>0</NumberChildrenAtHome>
      11     <Education>Bachelors </Education>
      12     <!-- 4 more: Occupation, HomeOwnerFlag, NumberCarsOwned, CommuteDistance -->
      13    </IndividualSurvey>
      14   </Record>
     Data/records_simplified.xml: customers 11000–11099, slightly simpliﬁed (see Readme). Common
     in practice: a JSON or XML column inside a database. Look at Education closely — and this is
     personal data (step 4).
15                          Text table        Tree               Binary            Meaning
~~~~

## Page 016

[Original page 16](../../../quellen/Unit03_slides_en.pdf#page=16)

~~~~text
                                                                               XPATH IN ONE SLIDE


                                                             Expression                              Result
                         records
                                                 path        /records/Record                         100 nodes
                                                 anywhere    //BirthDate                             100 nodes
     @id="11000"      Record     + 99 Record
                                                 attribute   /records/Record[1]/@id                  id="11000"
                                                 predicate   //Record[@id="11000"]//BirthDate        1 node
               IndividualSurvey                  function    count(//Record[.//TotalChildren>=3])    21

          BirthDate    Gender      + 11
                                                 Path, predicate, function — the three ideas you need. A path
                                                 walks the tree like folders on a disk; a predicate [...] ﬁlters
         1966-04-08      M                       like WHERE.
                                                 Run it: xmllint –xpath, Python lxml, KNIME node XPath.
      spec: w3.org/TR/xpath-10




16                                  Text table      Tree              Binary          Meaning
~~~~

## Page 017

[Original page 17](../../../quellen/Unit03_slides_en.pdf#page=17)

~~~~text
                        A QUERY THAT FINDS NOTHING RAISES NO ERROR

     Count the customers with a Bachelor’s degree in the survey ﬁle:
      1   $ F=records_simpliﬁed.xml
      2   $ xmllint --xpath 'count(//Record[IndividualSurvey/Education="Bachelors"])' $F
      3   0
      4   $ xmllint --xpath 'count(//Record[normalize-space(IndividualSurvey/Education)="Bachelors"])' $F
      5   21



                     stored in all 5,356 surveys:        "Bachelors␣"
                                       asked for:        "Bachelors"          → 0 rows, no error


     Zero rows is a result, not an error
     Normalise before comparing: XPath normalize-space() · pandas .str.strip() · KNIME
     String Manipulation, strip(). A surprising zero: look at the raw values.

17                           Text table         Tree                Binary              Meaning
~~~~

## Page 018

[Original page 18](../../../quellen/Unit03_slides_en.pdf#page=18)

~~~~text
                                                                        FROM DATA TO A REPORT: XSLT

     Data/invoice_pull.xsl, its one template
                                                                                         Invoice INV-43659
      1 <xsl:template match="/inv:Invoice">                                              Better Bike Shop
      2 <h1>Invoice <xsl:value−of select="@invoiceNo"/></h1>
      3 <p><xsl:value−of select="inv:Customer/inv:Name"/></p>                            Mountain-100 Black, 44    6074.9820
      4 <table>                                                                          Mountain-100 Silver, 44   4079.9880
      5 <xsl:for−each select="inv:Items/inv:Item">                                       Mountain-100 Silver, 38   2039.9940
      6   <xsl:sort select="inv:LineTotal" data−type="number"                            . . . 9 more rows
      7         order="descending"/>                                                     Lines: 12, sum: 20565.6206
      8   <tr><td><xsl:value−of select="inv:ProductName"/></td>
      9     <td><xsl:value−of select="inv:LineTotal"/></td></tr>                xsltproc invoice_pull.xsl invoice_43659.xml, opened in
     10 </xsl:for−each>                                                                               a browser
     11 </table>
     12 <p>Lines: <xsl:value−of select="count(inv:Items/inv:Item)"/>,           XSLT: a template matches an XPath
     13   sum: <xsl:value−of
     14        select="sum(inv:Items/inv:Item/inv:LineTotal)"/></p>             pattern, then sorts, counts, sums.
     15 </xsl:template>
                                                                                A report, not a dashboard: one ﬁxed
                                                                                document per order or month — to mail,
                                                                                print, archive (also as PDF).
                                                                                 XSLT = Extensible Stylesheet Language Transformations. Run
                                                                                         it: xsltproc, Python lxml, KNIME node XSLT.
       spec: w3.org/TR/xslt-10



18                                    Text table                Tree         Binary                 Meaning
~~~~

## Page 019

[Original page 19](../../../quellen/Unit03_slides_en.pdf#page=19)

~~~~text
                                               A STYLESHEET IS RULES, NOT A SCRIPT


     Nothing runs top to bottom: the processor walks the source tree node by node and runs
     the template that matches each node.
     Pull      for-each                  your template walks the tree itself (previous slide)
     Push      apply-templates           each child goes back to the processor to ﬁnd its rule

     No template of yours matches? Then two built-in rules apply — every stylesheet has them:
       1   <xsl:template match="*|/"> <xsl:apply−templates/> </xsl:template>
       2   <xsl:template match="text()"> <xsl:value−of select="."/> </xsl:template>

     line 1:    an element is not skipped: go on to its children
     line 2:    a text is printed
     Rules that match nothing still give output: all the text, no tags (next slide).
     spec: w3.org/TR/xslt-10, 5.8 Built-in Template Rules




19                              Text table            Tree           Binary           Meaning
~~~~

## Page 020

[Original page 20](../../../quellen/Unit03_slides_en.pdf#page=20)

~~~~text
                                   NO MATCH, NO ERROR: THE NAMESPACE TRAP

     invoice_no_prefix.xsl: the push stylesheet, the preﬁx         Output (ﬁrst 4 of 55 lines):
     inv: left out
                                                                     1   Adventure Works Cycles
     1 <xsl:template match="/Invoice">                               2    Better Bike Shop
     2 <h1>Invoice <xsl:value−of select="@invoiceNo"/></h1>
     3 <table><xsl:apply−templates select="Items/Item"/></table>     3    42525 Austell Road, Austell, Georgia
     4 </xsl:template>                                               4     Mountain-100 Black, 42
     5 <xsl:template match="Item">
     6 <tr><td><xsl:value−of select="ProductName"/></td></tr>
     7 </xsl:template>


      The invoice’s elements live in the namespace http://example.com/invoice. /Invoice without a
      preﬁx asks for an Invoice in no namespace — so neither rule matches, the built-in rules take over
      and print every text value.

      No <h1>, no table, no warning
      Bind the namespace to a preﬁx (xmlns:inv="...") and use it in every path: /inv:Invoice,
      inv:Item.
      Try it: Data/invoice_push.xsl, invoice_pull.xsl, invoice_no_prefix.xsl; Scripts/awc_xslt_demo.sh runs
      all three.
20                           Text table       Tree              Binary            Meaning
~~~~

## Page 021

[Original page 21](../../../quellen/Unit03_slides_en.pdf#page=21)

~~~~text
                                                                                                       JSON VS. XML

     Data/invoice_43659.json, excerpt: 1 of 12 items, 5
     keys left out                                                                        XML                    JSON
       1   {                                                             types            from the XSD:          six: string,
      2        "invoiceNo": "INV-43659",                                                  date, decimal, . . .   number, boolean,
      3        "invoiceDate": "2011-05-30",                                                                      null, array, object
      4        "customer": {"name": "Better Bike Shop"},                 comments         yes                    no
      5        "items": [
                                                                         schema           XSD, checked by        JSON Schema,
      6           {"productName": "Mountain-100 Black, 44",
      7            "quantity": 3,                                                         a validator            optional
      8            "unitPrice": 2024.994,
      9            "lineTotal": 6074.982}                                 • the date is just a string
      10       ],
      11       "subTotal": 20565.6206
                                                                          • money is a ﬂoat: 6074.9820 → 6074.982; all
      12   }                                                                121,317 AWC lines summed in ﬂoats miss by
                                                                            0.0002
                                                                          • optional schema = usually no schema
      spec: rfc-editor.org/rfc/rfc8259 · json-schema.org/specification



21                                 Text table          Tree                      Binary              Meaning
~~~~

## Page 022

[Original page 22](../../../quellen/Unit03_slides_en.pdf#page=22)

~~~~text
                                                                            AWC BASKETS AS JSON

      1    { "root": [
      2       { "customer_id": 676,
      3         "sales_order_id": 43659,
      4         "products_bought_SplitResultList": [
      5           "Helmets-711", "Socks-709", "Jerseys-714", "Jerseys-716",
      6           "Mountain Bikes-771", "Mountain Bikes-772", "Mountain Bikes-773",
      7           "Mountain Bikes-774", "Mountain Bikes-776", "Mountain Bikes-777",
      8           "Mountain Bikes-778", "Caps-712" ] },
      9       { "customer_id": 117,
     10         "sales_order_id": 43660,
      11        "products_bought_SplitResultList": [ "Road Bikes-758", "Road Bikes-762" ] }
     12    ]}

     Data/awc_basket.json: 2 of 997 orders, 1 to 35 products each.
      • A natural hierarchy: one order, many products, order ﬁelds written once.
      • "Mountain Bikes-771" = two variables in one string (subcategory, ProductID) — U01’s untidy
        pattern.


22                             Text table          Tree                 Binary                Meaning
~~~~

## Page 023

[Original page 23](../../../quellen/Unit03_slides_en.pdf#page=23)

~~~~text
                                     JSONPATH AND JQ: THE SAME THREE IDEAS


                     JSONPath expression                                                             Result
     path            $.root[0].sales_order_id                                                        43659
     predicate       $.root[?(@.customer_id==676)].sales_order_id                                    [43659, 44305]
     all entries     $.root[2].products_bought_SplitResultList[*]                                    15 products

       1   $ jq '.root | length' awc_basket.json                      # 997 orders
       2   $ jq '[.root[].products_bought_SplitResultList | length] | add' awc_basket.json # 4029

     Path, predicate, function again — other punctuation, same ideas. Learn the ideas, look up
     the syntax.
     jq = a command-line JSON tool. KNIME’s JSON Path node takes these JSONPath expressions.
     spec: rfc-editor.org/rfc/rfc9535 (JSONPath) · jqlang.org/manual (jq)




23                              Text table            Tree                  Binary         Meaning
~~~~

## Page 024

[Original page 24](../../../quellen/Unit03_slides_en.pdf#page=24)

~~~~text
                                                                                                                              FLATTENING BACK TO TIDY
     The file                                           {"root": [ …,
     one document; the orders sit in the                  {"sales_order_id": 43660, "customer_id": 117,
     array root. Each order nests a list,
                                                                                                                                          Analysis wants one row per
                                                           "products_bought_SplitResultList":
     each list entry packs two facts.                           ["Road Bikes-758", "Road Bikes-762"] },
                                                          … ] }

                                                                                                                                          observation (U01’s tidy data).
     1 One row per order
     select the array’s elements
                                                        json                                                                              Check the row count after each
                                                                                                                                          step: 997 orders → 4,029
     KNIME JSON Reader, Select with JSONPath            {"sales_order_id": 43660, "customer_id": 117, "products…": […]}
     $.root[*]
     Python for order in doc["root"]
     997 rows                                                                                                                             products.
     2 Fields become columns
     one path per field; the list stays a list,
                                                        sales_order_id     customer_id     product (list)
                                                                                                                                          Tools per step: in the ﬁgure (Python
                                                                                                                                          and KNIME).
     in one cell                                        43660              117             [Road Bikes-758, Road Bikes-762]
     KNIME JSON Path
     Python order["customer_id"], …
     997 rows



                                                                                                                                          Lossy in one direction
     3 Unnest: one row per list entry                   sales_order_id     customer_id     product
     the order’s fields are repeated on
     every row                                          43660              117             Road Bikes-758



                                                                                                                                          only
     KNIME Ungroup
                                                        43660              117             Road Bikes-762
     Python for packed in order[…]
     4,029 rows



     4 Unpack: one fact per column                      sales_order_id     customer_id     subcategory              product_id            Grouping by sales_order_id
     split at the hyphen; safe only because
     no subcategory contains one
     KNIME Cell Splitter, -
                                                        43660              117             Road Bikes               758
                                                                                                                                          rebuilds all 997 baskets, because
                                                                                                                                          the key survived. Drop the key and
                                                        43660              117             Road Bikes               762
     Python packed.rpartition("-")
     4,029 rows: tidy


         The key travels along: grouping by sales_order_id rebuilds every basket.
                                                                                                                                          the hierarchy is gone for good.
         The nested, packed value, until it is one fact per cell.




24                                                Text table                               Tree                                  Binary          Meaning
~~~~

## Page 025

[Original page 25](../../../quellen/Unit03_slides_en.pdf#page=25)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit03_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit03_slides_en.pdf#page=26)

~~~~text
             Break
           10 minutes




Then: Binary Formats: Parquet and HDF5
~~~~

## Page 027

[Original page 27](../../../quellen/Unit03_slides_en.pdf#page=27)

~~~~text
     STEP 3: TYPED AND FAST — BINARY FORMATS


       Text table   Tree    Binary   Meaning




27
~~~~

## Page 028

[Original page 28](../../../quellen/Unit03_slides_en.pdf#page=28)

~~~~text
                                        PARQUET: A TABLE STORED BY COLUMN

     Text and tree formats store row by row. Parquet stores column by column — because
     analysis asks about columns: the sum of LineTotal, not everything about order line 17.

                                                                                                   D = OrderDate
                   row by row (CSV) D1   P1   L1     D2 P2   L2   D3 P3    L3    D4 P4     L4      P = ProductID
                                                                                                   L = LineTotal
                                                                                                   1–4 = order line
         column by column (Parquet) D1   D2 D3 D4       P1   P2 P3 P4      L1    L2   L3   L4

                                                                  SUM(LineTotal) reads only this block


     • read one column without passing the others             AWC ﬂat table, 121,317 × 25:
     • types are kept: a date stays a date                                                          CSV        Parquet
     • similar values side by side compress well;             ﬁle size                          24.6 MB         2.9 MB
       min/max per block lets a reader skip blocks            read speed                             1×          ≈15×
                                                              dates read back as                    text         dates
     Binary: no editor, no grep. Python pd.read_parquet; KNIME Parquet Reader.
     Scripts/awc_formats_compare.py, best of 5 runs.

28                         Text table         Tree                Binary              Meaning
~~~~

## Page 029

[Original page 29](../../../quellen/Unit03_slides_en.pdf#page=29)

~~~~text
                                                      HDF5: BIG ARRAYS, READ IN CHUNKS

     HDF5 stores n-dimensional arrays with their metadata in one ﬁle, cut into chunks. A chunk
     is always read and unpacked whole, even for one cell — so the chunk shape should follow
     how you read. Example: 5,000 × 5,000 customer distances (U06), read one row:
           the row we read   chunks unpacked for it

                                                              chunk shape                     ﬁle     1 row
                                                              256 × 256                   19.9 MB   21.8 ms
                                                              1 row per chunk             26.3 MB    0.2 ms

                                                              Square chunks compress better; row chunks
                                                              read a row 100× faster. Columns would need
          square chunks          one row per chunk            the opposite.
            256 × 256

     Where you meet it: MATLAB .mat (v7.3) and NetCDF-4 (climate and weather data) are
     HDF5 inside; Python h5py. Parquet for tables read by column, HDF5 for arrays read in
     slices.

29                           Text table               Tree      Binary          Meaning
~~~~

## Page 030

[Original page 30](../../../quellen/Unit03_slides_en.pdf#page=30)

~~~~text
                                                                      ALL SIX, SIDE BY SIDE

     The same 4,029 order lines × 4 columns (the ﬂattened baskets) in every format, read back into a
     DataFrame. Both relative to CSV = 1:
             ﬁle size                                      read time (log scale)
                CSV        1.00                                CSV        1
                XML                                 5.73       XML                          30
               JSON                   3.43                    JSON                3.6
              YAML                    3.43                   YAML                                  420
             Parquet    0.20                                Parquet       1.0
               HDF5            1.56                           HDF5          1.4
                                                                      1            10        100   1000


      • Same information, a 28-fold spread in size (Parquet 0.20 vs XML 5.73): JSON and XML repeat
        every key or tag on every record, CSV writes the names once.
      • YAML reads 420× slower than CSV (yaml.safe_load, pure Python). Fine for a 40-line conﬁg,
        wrong for data.
      • At this size Parquet is no faster than CSV; at 121,317 rows it was ≈15×. Measure at your own
        scale.
30                       Text table          Tree           Binary                      Meaning
~~~~

## Page 031

[Original page 31](../../../quellen/Unit03_slides_en.pdf#page=31)

~~~~text
                                                                      CHOOSING A FORMAT

      Reader / situation                       Choose        Because
      data scientist in Python or KNIME        Parquet       types kept, small, read by column
      business analyst in Excel                CSV           opens by double-click
      50 million rows, ML pipeline             Parquet       read only the columns and blocks needed
      conﬁg or metadata, hand-edited           YAML          comments, readable; quote text
      web API                                  JSON          every language reads it; nests naturally
      contract with a partner (e-invoice)      XML + XSD     the partner can validate every document
      big arrays; MATLAB, NetCDF users         HDF5          chunked slices


     Three questions decide it
     Who reads it: a program or a person? How big, and read how: all of it, a few columns, a slice? Must
     the ﬁle enforce the rules: types, structure, required ﬁelds — or may every reader guess them?

     Even Parquet does not say what a column means, where it came from, or who may use it. That is
     step 4.

31                         Text table       Tree             Binary            Meaning
~~~~

## Page 032

[Original page 32](../../../quellen/Unit03_slides_en.pdf#page=32)

~~~~text
     STEP 4: WHAT NO FORMAT SAYS — METADATA


       Text table   Tree   Binary   Meaning




32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit03_slides_en.pdf#page=33)

~~~~text
                                               METADATA: WHAT THE DATA MEANS

     Metadata is data about the data: where it came from, and what each column means. It
     travels as a ﬁle next to the data, so the next reader need not ask.
                                                        1   columns:
                                                        2    - name: LineTotal
     awc_flat.metadata.yaml, next to awc_flat.csv       3     type: decimal(38,6)
                                                        4     unit: USD
     dataset         name, version, licence             5     meaning: >
                                                        6       Revenue of one order line, OrderQty *
     provenance   source, query, who, when
                                                        7       UnitPrice * (1 - UnitPriceDiscount).
     columns      name, type, unit, meaning             8       Sum this, not SubTotal.
                                                        9   known_issues:
     known_issues observed, status, impact             10    - id: SALESPERSON-ONLINE
                                                       11     observed: SalesPersonID is empty on all
     fair               F, A, I, R: 1–3 each
                                                       12       60,398 online order lines
                                                       13     status: explained
                                                       14     impact: keep it empty; never ﬁll it with 0

     USD because every rate in Sales_CurrencyRate converts from USD. Record unﬁxed problems too:
     unresolved is a status, silence is not. In companies, data catalogs do this job for every table.
33                         Text table          Tree          Binary               Meaning
~~~~

## Page 034

[Original page 34](../../../quellen/Unit03_slides_en.pdf#page=34)

~~~~text
                                   YAML: THE FORMAT FOR THE METADATA FILE

     1   # awc_ﬂat.metadata.yaml (excerpt)
                                                             Why YAML here: the metadata ﬁle is written and
     2   columns:                                            read by people. YAML is JSON’s tree with
     3    - name: LineTotal     # one entry per column       comments, without brackets; also used for
     4     type: decimal(38,6)                               conﬁguration ﬁles.
     5     unit: USD                                         Syntax: indentation is structure (no tabs), #
     6     description: >
                                                             comment, - list item, > folds lines into one string.
     7       Revenue of one order line.
     8       Sum this for revenue, not SubTotal.

     But YAML guesses types — a reader gets back something other than you wrote:
     YAML, unquoted                           safe_load returns
     invoiceDate: 2011-05-30                  datetime.date(2011, 5, 30)     a date (JSON has none)
     PostalCode: 01071                        569                            octal number: Dresden is gone
     country: NO                              False                          Norway becomes “no”
     Quote what is text: "NO" and "01071" stay strings (PyYAML follows YAML 1.1, where YES, ON, OFF are
     booleans too).
     spec: yaml.org/spec/1.2.2

34                               Text table         Tree            Binary            Meaning
~~~~

## Page 035

[Original page 35](../../../quellen/Unit03_slides_en.pdf#page=35)

~~~~text
                                                 PROVENANCE: ONE ORDER, THREE DATES

                           2025-01-10
                           old hand-typed
                          teaching sample                            Three ﬁles in this course carry order 43659, with




                                             sa oth
                                                                     three different dates. None says where it came
                          er ,
                        rd er




                                               m er
                     r o mb




                                                e or
                                                                     from, or which AdventureWorks it is; re-exports




                                                  nu de
                  he u
                ot e n




                                                    m r
                                                     be
                    m




                                  order                              change things on the way.
                 sa




                                                        r,
                                  43659                third-party   One day does not matter for a monthly total and
       our MySQL                                                     decides a daily count. From the ﬁles alone, the
                                                        re-export
     Adventureworks2019
                                  same order,           for Neo4j    question cannot be answered (U05 comes back
      DATE(OrderDate)            one day apart          orders.csv   to it).
     2011-05-30
                                                     5/31/2011

     The provenance record
     Your extract script already writes who, when, which query, rows, SHA-256 (U02). Add what
     no script knows: which source, which release — afterwards it cannot be reconstructed.

35                                  Text table               Tree      Binary            Meaning
~~~~

## Page 036

[Original page 36](../../../quellen/Unit03_slides_en.pdf#page=36)

~~~~text
                                              FAIR: A CHECKLIST FOR SHARED DATA


     FAIR (Wilkinson et al. 2016): data should be Findable, Accessible, Interoperable and
     Reusable. Research funders require it. Scored 1–3 for our extract awc_flat.csv:
                       What it requires                  Score   The artefact we are missing
     Findable          a persistent identiﬁer             2      no DOI or stable URL, only a course share
     Accessible        an open way to get it              3      — (a plain ﬁle, open tools)
     Interoperable     shared formats and                 2      countries use ISO 3166 codes, but Category
                       codes                                     and TerritoryName are free text
     Reusable          licence, provenance,               2      provenance is recorded; the licence of this
                       dictionary                                MySQL port is stated nowhere
     Score: 1 = missing · 2 = partial · 3 = met

     Name the missing artefact: a score without it can be neither checked nor ﬁxed. A
     self-assessment that scores itself 3/3/3/3 is not an assessment.


36                           Text table           Tree             Binary            Meaning
~~~~

## Page 037

[Original page 37](../../../quellen/Unit03_slides_en.pdf#page=37)

~~~~text
                                                                EVERY COPY LIVES ITS OWN LIFE

                                                                    Data pass through six phases, and each
                          creation                                  has a typical risk. The metadata ﬁle
                      nobody writes down
                      what a ﬁeld means
                                                                    answers the ﬁrst four; the last two are
      deletion                             processing               about copies: every extract, backup and
     copies survive                       a change reaches          dashboard cache is one more.
      the deletion                       some copies, not all

                                                                    Delete this customer
                                                                    The right to erasure (GDPR Art. 17) is not
      archiving                              analysis
     a format tools                          wrong join,            one DELETE: it reaches every copy you ever
     misread later                           wrong sum              made — and a model trained on the data
                        publication                                 still carries it (Cao & Yang 2015). Whether
                          no licence,
                                                                    you can honour the right is decided by
                         no dictionary
                                                                    your architecture.



37                          Text table                Tree            Binary          Meaning
~~~~

## Page 038

[Original page 38](../../../quellen/Unit03_slides_en.pdf#page=38)

~~~~text
                                    PERSONAL DATA HIDES IN COMBINATIONS

     awc_flat.csv holds no names — but CustomerID leads to a person, and the survey (the XML from
     step 2) holds BirthDate, Gender, MaritalStatus, YearlyIncome, Education, Occupation. Each is a
     quasi-identiﬁer: harmless alone, identifying in combination. The GDPR (Art. 4) asks whether a
     person is identiﬁable, not whether a name appears.

            share of the 18,484 surveyed customers who are unique
                        exact birth date alone             15.7 %
               exact birth date + the 5 others                                            91.8 %
                      birth year + the 5 others     2.4 %
                  birth decade + the 5 others      0.5 % (100)
                  decade + gender + income         4 people
                              decade + gender      nobody: k = 8


     k-anonymity (Sweeney 2002): k = the size of the smallest group of records that agree on all
     quasi-identiﬁers; k = 1 means somebody is unique. Coarsening one attribute helps a lot — yet k
     stays 1 until four of the six are dropped.

38                         Text table             Tree              Binary    Meaning
~~~~

## Page 039

[Original page 39](../../../quellen/Unit03_slides_en.pdf#page=39)

~~~~text
                                          ANONYMOUS OR ONLY PSEUDONYMOUS?


                                                  pseudonymised                          anonymous
                 personal                                                           nobody re-identiﬁable
                 name, or                         ID replaced by a
                                                 key or hash — can                   with means reason-
            CustomerID + survey                                                     ably likely to be used
                                                   be linked back

                          the GDPR applies (Art. 4(5))                    the GDPR no longer applies (Recital 26)


     Hashing CustomerID is pseudonymisation, not anonymisation: hashing every number up
     to the highest ID takes 17 ms, and then every hash is reversed. Anonymous is a high bar,
     rarely reached — the combinations on the previous slide show why.
     For your project: keep only the columns the question needs, coarsen what you keep (date
     → year), and say in the metadata ﬁle whether the data are personal.
     Beyond k-anonymity: ℓ-diversity (the sensitive value must vary inside each group) and differential privacy (a
     formal guarantee). Each closes a gap of the one before.


39                           Text table          Tree                Binary               Meaning
~~~~

## Page 040

[Original page 40](../../../quellen/Unit03_slides_en.pdf#page=40)

~~~~text
            Break
          10 minutes




Then: Hands On — Formats & Metadata
~~~~

## Page 041

[Original page 41](../../../quellen/Unit03_slides_en.pdf#page=41)

~~~~text
                 HANDS ON — EXERCISES 3 AND 4
                                         20 minutes
                       Sheet on Moodle: Unit03_Exercises_en.pdf

     The room splits: measure the formats, or describe your data. Bring numbers, not estimates.




41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit03_slides_en.pdf#page=42)

~~~~text
                                                                 KEY MESSAGES


     • Text table: a CSV records none of its assumptions — name encoding, separator,
       decimal mark and types yourself; the worst failures are silent (04139 → 4139)
     • Tree: XML with an XSD is a contract the ﬁle enforces, JSON has none; query
       trees with path, predicate, function, render reports with XSLT, and ﬂatten back
       to one row per observation — a zero result is no error
     • Binary: Parquet keeps types and reads by column, HDF5 reads arrays in
       chunks; the same data differ 28-fold in size — measure at your scale
     • Meaning: no format says what a column means — a metadata ﬁle does:
       dictionary, provenance, known issues, FAIR; personal data hide in
       combinations, and a hash is only a pseudonym
     • Next: U04 — data quality: proﬁling, then cleaning with reasons


42                   Text table     Tree           Binary         Meaning
~~~~

## Page 043

[Original page 43](../../../quellen/Unit03_slides_en.pdf#page=43)

~~~~text
                              SOURCES (1/2): DATA, PRIVACY & STORAGE

     • Wilkinson et al. (2016), The FAIR Guiding Principles for scientiﬁc data management and
       stewardship, Scientiﬁc Data 3:160018 doi.org/10.1038/sdata.2016.18
     • Sweeney (2002), k-Anonymity: A Model for Protecting Privacy, Int. J. Uncertainty, Fuzziness and
       Knowledge-Based Systems 10(5):557–570 — the measure used here
       doi.org/10.1142/S0218488502001648
     • Machanavajjhala et al. (2007), ℓ-diversity: Privacy beyond k-anonymity, ACM TKDD 1(1):3 — why
       k-anonymity alone is not enough doi.org/10.1145/1217299.1217302
     • Dwork (2006), Differential Privacy, ICALP, LNCS 4052:1–12 — a formal privacy guarantee
       doi.org/10.1007/11787006_1
     • Cao & Yang (2015), Towards Making Systems Forget with Machine Unlearning, IEEE Symp.
       Security & Privacy, 463–480 — deleting data from a trained model doi.org/10.1109/SP.2015.35
     • Abadi, Boncz & Harizopoulos (2013), The Design and Implementation of Modern Column-Oriented
       Database Systems, Foundations and Trends in Databases 5(3):197–280 — why columns win
       doi.org/10.1561/1900000024
     • Melnik et al. (2010), Dremel: Interactive Analysis of Web-Scale Datasets, PVLDB 3(1–2):330–339
       — how Parquet stores nested data doi.org/10.14778/1920841.1920886
43
~~~~

## Page 044

[Original page 44](../../../quellen/Unit03_slides_en.pdf#page=44)

~~~~text
                                         SOURCES (2/2): THE SPECIFICATIONS

     • CSV — RFC 4180 (Informational): describes common practice rfc-editor.org/rfc/rfc4180
     • XML — W3C XML 1.0 (5th ed.) w3.org/TR/xml + Namespaces w3.org/TR/xml-names
     • XSD — W3C XML Schema Deﬁnition Language 1.1, Part 1: Structures w3.org/TR/xmlschema11-1
     • XPath 1.0 and XSLT 1.0 — the versions xmllint and xsltproc implement w3.org/TR/xpath-10 +
       w3.org/TR/xslt-10
     • XRechnung — KoSIT’s viewer renders e-invoices to HTML and PDF with XSLT
       github.com/itplr-kosit/xrechnung-visualization
     • JSON — RFC 8259, the interchange rules (the grammar is also ECMA-404) rfc-editor.org/rfc/rfc8259
     • JSON Schema — JSON’s optional contract, the counterpart of XSD json-schema.org/specification
     • JSONPath — RFC 9535 (2024), standardised after the tools: expect dialects rfc-editor.org/rfc/rfc9535
     • jq — the manual is the language deﬁnition jqlang.org/manual
     • YAML — YAML 1.2.2; PyYAML, used here, follows YAML 1.1 yaml.org/spec/1.2.2 +
       pyyaml.org/wiki/PyYAMLDocumentation
     • Parquet — Apache format speciﬁcation: row groups, pages, encodings, the footer
       parquet.apache.org/docs/file-format
     • HDF5 — The HDF Group’s documentation; h5py, the Python API used here
       support.hdfgroup.org/documentation/hdf5/latest + docs.h5py.org
     • NetCDF-4 — Unidata’s ﬁle-format speciﬁcation: a scientiﬁc-data standard built on HDF5
       docs.unidata.ucar.edu/netcdf-c/current

44
~~~~
