---
source_id: DS-U03-EX
original_file: Unit03_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: 27dc79c773155367733230712848f609286375d26e55473e9ac6274a84110dca
verification: partial
---
# Unit03_Exercises_en

[Original PDF](../../../quellen/Unit03_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit03_Exercises_en.pdf#page=1)

<a id="ds-u03-ex-t01"></a>

**DS-U03-EX-T01 — Break a CSV, Then Diagnose It**

<a id="ds-u03-ex-t02"></a>

**DS-U03-EX-T02 — Hierarchy, Both Directions**

~~~~text
  Unit 03 — Exercises                                                                                   Formats & Metadata
Break a ﬁle on purpose, measure what a format costs, and describe your data.
▶ In the room  what ﬁts the stop — all that is expected. The room splits: at each stop take one of the two exercises; you
               hear the other one in the discussion.
⃝ Extra        voluntary, at home.
Stop A, 20 min Exercise 1 or 2     Stop B, 20 min: Exercise 3 or 4
Asynchronous the same sheet, before your weekly slot; bring what did not run.
You need       your ﬂat table AWC/awc_flat.csv, the database connection from Unit 02, the unit’s Data/ and Scripts/
               folders. KNIME: the Big Data File Formats extension; take Exercise 1 at stop A (Exercise 2 needs lxml or
               xmllint).


Exercise 1 — Break a CSV, Then Diagnose It stop A · ▶ 20 min · or Exercise 2
 1 Export SELECT DISTINCT City FROM Person_Address to cities.csv (UTF-8). Read it three times and compare:
       ref = pd.read_csv("cities.csv", encoding="utf-8")
       for enc in ["latin-1", "utf-8-sig"]:
           other = pd.read_csv("cities.csv", encoding=enc)
           print(enc, sorted(set(other.City) - set(ref.City)))            # names that changed
    Which names change? Which reading is correct — and how do you know?
 2 Write a CSV with one ﬁeld that contains your separator and a quote, e.g. Bike, "Pro" model. Read it back. What did
   you have to specify?
 3 Numbers have a format too. Save 20 rows of your ﬂat table with UnitPrice and LineTotal as CSV (English format:
   2024.994) and open it in LibreOfﬁce Calc or Excel with a German import setting (Calc: Language German in the import
   dialog; Excel: a German system). What happens to 2024.994, and to 4.99? Then the other way round: read a German
   CSV (; between ﬁelds, 2.024,994) with pandas — what do you have to specify?
  In KNIME
  DB Query Reader → CSV Writer; then two CSV Readers, File encoding UTF-8 and ISO-8859-1 (advanced settings). A Joiner on City
  that keeps unmatched rows shows what changed. Step 2: the value from a Table Creator, written and read back. Which settings
  make it work? Then set the writer’s Quote values to never.
⃝ Extra: (a) Write a CSV with lineterminator="\r"; compare len(text.split("\n")) with len(pd.read_csv(...)). (b)
Read your ﬂat table and look at the type of SalesPersonID. Fix it with dtype= — what would have broken later? Kit:
Scripts/awc_csv_traps.py.

Exercise 2 — Hierarchy, Both Directions stop A · ▶ 20 min · or Exercise 1
 1 Generate the invoice XML for one of your own orders and validate it:
       python3 Scripts/awc_invoice_xml.py 43659          # your SalesOrderID
       xmllint --noout --schema Data/invoice.xsd invoice_43659.xml     # or Data/validate.sh
    In Python, xml.etree does not check a schema; lxml does:
       schema = etree.XMLSchema(etree.parse("Data/invoice.xsd"))
       print(schema.validate(etree.parse("invoice_43659.xml")), schema.error_log)

 2 Make it fail — one change is enough. Write down the exact error message.
 3 Flatten Data/awc_basket.json to a table: one row per product bought, the packed value "Mountain Bikes-771" split
   into SubCategory and ProductID. You must get 4,029 rows.
  Example — the ﬁrst order, before and after

  {"customer_id": 676,                                         sales_order_id   customer_id   SubCategory   ProductID
   "sales_order_id": 43659,
   "products_bought_SplitResultList":                                  43659           676    Helmets               711
     ["Helmets-711", "Socks-709", ...]}                                43659           676    Socks                709
                                                                          ...
  One row per order → one row per list entry (unnest) → one column per fact (unpack). Check the row count after each step.

  In KNIME
  JSON Reader (Select with JSONPath $.root[*]) → JSON Path with three paths: $.sales_order_id, $.customer_id,
  $.products_bought_SplitResultList[*] (list) — replace the default $..* → Ungroup → Cell Splitter on -. More than 4,029
  rows: a path is still on $..*.
⃝ Extra: (a) Break the XML a second way, so one break is about structure and one about a value’s type. (b) Three
XPath queries on Data/records_simplified.xml — a count, a ﬁlter on a number, a ﬁlter on a string — then leave
out normalize-space() in the string one (kit: Scripts/awc_xpath.sh). (c) Group the 4,029 rows back into bas-
kets: do you get the JSON back? Kit: Scripts/awc_json_flatten.py. (d) Turn an invoice into a report with XSLT:
Scripts/awc_xslt_demo.sh and the stylesheets Data/*.xsl.


Unit 03 · Data Science · exercise sheet                                                                                          1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit03_Exercises_en.pdf#page=2)

<a id="ds-u03-ex-t03"></a>

**DS-U03-EX-T03 — Measure, Do Not Believe**

<a id="ds-u03-ex-t04"></a>

**DS-U03-EX-T04 — Describe Your Data**

~~~~text
Exercise 3 — Measure, Do Not Believe stop B · ▶ 20 min · or Exercise 4
 1 Write your ﬂat table as CSV, gzipped CSV, JSON and Parquet. Fill in the table: ﬁle size and read time. The code for CSV
   is given — do the other three the same way.
      Example — CSV, and the table to ﬁll

      df.to_csv("t.csv", index=False)                                            format                           size      read time
      size = Path("t.csv").stat().st_size / 1e6     # MB
      t0 = time.perf_counter(); pd.read_csv("t.csv")                             CSV                           . . . MB           . . . ms
      ms = (time.perf_counter() - t0) * 1000                                     CSV + gzip
                                                                                 JSON (orient="records")
                                                                                 Parquet

 2 Your JSON is larger than your CSV. Explain it by what is repeated.
 3 Read one column from Parquet, then all columns: report the ratio of the times. Do the same with CSV (usecols=). Why
   is the gain smaller?
  In KNIME
  CSV Writer, a second one with Compress ﬁle (gzip), Parquet Writer; one reader per ﬁle, executed twice, then Timer Info. For
  JSON’s shape, Row Filter (3 rows) → Table to JSON is enough; step 3 comes from the Python group. Parquet not faster in
  KNIME? Think about what every KNIME reader builds.
⃝ Extra:read the ﬂat table with parse_dates=["OrderDate", "ShipDate"], write CSV and Parquet, read both back: which
columns have a different type now? Kit: Scripts/awc_formats_compare.py.
Exercise 4 — Describe Your Data stop B · ▶ 20 min · or Exercise 3
 1 Write  a metadata ﬁle awc_flat.metadata.yaml                   next   to   your   extract.   Start   from    the       kit’s     example
    Scripts/awc_metadata.yaml and make it yours:
    • provenance: source and release, who extracted it, when, which query, rows, and the ﬁle’s sha256 (copy it from
      awc_flat.provenance.json, or run sha256sum / Get-FileHash on the CSV);
    • a data dictionary for three columns, one of them LineTotal: name, type, unit, meaning;
    • one known issue you met in this or the last unit, with a status (unresolved is a status);
    • a FAIR score, 1–3 per principle, each with the thing that is missing.
 2 Load it with yaml.safe_load and check that every value came back with the type you meant (a number as int, a date
   as text or date — as you intended).
 3 Does your extract hold personal data? Argue from identiﬁability: which columns lead to a person, alone or combined —
   not whether a name appears.
  In KNIME
  Step 2 in a Python Script node (bundled Python; any table at its input):
  import yaml, pandas as pd, knime.scripting.io as knio
  def walk(x, k=""):                  # every value, with its key and type
      if isinstance(x, dict):    items = x.items()
      elif isinstance(x, list): items = enumerate(x)
      else:                      return [(k, repr(x), type(x).__name__)]
      return [r for kk, v in items for r in walk(v, f"{k}.{kk}")]
  d = yaml.safe_load(open("/path/to/awc_flat.metadata.yaml"))
  knio.output_tables[0] = knio.Table.from_pandas(pd.DataFrame(walk(d), columns=["key", "value", "type"]))

⃝ Extra:   compute k (the size of the smallest group sharing the same values) for two sets of columns in
Data/records_simplified.xml (100 customers). Then export the full survey (SELECT BusinessEntityID, Demographics
FROM Person_Person) to AWC/awc_demographics.csv and run Scripts/awc_kanonymity.py. Why do the two results dis-
agree?

What to have ready
Show it and talk it through — in the room or in your weekly slot:
• Ex 1: the city names that changed, and how you decided which reading is right; what the German import did to 2024.994
• Ex 2: one validated XML, the error message you provoked, the basket at 4,029 rows
• Ex 3: your format table, and the one-column / all-columns ratio
• Ex 4: your metadata ﬁle, loaded without surprises, and your personal-data argument in two sentences




Unit 03 · Data Science · exercise sheet                                                                                                      2
~~~~
