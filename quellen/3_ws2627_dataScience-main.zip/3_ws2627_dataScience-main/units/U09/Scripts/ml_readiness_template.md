# ML-Readiness Checklist — AWC  *(template)*

The eleven criteria are the ones the lecture walked through. **Keep the criteria, fill the two
right-hand columns**, and add rows if your slice raised something these eleven do not cover.

`Result`: **✓** it holds · **~** partly, with a caveat you state · **×** it does not hold.

**A criterion with no evidence is an opinion.** The evidence column names a number, a table or a
figure you produced, and the unit it came from — not a feeling about the data.

**Find your weakest row.** Mark it × if the evidence says so; if it still holds, say why — that
sentence is the evidence. A ✓ without a number counts as ~. Where a row ends in **~**, the caveat
*is* the evidence: write it down. The `×` and `~` rows are what the go / no-go decision at the bottom weighs.

| # | Criterion | Result | Evidence — *the number, and where it came from* |
|---|---|---|---|
| 1 | one row = one unit of prediction (grain) | | |
| 2 | no information from after the cutoff in the features | | |
| 3 | the split respects time and the independent unit | | |
| 4 | missing values understood | | |
| 5 | scaling chosen and recorded | | |
| 6 | no rank-deficient columns | | |
| 7 | distribution shapes known | | |
| 8 | outliers judged, not deleted | | |
| 9 | source encodings verified | | |
| 10 | personal data handled | | |
| 11 | baseline established before modelling | | |

*Worked example of one filled row, from the course table — yours will hold your own numbers:*

| # | Criterion | Result | Evidence |
|---|---|---|---|
| 8 | outliers judged, not deleted | ✓ | a fence per channel: 0 online, 137 reseller orders above it (3.6 % of reseller orders, 12.6 % of revenue); kept, they are large reseller orders, not errors — U04 |

---

## The decision

**Go / no-go:** …

**Blocking criteria:** the numbers of the rows marked × (and the ~ rows that weigh most), and one
sentence each on what they would break if someone trained a model anyway.

**What would change the decision:** …

**The three things I would do next, in priority order:**

1. …
2. …
3. …
