---
source_id: DS-U09-R-KNIME-CHEATSHEET
original_file: "Scripts/knime_cheatsheet.pdf"
source_type: reference
language: en
page_count: 1
source_sha256: 1056ce0a009738eebac37e48047d4373c46112ea06ea60f324273713967cbaf3
verification: partial
---

# knime_cheatsheet

> Automatische Layout-Textfassung mit Originalseiten als Bildreferenz. Tabellen, Code, Formeln und Diagramme nicht vollständig semantisch normalisiert. Rekonstruktionen sind markiert.

## Page 001

![Originalseite 1](assets/DS-U09-R-KNIME-CHEATSHEET/p001.png)

~~~~text
  KNIME — U09 cheat sheet                                                                                 the pipeline is the content


The reference workﬂow AWC_Customer_Segmentation is 13 nodes, and it is the same pipeline as the Python path, step
for step: extract, derive, normalise, cluster, join the geocodes, present. The tool is only the tool.

The pipeline


                                                           three log transforms

         DB Connector           DB Query Reader            Math Formula ×3                  Normalizer                k-Means




                                   CSV Reader                     Joiner ×2                       Dashboard component
                                ext_geocodes.csv



Inside the dashboard component
    Lat_Lon to Geometry              turns the geocode columns into a mappable geometry
    Geospatial View                  the map. Python-backed — needs the Python Integration
    t-SNE (L. Jonsson)               the 2-D projection. A community extension
    Color Manager ,                  one visual channel per variable — see U08
    Shape Manager
    Row Filter ,                     ×3 ﬁlters — what makes it interactive, not a picture
    Refresh Button Widget
Cannot open the component? You are missing Geospatial Analytics, KNIME Python Integration or t-SNE (L. Jonsson) — see the U00
sheet.

Three things that cost time


 Layout is the painful part                                 1         The geocodes are an enrichment                                3
 The dataﬂow is easy and the arranging is not. Budget your time       ext_geocodes.csv is not in AWC — it came from Nominatim,
 the other way round than you would in Streamlit.                     and 19 of its 181 rows are ﬂagged. City-level map claims are
                                                                      unveriﬁable; state level is safe.
 Normalise before k-Means                                   2
 Otherwise the variable with the widest range decides every
 cluster. The three Math Formula log transforms come ﬁrst for
 the same reason.




  . The honest comparison
  KNIME makes the dataﬂow visible and the layout awkward; Streamlit the reverse. Neither is better — but notice that
  the KNIME graph is the provenance log U03 asked for, while the Streamlit version needs you to write one. That is
  a real argument for this tool, and it is the only place in the course where it applies without qualiﬁcation.



  Whichever tool you pick, the pipeline is the deliverable. Extract, derive, normalise, cluster, enrich, present — in that
                                  order, with the reason for each step written down.
~~~~
