---
source_id: DS-U09-R-ML-READINESS-TEMPLATE
original_file: "Scripts/ml_readiness_template.pdf"
source_type: reference
language: en
page_count: 2
source_sha256: 8c7c49a7f3b891b0a32db77a6a02bfeb263bcc94289d38e65bb2e752910315b1
verification: partial
---

# ml_readiness_template

> Automatische Layout-Textfassung mit Originalseiten als Bildreferenz. Tabellen, Code, Formeln und Diagramme nicht vollständig semantisch normalisiert. Rekonstruktionen sind markiert.

## Page 001

![Originalseite 1](assets/DS-U09-R-ML-READINESS-TEMPLATE/p001.png)

~~~~text
           ML-Readiness Checklist — AWC (template)
                         VL_9_DS/Scripts/ml_readiness_template.md




                                             2026-10-22 19:59


ML-Readiness Checklist — AWC (template)
The eleven criteria are the ones the lecture walked through. Keep the criteria, fill the two
right-hand columns, and add rows if your slice raised something these eleven do not cover.
Result: ✓ it holds · ~ partly, with a caveat you state · × it does not hold.

A criterion with no evidence is an opinion. The evidence column names a number, a table
or a figure you produced, and the unit it came from — not a feeling about the data.
Find your weakest row. Mark it × if the evidence says so; if it still holds, say why — that
sentence is the evidence. A ✓ without a number counts as ~. Where a row ends in **~**, the
caveat is the evidence: write it down. The × and ~ rows are what the go / no-go decision at the
bottom weighs.

                                                                         Evidence — the number, and where it
#         Criterion                                     Result           came from

1         one row = one unit of prediction (grain)
2         no information from after the cutoff in the
          features
3         the split respects time and the independent
          unit
4         missing values understood
5         scaling chosen and recorded
6         no rank-deficient columns
7         distribution shapes known
8         outliers judged, not deleted
9         source encodings verified
10        personal data handled
11        baseline established before modelling



Worked example of one filled row, from the course table — yours will hold your own numbers:

#      Criterion                    Result         Evidence

8      outliers judged, not         ✓             a fence per channel: 0 online, 137 reseller orders above it (3.6
       deleted                                    % of reseller orders, 12.6 % of revenue); kept, they are large
                                                  reseller orders, not errors — U04




                                                        1
~~~~

## Page 002

![Originalseite 2](assets/DS-U09-R-ML-READINESS-TEMPLATE/p002.png)

~~~~text
ML-Readiness Checklist — AWC (template)                   VL_9_DS/Scripts/ml_readiness_template.md




The decision
Go / no-go: …
Blocking criteria: the numbers of the rows marked × (and the ~ rows that weigh most), and
one sentence each on what they would break if someone trained a model anyway.
What would change the decision: …
The three things I would do next, in priority order:
  1. …
  2. …
  3. …




                                            2
~~~~
