---
source_id: DS-U09-EX
original_file: Unit09_Exercises_en.pdf
source_type: exercise
language: en
page_count: 2
source_sha256: f4ea156d5450dd6766503c92cf6add0f720e09f3b2e0a5c46139d4a62af80a00
verification: partial
---
# Unit09_Exercises_en

[Original PDF](../../../quellen/Unit09_Exercises_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit09_Exercises_en.pdf#page=1)

<a id="ds-u09-ex-t01"></a>

**DS-U09-EX-T01 — Three Questions, Then a Layout**

<a id="ds-u09-ex-t02"></a>

**DS-U09-EX-T02 — The Five Numbers**

<a id="ds-u09-ex-t03"></a>

**DS-U09-EX-T03 — Find the Leak**

~~~~text
  Unit 09 — Exercises                                                     Dashboards, Communication, ML-Readiness
Three questions, ﬁve numbers, a base rate, ﬁve checklist rows.
▶ In the room  what ﬁts the stop — all that is expected. The room splits: at each stop take one of the two exercises; you
               hear the other one in the discussion.
⃝ Extra        voluntary, at home.
Stop A, 20 min Exercise 1 or 2     Stop B, 20 min: Exercise 3 or 4
Asynchronous the same sheet, before your weekly slot; bring what did not run.
You need       your ﬂat table AWC/awc_flat.csv and whatever you have aggregated with all semester. Nothing new to
               install.

Exercise 1 — Three Questions, Then a Layout stop A · ▶ 20 min · or Exercise 2 · paper only
 1 Write the three questions a dashboard on your data would answer, and name the reader of each. If two questions have
   different readers, say which one wins.
 2 Sketch the layout on paper: which panel where, and the ﬁlters in one row at the top. Two ﬁlters are usually enough —
   every ﬁlter multiplies the states a reader can reach.
 3 Decide the one number in the largest type, and justify it with your three questions.
⃝ Extra:  (a) For each panel: what does it show when no rows match the ﬁlters, and when only three do? Build the empty
state. (b) Find two dashboards online, one you would defend and one you would not. Name the principle (of the lecture’s
ten) each keeps or breaks; for the bad one, say who is on the screen and what else that could be used for.
Exercise 2 — The Five Numbers stop A · ▶ 20 min · or Exercise 1
 1 From your ﬂat table, print ﬁve numbers — revenue, orders, customers, median order, online share — each with the n it is
   over, on the same line.
      Example — the ﬁrst of the ﬁve lines

      print(f"revenue {flat.LineTotal.sum():,.0f}           n = {len(flat):,} order lines")

    Online share of what? Orders, revenue and order lines give three different shares — say which one you print.
 2 Print the median order with its IQR, and the mean beside it. Which would you report, and why?
  In KNIME
  GroupBy on SalesOrderID (order value = Sum of LineTotal) → Statistics for median and quartiles; the n is the row count of the
  table each number comes from.
⃝ Extra:   put the ﬁve numbers behind one ﬁlter (e.g. channel = Reseller) and check that each still says which ﬁlter it is under.
Exercise 3 — Find the Leak stop B · ▶ 20 min · or Exercise 4 · nothing is ﬁtted
 1 Pick a target and a cutoff month. Say what one row is — a customer or a product — and how many of them have orders
   before the cutoff.
 2 Compute the base rate and write it down, with the cutoff next to it.
      Base rate = share of your population with the positive outcome. Population: the objects with orders before the cutoff. Label = 1
      if the object orders again at or after the cutoff. Base rate = mean of the labels. It is also the accuracy of a model that always
      says “yes” — every later score must beat it.
 3 Name the ﬁve features you would build. For each, one sentence: when was this value knowable? “After the cutoff” is a
   leak.
 4 Name the independent unit: the thing that must sit on only one side of a train/test split.
  In KNIME
  Row Filter on the date (before / at or after the cutoff), GroupBy on CustomerID for each part, a Joiner of the two to set the label.
  Split by ID: Table Partitioner on a table of distinct IDs, then Reference Row Filter.
⃝ Extra: build the ﬁve features and ﬁt a model. Report AUC, not accuracy. Then compute the same features over the whole
period, reﬁt, and explain the new number. Move the cutoff and ﬁt again: how much does the honest AUC move?




Unit 09 · Data Science · exercise sheet                                                                                                   1
~~~~

## Page 002

[Original page 2](../../../quellen/Unit09_Exercises_en.pdf#page=2)

<a id="ds-u09-ex-t04"></a>

**DS-U09-EX-T04 — The Checklist**

<a id="ds-u09-ex-t05"></a>

**DS-U09-EX-T05 — Present, and Be Questioned**

~~~~text
Exercise 4 — The Checklist stop B · ▶ 20 min · or Exercise 3
 1 Open Scripts/ml_readiness_template.md. It holds the lecture’s eleven criteria. Fill ﬁve rows for your own data: ✓ / ∼
   / ×, each with a number and the unit it came from. The template shows one worked row.
 2 Find the weakest of your ﬁve rows. Mark it × if the evidence says so; if not, say why it still holds — that sentence is the
    evidence. A ✓ without a number counts as ∼.
⃝ Extra: ﬁll all eleven rows, then decide go / no-go: which criteria block it, what would change the decision, and the three
things you would do ﬁrst.
Exercise 5 — Present, and Be Questioned ⃝ Extra · 3 minutes in front of people
 1 Present your results to another group in 3 minutes: three questions, ﬁve numbers, base rate, checklist rows.
 2 The other group ﬁnds a question your numbers cannot answer. Write it down.
 3 On your own, 10 minutes: which one thought from this course do you want to still know in ﬁve years?

What to have ready
Show it and talk it through — in the room or in your weekly slot, on one page:
• Ex 1: the three questions, their readers, the layout sketch
• Ex 2: the ﬁve numbers with their n, and the median-or-mean decision
• Ex 3: cutoff, population, independent unit and base rate — written down before anything was ﬁtted
• Ex 4: ﬁve checklist rows with their evidence, and your weakest row




Unit 09 · Data Science · exercise sheet                                                                                     2
~~~~
