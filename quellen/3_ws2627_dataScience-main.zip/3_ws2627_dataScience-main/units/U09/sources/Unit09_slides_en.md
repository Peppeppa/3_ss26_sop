---
source_id: DS-U09-L-EN
original_file: Unit09_slides_en.pdf
source_type: lecture
language: en
page_count: 47
source_sha256: 79d8c5ab522fc8b31fa9684e45f1b82009943576b322381aa42c1093f313a9b1
verification: partial
---
# Unit09_slides_en

[Original PDF](../../../quellen/Unit09_slides_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung. Rekonstruktionen sind gekennzeichnet.

## Page 001

[Original page 1](../../../quellen/Unit09_slides_en.pdf#page=1)

~~~~text
Data Science

DASHBOARDS,
COMMUNICATION &
ML-READINESS


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../../quellen/Unit09_slides_en.pdf#page=2)

~~~~text
                                                                  LEARNING GOALS


    • Explain the difference between an analysis tool and a dashboard
    • Design a dashboard around 1–3 questions, with reactivity as the mechanism
    • Apply ten principles of effective visualisation (Midway 2020) and ﬁnd where a real
      dashboard breaks them
    • Name the limits of a dashboard: ﬁxed viewpoint, false certainty, staleness
    • Explain what a model sees — a feature matrix and a target, nothing else
    • Justify a time-based split as an answer to “what does generalisation mean?”
    • Diagnose data leakage, including the cases that do not look like leakage
    • Assess a dataset against ML-readiness criteria and defend a go / no-go decision



2
~~~~

## Page 003

[Original page 3](../../../quellen/Unit09_slides_en.pdf#page=3)

~~~~text
    WHAT A DASHBOARD IS




3
~~~~

## Page 004

[Original page 4](../../../quellen/Unit09_slides_en.pdf#page=4)

~~~~text
                                                                                    TWO DEFINITIONS

    Few (2006)
    “A dashboard is a visual display of the most important information needed to achieve one
    or more objectives; consolidated and arranged on a single screen so the information can
    be monitored at a glance.” (p. 34)


    Yigitbasioglu & Velcu (2012)
    A dashboard is “a visual and interactive performance management tool that displays on a
    single screen the most important information to achieve one or several individual and/or
    organizational objectives, allowing the user to identify, explore, and communicate
    problem areas that need corrective action.”

    Both share “a single screen” and “the most important information”: the reason a dashboard is not a place for
    everything you found. Yigitbasioglu & Velcu add interactive: the reader explores, not only reads.
4
~~~~

## Page 005

[Original page 5](../../../quellen/Unit09_slides_en.pdf#page=5)

~~~~text
                                                            GOALS AND PROPERTIES

    Goals (Pauwels et al., 2009)                     General properties
     • consistency — the same measures in              • graphical summary of information
       every department
                                                       • visualises KPIs
     • monitoring — metrics checked day to day,
                                                       • interactive exploration — drill-down, roll-up
       acted on
                                                       • adaptable, to avoid information overload
     • planning — what-if scenarios
                                                       • matched to task, knowledge and user
     • communication — to stakeholders

     The word doing the work is “monitoring”
     A dashboard answers questions decided in advance, repeatedly, for a known audience. An analysis
     tool answers questions you have not thought of yet. Confuse them and you get a dashboard nobody
     can read, or an analysis nobody can repeat.



5
~~~~

## Page 006

[Original page 6](../../../quellen/Unit09_slides_en.pdf#page=6)

~~~~text
                                                                          WHAT ONE LOOKS LIKE




    A BI vendor’s template (datapine). Read the layout before the numbers.
      • Controls on top: tabs, report period, a ﬁlter button. The reactivity comes ﬁrst.
      • Five numbers, largest type, no chart — the questions decided in advance.
      • Then one chart per question: trend, geography, ranking. Below the fold begins a second screen, where “at a
         glance” has ended.
      • And the line in the left chart is labelled ProductID — an identiﬁer on a value axis. IDs are nominal (U00): a
         mean of them means nothing. Or it is a mislabelled count — either way, it still looks right.
6
~~~~

## Page 007

[Original page 7](../../../quellen/Unit09_slides_en.pdf#page=7)

~~~~text
                                                     REACTIVITY IS THE MECHANISM

    Strip a dashboard down and one loop remains:

                             ﬁlter → ﬁltered subset → every view updates

    Everything else is decoration. The design questions follow from that loop:
     • What can be ﬁltered? Each control multiplies the states a reader can reach — and each state
       must still make sense.
     • Does every view react? A panel that silently ignores the ﬁlter is worse than no panel.
     • What does an empty selection show — and a tiny one? Nothing selected is one case; three
       customers lassoed is a different one.

    The trap in the small selection
    A dashboard recomputes a mean over three rows without complaint, and displays it as conﬁdently as one over
    19,119. At n = 3 a single large customer is the mean, and all of U08 (skew, mixed groups, outliers) acts
    unchecked. Every aggregate needs its count beside it, always.

7
~~~~

### DS-U09-L-EN-P007-D01 — Rekonstruktion

```mermaid
flowchart LR
 A[Filter] --> B[Filtered subset] --> C[Every view updates]
```
Empty and tiny selections must be handled separately; each aggregate has its n.

## Page 008

[Original page 8](../../../quellen/Unit09_slides_en.pdf#page=8)

~~~~text
    TEN PRINCIPLES, APPLIED




8
~~~~

## Page 009

[Original page 9](../../../quellen/Unit09_slides_en.pdf#page=9)

~~~~text
                                                                                    PRINCIPLES 1–5
    Midway (2020) wrote ten principles for one ﬁgure. A dashboard is several ﬁgures on one screen, so every panel
    gets all ten. Titles as in the paper.
    1. Diagram ﬁrst. Decide the message — a comparison? a ranking? a composition? — on paper,
       before the software limits what you consider.
    2. Use the right software. An effective ﬁgure may need a tool you do not know yet; learning it is
       part of the method.
    3. Use an effective geometry and show data. Choose the form from the job; spend the ink on data;
       where n is small, show the points. (U08)
    4. Colors always mean something. The ﬁgure must still work in greyscale; repeat the colour with
       symbols or line types; use colour-blind-safe schemes. (U08)
    5. Include uncertainty. Error bars, shaded intervals — a point estimate alone claims more than you
       know. (U08)

    Principle 4 is not advice — U08 measured it
    The course’s old palette separated Bikes from Clothing by only ∆E = 1.5 under protanopia, and
    nobody saw it by looking. “Colour-blind-safe” means: run the check.

9
~~~~

## Page 010

[Original page 10](../../../quellen/Unit09_slides_en.pdf#page=10)

~~~~text
                                                                           PRINCIPLES 6–10


      6. Panel, when possible (small multiples). Repeat one chart with the same axes; each panel
         changes one variable — time, group, segment. (U08)
      7. Data and models are different things. A ﬁtted line or a forecast needs an explanation the reader
         can ﬁnd. That the software can add one is no reason to.
      8. Simple visuals, detailed captions. Figure plus caption must be understood without anything
         else. On a dashboard the caption is the panel title and the note under it.
     9. Consider an infographic. Text, images and diagram elements were remembered best in the
        study Midway cites (Borkin et al., 2013) — but he does not recommend turning every ﬁgure into
        one.
     10. Get an opinion. Let people outside the work review the ﬁgures — the ﬁgures alone.

     On 9: memorable is not the same as correct. A dashboard is read every month, so correct wins.
     Tables remain useful next to a chart, for the detail.


10
~~~~

## Page 011

[Original page 11](../../../quellen/Unit09_slides_en.pdf#page=11)

~~~~text
                                       TEN PRINCIPLES, ONE REAL DASHBOARD
                                                            Holds up
                                                              • 4 — every delta carries an arrow and a colour, so it
                                                                survives greyscale.
                                                              • 8 — a footer legend names what each icon compares
                                                                against.
                                                            Does not
                                                              • ACCUMULATED REVENUE: the axis starts at $2M, and
                                                                its six ticks read $2M, $2M, $3M, $3M, $3M, $3M.
                                                                Truncated and unreadable.
                                                              • COST BREAKDOWN: a donut for two numbers that are
                                                                printed next to it anyway.
                                                              • INCREMENTAL SALES: six channels separable by
                                                                colour only, legend detached, bars unsorted.
                                                              • 5 — not one interval on the whole screen.

     Two channels, two meanings
     The arrow means direction, the colour means good or bad: cost ▼12 % is green, revenue ▼9 % is red. Defensible —
     but say it, or the reader guesses.

11
~~~~

## Page 012

[Original page 12](../../../quellen/Unit09_slides_en.pdf#page=12)

~~~~text
     THE SAME DESIGN, ABOUT PEOPLE

           • Same grammar (a datapine template): status row,
             then panels. Status shown by symbol (check, ring,
             clock), not by colour alone: principle 4.
           • Workload bars carry their values; the tables are
             plain. Well drawn — yet the dummy numbers
             disagree: Kate 45 % in the bars, 34 % in the table
             (principle 10).
           • And every bar is a named person, ranked by
             workload; every overdue task is attributed by name.


          Ask before you build
          Who sees this screen? What does a 30 % bar next to a
          name do in a performance review? Personal data (U03),
          so purpose limitation applies (GDPR Art. 5(1)(b)): data
          collected to plan tasks may not simply be used to rate
          people. In Germany, a system able to monitor
          performance needs the works council’s consent (BetrVG
          § 87(1) No. 6).

12
~~~~

## Page 013

[Original page 13](../../../quellen/Unit09_slides_en.pdf#page=13)

~~~~text
   Break
 10 minutes




Then: Building One
~~~~

## Page 014

[Original page 14](../../../quellen/Unit09_slides_en.pdf#page=14)

~~~~text
     BUILDING ONE




14
~~~~

## Page 015

[Original page 15](../../../quellen/Unit09_slides_en.pdf#page=15)

~~~~text
                                                          TWO DASHBOARDS, TWO JOBS

     Those deﬁnitions were about monitoring: a ﬁxed set of questions, looked at again next month. A
     t-SNE map answers the opposite kind of question — and no single artefact does both well:
                                awc_kpi_dashboard.py                    awc_dashboard.py
      answers                   questions decided in advance            questions you have not thought of
      shows                     ﬁve numbers, a sorted bar, a month      a t-SNE map, a lasso, a table, a map
                                line, a drill
      reads                     awc_flat.csv (U02)                      awc_enriched.csv (U07 + U08)
      for                       someone who reads it every month        someone looking for something



     The left one is what M3 asks you to build
     The right one you will see run today, so you know what the other kind looks like — it is a
     demonstration, not a deliverable. Building the wrong one is not a small mistake: a lasso-driven
     explorer answers no question a reader brought with them.

     Neither is a new artefact. awc_flat.csv is U02’s; t-SNE and clusters U07’s; features U06’s; coordinates U08’s
     geocoding. A dashboard is a view onto what you already have.
15
~~~~

## Page 016

[Original page 16](../../../quellen/Unit09_slides_en.pdf#page=16)

~~~~text
                                                         EVERY KPI SAYS WHAT IT IS OVER

        number                      value                           over what — the n
        Revenue                     $109.8 M                        sum of LineTotal over 121,317 order items
        Orders                      31,465                          distinct SalesOrderID
        Customers                   19,119                          distinct CustomerID
        Median order                $783 (IQR $57 to $2,367)        31,465 orders
        Online share                88 %                            of 31,465 orders
      Real AWC: awc_flat.csv, all 38 months, no ﬁlter — the KPI row of awc_kpi_dashboard.py.


     One name, three numbers                                    The mean alone would mislead
     “Online share” is 88 % of orders, 27 % of revenue and      Mean order $3,491, 4.5× the median: the largest 5 %
     50 % of order items. All three are true. The KPI exists    of orders, all from resellers, carry 65 % of revenue.
     only once its base is named.                               87 % of orders are below the mean. So: median, IQR,
                                                                and the mean beside it (principle 5).
      A ﬁlter changes which business you look at. Set the channel to Reseller and the median order is $8,257 on 3,806
      orders. A KPI without its ﬁlter stated is not a KPI.


16
~~~~

## Page 017

[Original page 17](../../../quellen/Unit09_slides_en.pdf#page=17)

~~~~text
                         FILTER OR DRILL? A DRILL CHANGES WHAT A ROW IS

     Rolled up: one row = a territory, sorted by revenue          Drilled into Germany: one row = a customer
                        orders    customers      revenue          1,812 rows, 32 of them resellers. Revenue per
                                                                  customer:
     Southwest           6,224          4,565    $24.2 M
                                                                  largest (a reseller, 4 orders)   $337,757
     Canada              4,067          1,677    $16.4 M
     Northwest           4,594          3,428    $16.1 M          upper quartile                     $2,737
     Australia           6,843          3,625    $10.7 M          median (1 order)                    $554
     Central               385             69     $7.9 M          lower quartile                       $39
     Southeast             486             91     $7.9 M          smallest                               $4
     United Kingdom      3,219          1,951     $7.7 M
     France              2,672          1,844     $7.3 M          A median over 1,812 customers is a different claim
     Northeast             352             57     $6.9 M          from one over 57 (Northeast): the n moves with the
     Germany             2,623          1,812     $4.9 M          level.

        • Filter: fewer rows of the same thing. Drill: a row becomes a different thing — U01’s grain, clickable.
        • Thin months: for European resellers, 16 of 24 months have fewer than 30 orders. Mark them: 7 orders must
          not look like 46.
        • In KNIME, inside one component: Single Selection Widget (territory; re-execution on change) → Row
          Filter → GroupBy (customer) → Table View. If a view does not update, a Refresh Button Widget wired
          to those nodes forces it (a common workaround).
      Real AWC, awc_flat.csv, 38 months; threshold 30 as in awc_kpi_dashboard.py.
17
~~~~

## Page 018

[Original page 18](../../../quellen/Unit09_slides_en.pdf#page=18)

~~~~text
                                                     THE PYTHON PATH: STREAMLIT

     pip install streamlit plotly pandas
     streamlit run awc_kpi_dashboard.py             # reads awc_flat.csv (U02)
     awc_kpi_dashboard.py, 312 lines, is six kinds of call; the explorer adds the last two:
      st.sidebar + date_input/multiselect      the ﬁlters — one place
      st.columns(5) + st.metric                the ﬁve numbers
      st.plotly_chart                          the sorted bar and the month line
      st.dataframe(..., on_select)             the table — and the drill
      st.plotly_chart(..., on_select)          the lasso (explorer)
      st.pydeck_chart                          the map (explorer, needs pydeck)


     Why Streamlit and not a web framework
     Streamlit re-runs the whole script on every interaction and diffs the result. Reactivity is free — no
     callbacks, no state machine — at the cost of thinking about what is expensive (hence
     @st.cache_data on the loader). The shortest honest path from a DataFrame to something a
     colleague can click.


18
~~~~

## Page 019

[Original page 19](../../../quellen/Unit09_slides_en.pdf#page=19)

~~~~text
                                                  THE KNIME PATH: THE EXPLORER, VISIBLY

                                                                                                      Normalizer   Math Formula   Math Formula   Math Formula   k-Means




                                   DB Connector   DB Query Reader                     Column Filter



                                                                                                                                                                          Dashboard-Visualization
                                                                             Joiner




                                                  DB Query Reader


                                                                    Joiner




                                                    CSV Reader




     DS_09_dashboard.knwf is the explorer, not the KPI dashboard: pipeline above (connect, read, join, ﬁlter,
     normalise, three formulas, k-Means), geocodes below. Both feed the component Dashboard-Visualization, so
     no dashboard is visible here: the layout lives inside it. Right-click → Interactive View; to rearrange, open it and
     use Composite View Layout.
     The KPI dashboard is the same kind of component with other nodes: GroupBy and Statistics for the numbers;
     Bar Chart, Line Plot, Table View; the drill chain from Filter or Drill?

     The honest comparison
     KNIME makes the dataﬂow visible and the layout awkward; Streamlit the reverse. Neither is better —
     but the KNIME graph is the provenance log U03 asked for, while Streamlit needs you to write one.

19
~~~~

## Page 020

[Original page 20](../../../quellen/Unit09_slides_en.pdf#page=20)

~~~~text
                                       AND IN INDUSTRY? STREAMLIT IS ONE OF MANY




                         ⟷ the organisation, governed
                                                                                                                                                                   Looker
                                                                                                                                                                                           SAP Analytics Cloud

                                                                                                                                         Apache Superset                       Power BI
                                                                                                                                                                                      Qlik Sense
                                                                                                                                   Grafana                           Tableau

                                                                                     Dash                                                         Metabase

                                  one analyst, ad hoc
                                                                           Streamlit
                                                                     Panel / Voilà                                                                                                you write it (Python)
                                                                  Gradio                                                                                                          you run the server (open source)
                                                                                                                                                                                  you licence it (commercial)
                                                                                                                  written in Python      ⟷ assembled by clicking
                                                        Position is about how a tool is built and who it serves   — not about quality.


     Four questions that decide it — ask them in this order
     1. Python you can review, or clicks that are hard to diff? 2. Where does the computing happen — your process, a
     BI server, the warehouse? 3. Is there one deﬁnition of “revenue” (a semantic layer), or does each dashboard invent
     its own? 4. What does one more viewer cost — nothing, or a licence?

     Streamlit is right for your case. Company-wide reporting usually needs one governed deﬁnition of revenue
     (question 3), which Streamlit does not give you by itself.
20
~~~~

## Page 021

[Original page 21](../../../quellen/Unit09_slides_en.pdf#page=21)

~~~~text
                                                                     WHAT DASHBOARDS HIDE


      Fixed viewpoint     it answers the questions its author chose; the question that matters next month has no
                          panel
      False certainty     a number rendered large and centred reads as settled, whatever its n or its conﬁdence
                          interval
      Staleness           it keeps rendering after the pipeline breaks, the schema changes, or the data themselves
                          change — drift: the world moves and the dashboard does not say so
      Aggregation         the mixed groups U08 found in one column disappear into any single KPI


     The test that ﬁnds all four
     Give the dashboard to someone else with a question it was not built for. What they reach for and do
     not ﬁnd is the speciﬁcation for version two — and the limits section of its documentation.

     The alternative is often a data story: three plots and four sentences that argue one ﬁnding — rather than a panel
     serving every future question badly.



21
~~~~

## Page 022

[Original page 22](../../../quellen/Unit09_slides_en.pdf#page=22)

~~~~text
     WHAT A MODEL EXPECTS




22
~~~~

## Page 023

[Original page 23](../../../quellen/Unit09_slides_en.pdf#page=23)

~~~~text
                                                        A MATRIX AND A VECTOR

     Everything you built this semester reaches a model as exactly two objects:

                         X ∈ Rn×d    and   y ∈ Rn   (here 0/1: returns or not)

     No column names. No data types. No units. No documentation. No provenance. The
     model cannot know that column 3 is a currency and column 7 a proportion, that the rows
     are customers rather than order items, or that half of SalesPersonID is the text NULL
     (U04).

     Which is why this course existed
     Every defect the course found — wrong grain, a text sentinel, a non-UTF-8 export, mixed
     groups in one column, unscaled features, leaking recency — enters the model as an
     ordinary number. It will not error. It will train. It will report a score.


23
~~~~

### DS-U09-L-EN-P023-D01 — Rekonstruktion

Model input: $X\in\mathbb R^{n\times d}$ and $y\in\mathbb R^n$ (here binary). Names, types, units and provenance are not carried into these numeric objects.

## Page 024

[Original page 24](../../../quellen/Unit09_slides_en.pdf#page=24)

~~~~text
                                                      REQUIREMENTS BY MODEL CLASS


                                          Needs                                  Tolerates
      Linear / logistic                   scaling (for regularisation and        little — this is the fussy one
                                          gradient descent); roughly linear
                                          effects; full rank
      Tree / forest / boosting            almost nothing                         unscaled features, monotone
                                                                                 transforms, outliers
      Distance-based (kNN, k-means)       scaling and a chosen metric            nothing about scale
      Neural networks                     normalisation; a lot of rows           non-linearity, interactions

     U07’s rank-deﬁciency ﬁnding lands here: PC9 was exactly zero because the four share_* columns
     sum to 1. A tree will not notice. A linear model with a matrix inverse may fail outright or return
     unstable coefﬁcients.
     The practical order: ﬁx what every class needs (grain, encoding, leakage, target deﬁnition), then what your
     chosen class needs.




24
~~~~

## Page 025

[Original page 25](../../../quellen/Unit09_slides_en.pdf#page=25)

~~~~text
                                   THE SPLIT IS A QUESTION, NOT A RECIPE

     “Train/test split” is usually taught as a ratio. It is really the answer to: what would it mean
     for this model to generalise?
      If generalising means. . .                       then split by. . .
      “works on future data”                           time — train on the past, test on the future
      “works on new customers”                         customer — no customer on both sides
      “works in another region”                        region
      “works on new rows of the same process”          random — the only case where random is
                                                       right


     For AWC: time ﬁrst, then customers
     Features from the ﬁrst 25 of AWC’s 38 months, the outcome from the last 13: the model never sees
     what happened after the cutoff. Then the customers are split 70/30 at random, so no customer is on
     both sides — two rows of the table at once.


25
~~~~

## Page 026

[Original page 26](../../../quellen/Unit09_slides_en.pdf#page=26)

~~~~text
      HANDS ON — EXERCISES 1 AND 2
                              20 minutes
            Sheet on Moodle: Unit09_Exercises_en.pdf

     Work at your machine — I am in the room. We go through it right after.




26
~~~~

## Page 027

[Original page 27](../../../quellen/Unit09_slides_en.pdf#page=27)

~~~~text
        Break
      10 minutes




Then: Data Leakage, Measured
~~~~

## Page 028

[Original page 28](../../../quellen/Unit09_slides_en.pdf#page=28)

~~~~text
     DATA LEAKAGE, MEASURED




28
~~~~

## Page 029

[Original page 29](../../../quellen/Unit09_slides_en.pdf#page=29)

~~~~text
                      WHAT LEAKAGE IS: THE MODEL SEES THE ANSWER

     Kaufman et al. (2012)
     Leakage is “the introduction of information about the target [. . . ] that should not be legitimately
     available to mine from”. The trivial case: the target as an input — the model learns that “it rains on
     rainy days”.

     Example (AWC): in June 2013, sales wants to know which customers will order again within the next
     13 months, to contact the others. Everything the model uses must be known in June 2013.

                                                           cutoff: the day we predict
             leak: recency counted over all 38 months                       looks into the outcome
             honest: recency counted up to the cutoff

                             months 1–25: what we know                   months 26–38: the outcome
         May 2011                                                                               Jun 2014

     In the test, the leak looks brilliant. In June 2013 the months the orange bar needs have not happened
     yet — the model fails exactly when it is used.
29
~~~~

## Page 030

[Original page 30](../../../quellen/Unit09_slides_en.pdf#page=30)

~~~~text
                                                                     TWO KINDS OF LEAKAGE

     kind                           what happens
     in features                    a feature carries information from after the prediction time — the
                                    “no-time-machine” requirement is broken. Today: post-cutoff revenue
                                    as a feature; recency over all months.
     in training examples           information from the test rows reaches training, so the test no longer
                                    measures new data. Today: a scaler ﬁtted on train and test together;
                                    the items of one order on both sides of a split; repeated
                                    measurements of one sample.


        random split over order items                                grouped split by order

            train            test                                    train             test
                                        ■ one order’s three items:                            every order on
                                        two in train, one in test                             one side only
                                        ■ other orders


     Whether a leak harms is a measurement, not a rule — the four runs on AWC measure it.
30
~~~~

## Page 031

[Original page 31](../../../quellen/Unit09_slides_en.pdf#page=31)

~~~~text
                                                                        THE EXPERIMENT



     Task: for each customer active in months 1–25, predict whether they order again in
     months 26–38 — a returner (yes) or a churner (no). Logistic regression, scored by AUC.
     customers with an order in months 1–25                         5,909
     of them returners — the base rate                              88.5 %
     accuracy of always answering yes                               88.5 % — and it is useless

     Five features, all plain aggregates: order count, revenue, distinct products, total quantity,
     and months since last order (recency). The last one is the most natural churn feature
     anybody would write — remember it.
     Then the same model runs four times, changing only where the features come from. Customers are
     split 70/30 at random, the same split every time.




31
~~~~

## Page 032

[Original page 32](../../../quellen/Unit09_slides_en.pdf#page=32)

~~~~text
                                                                                                                                READING AN AUC
                                each curve is one model, read at every threshold
                          1.0

                          0.8                                                                 A model gives every customer a score, not a yes/no. Pick a
                                                                                              threshold: above it means “returns”. Then the true-positive rate is
     true positive rate




                          0.6                                                     .5)         the share of returners above it, the false-positive rate the share of
                                                                                C0
                                                                           AU                 churners above it. Sweep the threshold and the pairs trace the ROC
                                                                        e(
                          0.4                                  ch   a nc                      curve.
                                                           e
                                                        pur                                   The AUC is the area under it, with a reading that needs no integral:
                          0.2                                                                 take one returner and one churner at random — the AUC is the share
                                                     honest run — AUC 0.585                   of such pairs the model ranks the right way round.
                                                     leaked run — AUC 1.000
                          0.0
                                0.0     0.2       0.4      0.6    0.8                   1.0
                                              false positive rate

                  Why this and not accuracy
                  0.5 is the diagonal: pure guessing. 1.0 means not one pair the wrong way round. The AUC ﬁxes no threshold and
                  does not care that 88.5 % of customers return. Accuracy does: always answering yes scores 88.5 % and ranks
                  nobody.

32
~~~~

## Page 033

[Original page 33](../../../quellen/Unit09_slides_en.pdf#page=33)

~~~~text
                                                                         MEASURED: FOUR RUNS

     run                                    kind                         AUC                            accuracy
     1. honest: months 1–25 only            —                          0.585                                86.4 %
     2. post-cutoff revenue added           in features                0.942                                87.6 %
     3. same features, all 38 months        in features                1.000                                99.1 %
     4. scaler ﬁtted on train + test        in training examples       0.585                                86.4 %
     Real AWC: 5,909 customers, 1,773 in the test set; dashed line = AUC 0.5, guessing.
     1 is the truth, and it is worse than modest: 86.4 % accuracy against an 88.5 % base rate — worse than always
     answering “yes”. 2 smuggles the target in: post-cutoff revenue is 0 for every churner and > 0 for every returner,
     so it is the label. Yet it reaches only 0.942, because revenue is heavily right-skewed (U08) and the ﬁt does not
     separate it. A learning limit, not an information limit: an imperfect score does not mean a safe feature.

     3 is the one that matters, and it is perfect
     Same ﬁve aggregates as run 1, computed over all 38 months. Recency then gives returners 1–12 months and
     churners 13–37: no overlap — the most natural churn feature becomes the label. Nothing about it looks like
     cheating.


33
~~~~

## Page 034

[Original page 34](../../../quellen/Unit09_slides_en.pdf#page=34)

~~~~text
                                    THE WARNING SIGN IS THE GOOD RESULT


                            A churn model at AUC 1.000 has not solved churn.
                                     It has been handed the answer.

     This inverts the usual instinct. A bad score prompts investigation; a good one prompts a
     slide deck. But leakage only ever makes results better, so:
      • Establish the baseline ﬁrst. 88.5% here. Then anything far above the honest 0.585 is
        suspect by default.
      • For every feature ask: when was this value knowable? If the answer is “after the thing
        I am predicting”, it leaks.
      • Recompute every aggregate with an explicit as-of date. Run 3 was one wrong window,
        nothing more.
     Report the cutoff with every score. Move it and the honest AUC moves: 0.65, 0.66, 0.585, 0.80, 0.78
     at months 18, 21, 25, 28, 31. Take the cutoff as a parameter of the extract, and moving it is one edit.

34
~~~~

## Page 035

[Original page 35](../../../quellen/Unit09_slides_en.pdf#page=35)

~~~~text
                                                            WHEN ONE ROW IS A PRODUCT

     Four portfolio slices hold too few customers to ﬁt anything at customer grain, so for them one row is
     a product (ref_unit in slices.csv). The procedure does not change — only the grain, and one
     feature: distinct customers instead of distinct products.
                                             customers       products
     rows with history (months 1–25)               5,909           262
     base rate (returners)                        88.5 %        77.5 %
     negatives in the test set                       241            15
     AUC, run 1 (honest)                           0.585        0.991
     AUC, run 3 (leak)                             1.000         1.000


     The honest run reaches AUC 0.991 — interrogate it
     It is not a leak: every feature comes from months 1–25. What carries it is a product life cycle. 130 of the 203
     returning products were ﬁrst sold in the last month before the cutoff — new products keep selling — while old
     best-sellers stop. The score stays high at every cutoff tried (0.96–0.99), but rests on 15 negative products: say
     what that AUC is worth.
     Real AWC, Scripts/awc_leakage.py --unit product; cutoffs 18–31 re-run with the same script.
35
~~~~

## Page 036

[Original page 36](../../../quellen/Unit09_slides_en.pdf#page=36)

~~~~text
                                                              A LEAK THAT DID NO HARM

     Run 5, a leak in training examples: predict whether an order item is above the median item value,
     from the four order totals (subtotal, tax, freight, total due) — the same for every item of an order. Split
     the 121,317 items two ways:
     split                               orders on both sides       AUC
     A. random over order items      12,983 of 31,465 (41.3 %)     0.815
     B. grouped by order                              0 (0 %)      0.816
     A textbook grouping leak — two ﬁfths of all orders straddle the split (an order has 3.9 items on
     average) — and it made no difference. Seeing the other items of a test order in training adds almost
     nothing the four totals do not already say. A decision tree and a random forest, which could exploit it,
     agree: 0.86 either way.

     “Leaked” is not “harmed”
     Of four leaks measured: one fatal (run 3, AUC 1.000), one total but under-exploited (run 2), two with
     no measurable effect (run 4’s shared scaler, and this grouping leak at an alarming 41.3 %). You
     cannot rank leaks by how bad they sound. Measure them.

36
~~~~

## Page 037

[Original page 37](../../../quellen/Unit09_slides_en.pdf#page=37)

~~~~text
                                                        REPEATED MEASUREMENTS: THE SAME LEAK, FATAL


                                         sample 3 × 5                                          In spectroscopy, lab and sensor data, one sample is often
     absorbance (simulated)




                                                                        sample 1 × 5
                                                                                               measured several times. The replicates show the technical
                               1
                                                                                               variation, but they are the same sample: not independent.
                                                                                               The independent unit is the sample.
                               0
                                                                                               A model that can memorise (k-nearest neighbours, k = 5)
                                                                                               ﬁnds a test spectrum’s siblings in training and copies their
                              −1                                                               label: it recognises the sample, not the class.
                                                                    sample 2 × 5               Simulated: 60 samples × 5 replicates; three samples
                                   0.0          0.2       0.4        0.6           0.8   1.0
                                                        wavelength (scaled)                    drawn.

                        split of the 300 spectra, 70/30                                                      no class signal     weak class signal
                        A. random over measurements (50 of 60 samples on both sides)                        0.93 (0.82–1.00)      0.96 (0.88–0.99)
                        B. grouped by sample                                                                0.46 (0.15–0.65)      0.63 (0.41–0.94)
                        AUC, mean (range) over 20 simulated data sets; 0.5 = guessing. Scripts/u09_replicates.py.
                        Split A scores 0.93 with no signal at all. Split by the independent unit — sample, patient, batch,
                        customer — and count n in those units: 18 test samples, not 90 spectra.


37
~~~~

## Page 038

[Original page 38](../../../quellen/Unit09_slides_en.pdf#page=38)

~~~~text
     THE DECISION




38
~~~~

## Page 039

[Original page 39](../../../quellen/Unit09_slides_en.pdf#page=39)

~~~~text
                                                    THE ML-READINESS CHECKLIST


     #    criterion                                result   evidence (unit)
      1   one row = one unit of prediction         ×→✓      a customer, not an order item (U01, U04)
      2   no information from after the cutoff       ∼      run 3: recency over all months is the label (U09)
      3   split respects time and unit               ✓      cutoff month 25; no customer on both sides (U09)
      4   missing values understood                  ∼      SalesPersonID: text NULL on online items (U04)
      5   scaling chosen and recorded                ✓      z-scores, ﬁtted on training only (U06, run 4)
      6   no rank-deﬁcient columns                   ∼      four shares sum to 1: PC9 = 0 (U07)
      7   distribution shapes known                × →∼     three groups, medians 14× apart (U08)
      8   outliers judged, not deleted               ✓      137 reseller orders (3.6 %), kept (U04)
      9   source encodings veriﬁed                 ×→✓      cp1252, not UTF-8; read as such (U03, U04)
     10   personal data handled                      ∼      k = 1 on the demographics (U03)
     11   baseline before modelling                  ✓      88.5 % returners (U09)

     Eleven criteria this dataset exercised; the exercise asks for ten to seventeen of your own, from your
     slice. Most rows end in ∼: the value is the evidence and the caveat, not the tick. The arrows mark
     defects found and ﬁxed during the course.



39
~~~~

## Page 040

[Original page 40](../../../quellen/Unit09_slides_en.pdf#page=40)

~~~~text
                        GO OR NO-GO IS A JUDGEMENT WITH EVIDENCE

     Question: a churn model from customer history, cut in June 2013. Few rows are plainly yes or no;
     the verdict weighs the ∼ rows.
     #7 shapes        Addressable here, because the three groups show in a single column (U08): split by channel
                      and bike, or add the group as a feature. Groups visible only in several dimensions are harder.
     #2 leakage       Excluded only to the best of our knowledge: ask “when was it knowable?” per feature, take
                      the cutoff as a parameter. A systematic probe: train a model on something it should not be
                      able to predict (train vs test rows, the batch, the lab) and see which features carry it. IRMA
                      (Iterated Relevance Matrix Analysis) does this iteratively, one discriminative direction after
                      another, until nothing is left (Lövdal & Biehl, 2024).
     the target       The honest AUC is 0.585 at this cutoff, 0.65–0.80 at others: agree the outcome window with
                      the business before anything else.


     Verdict: not yet — and what would change it
     Not yet. It would change with an outcome window the business stands behind, the groups handled,
     and an honest AUC that holds across cutoffs. Graded: does each row cite evidence — not: did the
     data pass.

40
~~~~

## Page 041

[Original page 41](../../../quellen/Unit09_slides_en.pdf#page=41)

~~~~text
                                                     WHAT THIS COURSE DELIVERED


     U00–01   data, scale levels, tidy data, joins → the ﬂat-table
     U02      SQL console → program → a re-runnable extract
     U03      formats, schemas, metadata → a data dictionary
     U04      proﬁling, then cleaning → a cleaning log with reasons
     U05      time series, graphs → structure beyond the table
     U06      features, similarity → a distance you chose on purpose
     U07      PCA, t-SNE, clusters → a map you can defend
     U08      statistics, visualisation → plots that argue
     U09      dashboards, ML-readiness → a decision you can defend

     The only predictive models of the course were trained in this last unit, to show that a good score
     can be a symptom. Deliberate: the ML course starts where this one stops — it assumes X and y are
     trustworthy, and nothing in it checks that for you.

                                     The one thought worth keeping:
                        every number arrives with a history, and the history is your job.



41
~~~~

## Page 042

[Original page 42](../../../quellen/Unit09_slides_en.pdf#page=42)

~~~~text
              Break
            10 minutes




Then: Hands On — Dashboards and Leakage
~~~~

## Page 043

[Original page 43](../../../quellen/Unit09_slides_en.pdf#page=43)

~~~~text
     HANDS ON — EXERCISES 3 AND 4
                       20 minutes
       Sheet on Moodle: Unit09_Exercises_en.pdf

        Nothing is ﬁtted here — the base rate comes ﬁrst.




43
~~~~

## Page 044

[Original page 44](../../../quellen/Unit09_slides_en.pdf#page=44)

~~~~text
                        MILESTONE 3
         Communication — and whether anyone else can use it
          30 % of the module · one archive M3_G<nn>.zip
         plus M4, 20 % — the oral part: your own section, nothing to upload
                 Due date: see the course overview in Moodle
   One upload, ﬁve parts (details: HANDIN.pdf, §9):
    1. three supported questions — each with its n, its spread and the overlap
    2. the KPI dashboard, with the table it reads
    3. the leakage experiment — base rate, honest and broken AUC, mechanism
    4. the ML-readiness assessment — checklist, go / no-go, the three next
       steps
    5. the management report, generated by your pipeline

Graded on: can another team use your data and reach your decision — without
                              talking to you?
~~~~

## Page 045

[Original page 45](../../../quellen/Unit09_slides_en.pdf#page=45)

~~~~text
                                                                        SUMMARY

     • A dashboard answers questions decided in advance; an analysis tool answers
       questions nobody has asked yet. Build the ﬁrst one
     • Every aggregate carries its n — and the median carries its IQR, with the mean
       beside it
     • A ﬁlter shows fewer rows of the same thing; a drill changes what a row is —
       and the n travels with the level
     • The temporal split is a question, not a recipe — and the warning sign is the
       good result
     • Leakage: the model sees the answer. Split by time and by the independent unit
       — and measure each leak: its harm depends on data and model
     • ML-readiness is a judgement: evidence per row, a verdict, and what would
       change it
     • Next: M3 — your dashboard, your leakage experiment — and M4, the oral part
45
~~~~

## Page 046

[Original page 46](../../../quellen/Unit09_slides_en.pdf#page=46)

~~~~text
                                                          SOURCES & FURTHER READING


     • Few (2006), Information Dashboard Design, O’Reilly — the “single screen, at a glance” deﬁnition
     • Yigitbasioglu & Velcu (2012), A review of dashboards in performance management, Int. J. Accounting
       Information Systems 13(1):41–59
       doi.org/10.1016/j.accinf.2011.08.002
     • Pauwels et al. (2009), Dashboards as a service: why, what, how, and what research is needed?, J. Service
       Research 12(2):175–189 — the four goals
       doi.org/10.1177/1094670509344213
     • Midway (2020), Principles of effective data visualization, Patterns 1(9):100141 — the ten principles
       doi.org/10.1016/j.patter.2020.100141
     • Borkin et al. (2013), What makes a visualization memorable?, IEEE TVCG 19(12):2306–2315 — the study
       behind principle 9
       doi.org/10.1109/TVCG.2013.234
     • Knaﬂic (2015), Storytelling with Data, Wiley — the data story as the alternative to a dashboard
     • Munzner (2014), Visualization Analysis and Design, CRC Press — visualisation design treated systematically
       doi.org/10.1201/b17511



46
~~~~

## Page 047

[Original page 47](../../../quellen/Unit09_slides_en.pdf#page=47)

~~~~text
                                                    SOURCES & FURTHER READING (2)


     • Kaufman, Rosset, Perlich & Stitelman (2012), Leakage in data mining: formulation, detection, and avoidance,
       ACM TKDD 6(4):15 — the deﬁnition and the two kinds
       doi.org/10.1145/2382577.2382579
     • Lövdal & Biehl (2024), Iterated Relevance Matrix Analysis (IRMA) for the identiﬁcation of class-discriminative
       subspaces, Neurocomputing 577:127367
       doi.org/10.1016/j.neucom.2024.127367
     • van Veen et al. (2024), Subspace corrected relevance learning with application in neuroimaging, Artiﬁcial
       Intelligence in Medicine 149:102786 — removing centre-speciﬁc bias
       doi.org/10.1016/j.artmed.2024.102786
     • Hinder, Vaquet & Hammer (2024), One or two things we know about concept drift, Frontiers in Artiﬁcial
       Intelligence 7 — Part A detects drift, Part B locates and explains it
       doi.org/10.3389/frai.2024.1330257 · doi.org/10.3389/frai.2024.1330258
     • Streamlit, pydeck and KNIME documentation — the ways this unit’s dashboards are built
       docs.streamlit.io · deckgl.readthedocs.io · docs.knime.com




47
~~~~
