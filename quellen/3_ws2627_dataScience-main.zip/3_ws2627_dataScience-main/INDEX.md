# Quellen- und Wissensindex – Data Science (THWS)

Stand: 2026-11-28 · Repository `Peppeppa/3_ws2627_dataScience`, main.
Regeln: [Projektmanifest](DS_PROJECT_MANIFEST.md), [Projektkonfiguration](PROJECT.md), Study Knowledge 1.1.0 und Exercise 1.0.0 aus `Peppeppa/ki_skills`.

## Quellenregister

33 Einzel-PDFs, 535 physische Seiten, je eine Markdown-Textfassung. Originale unverändert in `quellen/`. Git-Blob-Hashes aller 33 stimmen mit lokalen Uploads überein; SHA-256 der Originalbytes in jedem Markdown-Frontmatter. Alle Quellen bleiben partial, da die vollständige semantische und visuelle Prüfung aussteht.

| ID | Typ | Markdown | Original | Seiten | Status |
|---|---|---|---|---:|---|
| DS-U00-L-EN | lecture | [Unit00_slides_en.md](units/U00/sources/Unit00_slides_en.md) | [PDF](quellen/Unit00_slides_en.pdf) | 43 | partial |
| DS-U00-L-DE | lecture | [Unit00_slides_de.md](units/U00/sources/Unit00_slides_de.md) | [PDF](quellen/Unit00_slides_de.pdf) | 43 | partial |
| DS-U00-EX | exercise | [Unit00_Exercises_en.md](units/U00/sources/Unit00_Exercises_en.md) | [PDF](quellen/Unit00_Exercises_en.pdf) | 1 | partial |
| DS-U01-L-EN | lecture | [Unit01_slides_en.md](units/U01/sources/Unit01_slides_en.md) | [PDF](quellen/Unit01_slides_en.pdf) | 29 | partial |
| DS-U01-EX | exercise | [Unit01_Exercises_en.md](units/U01/sources/Unit01_Exercises_en.md) | [PDF](quellen/Unit01_Exercises_en.pdf) | 2 | partial |
| DS-U02-L-EN | lecture | [Unit02_slides_en.md](units/U02/sources/Unit02_slides_en.md) | [PDF](quellen/Unit02_slides_en.pdf) | 38 | partial |
| DS-U02-EX | exercise | [Unit02_Exercises_en.md](units/U02/sources/Unit02_Exercises_en.md) | [PDF](quellen/Unit02_Exercises_en.pdf) | 2 | partial |
| DS-U03-L-EN | lecture | [Unit03_slides_en.md](units/U03/sources/Unit03_slides_en.md) | [PDF](quellen/Unit03_slides_en.pdf) | 44 | partial |
| DS-U03-EX | exercise | [Unit03_Exercises_en.md](units/U03/sources/Unit03_Exercises_en.md) | [PDF](quellen/Unit03_Exercises_en.pdf) | 2 | partial |
| DS-U04-L-EN | lecture | [Unit04_slides_en.md](units/U04/sources/Unit04_slides_en.md) | [PDF](quellen/Unit04_slides_en.pdf) | 42 | partial |
| DS-U04-EX | exercise | [Unit04_Exercises_en.md](units/U04/sources/Unit04_Exercises_en.md) | [PDF](quellen/Unit04_Exercises_en.pdf) | 2 | partial |
| DS-U05-L-EN | lecture | [Unit05_DS_en.md](units/U05/sources/Unit05_DS_en.md) | [PDF](quellen/Unit05_DS_en.pdf) | 48 | partial |
| DS-U05-EX | exercise | [Unit05_Exercises_en.md](units/U05/sources/Unit05_Exercises_en.md) | [PDF](quellen/Unit05_Exercises_en.pdf) | 2 | partial |
| DS-U06-L-EN | lecture | [Unit06_DS_en.md](units/U06/sources/Unit06_DS_en.md) | [PDF](quellen/Unit06_DS_en.pdf) | 38 | partial |
| DS-U06-EX | exercise | [Unit06_Exercises_en.md](units/U06/sources/Unit06_Exercises_en.md) | [PDF](quellen/Unit06_Exercises_en.pdf) | 2 | partial |
| DS-U07-L-EN | lecture | [Unit07_slides_en.md](units/U07/sources/Unit07_slides_en.md) | [PDF](quellen/Unit07_slides_en.pdf) | 45 | partial |
| DS-U07-EX | exercise | [Unit07_Exercises_en.md](units/U07/sources/Unit07_Exercises_en.md) | [PDF](quellen/Unit07_Exercises_en.pdf) | 2 | partial |
| DS-U08-L-EN | lecture | [Unit08_slides_en.md](units/U08/sources/Unit08_slides_en.md) | [PDF](quellen/Unit08_slides_en.pdf) | 40 | partial |
| DS-U08-EX | exercise | [Unit08_Exercises_en.md](units/U08/sources/Unit08_Exercises_en.md) | [PDF](quellen/Unit08_Exercises_en.pdf) | 2 | partial |
| DS-U09-L-EN | lecture | [Unit09_slides_en.md](units/U09/sources/Unit09_slides_en.md) | [PDF](quellen/Unit09_slides_en.pdf) | 47 | partial |
| DS-U09-EX | exercise | [Unit09_Exercises_en.md](units/U09/sources/Unit09_Exercises_en.md) | [PDF](quellen/Unit09_Exercises_en.pdf) | 2 | partial |
| DS-R001 | reference | [portfolio_studis_de.md](quellen/organisation/sources/portfolio_studis_de.md) | [PDF](quellen/portfolio_studis_de.pdf) | 9 | partial |
| DS-R002 | reference | [profiling_primer.md](quellen/primer/sources/profiling_primer.md) | [PDF](quellen/profiling_primer.pdf) | 8 | partial |
| DS-R003 | reference | [python_primer.md](quellen/primer/sources/python_primer.md) | [PDF](quellen/python_primer.pdf) | 9 | partial |
| DS-R004 | reference | [Schedule_Data_Science_students.md](quellen/organisation/sources/Schedule_Data_Science_students.md) | [PDF](quellen/Schedule_Data_Science_students.pdf) | 1 | partial |
| DS-R005 | reference | [statistic_stochastic_primer_short_en.md](quellen/primer/sources/statistic_stochastic_primer_short_en.md) | [PDF](quellen/statistic_stochastic_primer_short_en.pdf) | 11 | partial |
| DS-R006 | reference | [submission_howto_de.md](quellen/organisation/sources/submission_howto_de.md) | [PDF](quellen/submission_howto_de.pdf) | 3 | partial |

| DS-R007 | reference | [Glossary_en.md](quellen/primer/sources/Glossary_en.md) | [PDF](quellen/Glossary_en.pdf) | 3 | partial |
| DS-R008 | reference | [HANDIN.md](quellen/organisation/sources/HANDIN.md) | [PDF](quellen/HANDIN.pdf) | 5 | partial |
| DS-M1-EX | exercise | [M1_sheet.md](portfolio/M1/sources/M1_sheet.md) | [PDF](quellen/M1_sheet.pdf) | 3 | partial |
| DS-M2-EX | exercise | [M2_sheet.md](portfolio/M2/sources/M2_sheet.md) | [PDF](quellen/M2_sheet.pdf) | 3 | partial |
| DS-M3-EX | exercise | [M3_sheet.md](portfolio/M3/sources/M3_sheet.md) | [PDF](quellen/M3_sheet.pdf) | 3 | partial |
| DS-R009 | reference | [midterm_slide.md](portfolio/M1/sources/midterm_slide.md) | [PDF](quellen/midterm_slide.pdf) | 1 | partial |

## Themenübersicht
| Unit | Themen |
|---|---|
| [U00](units/U00/sources/) | Einführung, DIKW, Setup, Skalenniveaus |
| [U01](units/U01/sources/) | Tidy Data, Grain, Joins, Pivot/Melt |
| [U02](units/U02/sources/) | OLTP/OLAP, Treiber, Transaktionen, SQL-Parameter, Extraktion |
| [U03](units/U03/sources/) | CSV, XML, JSON, YAML, Parquet, HDF5, Metadaten, Datenschutz |
| [U04](units/U04/sources/) | Profiling, Missingness, Bias, Ausreißer, Cleaning Log |
| [U05](units/U05/sources/) | Zeitreihen, Sampling, Saisonalität, Graphen, Cypher |
| [U06](units/U06/sources/) | Encoding, Skalierung, Metriken, DTW, Edit Distance, Embeddings |
| [U07](units/U07/sources/) | Curse of Dimensionality, PCA, Mahalanobis, t-SNE, Clustering |
| [U08](units/U08/sources/) | Verteilungen, Korrelation, Konfidenzintervalle, Visualisierung |
| [U09](units/U09/sources/) | Dashboard, KPIs, Reaktivität, Leakage, ML-Readiness |

## Navigation

- [Aufgabenregister](EXERCISES.md) – 40 Unit-Hauptaufgaben + 20 Portfolio-Aufgaben, keine neuen Lösungen.
- [Qualitätsbericht](IMPORT_QA.md).
- [Portfolio M1–M4](portfolio/), [Chatindex](projekt_chats/README.md), [Pythonübungen](python_uebungen/README.md).

## Portfolio – verbindliche Quellen

- [HANDIN](quellen/organisation/sources/HANDIN.md), [M1](portfolio/M1/sources/M1_sheet.md), [M2](portfolio/M2/sources/M2_sheet.md), [M3](portfolio/M3/sources/M3_sheet.md), [Midterm](portfolio/M1/sources/midterm_slide.md). HANDIN und aktuelle Aufgabenblätter haben Vorrang.
- [Portfolio-Bestandsprüfung](PORTFOLIO_STATUS.md).

## Offene Quellen und Versionskonflikte

Alle 33 aktuell sichtbaren Einzel-PDFs sind als Markdown auf main importiert. Zusätzlich sind im Chat 13 ZIPs (10 Unit-Kits, AWC_tables, M2/M3-Template) vollständig verfügbar; sie und die sechs darin enthaltenen PDF-Referenzen (11 Seiten) sind **noch nicht auf GitHub gespeichert**. Ein lokales Ergänzungspaket mit 134 extrahierten Nutzdateien und 546 Seitenbildern ist erstellt. M1_template.zip fehlt; alte Sammel-PDF (103 Seiten) liegt lokal vor, separat nicht konvertiert.
M1/M2-Gruppenabgaben wurden im zum Prüfzeitpunkt sichtbaren Repository nicht gefunden. Keine Bewertung oder Bestätigung der Reproduzierbarkeit ohne Abgabeunterlagen.
Neuer Schedule DS-R004 nennt M1 am 23.11.2026, 23:59 statt 10.11. im Manifest; M2 18.12.2026, M3 25.01.2027. Offizielle aktuelle Unterlagen haben Vorrang.
