# Fachkonfiguration

- Fach: Data Science – THWS, Informatik, 3. Semester, Wintersemester 2026/27
- Fach-Repository: `Peppeppa/3_ws2627_dataScience`
- Branch: `main`
- Fachpfad: `/`
- Zentrale Skill-Bibliothek: `Peppeppa/ki_skills`, Branch `main`
- Skill-Register: `README.md`
- Basis-Skill: `skills/study-knowledge/SKILL.md` (beim Initialisieren geprüft: v1.1.0, 2026-11-26)
- Spezial-Skill-Routing: `skills/exercise/SKILL.md` für Aufgaben, Lösungen, Prüfungen und entsprechende Bearbeitung; nur bei Bedarf laden
- Wissenseinstiegspunkt: [INDEX.md](INDEX.md)
- Fachspezifische Regeln: [DS_PROJECT_MANIFEST.md](DS_PROJECT_MANIFEST.md)

**Wichtig:** Bei späteren Anfragen aktuelle zentrale Skill-Versionen auf GitHub prüfen, sofern erforderlich. `PROJECT.md` ist lediglich die Fachkonfiguration und keine Kopie zentraler Arbeitsanweisungen. Die zentrale Skill-Bibliothek darf nicht ungefragt verändert werden.
