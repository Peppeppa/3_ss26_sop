# Aufgabenregister – Data Science

40 Hauptaufgaben aus zehn offiziellen Übungsblättern, einschließlich Extra-Hauptaufgaben. Keine neuen Lösungen. Skriptzuordnung und Referenzlösungen nicht bestätigt.

| exercise_id | Originalnummer | Quelle / Seite | Thema | Lösungsstatus |
|---|---:|---|---|---|
| DS-U00-EX-T01 | 1 | [S. 1](units/U00/sources/Unit00_Exercises_en.md#ds-u00-ex-t01) | Data Inventory | none |
| DS-U00-EX-T02 | 2 | [S. 1](units/U00/sources/Unit00_Exercises_en.md#ds-u00-ex-t02) | Provenance & Questions | none |
| DS-U01-EX-T01 | 1 | [S. 1](units/U01/sources/Unit01_Exercises_en.md#ds-u01-ex-t01) | The First Join | none |
| DS-U01-EX-T02 | 2 | [S. 1](units/U01/sources/Unit01_Exercises_en.md#ds-u01-ex-t02) | Add Product Information | none |
| DS-U01-EX-T03 | 3 | [S. 1](units/U01/sources/Unit01_Exercises_en.md#ds-u01-ex-t03) | Pivot Round-Trip | none |
| DS-U01-EX-T04 | 4 | [S. 2](units/U01/sources/Unit01_Exercises_en.md#ds-u01-ex-t04) | Your Flat Table | none |
| DS-U02-EX-T01 | 1 | [S. 1](units/U02/sources/Unit02_Exercises_en.md#ds-u02-ex-t01) | Get Out of the Console | none |
| DS-U02-EX-T02 | 2 | [S. 1](units/U02/sources/Unit02_Exercises_en.md#ds-u02-ex-t02) | Break It, Then Fix It | none |
| DS-U02-EX-T03 | 3 | [S. 1](units/U02/sources/Unit02_Exercises_en.md#ds-u02-ex-t03) | Push Down, or Pull and Aggregate? | none |
| DS-U02-EX-T04 | 4 | [S. 2](units/U02/sources/Unit02_Exercises_en.md#ds-u02-ex-t04) | The Flat Table as a View | none |
| DS-U02-EX-T05 | 5 | [S. 2](units/U02/sources/Unit02_Exercises_en.md#ds-u02-ex-t05) | It Refuses to Connect | none |
| DS-U03-EX-T01 | 1 | [S. 1](units/U03/sources/Unit03_Exercises_en.md#ds-u03-ex-t01) | Break a CSV, Then Diagnose It | none |
| DS-U03-EX-T02 | 2 | [S. 1](units/U03/sources/Unit03_Exercises_en.md#ds-u03-ex-t02) | Hierarchy, Both Directions | none |
| DS-U03-EX-T03 | 3 | [S. 2](units/U03/sources/Unit03_Exercises_en.md#ds-u03-ex-t03) | Measure, Do Not Believe | none |
| DS-U03-EX-T04 | 4 | [S. 2](units/U03/sources/Unit03_Exercises_en.md#ds-u03-ex-t04) | Describe Your Data | none |
| DS-U04-EX-T01 | 1 | [S. 1](units/U04/sources/Unit04_Exercises_en.md#ds-u04-ex-t01) | Profile Your Own Flat-Table | none |
| DS-U04-EX-T02 | 2 | [S. 1](units/U04/sources/Unit04_Exercises_en.md#ds-u04-ex-t02) | Classify, Do Not Fix | none |
| DS-U04-EX-T03 | 3 | [S. 1](units/U04/sources/Unit04_Exercises_en.md#ds-u04-ex-t03) | Outliers, and What You Decide About Them | none |
| DS-U04-EX-T04 | 4 | [S. 2](units/U04/sources/Unit04_Exercises_en.md#ds-u04-ex-t04) | Find the Bias | none |
| DS-U05-EX-T01 | 1 | [S. 1](units/U05/sources/Unit05_Exercises_en.md#ds-u05-ex-t01) | Build the Series, Then Distrust It | none |
| DS-U05-EX-T02 | 2 | [S. 1](units/U05/sources/Unit05_Exercises_en.md#ds-u05-ex-t02) | Gaps and Windows | none |
| DS-U05-EX-T03 | 3 | [S. 1](units/U05/sources/Unit05_Exercises_en.md#ds-u05-ex-t03) | AWC as a Graph | none |
| DS-U05-EX-T04 | 4 | [S. 2](units/U05/sources/Unit05_Exercises_en.md#ds-u05-ex-t04) | Cypher | none |
| DS-U05-EX-T05 | 5 | [S. 2](units/U05/sources/Unit05_Exercises_en.md#ds-u05-ex-t05) | Which Model for Which Question? | none |
| DS-U06-EX-T01 | 1 | [S. 1](units/U06/sources/Unit06_Exercises_en.md#ds-u06-ex-t01) | One Matrix, Scaled | none |
| DS-U06-EX-T02 | 2 | [S. 1](units/U06/sources/Unit06_Exercises_en.md#ds-u06-ex-t02) | One Measure Each | none |
| DS-U06-EX-T03 | 3 | [S. 2](units/U06/sources/Unit06_Exercises_en.md#ds-u06-ex-t03) | Does the Measure See the Label? | none |
| DS-U07-EX-T01 | 1 | [S. 1](units/U07/sources/Unit07_Exercises_en.md#ds-u07-ex-t01) | PCA on the Matrix | none |
| DS-U07-EX-T02 | 2 | [S. 2](units/U07/sources/Unit07_Exercises_en.md#ds-u07-ex-t02) | t-SNE and the Perplexity Sweep | none |
| DS-U07-EX-T03 | 3 | [S. 2](units/U07/sources/Unit07_Exercises_en.md#ds-u07-ex-t03) | Clusters, Honestly | none |
| DS-U07-EX-T04 | 4 | [S. 2](units/U07/sources/Unit07_Exercises_en.md#ds-u07-ex-t04) | What You May and May Not Claim | none |
| DS-U08-EX-T01 | 1 | [S. 1](units/U08/sources/Unit08_Exercises_en.md#ds-u08-ex-t01) | Shape Before Summary | none |
| DS-U08-EX-T02 | 2 | [S. 1](units/U08/sources/Unit08_Exercises_en.md#ds-u08-ex-t02) | Anscombe, and Your Own Correlations | none |
| DS-U08-EX-T03 | 3 | [S. 1](units/U08/sources/Unit08_Exercises_en.md#ds-u08-ex-t03) | Break a Plot on Purpose | none |
| DS-U08-EX-T04 | 4 | [S. 2](units/U08/sources/Unit08_Exercises_en.md#ds-u08-ex-t04) | Five Questions, Five Plots | none |
| DS-U09-EX-T01 | 1 | [S. 1](units/U09/sources/Unit09_Exercises_en.md#ds-u09-ex-t01) | Three Questions, Then a Layout | none |
| DS-U09-EX-T02 | 2 | [S. 1](units/U09/sources/Unit09_Exercises_en.md#ds-u09-ex-t02) | The Five Numbers | none |
| DS-U09-EX-T03 | 3 | [S. 1](units/U09/sources/Unit09_Exercises_en.md#ds-u09-ex-t03) | Find the Leak | none |
| DS-U09-EX-T04 | 4 | [S. 2](units/U09/sources/Unit09_Exercises_en.md#ds-u09-ex-t04) | The Checklist | none |
| DS-U09-EX-T05 | 5 | [S. 2](units/U09/sources/Unit09_Exercises_en.md#ds-u09-ex-t05) | Present, and Be Questioned | none |

## Portfolio – offizielle Aufgaben M1–M3

| exercise_id | Originalnummer | Quelle / Seite | Thema | Lösungsstatus |
|---|---:|---|---|---|
| DS-M1-EX-T01 | 1 | [S. 1](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t01) | The extract | none |
| DS-M1-EX-T02 | 2 | [S. 1](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t02) | Your observation, your question, your target number | none |
| DS-M1-EX-T03 | 3 | [S. 2](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t03) | Profile | none |
| DS-M1-EX-T04 | 4 | [S. 2](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t04) | Outliers and who is absent | none |
| DS-M1-EX-T05 | 5 | [S. 2](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t05) | The cleaning log | none |
| DS-M1-EX-T06 | 6 | [S. 2](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t06) | The decision that matters most | none |
| DS-M1-EX-T07 | 7 | [S. 2](portfolio/M1/sources/M1_sheet.md#ds-m1-ex-t07) | Metadata and personal data | none |
| DS-M2-EX-T01 | 1 | [S. 1](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t01) | Carry out your cleaning log | none |
| DS-M2-EX-T02 | 2 | [S. 1](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t02) | The feature matrix | none |
| DS-M2-EX-T03 | 3 | [S. 2](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t03) | One measure of similarity, defended | none |
| DS-M2-EX-T04 | 4 | [S. 2](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t04) | Reduce: PCA and t-SNE | none |
| DS-M2-EX-T05 | 5 | [S. 2](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t05) | Cluster, and what you may claim | none |
| DS-M2-EX-T06 | 6 | [S. 2](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t06) | Five plots, five questions | none |
| DS-M2-EX-T07 | 7 | [S. 2](portfolio/M2/sources/M2_sheet.md#ds-m2-ex-t07) | Peer review | none |
| DS-M3-EX-T01 | 1 | [S. 1](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t01) | The table M3 stands on | none |
| DS-M3-EX-T02 | 2 | [S. 1](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t02) | Three questions your data supports | none |
| DS-M3-EX-T03 | 3 | [S. 2](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t03) | The KPI dashboard | none |
| DS-M3-EX-T04 | 4 | [S. 2](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t04) | The leakage experiment | none |
| DS-M3-EX-T05 | 5 | [S. 2](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t05) | ML-readiness | none |
| DS-M3-EX-T06 | 6 | [S. 2](portfolio/M3/sources/M3_sheet.md#ds-m3-ex-t06) | The management report | none |

Keine Gruppenabgaben beim Abruf gefunden; keine bestätigten Lösungszuordnungen.
