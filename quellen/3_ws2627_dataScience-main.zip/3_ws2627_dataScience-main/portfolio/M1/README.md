# M1 – Metadaten, Profiling und Bereinigungsplan

**Manifest-Termin:** 10.11.2026, 23:59 Uhr (vergangener Termin; maßgeblich bleiben offizielle Ankündigungen).

## Ziele
Metadaten dokumentieren, Datenqualität messen, bereinigende Schritte als nachvollziehbares Protokoll planen und Entscheidungen begründen.

## Anforderungen
Das offizielle `M1_sheet.pdf` und `HANDIN.pdf` sind verbindlich. Ohne die konkreten Gruppenabgaben keine Ergebnisse behaupten.

## Dokumentation
- Gruppen-Slice und Datenauswahl mit überprüfbarer Quelle
- Profiling-Ergebnisse, Messwerte und konkrete Beispiele
- Vorgeschlagene Bereinigungen, Begründungen und verworfene Alternativen
- Reproduzierbare SQL-/Python-Dateien und Abgabeprüfung
