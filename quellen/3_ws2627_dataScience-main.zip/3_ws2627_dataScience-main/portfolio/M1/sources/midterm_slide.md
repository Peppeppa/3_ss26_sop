---
source_id: DS-R009
original_file: midterm_slide.pdf
source_type: reference
language: en
page_count: 1
source_sha256: 3b6275cd44b299b6514b03c0b6495da21957387c93690266e76383d44a7a9292
verification: partial
---
# midterm_slide

[Original PDF](../../../quellen/midterm_slide.pdf). Vollständige Textschicht. Rekonstruktionen sind separat markiert. Seiten- und Aufgabenabdeckung geprüft; keine vollständige manuelle Überprüfung aller Layout- und Formelzeichen.

## Page 001

[Original page 1](../../../quellen/midterm_slide.pdf#page=1)

~~~~text
 <G07> · <S18 Northwest / Clothing>                                                                                             M1 · the decision that matters most


 1 · Observation and target
 Observation: <your real-world observation, one line>
 Target: <the number you compute on the raw slice, e.g. median order value> = <value on the raw slice>


 2 · The decision                                                           3 · Both alternatives, carried out
 Log ID: <D3>
 Column: <the column(s) the row of your log is                                                                                                         target lines
 about>                                                                     A: <action A, a few words>                                               <value>   <n>
 Problem: <what is wrong or unclear, one line>
                                                                            B: <action B, a few words>                                               <value>   <n>
 Rows affected: <lines> (<%> of the slice)
                                                                            difference B – A                                                          <∆, %>   <∆>


 4 · Choice
 Chosen: <A or B> — <one sentence: why, and what risk you accept>




One page, landscape. Every number comes from your own output and matches report Task 6. Three minutes to present. Any member may be asked to explain it.
~~~~

### DS-R009-P001-D01 — Midterm slide structure

One landscape page. Header group/slice placeholders and M1 Task 6. Full-width observation and target at top. Middle two columns: left log ID, column, problem, affected lines and percentage; right a comparison table. Full-width choice at bottom.

| Alternative | target | lines |
|---|---|---|
| A: action A | value | n |
| B: action B | value | n |
| difference B − A | Δ, % | Δ |

Choice: A or B, one sentence with why and accepted risk. Every number from group output and matching Task 6; three minutes. All shown values are placeholders, not results.

