---
source_id: DS-M1-EX
original_file: M1_sheet.pdf
source_type: exercise
language: en
page_count: 3
source_sha256: b9b20e7fbea1d817a73dc88ad8be549751e91135d95943a9de383bac788cbcc6
verification: partial
---
# M1_sheet

[Original PDF](../../../quellen/M1_sheet.pdf). Vollständige Textschicht. Rekonstruktionen sind separat markiert. Seiten- und Aufgabenabdeckung geprüft; keine vollständige manuelle Überprüfung aller Layout- und Formelzeichen.

## Page 001

[Original page 1](../../../quellen/M1_sheet.pdf#page=1)

<a id="ds-m1-ex-t01"></a>

**DS-M1-EX-T01 — The extract**

<a id="ds-m1-ex-t02"></a>

**DS-M1-EX-T02 — Your observation, your question, your target number**

~~~~text
   Data Science · Portfolio                                                                                             20 % of the module · built in U03 + U04
   Milestone M1 — Data quality: what is wrong with your slice
   Hand in M1_<group>.zip, e.g. M1_G07.zip · due 23:59 German time on the date in Schedule.pdf · how to hand in:
   HANDIN.pdf


   The question M1 answers: What is wrong with your slice — and does it matter for the question you want it to
   answer? You ﬁnd the problems and decide what to do. You change nothing yet: M2 carries out your decisions.

  Hand in M1_<group>.zip with

  report.pdf                                  one section per task, in this order (the template report.tex has them). Every
                                              ﬁgure goes into this PDF: export it as PNG (at least 150 dpi) or PDF from Python
                                              or KNIME, or take a screenshot of a KNIME view, and insert it where the task asks
                                              for it. Separate image ﬁles are not marked
  awc_flat.metadata.yaml                      Task 7
  your code                                   everything that produced a number: .py, .sql, .ipynb or .knwf
  manifest.yaml                               who did what, and the numbers in the box at the end

Your slice = your territory × your category (slices.csv). Your extract = the table your Task 1 script builds, one row per order
line. Raw = that table before any cleaning. Every task is marked; the rules in HANDIN.pdf §6 apply (short, tables rather than
prose, reproducible). Your slice may be clean in places — “0 missing, checked” is a valid answer, as long as the number behind
it is shown.

                                                                                                                    Sales_SalesOrderHeader
       Production_Product                                      Sales_SalesOrderDetail
                                                                                                                    SalesOrderID (key)
       ProductID (key)                                         SalesOrderDetailID (key)
                                                   many : 1                                              many : 1   OrderDate, OnlineOrderFlag
       Name, StandardCost,                                     SalesOrderID
                                                                                                                    CustomerID, TerritoryID
       ListPrice                                               ProductID
                                                                                                                    SalesPersonID (empty online)
       ProductSubcategoryID (can be                            OrderQty, UnitPrice,
                                                                                                                    SubTotal, TaxAmt, Freight,
       empty)                                                  UnitPriceDiscount, LineTotal
                                                                                                                    TotalDue (per order!)
                         many : 0..1 (LEFT JOIN)              one row of your extract = one order line                                 many : 1

       Production_ProductSubcategory
                                                                                                                    Sales_SalesTerritory
                                                                                                                                                     many : 1
       ProductSubcategoryID (key)
                                                                                                                    TerritoryID (key)
       ProductCategoryID, Name
                                                                                                                    Name ← your territory
                         many : 1                                                                                   CountryRegionCode, Group

       Production_ProductCategory
       ProductCategoryID (key)                                                                                      Sales_Customer
       Name ← your category                                                                                         CustomerID (key)
                                                                                                                    PersonID, StoreID, TerritoryID


Figure 1: The part of AdventureWorks (AWC) your extract is built from. Arrows point from many to one: an order has many
lines, a product sits in at most one subcategory. Your slice is the ﬁlter on the two orange names. TotalDue, SubTotal, TaxAmt
and Freight belong to the order: on a line-grain table they repeat on every line of that order, so summing them counts an
order several times — sum LineTotal. The ﬁgure shows how the tables join; the columns your extract keeps are the 25 of U01,
Exercise 4 — not SELECT *.


Task 1 — The extract
a) Write one script that builds your extract from the database along the ﬁgure: order line, order, product with sub-
   category and category, customer id, territory. It keeps the 25 columns of the U01 sheet, Exercise 4, under their
   names (the SELECT of Unit 02’s awc_extract.py). Filter it to your slice. It runs in one go: python3 extract.py,
   or a KNIME workﬂow with Reset and Execute All. It writes the extract once as a CSV ﬁle in your group folder
   (not into AWC/); your later scripts read that ﬁle. Say in the report in which order your scripts run.
b) Check it: lines, orders and customers equal your row of slices.csv. Count online and reseller lines, give the
   ﬁrst and last OrderDate and the number of months with at least one line.
c) Which join could lose rows without telling you, and how many lines of your slice would an inner join lose there?
   One sentence.
  Hand in: the script in the archive; in the report one small table: ﬁlter, counts, period, and the sentence on joins.
Taught in: U01 (join chain, grain), U02 (a re-runnable extract).

Task 2 — Your observation, your question, your target number
a) Observe something outside that AWC’s business has too: bikes, parts, helmets or clothing in a shop or online.
   Keep evidence with a date: a photo, a screenshot, a link, or a count you made (how many, where, when). No


Data Science · Portfolio · M1                                                                                                                                     1
~~~~

### DS-M1-EX-P001-D01 — Figure 1: AdventureWorks join graph

```mermaid
flowchart LR
 D[Sales_SalesOrderDetail] -->|many : 1; ProductID| P[Production_Product]
 D -->|many : 1; SalesOrderID| H[Sales_SalesOrderHeader]
 P -.->|many : 0..1; ProductSubcategoryID; LEFT JOIN| S[Production_ProductSubcategory]
 S -->|many : 1; ProductCategoryID| K[Production_ProductCategory]
 H -->|many : 1; TerritoryID| T[Sales_SalesTerritory]
 H -->|many : 1; CustomerID| C[Sales_Customer]
```

| Table | Key | Other attributes shown |
|---|---|---|
| Sales_SalesOrderDetail | SalesOrderDetailID | SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount, LineTotal |
| Production_Product | ProductID | Name, StandardCost, ListPrice, ProductSubcategoryID (may be empty) |
| Production_ProductSubcategory | ProductSubcategoryID | ProductCategoryID, Name |
| Production_ProductCategory | ProductCategoryID | Name (slice category) |
| Sales_SalesOrderHeader | SalesOrderID | OrderDate, OnlineOrderFlag, CustomerID, TerritoryID, SalesPersonID (empty online), SubTotal, TaxAmt, Freight, TotalDue |
| Sales_SalesTerritory | TerritoryID | Name (slice territory), CountryRegionCode, Group |
| Sales_Customer | CustomerID | PersonID, StoreID, TerritoryID |

Arrows point many→one; the optional product-subcategory edge is dashed. Orange highlights the order-line grain and the two slice filters. Order-level totals repeat on every line: sum LineTotal instead. Keep the 25 columns of U01 Exercise 4, not SELECT *.


## Page 002

[Original page 2](../../../quellen/M1_sheet.pdf#page=2)

<a id="ds-m1-ex-t03"></a>

**DS-M1-EX-T03 — Proﬁle**

<a id="ds-m1-ex-t04"></a>

**DS-M1-EX-T04 — Outliers and who is absent**

<a id="ds-m1-ex-t05"></a>

**DS-M1-EX-T05 — The cleaning log**

<a id="ds-m1-ex-t06"></a>

**DS-M1-EX-T06 — The decision that matters most**

<a id="ds-m1-ex-t07"></a>

**DS-M1-EX-T07 — Metadata and personal data**

~~~~text
   personal data.
b) Ask one question about your slice that the observation raises.
c) Deﬁne your target number: the number in your extract that answers it (column, grain, formula), and compute
   it on the raw extract. Every later decision is measured by what it does to this number.

  observed                                 question                                    target number
  20 helmet prices in 3 shops, median      what does a helmet sell for in our          median UnitPrice of the helmet lines
  60 EUR (photos)                          slice?
  a workshop orders parts once a           how big is a typical parts order?           median order value:    LineTotal per
                                                                                                             ∑
  month (photo of its delivery notes)                                                  SalesOrderID

  Hand in: the observation (at most ﬁve lines, evidence as a ﬁgure or link), the question, the target number with its deﬁnition
  and its raw value.
Why: data is not clean or dirty in general, only ﬁt or unﬁt for a purpose (U04).

Task 3 — Proﬁle
a) For every column: type, % missing, distinct values, min, max, most frequent value.
b) Missing values a plain count does not see: the text ’NULL’, ’N/A’, the empty string, -1, 1900-01-01. Per
   affected column: plain count and real count.
c) Grain: one column that is unique on every row, one that is not, with their distinct counts.
d) For every column with missing values: MCAR, MAR, MNAR or not applicable, one sentence why.
  Hand in: the full proﬁle as a CSV in the archive; in the report only the columns with a ﬁnding, the hidden-missing table, the
  grain line and the missingness lines.
Taught in: U01 (grain), U04 (proﬁling, missingness).

Task 4 — Outliers and who is absent
a) Median and mean of LineTotal, and mean divided by median.
b) Apply the 1.5 × IQR rule twice: to LineTotal (lines) and to the order value, LineTotal per SalesOrderID
                                                                               ∑
   (orders). Per grain: how many above and below the fences, and their share of revenue. Name the tool or
   quartile method you used.
c) Your three largest orders: error or real — and why?
d) Two groups that are absent from your slice, and the question each absence makes unanswerable.
  Hand in: one table for both grains, three lines on the largest orders, two lines on the absent groups.
Taught in: U04 (IQR fences at two grains, selection bias).

Task 5 — The cleaning log
One row per problem you found, with these columns:

           id    problem (column, with a number)       action   rejected alternative    why   effect on target   status

 • Action, precise enough that M2 can carry it out without asking you (column, condition, what happens), and one
   of: annotate (a ﬂag column), quarantine (rows move to a reject table), ﬁx when reading, ask the owner (nothing
   changes yet).
 • Effect on target: what the action does to your Task 2 number, and how many rows it removes.
 • Status: applied, deferred, rejected or unresolved.
 • At least four rows; at least one rejected or unresolved. For one row say why you keep the original value, and
   who might need it.
  Hand in: the log as a table. Worked rows: Scripts/cleaning_log_template.md in Unit 04.
Taught in: U04 (cleaning with reasons; correcting is not overwriting).

Task 6 — The decision that matters most
Take the row of your log whose action or rejected alternative moves your target number most. Carry out both, give
target number and row count for each, and argue for your choice.
  Hand in: half a page to a page, an argument rather than a table. Presented in the mid-term session (Schedule.pdf).

Task 7 — Metadata and personal data
a) Write awc_flat.metadata.yaml: what the dataset is; where it comes from (source, script, date, who ran it); a
   data dictionary for your 10 most important columns (name, type, unit, meaning); one known_issues entry per
   row of your log; a FAIR score 1–3 per principle with one thing you are missing.


Data Science · Portfolio · M1                                                                                                     2
~~~~

### DS-M1-EX-P002-T01 — Cleaning log schema

| id | problem (column, with a number) | action | rejected alternative | why | effect on target | status |
|---|---|---|---|---|---|---|

At least four rows, at least one rejected or unresolved. Original allowed actions: annotate, quarantine, fix when reading, ask the owner. Original statuses: applied, deferred, rejected, unresolved. Order value is $\sum_{i\in\mathrm{order}}\mathrm{LineTotal}_i$; outliers by $1.5\times\mathrm{IQR}$ at both grains.


## Page 003

[Original page 3](../../../quellen/M1_sheet.pdf#page=3)

~~~~text
b) Does your slice hold personal data? Argue from identiﬁability: which columns together could point to one
   person, and what you would coarsen ﬁrst.
  Hand in: the YAML ﬁle in the archive; in the report at most ten lines on personal data.
Taught in: U03 (metadata, FAIR, k-anonymity).

  The numbers in manifest.yaml — on your raw slice, copied from your own output

  lines, orders, customers                              Task 1b
  lines_online, lines_reseller, months_covered          Task 1b (0 is a valid value)
  linetotal_median, mean_over_median                    Task 4a
  iqr_outliers_lines, iqr_outliers_orders               Task 4b, above and below together

Before you upload: python3 check_submission.py M1_<group>.zip inside the kit. It checks names and counts, not the work.




Data Science · Portfolio · M1                                                                                        3
~~~~
