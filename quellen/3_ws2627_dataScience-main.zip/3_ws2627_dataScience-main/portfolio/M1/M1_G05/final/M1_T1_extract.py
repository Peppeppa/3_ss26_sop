#!/usr/bin/env python3
import os
from getpass import getpass
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

TERRITORY = "Germany"
CATEGORY = "Bikes"

QUERY = text("""
SELECT
    d.SalesOrderID,
    d.SalesOrderDetailID,
    d.ProductID,
    d.OrderQty,
    d.UnitPrice,
    d.UnitPriceDiscount,
    d.LineTotal,
    DATE(h.OrderDate) AS OrderDate,
    DATE(h.ShipDate) AS ShipDate,
    h.OnlineOrderFlag,
    h.CustomerID,
    h.TerritoryID,
    h.SalesPersonID,
    h.SubTotal,
    h.TaxAmt,
    h.Freight,
    h.TotalDue,
    p.Name AS ProductName,
    p.StandardCost,
    p.ListPrice,
    sc.Name AS SubCategory,
    cat.Name AS Category,
    t.Name AS TerritoryName,
    t.CountryRegionCode,
    t.`Group` AS TerritoryGroup
FROM Sales_SalesOrderDetail AS d
JOIN Sales_SalesOrderHeader AS h
    ON d.SalesOrderID = h.SalesOrderID
JOIN Production_Product AS p
    ON d.ProductID = p.ProductID
LEFT JOIN Production_ProductSubcategory AS sc
    ON p.ProductSubcategoryID = sc.ProductSubcategoryID
LEFT JOIN Production_ProductCategory AS cat
    ON sc.ProductCategoryID = cat.ProductCategoryID
JOIN Sales_SalesTerritory AS t
    ON h.TerritoryID = t.TerritoryID
WHERE t.Name = :territory
  AND cat.Name = :category
ORDER BY d.SalesOrderDetailID
""")


def main():
    # Use the environment variable or ask securely for the password.
    password = os.environ.get("AWC_DB_PW")
    if not password:
        password = getpass("MySQL-Passwort: ")
    if not password:
        raise SystemExit("Kein MySQL-Passwort eingegeben.")

    url = URL.create(
        "mysql+mysqlconnector",
        username=os.environ.get("AWC_DB_USER", "sqladmin"),
        password=password,
        host="localhost",
        port=3306,
        database="Adventureworks2019",
    )
    engine = create_engine(url)
    try:
        with engine.connect() as conn:
            df = pd.read_sql_query(
                QUERY,
                conn,
                params={"territory": TERRITORY, "category": CATEGORY},
            )
    finally:
        engine.dispose()

    if df.empty:
        raise SystemExit("Keine Zeilen gefunden: Datenbank, JOINs und Filter pruefen.")
    if df["SalesOrderDetailID"].duplicated().any():
        raise SystemExit("Fehler: Eine Bestellpositions-ID kommt mehrfach vor.")

    target = Path(__file__).resolve().parent / "extract.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(target, index=False, encoding="utf-8-sig")

    lines = len(df)
    orders = df["SalesOrderID"].nunique()
    customers = df["CustomerID"].nunique()
    print(f"Slice S11: {TERRITORY} / {CATEGORY}")
    print(f"Lines:     {lines}")
    print(f"Orders:    {orders}")
    print(f"Customers: {customers}")
    print(f"Extrakt gespeichert: {target}")
    if (lines, orders, customers) == (2255, 1701, 934):
        print("Kontrolle mit slices.csv: OK")
    else:
        print("ACHTUNG: Die Zahlen weichen von slices.csv (S11) ab.")


if __name__ == "__main__":
    main()
