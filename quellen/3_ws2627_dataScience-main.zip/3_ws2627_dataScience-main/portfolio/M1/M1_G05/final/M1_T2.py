#!/usr/bin/env python3

import pandas as pd

df = pd.read_csv("extract.csv")

# Revenue per order = sum of LineTotal per SalesOrderID
order_revenue = df.groupby("SalesOrderID")["LineTotal"].sum()

print(f"Average bicycle revenue per order: {order_revenue.mean():,.2f}")
