#!/usr/bin/env python3

from pathlib import Path
import pandas as pd

# Task 6: the decision that matters most -- C1, empty SalesPersonID / StoreID.
# Target: mean order value = sum(LineTotal) per SalesOrderID, averaged over orders.

csv_file = Path(__file__).with_name("extract.csv")
df = pd.read_csv(csv_file)


def mean_order_value(d):
    return d.groupby("SalesOrderID")["LineTotal"].sum().mean()


def summary(label, d):
    print(label)
    print(f"  lines            = {len(d):,}")
    print(f"  mean order value = {mean_order_value(d):,.2f} USD")
    print()


# Both variants of C1
action = df  # fix when reading: keep the NULLs
alternative = df[df["SalesPersonID"].notna()]  # drop rows with NULL

summary("Action: fix when reading, keep the NULLs", action)
summary("Alternative: drop rows with NULL", alternative)

