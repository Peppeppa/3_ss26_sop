#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

# Task 5: effect of every cleaning-log row on the Task 2 target number.
# Target: mean order value = sum(LineTotal) per SalesOrderID, averaged over orders.
csv_file = Path(__file__).with_name("extract.csv")
df = pd.read_csv(csv_file)
df["OrderDate"] = pd.to_datetime(df["OrderDate"])

FENCE = 4785.69  # upper 1.5*IQR fence from M1_T4.py (same for both grains)
USD_PER_EUR = 1.1216  # ECB reference rate 2026-11-02 (1 EUR = 1.1216 USD)
N_ROWS = len(df)


def target(d):
    orders = d.groupby("SalesOrderID")["LineTotal"].sum()
    return orders.mean(), len(orders)


def report(label, d):
    mean, n_orders = target(d)
    print(
        f"{label:<48} target = {mean:>10.2f} | orders = {n_orders:>4} "
        f"| rows removed = {N_ROWS - len(d)}"
    )


raw_mean, raw_n = target(df)
print(f"Raw target: {raw_mean:.2f} | orders = {raw_n} | lines = {N_ROWS}")
orders = df.groupby("SalesOrderID").agg(
    value=("LineTotal", "sum"),
    online=("OnlineOrderFlag", "first"),
    subtotal=("SubTotal", "first"),
    year=("OrderDate", lambda s: s.dt.year.iloc[0]),
)
print(orders.groupby("online")["value"].agg(["size", "mean", "median"]).to_string())
print()

# C1: SalesPersonID missing
miss = df["SalesPersonID"].isna()
print("C1 SalesPersonID missing:", miss.sum(), f"({100 * miss.mean():.2f} %)")
report("C1 action: annotate is_online", df)
report("C1 rejected: drop rows with NULL", df[~miss])
print()

# C2: line outliers above the IQR fence
out_line = df["LineTotal"] > FENCE
print("C2 line outliers:", out_line.sum())
report("C2 action: annotate outlier_line", df)
report("C2 rejected: quarantine outlier lines", df[~out_line])
print()

# C3: order outliers above the IQR fence
big = orders[orders["value"] > FENCE].index
in_big = df["SalesOrderID"].isin(big)
print(
    "C3 order outliers:",
    len(big),
    "orders,",
    in_big.sum(),
    "lines, online orders:",
    int(orders.loc[big, "online"].sum()),
)
report("C3 action: keep, annotate outlier_order", df)
report("C3 rejected: quarantine outlier orders", df[~in_big])
print()

# C4: currency -- AWC amounts are USD, shop prices are EUR
print(
    f"C4 rejected: convert to EUR when reading       target = {raw_mean / USD_PER_EUR:>10.2f} "
    f"| orders = {raw_n:>4} | rows removed = 0"
)
print()
