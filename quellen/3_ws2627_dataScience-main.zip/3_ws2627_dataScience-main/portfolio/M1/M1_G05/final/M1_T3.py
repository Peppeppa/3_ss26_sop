#!/usr/bin/env python3
"""M1 Task 3: data profiling and missing-value analysis for awc_flat.csv."""

from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parent
SOURCE = BASE / "extract.csv"
TARGET = BASE / "profile.csv"

# Columns present in the current AdventureWorks export.
DATE_COLUMNS = ["OrderDate", "ShipDate"]
DETAIL_ID = "SalesOrderDetailID"
ORDER_ID = "SalesOrderID"
SALESPERSON = "SalesPersonID"
ONLINE_FLAG = "OnlineOrderFlag"
REQUIRED_COLUMNS = [*DATE_COLUMNS, DETAIL_ID, ORDER_ID, SALESPERSON, ONLINE_FLAG]


def load_data():
    """Load original CSV values with inferred types; retain raw text for placeholder checks."""
    if not SOURCE.is_file():
        raise FileNotFoundError(f"CSV file not found: {SOURCE}")

    raw = pd.read_csv(SOURCE, encoding="utf-8-sig", dtype=str, keep_default_na=False)
    missing_columns = [c for c in REQUIRED_COLUMNS if c not in raw.columns]
    if missing_columns:
        raise ValueError(f"Expected CSV columns are missing: {missing_columns}")

    df = pd.read_csv(
        SOURCE,
        encoding="utf-8-sig",
        sep=",",
        decimal=".",
        keep_default_na=False,  # Retain NULL / N/A for Task 3b.
        na_values=[""],  # An empty CSV cell is missing.
        low_memory=False,
    )
    return df, raw


def report_value(value):
    """Represent missing statistics as empty cells in profile.csv."""
    if pd.isna(value):
        return None
    return value


# ---------------------------------------------------------------- Task 3a


def profile_column(series):
    """Calculate summary statistics for one column."""
    observed = series.dropna()
    mode = observed.mode()
    return {
        "column": series.name,
        "type": str(series.dtype),
        "pct_missing": round(series.isna().mean() * 100, 2),
        "distinct": observed.nunique(),
        "min": report_value(observed.min()) if not observed.empty else None,
        "max": report_value(observed.max()) if not observed.empty else None,
        "most_frequent": report_value(mode.iloc[0]) if not mode.empty else None,
    }


def task_3a(df):
    profile = pd.DataFrame([profile_column(df[c]) for c in df.columns])
    profile.to_csv(TARGET, index=False, encoding="utf-8-sig")

    types = sorted(profile["type"].unique())
    missing = profile.loc[profile["pct_missing"] > 0, "column"].tolist()
    print("TASK 3a - Profile")
    print(f"Rows: {len(df)}   Columns: {df.shape[1]}")
    print(f"Types: {', '.join(types)}")
    print(f"Missing: {', '.join(missing) if missing else 'none'}")
    print(f"Saved as {TARGET.name}")


# ---------------------------------------------------------------- Task 3b


def find_patterns(series):
    """Check placeholders in raw text, not in pandas-converted values."""
    stripped = series.str.strip()
    upper = stripped.str.upper()
    return {
        "null_text": upper == "NULL",
        "na_text": upper == "N/A",
        "blank_text": (stripped == "") & (series != ""),
        "minus_one": pd.to_numeric(stripped, errors="coerce") == -1,
        "date_1900": stripped.str.startswith("1900-01-01"),
    }


def missing_mask(series):
    """Identify empty cells and known hidden-missing placeholders."""
    mask = series == ""
    for pattern_mask in find_patterns(series).values():
        mask |= pattern_mask
    return mask


def task_3b(raw):
    results = []
    for column in raw.columns:
        series = raw[column]
        patterns = find_patterns(series)
        plain_missing = int((series == "").sum())
        real_missing = int(missing_mask(series).sum())
        results.append(
            {
                "column": column,
                "plain_missing": plain_missing,
                **{name: int(mask.sum()) for name, mask in patterns.items()},
                "real_missing": real_missing,
            }
        )

    result = pd.DataFrame(results)
    print("\nTASK 3b - Hidden missing values")
    print("Columns with missing values:")
    missing = result[result["real_missing"] > 0]
    if missing.empty:
        print("none")
    else:
        print("\n".join(missing["column"]))

    hidden = result[result["real_missing"] > result["plain_missing"]]
    if hidden.empty:
        print("No hidden missing values found; only empty CSV cells.")
    else:
        print("Hidden placeholders detected in:", ", ".join(hidden["column"]))


# ---------------------------------------------------------------- Task 3c


def task_3c(df):
    rows = len(df)
    unique_cols = [c for c in df.columns if df[c].notna().all() and df[c].is_unique]
    detail_unique = df[DETAIL_ID].notna().all() and df[DETAIL_ID].is_unique
    order_unique = df[ORDER_ID].notna().all() and df[ORDER_ID].is_unique

    print("\nTASK 3c - Grain")
    print(f"Rows: {rows}")
    print(f"Unique on every row: {unique_cols}")
    print(f"{DETAIL_ID}: {df[DETAIL_ID].nunique()} distinct; unique = {detail_unique}")
    print(f"{ORDER_ID}: {df[ORDER_ID].nunique()} distinct; unique = {order_unique}")
    if detail_unique:
        print(f"Grain: one row = one sales order line ({DETAIL_ID}).")
    else:
        print("Grain: cannot confirm one row per sales order line.")


# ---------------------------------------------------------------- Task 3d


def task_3d(raw):
    with_gaps = [c for c in raw if missing_mask(raw[c]).any()]

    print("\nTASK 3d - Missingness mechanism")
    print(f"Columns with missing values: {len(with_gaps)}")
    if not with_gaps:
        print("No missingness to analyze.")
        return

    # In this extract, only SalesPersonID has gaps; test its relation to
    # OnlineOrderFlag rather than guessing a mechanism from all columns.
    if SALESPERSON in with_gaps:
        mask = missing_mask(raw[SALESPERSON])
        grouped = mask.groupby(raw[ONLINE_FLAG]).agg(["size", "sum", "mean"])
        print(f"{SALESPERSON} by {ONLINE_FLAG}:")
        for flag, row in grouped.iterrows():
            print(
                f"  {ONLINE_FLAG} = {flag}: "
                f"{int(row['sum'])}/{int(row['size'])} missing "
                f"({row['mean']:.1%})"
            )

        if (
            "0" in grouped.index
            and "1" in grouped.index
            and grouped.loc["0", "mean"] == 0
            and grouped.loc["1", "mean"] == 1
        ):
            print(
                "Interpretation: structural missingness / not applicable "
                "for online orders (confirm with business rules)."
            )
            print("Not MCAR: the missingness is fully linked to OnlineOrderFlag.")
        else:
            print(
                "Missingness varies with OnlineOrderFlag; investigate "
                "the business rules before classifying the mechanism."
            )

    for column in with_gaps:
        if column != SALESPERSON:
            print(f"{column}: missing values found; investigate separately.")
    print("MCAR/MAR/MNAR cannot be proven from these comparisons alone;")
    print("MNAR in particular requires additional assumptions or information.")


def main():
    df, raw = load_data()
    task_3a(df)
    task_3b(raw)
    task_3c(df)
    task_3d(raw)


if __name__ == "__main__":
    main()
