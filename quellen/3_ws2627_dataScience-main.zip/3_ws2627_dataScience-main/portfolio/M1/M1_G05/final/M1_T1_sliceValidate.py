#!/usr/bin/env python3
from pathlib import Path

import pandas as pd


# The two CSV files are expected next to this script in the AWC folder.
folder = Path(__file__).resolve().parent
flat_file = folder / "extract.csv"
slices_file = folder / "slices.csv"

# This is only the identifier of our assigned slice, not a reference value.
slice_id = "S11"

df = pd.read_csv(
    flat_file,
    encoding="utf-8-sig",
    sep=",",
    decimal=".",
    header=0,
    dtype={
        "SalesOrderDetailID": "Int64",
        "SalesOrderID": "Int64",
        "CustomerID": "Int64",
        "OnlineOrderFlag": "Int64",
        "TerritoryName": "string",
        "Category": "string",
        "OrderDate": "string",
    },
    low_memory=False,
)

slices = pd.read_csv(
    slices_file,
    encoding="utf-8-sig",
    sep=",",
    decimal=".",
    header=0,
    dtype={
        "slice_id": "string",
        "TerritoryName": "string",
        "Category": "string",
        "lines": "Int64",
        "orders": "Int64",
        "customers": "Int64",
        "products": "Int64",
        "revenue": "float64",
        "pool": "string",
        "ref_cutoff": "Int64",
        "ref_unit": "string",
    },
    low_memory=False,
)

# Locate the reference row using its unique ID, never its row position.
reference_rows = slices.loc[slices["slice_id"] == slice_id]
if len(reference_rows) != 1:
    raise ValueError(
        f"Expected exactly one row for {slice_id}; found {len(reference_rows)}."
    )
reference = reference_rows.iloc[0]
territory = reference["TerritoryName"]
category = reference["Category"]

# Check that the flat table contains exactly our assigned slice.
if df.empty:
    raise ValueError("The CSV file is empty.")
if not df["TerritoryName"].eq(territory).all():
    raise ValueError(f"The CSV contains rows outside {territory}.")
if not df["Category"].eq(category).all():
    raise ValueError(f"The CSV contains rows outside {category}.")
if df["SalesOrderDetailID"].isna().any() or not df["SalesOrderDetailID"].is_unique:
    raise ValueError("SalesOrderDetailID must be present and unique.")

# Calculate values from the flat table.
lines = len(df)
orders = df["SalesOrderID"].nunique()
customers = df["CustomerID"].nunique()

if df["OnlineOrderFlag"].isna().any() or not df["OnlineOrderFlag"].isin([0, 1]).all():
    raise ValueError(
        "OnlineOrderFlag contains missing values or values other than 0 or 1."
    )
lines_online = int((df["OnlineOrderFlag"] == 1).sum())
lines_reseller = int((df["OnlineOrderFlag"] == 0).sum())

order_dates = pd.to_datetime(df["OrderDate"], errors="raise")
if order_dates.isna().any():
    raise ValueError("Some order dates are missing.")
first_date = order_dates.min().date()
last_date = order_dates.max().date()
months_covered = order_dates.dt.to_period("M").nunique()

# Preserve the existing output structure.
print(f"TASK 1b - {territory} / {category}")
print(f"Lines:           {lines}")
print(f"Orders:          {orders}")
print(f"Customers:       {customers}")
print(f"Online lines:    {lines_online}")
print(f"Reseller lines:  {lines_reseller}")
print(f"First OrderDate: {first_date}")
print(f"Last OrderDate:  {last_date}")
print(f"Months covered:  {months_covered}")

# All expected counts are read from slices.csv.
expected_counts = tuple(
    int(reference[column]) for column in ("lines", "orders", "customers")
)
actual_counts = (lines, orders, customers)

print("\nSLICE COUNT CHECK")
print(f"Lines:     expected {expected_counts[0]}, calculated {lines}")
print(f"Orders:    expected {expected_counts[1]}, calculated {orders}")
print(f"Customers: expected {expected_counts[2]}, calculated {customers}")

if actual_counts == expected_counts:
    print("Result: OK - All counts match the reference values.")
else:
    print("Result: MISMATCH - Some counts are different.")

print("\nCHANNEL COUNT CHECK")
print(f"Online lines:   {lines_online}")
print(f"Reseller lines: {lines_reseller}")
print(f"Sum:            {lines_online + lines_reseller}")
print(f"Total lines:    {lines}")

if lines_online + lines_reseller == lines:
    print("Result: OK - All lines are included in the two channels.")
else:
    print("Result: MISMATCH - The channel counts do not match.")
