#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

# Read the raw Germany/Bikes extract.
csv_file = Path(__file__).with_name("extract.csv")
df = pd.read_csv(csv_file)

# Task 4a: mean, median and their ratio.
mean_line = df["LineTotal"].mean()
median_line = df["LineTotal"].median()
mean_median_ratio = mean_line / median_line

print("TASK 4a - LineTotal")
print(f"Mean: {mean_line:.2f}")
print(f"Median: {median_line:.2f}")
print(f"Mean / median: {mean_median_ratio:.4f}")


# Task 4b: first check individual order lines.
q1_line = df["LineTotal"].quantile(0.25)
q3_line = df["LineTotal"].quantile(0.75)
iqr_line = q3_line - q1_line

line_low = q1_line - 1.5 * iqr_line
line_high = q3_line + 1.5 * iqr_line

low_lines = df[df["LineTotal"] < line_low]
high_lines = df[df["LineTotal"] > line_high]

# Add the line amounts within each order before checking order outliers.
orders = df.groupby("SalesOrderID").agg(
    Revenue=("LineTotal", "sum"),
    Lines=("SalesOrderDetailID", "size"),
    Quantity=("OrderQty", "sum"),
    OnlineFlag=("OnlineOrderFlag", "first"),
)

order_values = orders["Revenue"]

q1_order = order_values.quantile(0.25)
q3_order = order_values.quantile(0.75)
iqr_order = q3_order - q1_order

order_low = q1_order - 1.5 * iqr_order
order_high = q3_order + 1.5 * iqr_order

low_orders = order_values[order_values < order_low]
high_orders = order_values[order_values > order_high]

# Revenue shares use the same Germany/Bikes total at both grains.
total_revenue = df["LineTotal"].sum()

line_outlier_revenue = low_lines["LineTotal"].sum() + high_lines["LineTotal"].sum()

order_outlier_revenue = low_orders.sum() + high_orders.sum()

line_share = 100 * line_outlier_revenue / total_revenue
order_share = 100 * order_outlier_revenue / total_revenue

assert abs(order_values.sum() - total_revenue) < 0.01

print("\nTASK 4b - Outliers (pandas quantile, linear interpolation)")
print(f"Line fences: {line_low:.2f} to {line_high:.2f}")
print(f"Order fences: {order_low:.2f} to {order_high:.2f}")

results = pd.DataFrame(
    [
        ["Order lines", len(df), len(low_lines), len(high_lines), f"{line_share:.2f}%"],
        [
            "Orders",
            len(orders),
            len(low_orders),
            len(high_orders),
            f"{order_share:.2f}%",
        ],
    ],
    columns=["Grain", "Total", "Below", "Above", "Revenue share"],
)

print(results.to_string(index=False))
print(f"Total revenue: {total_revenue:.2f}")
print(f"Outlier line revenue: {line_outlier_revenue:.2f}")
print(f"Outlier order revenue: {order_outlier_revenue:.2f}")


# Task 4c: look at the three orders with the largest bike revenue.
top3 = orders.nlargest(3, "Revenue")

print("\nTASK 4c - Three largest orders")

for order_id, item in top3.iterrows():
    print(
        f"{order_id}: revenue {item['Revenue']:.2f}, "
        f"{int(item['Lines'])} lines, "
        f"{int(item['Quantity'])} bikes, "
        f"OnlineOrderFlag {int(item['OnlineFlag'])}"
    )

# Check whether their line totals match quantity, price and discount.
top3_lines = df[df["SalesOrderID"].isin(top3.index)]

expected = (
    top3_lines["OrderQty"]
    * top3_lines["UnitPrice"]
    * (1 - top3_lines["UnitPriceDiscount"])
)

difference = (top3_lines["LineTotal"] - expected).abs()

print(f"Lines checked: {len(top3_lines)}")
print(f"Differences over 0.01: {(difference > 0.01).sum()}")
print(f"Largest difference: {difference.max():.12f}")


# Task 4d: These groups are absent from our slice.
print("\nTASK 4d - Groups not covered")

print(
    "\n1. Non-buyers (Selection Bias):\n"
    "Our slice contains only recorded bicycle purchases, "
    "not people who considered buying but did not purchase. "
    "Therefore, we cannot determine why potential customers "
    "did not buy a bicycle."
)

print(
    "\n2. Rejected and cancelled orders (Survivorship Bias):\n"
    "According to Unit 04, AdventureWorks contains only shipped "
    "orders (status 5). Rejected and cancelled orders are absent. "
    "Therefore, we cannot determine how often orders were "
    "rejected or cancelled."
)
