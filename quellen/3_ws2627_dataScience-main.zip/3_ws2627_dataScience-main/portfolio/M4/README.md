# M4 – Mündliche Verteidigung

**Termin:** Im Prüfungszeitraum, laut Manifest noch offen.

## Ziele
Alle Entscheidungen aus M1–M3 inklusive Datenherkunft, Datenqualität, Methodenauswahl, Visualisierungen, Alternativen und Reproduzierbarkeit selbstständig erklären können.

Keine zusätzliche Datei im Manifest vorgesehen; maßgeblich sind aktuelle offizielle Prüfungsinformationen.
