---
source_id: DS-M2-EX
original_file: M2_sheet.pdf
source_type: exercise
language: en
page_count: 3
source_sha256: 6bb9f1e2f61028ce6f6727e3264316b1ee002c6356048902b5c093c14f5f6481
verification: partial
---
# M2_sheet

[Original PDF](../../../quellen/M2_sheet.pdf). Vollständige Textschicht. Rekonstruktionen sind separat markiert. Seiten- und Aufgabenabdeckung geprüft; keine vollständige manuelle Überprüfung aller Layout- und Formelzeichen.

## Page 001

[Original page 1](../../../quellen/M2_sheet.pdf#page=1)

<a id="ds-m2-ex-t01"></a>

**DS-M2-EX-T01 — Carry out your cleaning log**

<a id="ds-m2-ex-t02"></a>

**DS-M2-EX-T02 — The feature matrix**

~~~~text
   Data Science · Portfolio                                                          20 % of the module · built in U06 + U07 + U08
   Milestone M2 — The cleaned table, and its structure
   Hand in M2_<group>.zip, e.g. M2_G07.zip · due 23:59 German time on the date in Schedule.pdf · how to hand in:
   HANDIN.pdf


   The question M2 answers: You carry out your M1 cleaning log and hand in the table it produces. Then you
   look for structure: which customers resemble which, whether groups exist, and which ﬁve pictures are worth
   showing.

  Hand in M2_<group>.zip with

  report.pdf              one section per task, in this order (the template report.tex has them). Every ﬁgure goes
                          into this PDF: export it as PNG (at least 150 dpi) or PDF from Python or KNIME, or take a
                          screenshot of a KNIME view, and insert it where the task asks for it. Separate image ﬁles
                          are not marked
  clean_flat.csv          the table your M1 log produces (Task 1). M3 is built on it
  your code               everything that produced a number: .py, .sql, .ipynb or .knwf
  manifest.yaml           who did what, and the blocks in the box at the end

Every task is marked; the rules in HANDIN.pdf §6 apply. “No clear cluster structure” is a valid result. A structure you claim
without the evidence asked for below is not.

                                                                                       measure, heatmap
                                                                                           Task 3



          raw extract               clean_flat.csv                  feature matrix
                                                                                          PCA, t-SNE                   ﬁve plots
         (M1, Task 1)               row = order line               row = customer
                           M1 log                      aggregate                           Task 4                       Task 6
                                        Task 1                          Task 2
                                                                                                                swap               revise

                                                                                           k-means,
                                                                                                                   peer review
                                                                                          agreement
                                                                                                                     Task 7
                                                                                            Task 5


Figure 1: What M2 builds, and from what. Orange: what the archive carries as ﬁles. The grain changes once: clean_flat.csv
has one row per order line, the feature matrix one row per customer.



Task 1 — Carry out your cleaning log
a) Apply every decision of your M1 log, in the order of the log, to the raw extract. Write the result as
   clean_flat.csv, one row per order line. Do not clean again from scratch: M2 carries out what M1 decided.
b) Per decision id: how many rows it touched, and what changed. Name every decision you could not apply, and
   what you did instead.
c) Say how the raw extract can be rebuilt from what you hand in (ﬂag columns, a quarantine ﬁle, the script).
d) The numbers must close: rows in − rows removed = rows out = data rows in clean_flat.csv. If your log
   removes nothing, rows removed is 0.
  Hand in: one table, one row per decision id (rows touched, what changed, applied or not); two lines on rebuilding the raw
  extract.
Taught in: U04 (correcting is not overwriting).

Task 2 — The feature matrix
a) Aggregate clean_flat.csv to one row per customer. Start from these nine features: the ﬁve size features
   of U07 (revenue, number of orders, distinct products, average order value, total quantity), plus span in days
   (ﬁrst to last order), recency in days (last order to the last order date in your table), discount share (share of the
   customer’s order lines with a discount) and online share. U07’s four category shares do not apply: in a slice of
   one category they are constant. Drop or add features, each with a reason.
b) One line per scaling or encoding decision: what you did, the alternative you rejected, the risk your choice
   creates.
c) If the matrix has fewer customers than your cleaned table, say which you left out and why.
  Hand in: objects and features of the matrix, and the decision lines as a table.
Taught in: U06 (encoding, scaling: an unscaled Euclidean distance compares one feature).



Data Science · Portfolio · M2                                                                                                               1
~~~~

### DS-M2-EX-P001-D01 — Figure 1: M2 workflow

```mermaid
flowchart LR
 R[Raw extract M1 Task 1] -->|M1 log| C[clean_flat.csv: order line; Task 1]
 C -->|aggregate| F[Feature matrix: customer; Task 2]
 F --> D[Measure and heatmap: Task 3]
 F --> P[PCA and t-SNE: Task 4]
 F --> K[k-means and agreement: Task 5]
 D --> V[Five plots: Task 6]
 P --> V
 K --> V
 V -->|swap| Q[Peer review: Task 7]
 Q -->|revise| V
```

Orange outline: clean_flat.csv is carried in the archive; orange swap/revise arrows form the review cycle. Grain changes only once, from order line to customer. Task 6 uses revised plots; original plots go in the report appendix.


## Page 002

[Original page 2](../../../quellen/M2_sheet.pdf#page=2)

<a id="ds-m2-ex-t03"></a>

**DS-M2-EX-T03 — One measure of similarity, defended**

<a id="ds-m2-ex-t04"></a>

**DS-M2-EX-T04 — Reduce: PCA and t-SNE**

<a id="ds-m2-ex-t05"></a>

**DS-M2-EX-T05 — Cluster, and what you may claim**

<a id="ds-m2-ex-t06"></a>

**DS-M2-EX-T06 — Five plots, ﬁve questions**

<a id="ds-m2-ex-t07"></a>

**DS-M2-EX-T07 — Peer review**

~~~~text
Task 3 — One measure of similarity, defended
a) Ask a business question about your customers and choose one measure for it (e.g. Euclidean on scaled fea-
   tures, cosine, Jaccard on the products bought). Which question does it answer well, which would it answer
   wrongly, what does it ignore?
b) Compute a second measure. Show one pair of customers the two disagree about, with both values, and explain
   why in business terms.
c) Keep one label outside the matrix: the channel (online or reseller), or, if your slice has one channel only, another
   one (e.g. the subcategory a customer buys most). Sort the distance matrix by it and show it as a heatmap: do
   blocks appear? If a feature already encodes the label (online share is the channel), the blocks are a tautology,
   not a ﬁnding.
  Hand in: the measure with its question (at most ﬁve lines), the disagreeing pair with both values, the sorted heatmap with
  two lines on what it shows.
Taught in: U06 (Euclidean, cosine, Jaccard; when two measures disagree).

Task 4 — Reduce: PCA and t-SNE
a) PCA on the scaled matrix: explained variance per component, how many components you keep, and the rule
   that ﬁxed that number. What does PC1 measure (its loadings)?
b) Show the scree plot with the cumulative curve, and PC1 against PC2. Every projection carries the variance
   share of its two axes in the caption.
c) t-SNE at three perplexities, and one of them at three seeds. Report as a ﬁnding only what all runs show.
  Hand in: the variance table, the scree ﬁgure, PC1 in one line, the t-SNE runs as one ﬁgure with a short verdict.
Taught in: U07 (scree, loadings, the rule for k; what t-SNE keeps and what it does not).

Task 5 — Cluster, and what you may claim
a) k-means with restarts: which k, by which criterion, how stable across restarts, and the cluster sizes.
b) Run the same k-means on your t-SNE map and on the PCA plane. Give each one’s agreement with the cluster-
   ing on the features, as one number, and say which measure you used: the ARI (0 = chance, 1 = identical; Python
   adjusted_rand_score) or any other agreement measure. KNIME has no ARI node: the Entropy Scorer com-
   pares a cluster column with a reference column (entropy 0, quality 1 = identical), and a Crosstab of the two
   labellings shows where they part. Which picture may you read clusters from?
c) If your clusters just repeat the channel, say so — it is a result, but a known one — and look once inside the larger
   channel.
d) Two claims you can defend, two you cannot, each with a number from Tasks 3 to 5.
  Hand in: k with its criterion and stability, the sizes, the two agreement values with their measure, and the four claims as a
  table.
Taught in: U07 (k-means and restarts, agreement of two clusterings; clustering a 2D map is not clustering the data).

Task 6 — Five plots, ﬁve questions
Five questions about your cleaned slice, one plot each:
 • the title states the answer, not the topic, and one or two sentences say what to read;
 • the chart form follows from the question, and you say why (U08);
 • axes with units, a legend for more than one series, a palette that passes the colour-blindness check
   (validate_palette.py, U08).
  Hand in: ﬁve ﬁgures, each with its question, its answer as the title and one or two sentences — the revised versions after
  Task 7.
Taught in: U08 (form from the question; where the axis starts; colour is computed, not eyeballed).

Task 7 — Peer review
In the peer-review session (Schedule.pdf) you swap your ﬁve plots with another group, review theirs, and revise
yours.
 • The revised plots go into Task 6; the originals go into an appendix Before the review at the end of report.pdf.
 • Per plot: what the other group said, what you changed — or why not — and who revised it.
 • Name the group that reviewed you.
  Hand in: one table, one row per plot (what they said, what you changed or why not, who revised it); the ﬁve original plots in
  the appendix.
Why: this part can be attributed to one person, and is used that way if a mark has to differ from the group’s.




Data Science · Portfolio · M2                                                                                                     2
~~~~

## Page 003

[Original page 3](../../../quellen/M2_sheet.pdf#page=3)

~~~~text
  What manifest.yaml carries for M2 (format: HANDIN.pdf §5)

  findings: lines, orders, customers, linetotal_median   your raw slice, as in M1
  cleaned: rows, columns, median_of, median              from your clean_flat.csv
  cleaning: rows_in, rows_removed, rows_out              Task 1d
  matrix: objects, features, dropped_because             Task 2 (the reason only if you left customers out)
  clusters: k, sizes, unassigned                         Task 5: sizes + unassigned = objects

Before you upload: python3 check_submission.py M2_<group>.zip inside the kit. It recomputes the cleaned block from
your ﬁle and checks that the blocks add up — not the work.




Data Science · Portfolio · M2                                                                                   3
~~~~
