# M2 – Bereinigte Flat-Table, Ähnlichkeit, Clustering und Plots

**Manifest-Termin:** 18.12.2026, 23:59 Uhr.

## Ziele
M1-Bereinigungsprotokoll umsetzen, eine bereinigte Flat-Table bereitstellen, Merkmale und Distanzen begründen, Clusteranalyse und fünf Plots erstellen, Peer-Review dokumentieren.

## Anforderungen
Das offizielle `M2_sheet.pdf` und `HANDIN.pdf` sind verbindlich. Ergebnisse erst nach tatsächlicher Berechnung eintragen.

## Dokumentation
- Eingabedaten und Bereinigungsschritte
- Feature-Auswahl und Vergleich von Distanzmaßen
- Reproduzierbare Clusteranalyse mit Sensitivitätsprüfung
- Fünf Plots mit Aussage, Datenbasis und Limitationen
- Peer-Review und nachvollziehbare Abgabe
