#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

folder = Path(__file__).resolve().parent
limit = 4785.69  # Outlier threshold from M1

# Read original values without changing their representation.
raw = pd.read_csv(folder / "extract.csv", dtype=str, keep_default_na=False)
clean = raw.copy()

assert raw.shape == (2255, 25)
assert raw["SalesOrderDetailID"].is_unique
assert set(raw["TerritoryName"]) == {"Germany"}
assert set(raw["Category"]) == {"Bikes"}
assert raw["SalesOrderID"].nunique() == 1701
assert raw["CustomerID"].nunique() == 934

# C1: Keep missing salesperson IDs.
missing = raw["SalesPersonID"] == ""
online = raw["OnlineOrderFlag"] == "1"
assert (missing == online).all()

# C2: Flag outliers at order-line level.
line_total = raw["LineTotal"].astype(float)
clean["outlier_line"] = (line_total > limit).astype(int)

# C3: Flag all lines belonging to high-value orders.
order_total = line_total.groupby(raw["SalesOrderID"]).transform("sum")
clean["outlier_order"] = (order_total > limit).astype(int)

# C4: Flag unit prices below standard cost (owner confirmation pending).
price = raw["UnitPrice"].astype(float)
discount = raw["UnitPriceDiscount"].astype(float)
cost = raw["StandardCost"].astype(float)
net_price = price * (1 - discount)
clean["below_cost"] = (net_price < cost).astype(int)

# Check the expected result before saving.
assert clean.shape == (2255, 28)
assert clean[raw.columns].equals(raw)
assert missing.sum() == 1600
assert clean["outlier_line"].sum() == 74
assert clean["outlier_order"].sum() == 576
assert clean["below_cost"].sum() == 542

clean.to_csv(folder / "clean_flat.csv", index=False, encoding="utf-8-sig")

# Print results for the report.
print("Rows in:", len(raw))
print("Rows removed:", len(raw) - len(clean))
print("Rows out:", len(clean))
print("Columns:", len(clean.columns))
print("Orders:", clean["SalesOrderID"].nunique())
print("Customers:", clean["CustomerID"].nunique())
print("Median LineTotal:", round(line_total.median(), 2))
print("Mean order value:", round(line_total.sum() / clean["SalesOrderID"].nunique(), 2))
print("C1 missing:", missing.sum())
print("C2 flagged lines:", clean["outlier_line"].sum())
print(
    "C3 flagged orders:",
    clean.loc[clean["outlier_order"] == 1, "SalesOrderID"].nunique(),
)
print("C3 flagged lines:", clean["outlier_order"].sum())
print("C4 below cost:", clean["below_cost"].sum())
