# M3 starter kit

Rename the folder to `M3_G07` (your group id from the group mail; BSED: `M3_B01`),
fill it in, and zip **the contents** as `M3_G07.zip`.

```
manifest.yaml       fill in -- read by a script, keep the keys
report.tex          the required sections in order; delete the % PROMPT lines
analysis.py         Python route: loads your slice
slice_knime.md      KNIME route: the same as nodes or one SQL query
check_submission.py + slices.csv    the self-check
```

Python or KNIME: use one route, delete the other. A `.knwf` counts as code.
**`report.pdf` is what is graded** (build with `pdflatex report.tex`, twice, or any
tool). Every figure goes into report.pdf. No folders.

**Dashboard pitfalls** (all hit by the reference solution):

* Streamlit: read the data relative to the script,
  `Path(__file__).parent / "dashboard_orders.csv"`, so it runs from any folder.
* Check that `CustomerID` survives your join -- without it there is no drill.
* When a filter removes the region you drilled into, reset the drill.
* Say on screen which panels follow the drill.
* Streamlit: give every widget a `key`; test with `streamlit.testing.v1.AppTest`.
* KNIME: the drill is a re-execution (`Refresh Button Widget` -> `Row Filter` ->
  `GroupBy`, as in the U09 workflow), and both levels need their n (`COUNT(*)`).
* Management report: put numbers in by code (KNIME: flow variables), never by typing.


Before you upload: `python3 check_submission.py M3_G07.zip`. It checks names and
numbers, not the work.

**Your split is given** in your row of `slices.csv`: `ref_cutoff` (the last history
month, counting the months of your **raw** extract that hold an order line: 1, 2, 3, ...)
and `ref_unit` (`customer`, or `product` on the few slices with too few customers --
then read "product" wherever the sheet says customer). `ref_population` and
`base_rate_reference` in the manifest are computed at this split on the raw extract.
You may cut elsewhere as well; report the given split too.

The task is `M3_sheet.pdf`, how to hand in is `HANDIN.pdf`; both win over this file.
