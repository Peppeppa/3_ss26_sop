# M3 – Fragen, KPI-Dashboard und ML-Readiness

**Manifest-Termin:** 25.01.2027, 23:59 Uhr.

## Ziele
Drei datenbasiert belegte Fragen beantworten, KPI-Dashboard entwickeln, Leakage-Risiken prüfen und ML-Readiness einschätzen.

## Anforderungen
Offizielles `M3_sheet.pdf` und `HANDIN.pdf` haben Vorrang. Nur aus reproduzierbarem Code belegte Zahlen veröffentlichen.
