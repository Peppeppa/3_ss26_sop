Unpack this next to your unit folders, so that every unit's
Scripts/ has this AWC/ folder in a folder above it. The scripts
look for AWC/ in the current folder and every folder above.

Two files are missing on purpose, because you build them:
  awc_flat.csv          your U01 extract (121,317 order lines)
  awc_demographics.csv  your U03 export
Save both into this same AWC/ folder.
