# Originalseiten als Bilder – lokales Importpaket

Diese PNGs geben den visuellen Zustand der Originalseite wieder, nicht eine semantische Interpretation. Sie ergänzen die normalisierten Markdown-Dateien.

## DS-M1-EX

[Markdown-Quelle](portfolio/M1/sources/M1_sheet.md) · 3 Seiten.

[S. 1](portfolio/M1/sources/assets/DS-M1-EX/p001.png) · [S. 2](portfolio/M1/sources/assets/DS-M1-EX/p002.png) · [S. 3](portfolio/M1/sources/assets/DS-M1-EX/p003.png)

## DS-M2-EX

[Markdown-Quelle](portfolio/M2/sources/M2_sheet.md) · 3 Seiten.

[S. 1](portfolio/M2/sources/assets/DS-M2-EX/p001.png) · [S. 2](portfolio/M2/sources/assets/DS-M2-EX/p002.png) · [S. 3](portfolio/M2/sources/assets/DS-M2-EX/p003.png)

## DS-M3-EX

[Markdown-Quelle](portfolio/M3/sources/M3_sheet.md) · 3 Seiten.

[S. 1](portfolio/M3/sources/assets/DS-M3-EX/p001.png) · [S. 2](portfolio/M3/sources/assets/DS-M3-EX/p002.png) · [S. 3](portfolio/M3/sources/assets/DS-M3-EX/p003.png)

## DS-R001

[Markdown-Quelle](quellen/organisation/sources/portfolio_studis_de.md) · 9 Seiten.

[S. 1](quellen/organisation/sources/assets/DS-R001/p001.png) · [S. 2](quellen/organisation/sources/assets/DS-R001/p002.png) · [S. 3](quellen/organisation/sources/assets/DS-R001/p003.png) · [S. 4](quellen/organisation/sources/assets/DS-R001/p004.png) · [S. 5](quellen/organisation/sources/assets/DS-R001/p005.png) · [S. 6](quellen/organisation/sources/assets/DS-R001/p006.png) · [S. 7](quellen/organisation/sources/assets/DS-R001/p007.png) · [S. 8](quellen/organisation/sources/assets/DS-R001/p008.png) · [S. 9](quellen/organisation/sources/assets/DS-R001/p009.png)

## DS-R002

[Markdown-Quelle](quellen/primer/sources/profiling_primer.md) · 8 Seiten.

[S. 1](quellen/primer/sources/assets/DS-R002/p001.png) · [S. 2](quellen/primer/sources/assets/DS-R002/p002.png) · [S. 3](quellen/primer/sources/assets/DS-R002/p003.png) · [S. 4](quellen/primer/sources/assets/DS-R002/p004.png) · [S. 5](quellen/primer/sources/assets/DS-R002/p005.png) · [S. 6](quellen/primer/sources/assets/DS-R002/p006.png) · [S. 7](quellen/primer/sources/assets/DS-R002/p007.png) · [S. 8](quellen/primer/sources/assets/DS-R002/p008.png)

## DS-R003

[Markdown-Quelle](quellen/primer/sources/python_primer.md) · 9 Seiten.

[S. 1](quellen/primer/sources/assets/DS-R003/p001.png) · [S. 2](quellen/primer/sources/assets/DS-R003/p002.png) · [S. 3](quellen/primer/sources/assets/DS-R003/p003.png) · [S. 4](quellen/primer/sources/assets/DS-R003/p004.png) · [S. 5](quellen/primer/sources/assets/DS-R003/p005.png) · [S. 6](quellen/primer/sources/assets/DS-R003/p006.png) · [S. 7](quellen/primer/sources/assets/DS-R003/p007.png) · [S. 8](quellen/primer/sources/assets/DS-R003/p008.png) · [S. 9](quellen/primer/sources/assets/DS-R003/p009.png)

## DS-R004

[Markdown-Quelle](quellen/organisation/sources/Schedule_Data_Science_students.md) · 1 Seiten.

[S. 1](quellen/organisation/sources/assets/DS-R004/p001.png)

## DS-R005

[Markdown-Quelle](quellen/primer/sources/statistic_stochastic_primer_short_en.md) · 11 Seiten.

[S. 1](quellen/primer/sources/assets/DS-R005/p001.png) · [S. 2](quellen/primer/sources/assets/DS-R005/p002.png) · [S. 3](quellen/primer/sources/assets/DS-R005/p003.png) · [S. 4](quellen/primer/sources/assets/DS-R005/p004.png) · [S. 5](quellen/primer/sources/assets/DS-R005/p005.png) · [S. 6](quellen/primer/sources/assets/DS-R005/p006.png) · [S. 7](quellen/primer/sources/assets/DS-R005/p007.png) · [S. 8](quellen/primer/sources/assets/DS-R005/p008.png) · [S. 9](quellen/primer/sources/assets/DS-R005/p009.png) · [S. 10](quellen/primer/sources/assets/DS-R005/p010.png) · [S. 11](quellen/primer/sources/assets/DS-R005/p011.png)

## DS-R006

[Markdown-Quelle](quellen/organisation/sources/submission_howto_de.md) · 3 Seiten.

[S. 1](quellen/organisation/sources/assets/DS-R006/p001.png) · [S. 2](quellen/organisation/sources/assets/DS-R006/p002.png) · [S. 3](quellen/organisation/sources/assets/DS-R006/p003.png)

## DS-R007

[Markdown-Quelle](quellen/primer/sources/Glossary_en.md) · 3 Seiten.

[S. 1](quellen/primer/sources/assets/DS-R007/p001.png) · [S. 2](quellen/primer/sources/assets/DS-R007/p002.png) · [S. 3](quellen/primer/sources/assets/DS-R007/p003.png)

## DS-R008

[Markdown-Quelle](quellen/organisation/sources/HANDIN.md) · 5 Seiten.

[S. 1](quellen/organisation/sources/assets/DS-R008/p001.png) · [S. 2](quellen/organisation/sources/assets/DS-R008/p002.png) · [S. 3](quellen/organisation/sources/assets/DS-R008/p003.png) · [S. 4](quellen/organisation/sources/assets/DS-R008/p004.png) · [S. 5](quellen/organisation/sources/assets/DS-R008/p005.png)

## DS-R009

[Markdown-Quelle](portfolio/M1/sources/midterm_slide.md) · 1 Seiten.

[S. 1](portfolio/M1/sources/assets/DS-R009/p001.png)

## DS-U00-EX

[Markdown-Quelle](units/U00/sources/Unit00_Exercises_en.md) · 1 Seiten.

[S. 1](units/U00/sources/assets/DS-U00-EX/p001.png)

## DS-U00-L-DE

[Markdown-Quelle](units/U00/sources/Unit00_slides_de.md) · 43 Seiten.

[S. 1](units/U00/sources/assets/DS-U00-L-DE/p001.png) · [S. 2](units/U00/sources/assets/DS-U00-L-DE/p002.png) · [S. 3](units/U00/sources/assets/DS-U00-L-DE/p003.png) · [S. 4](units/U00/sources/assets/DS-U00-L-DE/p004.png) · [S. 5](units/U00/sources/assets/DS-U00-L-DE/p005.png) · [S. 6](units/U00/sources/assets/DS-U00-L-DE/p006.png) · [S. 7](units/U00/sources/assets/DS-U00-L-DE/p007.png) · [S. 8](units/U00/sources/assets/DS-U00-L-DE/p008.png) · [S. 9](units/U00/sources/assets/DS-U00-L-DE/p009.png) · [S. 10](units/U00/sources/assets/DS-U00-L-DE/p010.png) · [S. 11](units/U00/sources/assets/DS-U00-L-DE/p011.png) · [S. 12](units/U00/sources/assets/DS-U00-L-DE/p012.png) · [S. 13](units/U00/sources/assets/DS-U00-L-DE/p013.png) · [S. 14](units/U00/sources/assets/DS-U00-L-DE/p014.png) · [S. 15](units/U00/sources/assets/DS-U00-L-DE/p015.png) · [S. 16](units/U00/sources/assets/DS-U00-L-DE/p016.png) · [S. 17](units/U00/sources/assets/DS-U00-L-DE/p017.png) · [S. 18](units/U00/sources/assets/DS-U00-L-DE/p018.png) · [S. 19](units/U00/sources/assets/DS-U00-L-DE/p019.png) · [S. 20](units/U00/sources/assets/DS-U00-L-DE/p020.png) · [S. 21](units/U00/sources/assets/DS-U00-L-DE/p021.png) · [S. 22](units/U00/sources/assets/DS-U00-L-DE/p022.png) · [S. 23](units/U00/sources/assets/DS-U00-L-DE/p023.png) · [S. 24](units/U00/sources/assets/DS-U00-L-DE/p024.png) · [S. 25](units/U00/sources/assets/DS-U00-L-DE/p025.png) · [S. 26](units/U00/sources/assets/DS-U00-L-DE/p026.png) · [S. 27](units/U00/sources/assets/DS-U00-L-DE/p027.png) · [S. 28](units/U00/sources/assets/DS-U00-L-DE/p028.png) · [S. 29](units/U00/sources/assets/DS-U00-L-DE/p029.png) · [S. 30](units/U00/sources/assets/DS-U00-L-DE/p030.png) · [S. 31](units/U00/sources/assets/DS-U00-L-DE/p031.png) · [S. 32](units/U00/sources/assets/DS-U00-L-DE/p032.png) · [S. 33](units/U00/sources/assets/DS-U00-L-DE/p033.png) · [S. 34](units/U00/sources/assets/DS-U00-L-DE/p034.png) · [S. 35](units/U00/sources/assets/DS-U00-L-DE/p035.png) · [S. 36](units/U00/sources/assets/DS-U00-L-DE/p036.png) · [S. 37](units/U00/sources/assets/DS-U00-L-DE/p037.png) · [S. 38](units/U00/sources/assets/DS-U00-L-DE/p038.png) · [S. 39](units/U00/sources/assets/DS-U00-L-DE/p039.png) · [S. 40](units/U00/sources/assets/DS-U00-L-DE/p040.png) · [S. 41](units/U00/sources/assets/DS-U00-L-DE/p041.png) · [S. 42](units/U00/sources/assets/DS-U00-L-DE/p042.png) · [S. 43](units/U00/sources/assets/DS-U00-L-DE/p043.png)

## DS-U00-L-EN

[Markdown-Quelle](units/U00/sources/Unit00_slides_en.md) · 43 Seiten.

[S. 1](units/U00/sources/assets/DS-U00-L-EN/p001.png) · [S. 2](units/U00/sources/assets/DS-U00-L-EN/p002.png) · [S. 3](units/U00/sources/assets/DS-U00-L-EN/p003.png) · [S. 4](units/U00/sources/assets/DS-U00-L-EN/p004.png) · [S. 5](units/U00/sources/assets/DS-U00-L-EN/p005.png) · [S. 6](units/U00/sources/assets/DS-U00-L-EN/p006.png) · [S. 7](units/U00/sources/assets/DS-U00-L-EN/p007.png) · [S. 8](units/U00/sources/assets/DS-U00-L-EN/p008.png) · [S. 9](units/U00/sources/assets/DS-U00-L-EN/p009.png) · [S. 10](units/U00/sources/assets/DS-U00-L-EN/p010.png) · [S. 11](units/U00/sources/assets/DS-U00-L-EN/p011.png) · [S. 12](units/U00/sources/assets/DS-U00-L-EN/p012.png) · [S. 13](units/U00/sources/assets/DS-U00-L-EN/p013.png) · [S. 14](units/U00/sources/assets/DS-U00-L-EN/p014.png) · [S. 15](units/U00/sources/assets/DS-U00-L-EN/p015.png) · [S. 16](units/U00/sources/assets/DS-U00-L-EN/p016.png) · [S. 17](units/U00/sources/assets/DS-U00-L-EN/p017.png) · [S. 18](units/U00/sources/assets/DS-U00-L-EN/p018.png) · [S. 19](units/U00/sources/assets/DS-U00-L-EN/p019.png) · [S. 20](units/U00/sources/assets/DS-U00-L-EN/p020.png) · [S. 21](units/U00/sources/assets/DS-U00-L-EN/p021.png) · [S. 22](units/U00/sources/assets/DS-U00-L-EN/p022.png) · [S. 23](units/U00/sources/assets/DS-U00-L-EN/p023.png) · [S. 24](units/U00/sources/assets/DS-U00-L-EN/p024.png) · [S. 25](units/U00/sources/assets/DS-U00-L-EN/p025.png) · [S. 26](units/U00/sources/assets/DS-U00-L-EN/p026.png) · [S. 27](units/U00/sources/assets/DS-U00-L-EN/p027.png) · [S. 28](units/U00/sources/assets/DS-U00-L-EN/p028.png) · [S. 29](units/U00/sources/assets/DS-U00-L-EN/p029.png) · [S. 30](units/U00/sources/assets/DS-U00-L-EN/p030.png) · [S. 31](units/U00/sources/assets/DS-U00-L-EN/p031.png) · [S. 32](units/U00/sources/assets/DS-U00-L-EN/p032.png) · [S. 33](units/U00/sources/assets/DS-U00-L-EN/p033.png) · [S. 34](units/U00/sources/assets/DS-U00-L-EN/p034.png) · [S. 35](units/U00/sources/assets/DS-U00-L-EN/p035.png) · [S. 36](units/U00/sources/assets/DS-U00-L-EN/p036.png) · [S. 37](units/U00/sources/assets/DS-U00-L-EN/p037.png) · [S. 38](units/U00/sources/assets/DS-U00-L-EN/p038.png) · [S. 39](units/U00/sources/assets/DS-U00-L-EN/p039.png) · [S. 40](units/U00/sources/assets/DS-U00-L-EN/p040.png) · [S. 41](units/U00/sources/assets/DS-U00-L-EN/p041.png) · [S. 42](units/U00/sources/assets/DS-U00-L-EN/p042.png) · [S. 43](units/U00/sources/assets/DS-U00-L-EN/p043.png)

## DS-U00-R-KNIME-CHEATSHEET

[Markdown-Quelle](units/U00/sources/knime_cheatsheet.md) · 1 Seiten.

[S. 1](units/U00/sources/assets/DS-U00-R-KNIME-CHEATSHEET/p001.png)

## DS-U01-EX

[Markdown-Quelle](units/U01/sources/Unit01_Exercises_en.md) · 2 Seiten.

[S. 1](units/U01/sources/assets/DS-U01-EX/p001.png) · [S. 2](units/U01/sources/assets/DS-U01-EX/p002.png)

## DS-U01-L-EN

[Markdown-Quelle](units/U01/sources/Unit01_slides_en.md) · 29 Seiten.

[S. 1](units/U01/sources/assets/DS-U01-L-EN/p001.png) · [S. 2](units/U01/sources/assets/DS-U01-L-EN/p002.png) · [S. 3](units/U01/sources/assets/DS-U01-L-EN/p003.png) · [S. 4](units/U01/sources/assets/DS-U01-L-EN/p004.png) · [S. 5](units/U01/sources/assets/DS-U01-L-EN/p005.png) · [S. 6](units/U01/sources/assets/DS-U01-L-EN/p006.png) · [S. 7](units/U01/sources/assets/DS-U01-L-EN/p007.png) · [S. 8](units/U01/sources/assets/DS-U01-L-EN/p008.png) · [S. 9](units/U01/sources/assets/DS-U01-L-EN/p009.png) · [S. 10](units/U01/sources/assets/DS-U01-L-EN/p010.png) · [S. 11](units/U01/sources/assets/DS-U01-L-EN/p011.png) · [S. 12](units/U01/sources/assets/DS-U01-L-EN/p012.png) · [S. 13](units/U01/sources/assets/DS-U01-L-EN/p013.png) · [S. 14](units/U01/sources/assets/DS-U01-L-EN/p014.png) · [S. 15](units/U01/sources/assets/DS-U01-L-EN/p015.png) · [S. 16](units/U01/sources/assets/DS-U01-L-EN/p016.png) · [S. 17](units/U01/sources/assets/DS-U01-L-EN/p017.png) · [S. 18](units/U01/sources/assets/DS-U01-L-EN/p018.png) · [S. 19](units/U01/sources/assets/DS-U01-L-EN/p019.png) · [S. 20](units/U01/sources/assets/DS-U01-L-EN/p020.png) · [S. 21](units/U01/sources/assets/DS-U01-L-EN/p021.png) · [S. 22](units/U01/sources/assets/DS-U01-L-EN/p022.png) · [S. 23](units/U01/sources/assets/DS-U01-L-EN/p023.png) · [S. 24](units/U01/sources/assets/DS-U01-L-EN/p024.png) · [S. 25](units/U01/sources/assets/DS-U01-L-EN/p025.png) · [S. 26](units/U01/sources/assets/DS-U01-L-EN/p026.png) · [S. 27](units/U01/sources/assets/DS-U01-L-EN/p027.png) · [S. 28](units/U01/sources/assets/DS-U01-L-EN/p028.png) · [S. 29](units/U01/sources/assets/DS-U01-L-EN/p029.png)

## DS-U01-R-KNIME-CHEATSHEET

[Markdown-Quelle](units/U01/sources/knime_cheatsheet.md) · 1 Seiten.

[S. 1](units/U01/sources/assets/DS-U01-R-KNIME-CHEATSHEET/p001.png)

## DS-U02-EX

[Markdown-Quelle](units/U02/sources/Unit02_Exercises_en.md) · 2 Seiten.

[S. 1](units/U02/sources/assets/DS-U02-EX/p001.png) · [S. 2](units/U02/sources/assets/DS-U02-EX/p002.png)

## DS-U02-L-EN

[Markdown-Quelle](units/U02/sources/Unit02_slides_en.md) · 38 Seiten.

[S. 1](units/U02/sources/assets/DS-U02-L-EN/p001.png) · [S. 2](units/U02/sources/assets/DS-U02-L-EN/p002.png) · [S. 3](units/U02/sources/assets/DS-U02-L-EN/p003.png) · [S. 4](units/U02/sources/assets/DS-U02-L-EN/p004.png) · [S. 5](units/U02/sources/assets/DS-U02-L-EN/p005.png) · [S. 6](units/U02/sources/assets/DS-U02-L-EN/p006.png) · [S. 7](units/U02/sources/assets/DS-U02-L-EN/p007.png) · [S. 8](units/U02/sources/assets/DS-U02-L-EN/p008.png) · [S. 9](units/U02/sources/assets/DS-U02-L-EN/p009.png) · [S. 10](units/U02/sources/assets/DS-U02-L-EN/p010.png) · [S. 11](units/U02/sources/assets/DS-U02-L-EN/p011.png) · [S. 12](units/U02/sources/assets/DS-U02-L-EN/p012.png) · [S. 13](units/U02/sources/assets/DS-U02-L-EN/p013.png) · [S. 14](units/U02/sources/assets/DS-U02-L-EN/p014.png) · [S. 15](units/U02/sources/assets/DS-U02-L-EN/p015.png) · [S. 16](units/U02/sources/assets/DS-U02-L-EN/p016.png) · [S. 17](units/U02/sources/assets/DS-U02-L-EN/p017.png) · [S. 18](units/U02/sources/assets/DS-U02-L-EN/p018.png) · [S. 19](units/U02/sources/assets/DS-U02-L-EN/p019.png) · [S. 20](units/U02/sources/assets/DS-U02-L-EN/p020.png) · [S. 21](units/U02/sources/assets/DS-U02-L-EN/p021.png) · [S. 22](units/U02/sources/assets/DS-U02-L-EN/p022.png) · [S. 23](units/U02/sources/assets/DS-U02-L-EN/p023.png) · [S. 24](units/U02/sources/assets/DS-U02-L-EN/p024.png) · [S. 25](units/U02/sources/assets/DS-U02-L-EN/p025.png) · [S. 26](units/U02/sources/assets/DS-U02-L-EN/p026.png) · [S. 27](units/U02/sources/assets/DS-U02-L-EN/p027.png) · [S. 28](units/U02/sources/assets/DS-U02-L-EN/p028.png) · [S. 29](units/U02/sources/assets/DS-U02-L-EN/p029.png) · [S. 30](units/U02/sources/assets/DS-U02-L-EN/p030.png) · [S. 31](units/U02/sources/assets/DS-U02-L-EN/p031.png) · [S. 32](units/U02/sources/assets/DS-U02-L-EN/p032.png) · [S. 33](units/U02/sources/assets/DS-U02-L-EN/p033.png) · [S. 34](units/U02/sources/assets/DS-U02-L-EN/p034.png) · [S. 35](units/U02/sources/assets/DS-U02-L-EN/p035.png) · [S. 36](units/U02/sources/assets/DS-U02-L-EN/p036.png) · [S. 37](units/U02/sources/assets/DS-U02-L-EN/p037.png) · [S. 38](units/U02/sources/assets/DS-U02-L-EN/p038.png)

## DS-U02-R-KNIME-CHEATSHEET

[Markdown-Quelle](units/U02/sources/knime_cheatsheet.md) · 1 Seiten.

[S. 1](units/U02/sources/assets/DS-U02-R-KNIME-CHEATSHEET/p001.png)

## DS-U03-EX

[Markdown-Quelle](units/U03/sources/Unit03_Exercises_en.md) · 2 Seiten.

[S. 1](units/U03/sources/assets/DS-U03-EX/p001.png) · [S. 2](units/U03/sources/assets/DS-U03-EX/p002.png)

## DS-U03-L-EN

[Markdown-Quelle](units/U03/sources/Unit03_slides_en.md) · 44 Seiten.

[S. 1](units/U03/sources/assets/DS-U03-L-EN/p001.png) · [S. 2](units/U03/sources/assets/DS-U03-L-EN/p002.png) · [S. 3](units/U03/sources/assets/DS-U03-L-EN/p003.png) · [S. 4](units/U03/sources/assets/DS-U03-L-EN/p004.png) · [S. 5](units/U03/sources/assets/DS-U03-L-EN/p005.png) · [S. 6](units/U03/sources/assets/DS-U03-L-EN/p006.png) · [S. 7](units/U03/sources/assets/DS-U03-L-EN/p007.png) · [S. 8](units/U03/sources/assets/DS-U03-L-EN/p008.png) · [S. 9](units/U03/sources/assets/DS-U03-L-EN/p009.png) · [S. 10](units/U03/sources/assets/DS-U03-L-EN/p010.png) · [S. 11](units/U03/sources/assets/DS-U03-L-EN/p011.png) · [S. 12](units/U03/sources/assets/DS-U03-L-EN/p012.png) · [S. 13](units/U03/sources/assets/DS-U03-L-EN/p013.png) · [S. 14](units/U03/sources/assets/DS-U03-L-EN/p014.png) · [S. 15](units/U03/sources/assets/DS-U03-L-EN/p015.png) · [S. 16](units/U03/sources/assets/DS-U03-L-EN/p016.png) · [S. 17](units/U03/sources/assets/DS-U03-L-EN/p017.png) · [S. 18](units/U03/sources/assets/DS-U03-L-EN/p018.png) · [S. 19](units/U03/sources/assets/DS-U03-L-EN/p019.png) · [S. 20](units/U03/sources/assets/DS-U03-L-EN/p020.png) · [S. 21](units/U03/sources/assets/DS-U03-L-EN/p021.png) · [S. 22](units/U03/sources/assets/DS-U03-L-EN/p022.png) · [S. 23](units/U03/sources/assets/DS-U03-L-EN/p023.png) · [S. 24](units/U03/sources/assets/DS-U03-L-EN/p024.png) · [S. 25](units/U03/sources/assets/DS-U03-L-EN/p025.png) · [S. 26](units/U03/sources/assets/DS-U03-L-EN/p026.png) · [S. 27](units/U03/sources/assets/DS-U03-L-EN/p027.png) · [S. 28](units/U03/sources/assets/DS-U03-L-EN/p028.png) · [S. 29](units/U03/sources/assets/DS-U03-L-EN/p029.png) · [S. 30](units/U03/sources/assets/DS-U03-L-EN/p030.png) · [S. 31](units/U03/sources/assets/DS-U03-L-EN/p031.png) · [S. 32](units/U03/sources/assets/DS-U03-L-EN/p032.png) · [S. 33](units/U03/sources/assets/DS-U03-L-EN/p033.png) · [S. 34](units/U03/sources/assets/DS-U03-L-EN/p034.png) · [S. 35](units/U03/sources/assets/DS-U03-L-EN/p035.png) · [S. 36](units/U03/sources/assets/DS-U03-L-EN/p036.png) · [S. 37](units/U03/sources/assets/DS-U03-L-EN/p037.png) · [S. 38](units/U03/sources/assets/DS-U03-L-EN/p038.png) · [S. 39](units/U03/sources/assets/DS-U03-L-EN/p039.png) · [S. 40](units/U03/sources/assets/DS-U03-L-EN/p040.png) · [S. 41](units/U03/sources/assets/DS-U03-L-EN/p041.png) · [S. 42](units/U03/sources/assets/DS-U03-L-EN/p042.png) · [S. 43](units/U03/sources/assets/DS-U03-L-EN/p043.png) · [S. 44](units/U03/sources/assets/DS-U03-L-EN/p044.png)

## DS-U04-EX

[Markdown-Quelle](units/U04/sources/Unit04_Exercises_en.md) · 2 Seiten.

[S. 1](units/U04/sources/assets/DS-U04-EX/p001.png) · [S. 2](units/U04/sources/assets/DS-U04-EX/p002.png)

## DS-U04-L-EN

[Markdown-Quelle](units/U04/sources/Unit04_slides_en.md) · 42 Seiten.

[S. 1](units/U04/sources/assets/DS-U04-L-EN/p001.png) · [S. 2](units/U04/sources/assets/DS-U04-L-EN/p002.png) · [S. 3](units/U04/sources/assets/DS-U04-L-EN/p003.png) · [S. 4](units/U04/sources/assets/DS-U04-L-EN/p004.png) · [S. 5](units/U04/sources/assets/DS-U04-L-EN/p005.png) · [S. 6](units/U04/sources/assets/DS-U04-L-EN/p006.png) · [S. 7](units/U04/sources/assets/DS-U04-L-EN/p007.png) · [S. 8](units/U04/sources/assets/DS-U04-L-EN/p008.png) · [S. 9](units/U04/sources/assets/DS-U04-L-EN/p009.png) · [S. 10](units/U04/sources/assets/DS-U04-L-EN/p010.png) · [S. 11](units/U04/sources/assets/DS-U04-L-EN/p011.png) · [S. 12](units/U04/sources/assets/DS-U04-L-EN/p012.png) · [S. 13](units/U04/sources/assets/DS-U04-L-EN/p013.png) · [S. 14](units/U04/sources/assets/DS-U04-L-EN/p014.png) · [S. 15](units/U04/sources/assets/DS-U04-L-EN/p015.png) · [S. 16](units/U04/sources/assets/DS-U04-L-EN/p016.png) · [S. 17](units/U04/sources/assets/DS-U04-L-EN/p017.png) · [S. 18](units/U04/sources/assets/DS-U04-L-EN/p018.png) · [S. 19](units/U04/sources/assets/DS-U04-L-EN/p019.png) · [S. 20](units/U04/sources/assets/DS-U04-L-EN/p020.png) · [S. 21](units/U04/sources/assets/DS-U04-L-EN/p021.png) · [S. 22](units/U04/sources/assets/DS-U04-L-EN/p022.png) · [S. 23](units/U04/sources/assets/DS-U04-L-EN/p023.png) · [S. 24](units/U04/sources/assets/DS-U04-L-EN/p024.png) · [S. 25](units/U04/sources/assets/DS-U04-L-EN/p025.png) · [S. 26](units/U04/sources/assets/DS-U04-L-EN/p026.png) · [S. 27](units/U04/sources/assets/DS-U04-L-EN/p027.png) · [S. 28](units/U04/sources/assets/DS-U04-L-EN/p028.png) · [S. 29](units/U04/sources/assets/DS-U04-L-EN/p029.png) · [S. 30](units/U04/sources/assets/DS-U04-L-EN/p030.png) · [S. 31](units/U04/sources/assets/DS-U04-L-EN/p031.png) · [S. 32](units/U04/sources/assets/DS-U04-L-EN/p032.png) · [S. 33](units/U04/sources/assets/DS-U04-L-EN/p033.png) · [S. 34](units/U04/sources/assets/DS-U04-L-EN/p034.png) · [S. 35](units/U04/sources/assets/DS-U04-L-EN/p035.png) · [S. 36](units/U04/sources/assets/DS-U04-L-EN/p036.png) · [S. 37](units/U04/sources/assets/DS-U04-L-EN/p037.png) · [S. 38](units/U04/sources/assets/DS-U04-L-EN/p038.png) · [S. 39](units/U04/sources/assets/DS-U04-L-EN/p039.png) · [S. 40](units/U04/sources/assets/DS-U04-L-EN/p040.png) · [S. 41](units/U04/sources/assets/DS-U04-L-EN/p041.png) · [S. 42](units/U04/sources/assets/DS-U04-L-EN/p042.png)

## DS-U04-R-CLEANING-LOG-TEMPLATE

[Markdown-Quelle](units/U04/sources/cleaning_log_template.md) · 5 Seiten.

[S. 1](units/U04/sources/assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p001.png) · [S. 2](units/U04/sources/assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p002.png) · [S. 3](units/U04/sources/assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p003.png) · [S. 4](units/U04/sources/assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p004.png) · [S. 5](units/U04/sources/assets/DS-U04-R-CLEANING-LOG-TEMPLATE/p005.png)

## DS-U05-EX

[Markdown-Quelle](units/U05/sources/Unit05_Exercises_en.md) · 2 Seiten.

[S. 1](units/U05/sources/assets/DS-U05-EX/p001.png) · [S. 2](units/U05/sources/assets/DS-U05-EX/p002.png)

## DS-U05-L-EN

[Markdown-Quelle](units/U05/sources/Unit05_DS_en.md) · 48 Seiten.

[S. 1](units/U05/sources/assets/DS-U05-L-EN/p001.png) · [S. 2](units/U05/sources/assets/DS-U05-L-EN/p002.png) · [S. 3](units/U05/sources/assets/DS-U05-L-EN/p003.png) · [S. 4](units/U05/sources/assets/DS-U05-L-EN/p004.png) · [S. 5](units/U05/sources/assets/DS-U05-L-EN/p005.png) · [S. 6](units/U05/sources/assets/DS-U05-L-EN/p006.png) · [S. 7](units/U05/sources/assets/DS-U05-L-EN/p007.png) · [S. 8](units/U05/sources/assets/DS-U05-L-EN/p008.png) · [S. 9](units/U05/sources/assets/DS-U05-L-EN/p009.png) · [S. 10](units/U05/sources/assets/DS-U05-L-EN/p010.png) · [S. 11](units/U05/sources/assets/DS-U05-L-EN/p011.png) · [S. 12](units/U05/sources/assets/DS-U05-L-EN/p012.png) · [S. 13](units/U05/sources/assets/DS-U05-L-EN/p013.png) · [S. 14](units/U05/sources/assets/DS-U05-L-EN/p014.png) · [S. 15](units/U05/sources/assets/DS-U05-L-EN/p015.png) · [S. 16](units/U05/sources/assets/DS-U05-L-EN/p016.png) · [S. 17](units/U05/sources/assets/DS-U05-L-EN/p017.png) · [S. 18](units/U05/sources/assets/DS-U05-L-EN/p018.png) · [S. 19](units/U05/sources/assets/DS-U05-L-EN/p019.png) · [S. 20](units/U05/sources/assets/DS-U05-L-EN/p020.png) · [S. 21](units/U05/sources/assets/DS-U05-L-EN/p021.png) · [S. 22](units/U05/sources/assets/DS-U05-L-EN/p022.png) · [S. 23](units/U05/sources/assets/DS-U05-L-EN/p023.png) · [S. 24](units/U05/sources/assets/DS-U05-L-EN/p024.png) · [S. 25](units/U05/sources/assets/DS-U05-L-EN/p025.png) · [S. 26](units/U05/sources/assets/DS-U05-L-EN/p026.png) · [S. 27](units/U05/sources/assets/DS-U05-L-EN/p027.png) · [S. 28](units/U05/sources/assets/DS-U05-L-EN/p028.png) · [S. 29](units/U05/sources/assets/DS-U05-L-EN/p029.png) · [S. 30](units/U05/sources/assets/DS-U05-L-EN/p030.png) · [S. 31](units/U05/sources/assets/DS-U05-L-EN/p031.png) · [S. 32](units/U05/sources/assets/DS-U05-L-EN/p032.png) · [S. 33](units/U05/sources/assets/DS-U05-L-EN/p033.png) · [S. 34](units/U05/sources/assets/DS-U05-L-EN/p034.png) · [S. 35](units/U05/sources/assets/DS-U05-L-EN/p035.png) · [S. 36](units/U05/sources/assets/DS-U05-L-EN/p036.png) · [S. 37](units/U05/sources/assets/DS-U05-L-EN/p037.png) · [S. 38](units/U05/sources/assets/DS-U05-L-EN/p038.png) · [S. 39](units/U05/sources/assets/DS-U05-L-EN/p039.png) · [S. 40](units/U05/sources/assets/DS-U05-L-EN/p040.png) · [S. 41](units/U05/sources/assets/DS-U05-L-EN/p041.png) · [S. 42](units/U05/sources/assets/DS-U05-L-EN/p042.png) · [S. 43](units/U05/sources/assets/DS-U05-L-EN/p043.png) · [S. 44](units/U05/sources/assets/DS-U05-L-EN/p044.png) · [S. 45](units/U05/sources/assets/DS-U05-L-EN/p045.png) · [S. 46](units/U05/sources/assets/DS-U05-L-EN/p046.png) · [S. 47](units/U05/sources/assets/DS-U05-L-EN/p047.png) · [S. 48](units/U05/sources/assets/DS-U05-L-EN/p048.png)

## DS-U06-EX

[Markdown-Quelle](units/U06/sources/Unit06_Exercises_en.md) · 2 Seiten.

[S. 1](units/U06/sources/assets/DS-U06-EX/p001.png) · [S. 2](units/U06/sources/assets/DS-U06-EX/p002.png)

## DS-U06-L-EN

[Markdown-Quelle](units/U06/sources/Unit06_DS_en.md) · 38 Seiten.

[S. 1](units/U06/sources/assets/DS-U06-L-EN/p001.png) · [S. 2](units/U06/sources/assets/DS-U06-L-EN/p002.png) · [S. 3](units/U06/sources/assets/DS-U06-L-EN/p003.png) · [S. 4](units/U06/sources/assets/DS-U06-L-EN/p004.png) · [S. 5](units/U06/sources/assets/DS-U06-L-EN/p005.png) · [S. 6](units/U06/sources/assets/DS-U06-L-EN/p006.png) · [S. 7](units/U06/sources/assets/DS-U06-L-EN/p007.png) · [S. 8](units/U06/sources/assets/DS-U06-L-EN/p008.png) · [S. 9](units/U06/sources/assets/DS-U06-L-EN/p009.png) · [S. 10](units/U06/sources/assets/DS-U06-L-EN/p010.png) · [S. 11](units/U06/sources/assets/DS-U06-L-EN/p011.png) · [S. 12](units/U06/sources/assets/DS-U06-L-EN/p012.png) · [S. 13](units/U06/sources/assets/DS-U06-L-EN/p013.png) · [S. 14](units/U06/sources/assets/DS-U06-L-EN/p014.png) · [S. 15](units/U06/sources/assets/DS-U06-L-EN/p015.png) · [S. 16](units/U06/sources/assets/DS-U06-L-EN/p016.png) · [S. 17](units/U06/sources/assets/DS-U06-L-EN/p017.png) · [S. 18](units/U06/sources/assets/DS-U06-L-EN/p018.png) · [S. 19](units/U06/sources/assets/DS-U06-L-EN/p019.png) · [S. 20](units/U06/sources/assets/DS-U06-L-EN/p020.png) · [S. 21](units/U06/sources/assets/DS-U06-L-EN/p021.png) · [S. 22](units/U06/sources/assets/DS-U06-L-EN/p022.png) · [S. 23](units/U06/sources/assets/DS-U06-L-EN/p023.png) · [S. 24](units/U06/sources/assets/DS-U06-L-EN/p024.png) · [S. 25](units/U06/sources/assets/DS-U06-L-EN/p025.png) · [S. 26](units/U06/sources/assets/DS-U06-L-EN/p026.png) · [S. 27](units/U06/sources/assets/DS-U06-L-EN/p027.png) · [S. 28](units/U06/sources/assets/DS-U06-L-EN/p028.png) · [S. 29](units/U06/sources/assets/DS-U06-L-EN/p029.png) · [S. 30](units/U06/sources/assets/DS-U06-L-EN/p030.png) · [S. 31](units/U06/sources/assets/DS-U06-L-EN/p031.png) · [S. 32](units/U06/sources/assets/DS-U06-L-EN/p032.png) · [S. 33](units/U06/sources/assets/DS-U06-L-EN/p033.png) · [S. 34](units/U06/sources/assets/DS-U06-L-EN/p034.png) · [S. 35](units/U06/sources/assets/DS-U06-L-EN/p035.png) · [S. 36](units/U06/sources/assets/DS-U06-L-EN/p036.png) · [S. 37](units/U06/sources/assets/DS-U06-L-EN/p037.png) · [S. 38](units/U06/sources/assets/DS-U06-L-EN/p038.png)

## DS-U07-EX

[Markdown-Quelle](units/U07/sources/Unit07_Exercises_en.md) · 2 Seiten.

[S. 1](units/U07/sources/assets/DS-U07-EX/p001.png) · [S. 2](units/U07/sources/assets/DS-U07-EX/p002.png)

## DS-U07-L-EN

[Markdown-Quelle](units/U07/sources/Unit07_slides_en.md) · 45 Seiten.

[S. 1](units/U07/sources/assets/DS-U07-L-EN/p001.png) · [S. 2](units/U07/sources/assets/DS-U07-L-EN/p002.png) · [S. 3](units/U07/sources/assets/DS-U07-L-EN/p003.png) · [S. 4](units/U07/sources/assets/DS-U07-L-EN/p004.png) · [S. 5](units/U07/sources/assets/DS-U07-L-EN/p005.png) · [S. 6](units/U07/sources/assets/DS-U07-L-EN/p006.png) · [S. 7](units/U07/sources/assets/DS-U07-L-EN/p007.png) · [S. 8](units/U07/sources/assets/DS-U07-L-EN/p008.png) · [S. 9](units/U07/sources/assets/DS-U07-L-EN/p009.png) · [S. 10](units/U07/sources/assets/DS-U07-L-EN/p010.png) · [S. 11](units/U07/sources/assets/DS-U07-L-EN/p011.png) · [S. 12](units/U07/sources/assets/DS-U07-L-EN/p012.png) · [S. 13](units/U07/sources/assets/DS-U07-L-EN/p013.png) · [S. 14](units/U07/sources/assets/DS-U07-L-EN/p014.png) · [S. 15](units/U07/sources/assets/DS-U07-L-EN/p015.png) · [S. 16](units/U07/sources/assets/DS-U07-L-EN/p016.png) · [S. 17](units/U07/sources/assets/DS-U07-L-EN/p017.png) · [S. 18](units/U07/sources/assets/DS-U07-L-EN/p018.png) · [S. 19](units/U07/sources/assets/DS-U07-L-EN/p019.png) · [S. 20](units/U07/sources/assets/DS-U07-L-EN/p020.png) · [S. 21](units/U07/sources/assets/DS-U07-L-EN/p021.png) · [S. 22](units/U07/sources/assets/DS-U07-L-EN/p022.png) · [S. 23](units/U07/sources/assets/DS-U07-L-EN/p023.png) · [S. 24](units/U07/sources/assets/DS-U07-L-EN/p024.png) · [S. 25](units/U07/sources/assets/DS-U07-L-EN/p025.png) · [S. 26](units/U07/sources/assets/DS-U07-L-EN/p026.png) · [S. 27](units/U07/sources/assets/DS-U07-L-EN/p027.png) · [S. 28](units/U07/sources/assets/DS-U07-L-EN/p028.png) · [S. 29](units/U07/sources/assets/DS-U07-L-EN/p029.png) · [S. 30](units/U07/sources/assets/DS-U07-L-EN/p030.png) · [S. 31](units/U07/sources/assets/DS-U07-L-EN/p031.png) · [S. 32](units/U07/sources/assets/DS-U07-L-EN/p032.png) · [S. 33](units/U07/sources/assets/DS-U07-L-EN/p033.png) · [S. 34](units/U07/sources/assets/DS-U07-L-EN/p034.png) · [S. 35](units/U07/sources/assets/DS-U07-L-EN/p035.png) · [S. 36](units/U07/sources/assets/DS-U07-L-EN/p036.png) · [S. 37](units/U07/sources/assets/DS-U07-L-EN/p037.png) · [S. 38](units/U07/sources/assets/DS-U07-L-EN/p038.png) · [S. 39](units/U07/sources/assets/DS-U07-L-EN/p039.png) · [S. 40](units/U07/sources/assets/DS-U07-L-EN/p040.png) · [S. 41](units/U07/sources/assets/DS-U07-L-EN/p041.png) · [S. 42](units/U07/sources/assets/DS-U07-L-EN/p042.png) · [S. 43](units/U07/sources/assets/DS-U07-L-EN/p043.png) · [S. 44](units/U07/sources/assets/DS-U07-L-EN/p044.png) · [S. 45](units/U07/sources/assets/DS-U07-L-EN/p045.png)

## DS-U08-EX

[Markdown-Quelle](units/U08/sources/Unit08_Exercises_en.md) · 2 Seiten.

[S. 1](units/U08/sources/assets/DS-U08-EX/p001.png) · [S. 2](units/U08/sources/assets/DS-U08-EX/p002.png)

## DS-U08-L-EN

[Markdown-Quelle](units/U08/sources/Unit08_slides_en.md) · 40 Seiten.

[S. 1](units/U08/sources/assets/DS-U08-L-EN/p001.png) · [S. 2](units/U08/sources/assets/DS-U08-L-EN/p002.png) · [S. 3](units/U08/sources/assets/DS-U08-L-EN/p003.png) · [S. 4](units/U08/sources/assets/DS-U08-L-EN/p004.png) · [S. 5](units/U08/sources/assets/DS-U08-L-EN/p005.png) · [S. 6](units/U08/sources/assets/DS-U08-L-EN/p006.png) · [S. 7](units/U08/sources/assets/DS-U08-L-EN/p007.png) · [S. 8](units/U08/sources/assets/DS-U08-L-EN/p008.png) · [S. 9](units/U08/sources/assets/DS-U08-L-EN/p009.png) · [S. 10](units/U08/sources/assets/DS-U08-L-EN/p010.png) · [S. 11](units/U08/sources/assets/DS-U08-L-EN/p011.png) · [S. 12](units/U08/sources/assets/DS-U08-L-EN/p012.png) · [S. 13](units/U08/sources/assets/DS-U08-L-EN/p013.png) · [S. 14](units/U08/sources/assets/DS-U08-L-EN/p014.png) · [S. 15](units/U08/sources/assets/DS-U08-L-EN/p015.png) · [S. 16](units/U08/sources/assets/DS-U08-L-EN/p016.png) · [S. 17](units/U08/sources/assets/DS-U08-L-EN/p017.png) · [S. 18](units/U08/sources/assets/DS-U08-L-EN/p018.png) · [S. 19](units/U08/sources/assets/DS-U08-L-EN/p019.png) · [S. 20](units/U08/sources/assets/DS-U08-L-EN/p020.png) · [S. 21](units/U08/sources/assets/DS-U08-L-EN/p021.png) · [S. 22](units/U08/sources/assets/DS-U08-L-EN/p022.png) · [S. 23](units/U08/sources/assets/DS-U08-L-EN/p023.png) · [S. 24](units/U08/sources/assets/DS-U08-L-EN/p024.png) · [S. 25](units/U08/sources/assets/DS-U08-L-EN/p025.png) · [S. 26](units/U08/sources/assets/DS-U08-L-EN/p026.png) · [S. 27](units/U08/sources/assets/DS-U08-L-EN/p027.png) · [S. 28](units/U08/sources/assets/DS-U08-L-EN/p028.png) · [S. 29](units/U08/sources/assets/DS-U08-L-EN/p029.png) · [S. 30](units/U08/sources/assets/DS-U08-L-EN/p030.png) · [S. 31](units/U08/sources/assets/DS-U08-L-EN/p031.png) · [S. 32](units/U08/sources/assets/DS-U08-L-EN/p032.png) · [S. 33](units/U08/sources/assets/DS-U08-L-EN/p033.png) · [S. 34](units/U08/sources/assets/DS-U08-L-EN/p034.png) · [S. 35](units/U08/sources/assets/DS-U08-L-EN/p035.png) · [S. 36](units/U08/sources/assets/DS-U08-L-EN/p036.png) · [S. 37](units/U08/sources/assets/DS-U08-L-EN/p037.png) · [S. 38](units/U08/sources/assets/DS-U08-L-EN/p038.png) · [S. 39](units/U08/sources/assets/DS-U08-L-EN/p039.png) · [S. 40](units/U08/sources/assets/DS-U08-L-EN/p040.png)

## DS-U09-EX

[Markdown-Quelle](units/U09/sources/Unit09_Exercises_en.md) · 2 Seiten.

[S. 1](units/U09/sources/assets/DS-U09-EX/p001.png) · [S. 2](units/U09/sources/assets/DS-U09-EX/p002.png)

## DS-U09-L-EN

[Markdown-Quelle](units/U09/sources/Unit09_slides_en.md) · 47 Seiten.

[S. 1](units/U09/sources/assets/DS-U09-L-EN/p001.png) · [S. 2](units/U09/sources/assets/DS-U09-L-EN/p002.png) · [S. 3](units/U09/sources/assets/DS-U09-L-EN/p003.png) · [S. 4](units/U09/sources/assets/DS-U09-L-EN/p004.png) · [S. 5](units/U09/sources/assets/DS-U09-L-EN/p005.png) · [S. 6](units/U09/sources/assets/DS-U09-L-EN/p006.png) · [S. 7](units/U09/sources/assets/DS-U09-L-EN/p007.png) · [S. 8](units/U09/sources/assets/DS-U09-L-EN/p008.png) · [S. 9](units/U09/sources/assets/DS-U09-L-EN/p009.png) · [S. 10](units/U09/sources/assets/DS-U09-L-EN/p010.png) · [S. 11](units/U09/sources/assets/DS-U09-L-EN/p011.png) · [S. 12](units/U09/sources/assets/DS-U09-L-EN/p012.png) · [S. 13](units/U09/sources/assets/DS-U09-L-EN/p013.png) · [S. 14](units/U09/sources/assets/DS-U09-L-EN/p014.png) · [S. 15](units/U09/sources/assets/DS-U09-L-EN/p015.png) · [S. 16](units/U09/sources/assets/DS-U09-L-EN/p016.png) · [S. 17](units/U09/sources/assets/DS-U09-L-EN/p017.png) · [S. 18](units/U09/sources/assets/DS-U09-L-EN/p018.png) · [S. 19](units/U09/sources/assets/DS-U09-L-EN/p019.png) · [S. 20](units/U09/sources/assets/DS-U09-L-EN/p020.png) · [S. 21](units/U09/sources/assets/DS-U09-L-EN/p021.png) · [S. 22](units/U09/sources/assets/DS-U09-L-EN/p022.png) · [S. 23](units/U09/sources/assets/DS-U09-L-EN/p023.png) · [S. 24](units/U09/sources/assets/DS-U09-L-EN/p024.png) · [S. 25](units/U09/sources/assets/DS-U09-L-EN/p025.png) · [S. 26](units/U09/sources/assets/DS-U09-L-EN/p026.png) · [S. 27](units/U09/sources/assets/DS-U09-L-EN/p027.png) · [S. 28](units/U09/sources/assets/DS-U09-L-EN/p028.png) · [S. 29](units/U09/sources/assets/DS-U09-L-EN/p029.png) · [S. 30](units/U09/sources/assets/DS-U09-L-EN/p030.png) · [S. 31](units/U09/sources/assets/DS-U09-L-EN/p031.png) · [S. 32](units/U09/sources/assets/DS-U09-L-EN/p032.png) · [S. 33](units/U09/sources/assets/DS-U09-L-EN/p033.png) · [S. 34](units/U09/sources/assets/DS-U09-L-EN/p034.png) · [S. 35](units/U09/sources/assets/DS-U09-L-EN/p035.png) · [S. 36](units/U09/sources/assets/DS-U09-L-EN/p036.png) · [S. 37](units/U09/sources/assets/DS-U09-L-EN/p037.png) · [S. 38](units/U09/sources/assets/DS-U09-L-EN/p038.png) · [S. 39](units/U09/sources/assets/DS-U09-L-EN/p039.png) · [S. 40](units/U09/sources/assets/DS-U09-L-EN/p040.png) · [S. 41](units/U09/sources/assets/DS-U09-L-EN/p041.png) · [S. 42](units/U09/sources/assets/DS-U09-L-EN/p042.png) · [S. 43](units/U09/sources/assets/DS-U09-L-EN/p043.png) · [S. 44](units/U09/sources/assets/DS-U09-L-EN/p044.png) · [S. 45](units/U09/sources/assets/DS-U09-L-EN/p045.png) · [S. 46](units/U09/sources/assets/DS-U09-L-EN/p046.png) · [S. 47](units/U09/sources/assets/DS-U09-L-EN/p047.png)

## DS-U09-R-KNIME-CHEATSHEET

[Markdown-Quelle](units/U09/sources/knime_cheatsheet.md) · 1 Seiten.

[S. 1](units/U09/sources/assets/DS-U09-R-KNIME-CHEATSHEET/p001.png)

## DS-U09-R-ML-READINESS-TEMPLATE

[Markdown-Quelle](units/U09/sources/ml_readiness_template.md) · 2 Seiten.

[S. 1](units/U09/sources/assets/DS-U09-R-ML-READINESS-TEMPLATE/p001.png) · [S. 2](units/U09/sources/assets/DS-U09-R-ML-READINESS-TEMPLATE/p002.png)

