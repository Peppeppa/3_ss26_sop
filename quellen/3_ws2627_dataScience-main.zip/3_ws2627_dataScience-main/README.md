# Data Science – THWS, Wintersemester 2026/27

Begleit-Repository für Data Science (3. Semester Informatik). **Privates** Projekt mit Unterlagen zu U00–U09, Portfolio M1–M4, Python-Übungen und einer nachvollziehbaren Chat-/Entscheidungsdokumentation.

## Aufbau

- `units/U00` bis `units/U09`: Folien, Übungen, Lernmaterial und Ergebnisse je Vorlesungseinheit.
- `portfolio/M1` bis `portfolio/M4`: Anforderungen, Implementierung, Ergebnisse und Entscheidungen je Meilenstein.
- `projekt_chats/`: Gesprächsindex und aus den zugänglichen Chats belegbare Zusammenfassungen (keine vollständigen Chattranskripte).
- `python_uebungen/`: Übungen, Jupyter, pandas, SQL und KNIME.
- `quellen/`: Original-Kursunterlagen, soweit tatsächlich verfügbar.
- `DS_PROJECT_MANIFEST.md`: projektweite Regeln und Quellenhierarchie (vollständige Fassung im lokalen Startpaket).

**Maßgeblich:** Offizielle Aufgabenblätter (`M*_sheet.pdf`), `HANDIN.pdf`, `Schedule.pdf` und Vorlesungsunterlagen haben Vorrang vor persönlichen Notizen. Keine personenbezogenen Geheimnisse, Passwörter oder großen Rohdaten committen.

**Status:** Die Projektstruktur wird aus dem ChatGPT-Projekt übernommen. Nicht zugängliche Chatverläufe, PDF-Dateien und noch nicht erhobene Analyseergebnisse werden nicht erfunden.
