# Portfolio-Bestandsprüfung – 2026-11-28

Geprüfter Ausgangsstand main: `5c7db20ae79578947ed6a07f698cd93551865529`. Direkter Abruf portfolio/M1 und portfolio/M2: nur jeweilige README.md, keine Gruppenabgabe oder Arbeitsdateien. Die im aktuellen Import erzeugten sources/ enthalten ausschließlich offizielle Aufgabenblätter und Vorlagen, nicht studentische Lösungen. Keine Einstufung als fehlende *Abgabe bei Moodle/Nextcloud*; nur im abgefragten Repository nicht sichtbar.

## Benötigte Unterlagen für den tatsächlichen M1/M2-Abgleich

| Milestone | Benötigt (offizielle Quelle) | Status der Gruppenarbeit |
|---|---|---|
| M1 | report.pdf, manifest.yaml, awc_flat.metadata.yaml, Profil-CSV, Extraktions-/Analysecode, ggf. Midterm-Slide | nicht abrufbar |
| M2 | aktueller Bericht/TeX, manifest.yaml, clean_flat.csv, Code, M1-Log und Rohdaten für Reproduktion, Plots/Peer-Review soweit schon vorhanden | nicht abrufbar; Arbeitsstand nicht bewertbar |

Offizielle Pflichtquellen: [HANDIN §4–6](quellen/organisation/sources/HANDIN.md), [M1 Blatt](portfolio/M1/sources/M1_sheet.md), [M2 Blatt](portfolio/M2/sources/M2_sheet.md), [M3 Blatt](portfolio/M3/sources/M3_sheet.md). M4 hat keine eigene Abgabedatei.

## Lokal überprüfte Kursreferenz

Die beiden Starter-Kits M2/M3 enthalten byteidentische slices.csv (SHA-256 d3ceba478cc95a3f6443b881b657da9b31cc57cb6421d091993bccf17a95b07d). Der Eintrag S11 Germany/Bikes nennt 2255 lines, 1701 orders, 934 customers, 88 products, revenue 4382176.51, ref_cutoff 30, ref_unit customer. Diese Referenzwerte sind keine bestätigten Ergebnisse eurer Abgabe. Kein Gruppenname/keine Gruppennummer abgeleitet.

M2 führt M1-Log aus; rows_in − rows_removed = rows_out = cleaned.rows; Clustergrößen + unassigned = matrix.objects. M3 basiert auf M2; die Outcome-Definition muss ref_cutoff/ref_unit verwenden. Der reine Inventarcheck ersetzt nicht die fachliche Prüfung oder check_submission.py.

## Fehlende Dateien außerhalb der Gruppenarbeit

M1_template.zip ist nicht in den bereitgestellten 13 ZIPs. Unit09-Kit nennt Dashboard-Dateien awc_dashboard.py, awc_kpi_dashboard.py und DS_09_dashboard.knwf, die nicht im Archiv liegen. AWC_tables.zip enthält Lookup-Tabellen, nicht die aus der lokalen Datenbank zu erzeugende awc_flat.csv. Für vollständige Reproduzierbarkeit der eigenen Ergebnisse sind euer Extrakt und ggf. Zugang zur eigenen Datenbank nötig; keine Passwörter hochladen.
