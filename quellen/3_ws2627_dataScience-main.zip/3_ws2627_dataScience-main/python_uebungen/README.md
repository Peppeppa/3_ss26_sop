# Python, Jupyter, pandas, SQL und KNIME

Reproduzierbare Übungen mit nachvollziehbarem Code, Ausgangsdaten, erwarteter Ausgabe und Fehleranalyse. Python-Syntax für Einsteiger erklären, bei Bedarf Vergleiche zu Java ergänzen. MySQL läuft im bestehenden Docker-Compose-Setup; keine Passwörter committen.
