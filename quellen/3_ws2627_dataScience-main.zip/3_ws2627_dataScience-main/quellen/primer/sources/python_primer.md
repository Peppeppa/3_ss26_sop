---
source_id: DS-R003
original_file: python_primer.pdf
source_type: reference
language: en
page_count: 9
source_sha256: 4ea8a6dc48c1750ef365125408fb5816780680289513c216cc4d6ce776d8e845
verification: partial
---
# python_primer

[Original PDF](../../python_primer.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../python_primer.pdf#page=1)

~~~~text
                           Python Primer - the Short One
         Eight things to understand before the module Data Science shows them to you


            Prof. Dr. Frank-Michael Schleif          ·    frank-michael.schleif@thws.de




Eight ideas, one section each. Nothing here is examined. You already know how to program - this is only about
where Python differs from what you were taught, and about the five things the module’s scripts show you most
often. Python is one of two routes through this module; KNIME is the other, and equally valid. If you work in
KNIME, this primer helps you read the Python listings on the slides. If you know Kotlin rather than Java, read the
Java column as “the language with types and braces”.
~~~~

## Page 002

[Original page 2](../../python_primer.pdf#page=2)

~~~~text
1 - You Will Write Fewer Classes Than You Think                                                                                  Bites at: U00

    The scripts behind this course contain hundreds of functions and a single class. That ratio is not sloppiness - it is
    the idiom. A class earns its place when it holds state that several methods share; an analysis step usually holds
    none.

   Java                                                                    Python
   public class Re ven ueC alc u l a t o r {                               def net ( gross , rate =0.19) :
     private final double rate ;                                               return gross * (1 - rate )
     public Re ven ueCa lcu lat o r ( double r ) {
       this . rate = r ;
     }                                                                     No class, no constructor, no field. The default value replaces
     public double net ( double gross ) {                                  the thing the constructor was there to remember.
       return gross * (1 - rate ) ;
     }
   }


    Three syntax facts, and then you can read any script here
    Indentation is the block - there are no braces, and getting it wrong is a syntax error, not a style complaint. No
    type declarations - rate = 0.19 is enough, and a function takes whatever you pass it. No new -
    df = pd.DataFrame() constructs.


    Kotlin readers: much of this will look familiar - top-level functions (your fun), default arguments, type inference. The difference is
    that Python does not check the types before the code runs.
                                                                                                                                             2/9
~~~~

## Page 003

[Original page 3](../../python_primer.pdf#page=3)

~~~~text
2 - The Five Things You Will See Most                                                                Bites at: U00, U01




   Learn these five and you can read nearly every script in this course.
                       Python                           What you knew it as
    f-string           f"{n} rows"                      String.format("%d rows", n)
    comprehension      [x*2 for x in xs]                a stream().map().toList()
    function           def f(a, b=1):                   a static method; b=1 replaces an overload
    path               Path("AWC")/name                 Paths.get(...), and / is the separator
    dict               {"a": 1}                         Map<String,Integer>, with literal syntax


   The comprehension is the one to get comfortable with
   Read [r for r in rows if r.total > 100] from the for: take each r in rows, keep the ones over 100, collect them
   into a list. It is a filter and a collect in one line, and it appears everywhere in this material.




                                                                                                                     3/9
~~~~

## Page 004

[Original page 4](../../python_primer.pdf#page=4)

~~~~text
3 - A DataFrame Is a Table, Not a List of Objects                                                               Bites at: U01




                                                              Java instinct            pandas reality
                    OrderQty   LineTotal   Category
              0                                               List<Order>, one         one array per column, all
              1                                               object per row           rows at once
              2                                               order.getTotal()         df["LineTotal"] - the
              3                                                                        whole column
                         df["LineTotal"]                      a loop over the list     an operation on the column


                                                             Why it matters here
  The grey numbers on the left are the index. A column is    Most numbers in this course are column summaries: a row
  the unit you work with, and it comes out as a Series - a   count, a sum, a share of missing values. Reach for the row
  labelled array.                                            and you write ten lines; reach for the column and you write
                                                             one - and the one is faster by orders of magnitude.




                                                                                                                           4/9
~~~~

## Page 005

[Original page 5](../../python_primer.pdf#page=5)

~~~~text
4 - Do Not Loop. Select.                                                                                             Bites at: U01, U04




   Java                                                                  Python
   double sum = 0;                                                        mask = ( df . TerritoryID == 8) \
   for ( Order o : orders ) {                                                  & ( df . O nlin eOr derF lag == 0)
     if ( o . getTerritory () == 8                                        total = df . loc [ mask , " LineTotal " ]. sum ()
          && ! o . isOnline () ) {
       sum += o . getTotal () ;
                                                                         mask is a column of True/False, one per row. df.loc keeps
     }
   }                                                                     the True ones. Same three ideas, no loop.


    Two traps that bite Java readers on day one
    Use & and |, not && and || - and parenthesise every condition, because & binds tighter than ==. And a masked
    selection is a copy: assigning through a slice of a slice changes nothing and warns you about it. Assign through
    .loc once.

    This is the whole of the warm-up filter in U01: two conditions, one mask, 1,903 rows.




                                                                                                                                     5/9
~~~~

## Page 006

[Original page 6](../../python_primer.pdf#page=6)

~~~~text
5 - A Join Is a Join: merge Is JOIN                                                                          Bites at: U01




    You already know joins from Databases I. pandas spells them differently and forgets to warn you about the same
    thing SQL forgets to warn you about.
   SQL                                                            Python
   SELECT * FROM header h                                         m = header . merge ( detail ,
   JOIN detail d ON h . SalesOrderID                                                   on = " SalesOrderID " ,
                 = d . SalesOrderID                                                    how = " inner " )

     how="inner"      only matching rows, the default - same as JOIN
     how="left"       every left row, matched or not - same as LEFT JOIN
     validate=        "1:m", "1:1" ... raises if the cardinality is not what you claimed


    The habit that saves you in U01
    Print the row count before and after every join. A join that silently multiplies rows is a common bug in this
    material, and the only symptom is a number that got bigger. validate="1:m" turns that silence into an
    exception.




                                                                                                                       6/9
~~~~

## Page 007

[Original page 7](../../python_primer.pdf#page=7)

~~~~text
6 - Missing Is Not One Thing, and isna Sees Only One of Them                                             Bites at: U04




                                                        None is Python’s null. NaN is a floating-point number that
                        NaN        isna ✓               means “not a number”, and it is what pandas puts in a
                      "NULL"       isna ×               numeric column. df.isna() finds those two (and pandas’
                        ""         isna ×               NaT, pd.NA) - no text, no zero.
                         0         isna ×
                       "n/a"       isna ×               The number to remember
                                                        In U04 one file shows 0 missing in KNIME and 3 of 17
  Once in memory, only NaN counts. How the other four   rows (17.6 %) in pandas. The cells hold the text NULL;
  arrive depends on how you read the file.              read_csv guessed right, from a fixed word list that also
                                                        turns NA (Namibia) into missing. Decide when reading
                                                        (na_values=, keep_default_na=False) and count the
                                                        placeholders the list does not know (-1, 1900-01-01)
                                                        yourself.
    And NaN is contagious: NaN + 1 is NaN, and NaN == NaN is False. Compare with .isna(), never with ==.




                                                                                                                     7/9
~~~~

## Page 008

[Original page 8](../../python_primer.pdf#page=8)

~~~~text
7 - The Types Arrive Wrong, and Nobody Tells You                                                                   Bites at: U02


   A database column has a type. The driver picks the nearest Python type. “Nearest” is not “same”, and no
   warning is printed.
    in MySQL                           arrives as                   what that costs you
    DECIMAL(19,4) - exact              float64 - binary             money becomes inexact; 0.1 + 0.2 !=
                                                                    0.3. Java made you say BigDecimal;
                                                                    here you get no such prompt
    TINYINT(1)                         int64, not bool              it will be summed and averaged, and
                                                                    “mean OnlineOrderFlag = 0.879” (per
                                                                    order) is a proportion pretending to be a
                                                                    measurement
    DATETIME, TIMESTAMP                datetime64                   the pleasant surprise: the driver parsed it.
                                                                    A plain DATE arrives as object; convert
                                                                    it with pd.to_datetime


   So the first thing you do after reading a table
   print(df.dtypes). It costs one line and it is the only place these three facts are visible. In U02 you will be asked
   which two columns surprised you.


                                                                                                                             8/9
~~~~

## Page 009

[Original page 9](../../python_primer.pdf#page=9)

~~~~text
8 - Your Notebook Lies About What It Ran                                                                               Bites at: U02




                                                           A notebook keeps state, not a program. A cell you edited and
               [1]   df = read_sql(...)                    did not re-run is still in memory; a cell you deleted still has its
                                                           effect. The order on screen and the order that ran are different
               [3] df = df.dropna()
                                                           things.
               [2] print(len(df))
                                                           One habit worth keeping
  Read top to bottom it is wrong. Read by execution        Before you show anything: Restart & Run All (KNIME: reset
  number it is right. Only the brackets are true.          and execute the whole workflow). If it does not survive that, it
                                                           was never a result - it was an accident that happened to be on
                                                           your screen.
    And the environment. Install the packages U00 lists. If you keep several Python projects, python -m venv
    .venv gives this one its own package set, much like a project’s own pom.xml dependencies.
    U02 makes this concrete: your extract must run end to end from an empty session and produce the same hash twice.




                                                                                                                                 9/9
~~~~
