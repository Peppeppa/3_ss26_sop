---
source_id: DS-R005
original_file: statistic_stochastic_primer_short_en.pdf
source_type: reference
language: en
page_count: 11
source_sha256: 0f9a16f47309b973a528d2e25255ae6834ca5b4f3d77798586e5a8a1b253d5b8
verification: partial
---
# statistic_stochastic_primer_short_en

[Original PDF](../../statistic_stochastic_primer_short_en.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../statistic_stochastic_primer_short_en.pdf#page=1)

~~~~text
                         Statistics Primer - the Short One
         Eight things to understand before the module Data Science shows them to you


           Prof. Dr. Frank-Michael Schleif          ·    frank-michael.schleif@thws.de




Eight sections, one idea each. Nothing here is examined. The module never derives a formula - it asks you to
read a number and say what it does not prove, and these eight ideas are what that takes. Read it in one sitting;
come back to section 7 before the PCA unit.
~~~~

## Page 002

[Original page 2](../../statistic_stochastic_primer_short_en.pdf#page=2)

~~~~text
1 - What You Are Allowed to Compute                                                      Bites at: U00, U05

    Scale              Typical value            Example
    Nominal            mode                     colour, country, product ID - the number is a label
    Ordinal            median                   size S/M/L, income bracket - order, no distances
    Interval / ratio   mean                     revenue, quantity (add), date (subtract)
    Cyclic             see below                weekday, month, hour - the scale wraps

   The rule
   A statistic is computable whenever the column holds numbers, meaningful only at the right
   scale. The mean of a set of postcodes exists. It means nothing. And on a wrapping column,
   ordinary subtraction breaks at the seam: Sunday to Monday is 6 days if you subtract the day
   numbers, and 1 day in reality.

   And one word about the rows
   Your data is a sample, never the population - even at 30,000 rows. “A sample of what?” is the
   question, and statistics cannot answer it: the rows that would reveal a filter nobody wrote
   down are exactly the rows that are absent. Only the source can - ask what the query was, and
   what it excluded. Hence the provenance log.
                                                                                                        2/11
~~~~

## Page 003

[Original page 3](../../statistic_stochastic_primer_short_en.pdf#page=3)

~~~~text
2 - “Typical” Has Three Answers, and Spread Has Two                                                            Bites at: U04


                                      Use when                               Breaks when
      Mean x̄                         roughly symmetric                      one large value drags it
      Median x̃                       skewed, or extremes present            ignores how extreme the tail is
      Mode                            categorical, multi-peaked              unstable on continuous data
      sd s (not robust)               the mean is meaningful                 built from the mean, so it is
                                                                             dragged too
      IQR Q3 − Q1 (robust)            always safe                            says nothing about the tail

                                                           The one diagnostic worth memorising
                                                           Divide the mean by the median. Far from 1.0 the column is
           median                                          skewed: “the average” is the wrong word for that column,
                      mean                                 and you know it before you have plotted anything.


                        order value                        AWC order values have mean 3,916 and median 865. The
                                                           ratio is 4.53 - the mean order is four and a half times the
  The long right tail drags the mean away from the bulk.   typical one.
  The median stays where the rows are.

                                                                                                                         3/11
~~~~

## Page 004

[Original page 4](../../statistic_stochastic_primer_short_en.pdf#page=4)

~~~~text
3 - The Shape Decides Which Summary Is Honest                                                                    Bites at: U04, U08

                      symmetric                  skewed                   bimodal                 heavy-tailed




    Shape              Recognise by                                  What it breaks
    Symmetric          x̄ ≈ x̃                                       nothing
    Skewed             x̄ ̸= x̃                                      “the average” misleads
    Bimodal            two peaks, or odd jumps between               every single-number summary
                       deciles
    Heavy-tailed       a few enormous values                         the sd, and every normality assumption

   Bimodal is the dangerous one - and it is the AWC case
   Skew makes a summary imprecise. Bimodality makes it wrong: the mean of two mixed
   populations describes neither: it lands in the empty valley between them, or, as in AWC, inside
   one group, dragged far off by the other. Shape first, then the summary. Reversed, you get
   confident nonsense.

   AWC is bimodal because one table holds two businesses - resellers and online. Almost every column you summarise is really two
   columns stacked.
                                                                                                                                   4/11
~~~~

## Page 005

[Original page 5](../../statistic_stochastic_primer_short_en.pdf#page=5)

~~~~text
4 - Correlation: Two Coefficients, One Free Diagnostic                                                          Bites at: U08

                             Measures                                    Assumes
      Pearson r              how well a straight line fits               linearity; badly hurt by outliers
      Spearman ρ             how well any rising or falling curve fits   only the ordering; robust

                                                          Compute both, and subtract

                                                             • roughly equal ⇒ the relationship really is close to a
                                                               straight line
              r ≈ρ                     r >ρ
             really a line       three points carry it       • Spearman much higher ⇒ it rises, but curved
                                                             • Pearson much higher ⇒ a handful of extreme
  Both clouds give a high Pearson. Only the left one           points are carrying it
  is a relationship.                                      Two numbers and one subtraction diagnose the shape of
                                                          a relationship, with no plot.

    And read r on the right scale
    r = 0.7 is not “70 % related”. Square it: r 2 = 0.49 is the share of the variation a straight line accounts for. A
    parabola symmetric about its vertex gives r ≈ 0: r is blind to any shape but a line.

    AWC: order value against total quantity gives Pearson 0.869, Spearman 0.215 - the third bullet, exactly.              5/11
~~~~

## Page 006

[Original page 6](../../statistic_stochastic_primer_short_en.pdf#page=6)

~~~~text
5 - Correlation Is Not Cause: Always Look for the Third Variable                                                       Bites at: U08, U09



                                                           Three different worlds produce the same correlation: x causes y ,
                          customer                         y causes x , or something else causes both - a confounder. The
                            size
                                                           coefficient cannot tell them apart. Ever.
                variety
                                      revenue              The case you will meet in the course
                bought    r = 0.87?
                                                            Per AWC customer, revenue correlates with the number of distinct products
  Solid arrows are real. The dashed one is what you         bought at r = 0.87. The tempting conclusion - “show them more variety
  want to conclude, and the correlation does not            and they will spend more” - is wrong. Both are symptoms of customer size:
  support it.                                               a big reseller orders more often, buys more variety and spends more.


    The test, and it is cheap
    Hold the third variable constant and look again - compare only customers of similar size - and see whether the
    relationship survives. Usually most of it does not. A correlation over two mixed populations can even have the
    opposite sign to the one inside each group.

    A dashboard invites the causal reading: two lines move together, and the viewer supplies the “because” for free.


                                                                                                                                        6/11
~~~~

## Page 007

[Original page 7](../../statistic_stochastic_primer_short_en.pdf#page=7)

~~~~text
6 - How Much Does a Number Actually Know?                                                                 Bites at: U00, U04




                                                                                   √
                                                           noise    shrinks like 1/ n: more rows help, but halving it
                                                                    needs four times the data
                                                           bias     does not shrink at all; past a modest n the bias is
                                                                    the whole error
                                                          So “we have millions of rows” is an argument about noise
                 noise             bias
                                                          only. It says nothing about a wrong join or a silently dropped
                                                          region - those do not average out, they all push the same way.
  Orange is the truth. Scattered but centred shrinks as
  you add rows; tight but off-centre never does.




                                                                                                                           7/11
~~~~

## Page 008

[Original page 8](../../statistic_stochastic_primer_short_en.pdf#page=8)

~~~~text
6 - What a Confidence Interval and a p-Value Actually Claim                                                      Bites at: U00, U08



                     the true value                            A 95 % confidence interval
                                                               Does not say “the true value is in here with 95 % probability”.
                                                               It says: repeat this whole sampling procedure many times
                                                               and 95 % of the intervals built this way would contain the
                                                               true value. The guarantee belongs to the procedure. It also
                                                               assumes the mean is meaningful and one population - so on a
  Ten repeats of the same sampling procedure; at 95 % one
                                                               bimodal column (section 3) it is precise nonsense.
  in twenty misses on average. Nothing on the orange
  interval marks it as the miss. You are handed exactly one.


    A p-value
    Is the probability of a result at least this extreme if nothing were going on. It is not the probability that
    nothing is going on, and - the one that matters here - not a measure of how big the effect is. At
    n = 30,000 a difference far too small to act on comes out “significant”. Report the number, then say
    what it does not license.

    U00 on AWC: d = 1.50 (gap of the group means in standard deviations) needs 8 orders per group, d = 0.03 about 22,000 - more
    than AWC holds.                                                                                                               8/11
~~~~

## Page 009

[Original page 9](../../statistic_stochastic_primer_short_en.pdf#page=9)

~~~~text
7 - One Piece of Linear Algebra: an Eigenvalue Is a Variance                                                       Bites at: U07


    The setup
    Your table is a matrix: one row per customer (U07), one column per variable. How much two
    columns move together is their covariance; every pair of them gives the square, symmetric
    covariance matrix S.


                                                                The one equation, Sv = λv
                                            λ1
                         λ2                                     Picture your rows as a cloud of points, longer in some
                                                                directions than others. Such a direction is an eigenvector
                                                                v; how far the cloud stretches along it is its eigenvalue λ -
                                                                for a covariance matrix, simply the variance in that
                                                                direction. That is all the equation says: S does not turn
  Each dot is one row; the arrows are the eigenvectors, their   that direction, only scales it. PCA: take those directions
                     √
  lengths the spread, λ.                                        as the new axes, biggest first, keep two or three.

    The two things to carry into the unit
           ∑
    λk /    j
                λj is the “share of variance explained”, so how many to keep is a judgement - different rules disagree on
    the same data. Naming PC1 “customer size” is your interpretation, not the arithmetic’s.
                                                                                                                                9/11
~~~~

## Page 010

[Original page 10](../../statistic_stochastic_primer_short_en.pdf#page=10)

~~~~text
8 - “Independent” - the Word Behind Three Later Traps                                              Bites at: U04, U05, U09


   Two things are independent when knowing one tells you nothing about the other. Three places
   it fails quietly:
    Missing values                           Why a value is missing decides whether you may fill it in. By
                                             chance, or because of something you did observe: you can.
                                             Because of the value itself - high earners not stating income -
                                             and filling it in invents a population without rich people.
    Time series                              This month resembles last month - autocorrelation - so
                                             consecutive rows are not independent. Two series that merely
                                             both trend upward correlate for no reason.
    Train / test split                       Held-back data only tests a model if the two halves are
                                             independent. Split months at random and neighbours land on
                                             both sides - the model half remembers the answer. Split by
                                             time.

   The general form
   Information that reaches a model but would not exist at prediction time makes it look brilliant
   and useless. A suspiciously perfect result is a warning, not a reward.

   In U09 an honest model reaches an AUC of 0.585 and a leaking one 1.000 - on the same data.

                                                                                                                      10/11
~~~~

## Page 011

[Original page 11](../../statistic_stochastic_primer_short_en.pdf#page=11)

~~~~text
Check yourself - five questions
  1. Mean 3,916, median 865. What have you learned?
     Strongly skewed - “the average order” is the wrong phrase for this column.
  2. Pearson 0.87, Spearman 0.22. What shape?
     Rising but not linear, and a few extreme points are carrying the line.
  3. Why does more data not repair a biased sample?
     More data shrinks noise, not bias. Bias does not shrink at all.
  4. State what a 95 % CI claims, without saying “with 95 % probability”.
     Repeat the procedure many times and 95 % of the intervals it builds would contain the true value.
  5. Your model scores 99 %. What do you do first?
     Look for leakage - on real business data that result is a bug until proven otherwise.

Got all five? Then this deck has done its job. Read the shape before you quote a summary, and name what a
number does not prove - that is the whole of it.
~~~~
