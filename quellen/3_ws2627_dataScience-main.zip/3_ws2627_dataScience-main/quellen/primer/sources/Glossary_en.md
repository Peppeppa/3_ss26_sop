---
source_id: DS-R007
original_file: Glossary_en.pdf
source_type: reference
language: en
page_count: 3
source_sha256: 0aadd36dbd28dcf3b900638f60e750cc98ad970f59a94a5527c5ecd239aa423c
verification: partial
---
# Glossary_en

[Original PDF](../../Glossary_en.pdf). Vollständige Textschicht. Rekonstruktionen sind separat markiert. Seiten- und Aufgabenabdeckung geprüft; keine vollständige manuelle Überprüfung aller Layout- und Formelzeichen.

## Page 001

[Original page 1](../../Glossary_en.pdf#page=1)

~~~~text
                             Glossary — Data Science
                                              GLOSSARY.md




                                             2026-09-25 15:05


Glossary — Data Science
Every abbreviation and term the ten units use, with the unit it first appears in. This is a place
to look things up, not a substitute for the units — the slide that introduces a term also
says why it matters.
The unit column is generated from the decks themselves, so it cannot drift out of step. If
something you need is missing, say so and it gets added.

term            stands for                        what it means                                             unit

CTE             common table expression           A named subquery (WITH ...). RECURSIVE makes it           --
                                                  walk a hierarchy of unknown depth.
DIKW            Data, Information, Knowledge,     The ladder from a raw value to a decision. Context        U00
                Wisdom                            is what moves you up it.
grain           —                                 What ONE ROW of a table is. An order line and an          U00
                                                  order are different grains, and every aggregate
                                                  depends on which you are in.
tidy data       —                                 One observation per row, one variable per column,         U00
                                                  one value per cell (Wickham, 2014).
PCA, PC1        principal component analysis      Rotate the data onto the directions of greatest           U00
                                                  variance. PC1 is the first such direction; the rotation
                                                  is one linear map you can reuse on new points.
t-SNE           t-distributed stochastic          A 2-D map that preserves NEIGHBOURHOODS, not              U00
                neighbour embedding               distances. It cannot be applied to a new point, and
                                                  its axes have no meaning.
EDA             exploratory data analysis         Looking at the data before claiming anything about        U00
                                                  it: shape, spread, relationships — statistics first,
                                                  then the picture.
DBMS            database management system        The software around the data: storage, queries,           U02
                                                  transactions, access control.
OLTP            online transaction processing     The operational system — many small writes, kept          U02
                                                  correct and fast. Analysis does not belong here,
                                                  which is why you take an extract.
ODBC / JDBC     Open / Java Database              Driver standards: one API, a different driver per         U02
                Connectivity                      database, so the program does not change when
                                                  the database does.
ORM             object-relational mapping         A layer that presents rows as objects. Convenient,        U02
                                                  and it hides the query it generates.
ACID            Atomicity, Consistency,           What a transaction guarantees: all or nothing, valid      U02
                Isolation, Durability             state, no interference, survives a crash.
CAP / BASE      Consistency, Availability,        Under a network partition a distributed store must        U02
                Partition tolerance               choose consistency or availability. BASE is the
                                                  pragmatic answer that picks availability.
ETL             extract, transform, load          The three stages of moving data somewhere it can          U02
                                                  be analysed. Your notebook is a small ETL pipeline.




                                                     1
~~~~

## Page 002

[Original page 2](../../Glossary_en.pdf#page=2)

~~~~text
Glossary — Data Science                                                                                GLOSSARY.md




term              stands for                       what it means                                           unit

BOM               byte order mark                  Invisible bytes some tools write at the start of a      U03
                                                   UTF-8 file. pandas removes them; Python's open()
                                                   and the csv module keep them, glued to the first
                                                   column name. Read with encoding=”utf-8-sig”.
CR, LF, CRLF      carriage return, line feed       The three ways a line can end: LF (Linux, macOS),       U03
                                                   CRLF (Windows), a bare CR (classic Mac OS). A
                                                   mismatch shows as stray characters, or, in
                                                   line-based tools like wc and head, as one giant line.
DTD / XSD         document type definition / XML   The contract an XML document is checked against.        U03
                  Schema Definition                A DTD constrains structure only; an XSD adds types
                                                   and value ranges.
XPath /           —                                Query languages for one tree: address a node by its     U03
JSONPath                                           path instead of looping over the document.
XSLT              XSL Transformations              Declarative, template-driven transformation of one      U03
                                                   XML tree into another (or into HTML or text).
DOM / SAX         Document Object Model /          Two ways to read a tree: DOM builds it all in           U03
                  Simple API for XML               memory, SAX streams events past you. DOM is
                                                   convenient, SAX survives a file larger than RAM.
YAML              YAML Ain't Markup Language       JSON's tree written for people: indentation,            U03
                                                   comments. For configuration and metadata files,
                                                   not for data. Unquoted values are guessed: NO
                                                   becomes false, 01071 an octal number.
FAIR              Findable, Accessible,            Four criteria a dataset is assessed against. They are   U03
                  Interoperable, Reusable          about the metadata as much as the data.
quasi-            —                                An attribute that identifies nobody alone but does in   U03
identifier                                         combination — birth date plus postcode plus sex.
k-anonymity       —                                Every record is indistinguishable from at least k-1     U03
                                                   others on the quasi-identifiers. k = 1 means
                                                   uniquely identifiable.
pseudonymisation—                                  Replacing a name by a key that can still be linked      U03
                                                   back. The data stays personal data under the GDPR;
                                                   hashing an ID is pseudonymisation, not
                                                   anonymisation.
KL divergence     Kullback-Leibler divergence      The cost t-SNE minimises: how far the 2-D               U03
                                                   neighbourhood distribution Q is from the
                                                   high-dimensional P. Asymmetric — separating true
                                                   neighbours is punished hard, crowding strangers is
                                                   cheap.
quartile, Q1,     —                                Cut the sorted values into four equal parts. Q1 is      U04
Q3                                                 the value below which 25 % lie, Q3 the value below
                                                   which 75 % lie; the median is Q2.
IQR               interquartile range              The middle half of the data: IQR = Q3 - Q1. The         U04
                                                   usual outlier fences sit 1.5 IQR below Q1 and above
                                                   Q3, and one huge value does not move them.
z-score           —                                How many standard deviations a value sits from the      U04
                                                   mean. Unlike the IQR fences, one extreme value
                                                   moves both the mean and the spread.
MCAR / MAR /      missing completely at random /   Why a value is absent: pure chance, something you       U04
MNAR              at random / not at random        did observe, or the missing value itself. Only the
                                                   first two can be imputed without bias.
sentinel          —                                A normal-looking value standing in for 'no value' —     U04
                                                   the string 'NULL', -1, 1900-01-01. A null check
                                                   reports 0 % missing.
one-hot           —                                One binary column per category. 37 subcategories        U04
                                                   become 37 columns, and the distance between two
                                                   rows changes accordingly.
KPI               key performance indicator        The one number put on a wall. Choosing it IS the        U05
                                                   analysis: the same series can be reported as growth
                                                   or as shrinking baskets.
cosine /          —                                Angle between two vectors, ignoring length; and         U06
Jaccard                                            the overlap of two sets. Both answer 'similar'
                                                   differently from Euclidean distance.




                                                      2
~~~~

## Page 003

[Original page 3](../../Glossary_en.pdf#page=3)

~~~~text
Glossary — Data Science                                                                                 GLOSSARY.md




term              stands for                        what it means                                           unit

DTW               dynamic time warping              Distance between two sequences that may run at          U06
                                                    different speeds: it stretches the time axis to match
                                                    them.
embedding         —                                 A learned vector per object (word2vec, node2vec).       U06
                                                    Similar objects land close together, and the vectors
                                                    are the new features.
skew              —                                 How lopsided a distribution is. AWC revenue is          U06
                                                    heavily right-skewed, which is why its mean is far
                                                    above its median.
eigenvector       —                                 A direction a matrix does not rotate, only stretches:   U07
                                                    Av = (lambda)v. The eigenvalue is how much it
                                                    stretches.
perplexity        —                                 t-SNE's one real knob: roughly how many                 U07
                                                    neighbours each point should consider. Change it
                                                    and the picture changes.
UMAP / MDS        uniform manifold                  Two more projections. UMAP can place a new point        U07
                  approximation and projection /    approximately; classical MDS works from a distance
                  multidimensional scaling          matrix alone.
ARI               adjusted Rand index               How much two clusterings of the same objects            U07
                                                    agree, corrected for chance. 1 is identical, 0 is
                                                    chance.
Pearson /         —                                 Correlation of the values, and correlation of the       U08
Spearman                                            ranks. A large gap between them says a few
                                                    extreme points are making the straight line.
confounder        —                                 A third variable driving both of the two you are        U08
                                                    comparing. Customer size drives orders, variety
                                                    AND revenue at once.
WGS84             World Geodetic System 1984        The reference system GPS coordinates are given in.      U08
                                                    Two datasets in different systems can be kilometres
                                                    apart on the same street.
base rate         —                                 The share of the majority class. 88.5 % of AWC          U09
                                                    customers return, so a model that always says 'yes'
                                                    is 88.5 % accurate and useless.
TP, FP, TN, FN    true/false positive, true/false   The four cells of the confusion matrix: hit, false      U09
                  negative                          alarm, correct rejection, missed hit.
TPR / FPR         true positive rate / false        TPR = TP/(TP+FN), FPR = FP/(FP+TN). One                 U09
                  positive rate                     threshold gives one pair of them.
ROC               receiver operating                The curve traced by (FPR, TPR) as the threshold         U09
                  characteristic                    sweeps through every value. The diagonal is pure
                                                    guessing.
AUC               area under the (ROC) curve        Take one positive and one negative object at            U09
                                                    random: the AUC is the share of such pairs the
                                                    model ranks the right way round. 0.5 is guessing,
                                                    1.0 is perfect — and on a leaked feature, suspicious.
leakage           —                                 Information in the features that would not have         U09
                                                    been available at prediction time. It only ever
                                                    makes results look BETTER, so a good score is the
                                                    warning sign.
ref_cutoff /      —                                 Your slice's given temporal split and its unit of       U09
ref_unit                                            analysis (a customer on most slices, a product on
                                                    four). Both are handed to you in slices.csv.




                                                       3
~~~~
