---
source_id: DS-R002
original_file: profiling_primer.pdf
source_type: reference
language: en
page_count: 8
source_sha256: e4c9cae9911993d2316d6d1e9380597970e540f21da36a132de1fb1076154cdb
verification: partial
---
# profiling_primer

[Original PDF](../../profiling_primer.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../profiling_primer.pdf#page=1)

~~~~text
                                       Profiling Primer
               How to produce what U04 asks for — in SQL, pandas and KNIME


           Prof. Dr. Frank-Michael Schleif        ·    frank-michael.schleif@thws.de




U04 shows you what a profile finds. This shows you how to make one. Where a recipe runs on the same file as
U04, it reproduces the number U04 put on a slide, so you can check it rather than trust it.
~~~~

## Page 002

[Original page 2](../../profiling_primer.pdf#page=2)

~~~~text
1 — The Table You Are Asked to Build                                                                                    Bites at: U04, M1




  Exercise 1 asks for one row per column — eight you would report
  on; M1 wants every column of your flat table:                          The point of the table
  column            what it holds
                                                                         It is not a report you file. It is the list of questions the data
  type              what the reader will guess it is
  % missing         empty cells and sentinels (page 4)                   has raised, and every milestone after M1 refers back to it.
  distinct          1 means constant, n means a key
  min / max         the range a plausibility check needs                 Do it on your own slice. U04 uses two sources: the export
  most frequent     a sentinel hides here                                in VL_4_DS/Data/ (reseller orders only) and real AWC,
                                                                         awc_flat.csv (all orders). Your slice is a third; its
  Six entries per column. On the 25 columns of awc_flat.csv that         numbers will differ, and that difference is the point.
  is 150 cells — which is why nobody does it by hand, and why all
  three tools below give it to you in one call. Why a value is missing
  (MCAR, MAR, MNAR, not applicable) is Exercise 2.




                                                                                                                                             2/8
~~~~

## Page 003

[Original page 3](../../profiling_primer.pdf#page=3)

~~~~text
2 — One Call Gets You Most of It                                                                                     Bites at: U04




 pandas                                      SQL                                          KNIME
 df = pd.read_csv("awc_flat.csv")            -- shape and types                           node               gives
                                             DESCRIBE Sales_SalesOrderHeader;
 df.info()            # types, non-                                                       Statistics         min, max, mean,
       null                                  -- one column, all five numbers                                 median, missing,
 df.describe()        # min/max/             SELECT COUNT(*)        AS n,                                    unique — per
       quartiles                                    COUNT(t)        AS non_null,                             column, in one
 df.describe(include="all")                         COUNT(DISTINCT t) AS n_distinct,                         view
 df.nunique()         # distinct per                MIN(t), MAX(t)                        Value Counter      the frequency
       col                                   FROM (SELECT TerritoryID AS t                                   table of one
 df.isna().mean()*100 # %                           FROM Sales_SalesOrderHeader) x;                          column
       missing                                                                            Data Explorer      the same, with a
                                             COUNT(col) skips NULLs, COUNT(*) does not.                      histogram beside
 describe() covers numeric columns                                                                           each column
 only unless you ask for all — that          The difference is the missing count.
 omission is where half of a first profile                                                Data Explorer is the fastest first
 goes missing.
                                                                                          look of the three routes: it draws
                                                                                          while it counts.




                                                                                                                                3/8
~~~~

## Page 004

[Original page 4](../../profiling_primer.pdf#page=4)

~~~~text
3 — What isna() Cannot See                                                                                              Bites at: U04



   Whether a word counts as missing is decided when you read the file. KNIME’s CSV Reader counts only empty cells; pandas’
   read_csv also turns NULL, NA, N/A and "" into NaN — including NA = Namibia. Values like -1, 1900-01-01 or unknown stay
   values in every tool. U04’s employee file: KNIME 0 missing, pandas 3.

  pandas                                                           SQL
  # read the words as text, then count them yourself               SELECT JobTitle, COUNT(*) AS n
  emp = pd.read_csv("employees.csv",                               FROM   HumanResources_Employee
          encoding="cp1252", keep_default_na=False)                GROUP BY JobTitle
  SENTINELS = ["NULL", "N/A", "n/a", "-", "",                      ORDER BY n DESC
               "unknown", "?", "1900-01-01", "-1"]                 LIMIT 10;
  for c in emp.columns:                                            KNIME: CSV Reader keeps NULL as text → Rule-based Row
      hits = emp[c].astype(str).isin(SENTINELS).sum()              Filter (or Rule Engine: $ManagerID$ = "NULL" =>
      if hits:                                                     "sentinel") → Value Counter.
          print(c, hits)   # ManagerID 3, ...

  # and the most frequent value, always:                           Read the top of that list
  emp["JobTitle"].value_counts().head()
                                                                   A value that appears far more often than the others is either
                                                                   the business (most customers really are in one territory) or a
                                                                   filler somebody typed. Only the source can tell you which —
                                                                   which is U04’s whole point.



                                                                                                                                    4/8
~~~~

## Page 005

[Original page 5](../../profiling_primer.pdf#page=5)

~~~~text
4 — State the Grain, Then Prove It                                                                                    Bites at: U01, U04, M1




   “One row is . . . ” is the first line of your profile, and it is checkable: find a column that is unique and one that is not.

   pandas                                                                  SQL
   len(df)                      # 121,317 rows                             SELECT COUNT(*) AS lines,
   df.SalesOrderID.nunique()    # 31,465 orders                                     COUNT(DISTINCT SalesOrderID) AS orders,
   df.SalesOrderDetailID.is_unique   # True                                         COUNT(*) / COUNT(DISTINCT SalesOrderID)
                                                                                      AS per_order
   # so: one row is an ORDER LINE, and there                               FROM     Sales_SalesOrderDetail;
   # are 3.9 lines per order                                               KNIME: Statistics (or Data Explorer), unique count:
                                                                           SalesOrderDetailID equals the row count, SalesOrderID is
                                                                           smaller.

    Why this is the first thing, not a detail
    Every average you compute afterwards is an average per something. Get the grain wrong and the number is not slightly off, it
    answers a different question — the mean “order value” over 121,317 lines is not the mean over 31,465 orders.




                                                                                                                                         5/8
~~~~

## Page 006

[Original page 6](../../profiling_primer.pdf#page=6)

~~~~text
5 — Look, Do Not Only Count                                                                                         Bites at: U04, U08




   Four pictures answer questions a table of numbers hides. Each is one line.

  pandas
                                                                          picture         the question it answers
  # 1 shape of one column
  df.LineTotal.plot.hist(bins=60, log=True)                               histogram       is it one distribution, or two glued
                                                                                          together?
  # 2 where the missing values SIT                                        missing map     is the missingness patterned? Stripes
  import seaborn as sns                                                                   mean a rule, scatter means chance
  sns.heatmap(df.isna(), cbar=False)                                      bar of counts   are five spellings one category?
                                                                          box by group    is the outlier an outlier in its own group?
  # 3 how a category is spelled                                           KNIME: Data Explorer draws 1 and 3 without a node of
  df.Category.value_counts().plot.barh()
                                                                          your own; Box Plot and Histogram do the rest.
  # 4 outliers, with the quartiles drawn
  df.boxplot(column="LineTotal", by="OnlineOrderFlag")




                                                                                                                                        6/8
~~~~

## Page 007

[Original page 7](../../profiling_primer.pdf#page=7)

~~~~text
6 — The KNIME Route, End to End                                                                                        Bites at: U04, M1




   Six nodes produce the whole profiling table. Copy the connector from the U02 workflow rather than configuring it again.
        node                                        what it is for
   1    MySQL Connector → DB Query Reader           your slice, as rows
   2    Statistics                                  min, max, mean, median, missing, unique — the bulk of the table
   3    Value Counter                               one column’s frequencies; run it on every suspicious column
   4    Data Explorer                               the same numbers with a plot per column
   5    Rule Engine                                 flag sentinels: $ManagerID$ = "NULL" => "sentinel"
   6    CSV Writer                                  the profile itself, so M1 can hand it in



   The node that is missing on purpose
   There is no “fix it” node here. Missing Value exists and you will want it later — in M2, driven by the decisions your cleaning log
   records. Profiling marks; it never corrects.




                                                                                                                                        7/8
~~~~

## Page 008

[Original page 8](../../profiling_primer.pdf#page=8)

~~~~text
7 — Where the Recipes Stop                                                                                             Bites at: U04, M1




   Everything above is mechanical, and that is its limit. The findings U04 files as 3rd-class defects — detected and corrected by a
   person (Kemper, Baars & Mehanna) — were none of them produced by a tool:
   the tool says                                                     the question it cannot answer
   ManagerID: 3 × NULL                                               why is it missing? Only the source can say
   SubCategoryID: 0 missing                                          or did a WHERE clause remove 209 products?
   3,806 orders, all reseller                                        where are the online customers?
   no cancelled order anywhere                                       were they never there, or filtered out?



   So the deliverable is not the table
   It is the table plus what you decided about each line of it — that is the cleaning log, and M2 has to execute it. A profile nobody
   drew a conclusion from is a file, not a finding.

   Reproduce U04’s numbers for the export with VL_4_DS/Scripts/awc_profile.py — standard library only, so it runs anywhere.




                                                                                                                                        8/8
~~~~
