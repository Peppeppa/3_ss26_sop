# Quellen – Data Science

Hier gehören ausschließlich Originalunterlagen des Moduls **Data Science** hin: offizielle Unit-Folien, Aufgabenblätter, `HANDIN.pdf` und ergänzende Kursunterlagen, soweit tatsächlich vorhanden. Noch nicht hochgeladene PDFs nicht als im Repository archiviert ausgeben.

**Priorität:** Aktuelle offizielle Aufgabenblätter / HANDIN / Schedule > Vorlesungsfolien / Übungen / Primer > Projektmanifest > externe Erklärungen.

Die Kursunterlagen zum eigenständigen Fach **System-oriented Programming** befinden sich im separaten Repository `Peppeppa/3_ss26_sop`.
