---
source_id: DS-R001
original_file: portfolio_studis_de.pdf
source_type: reference
language: de
page_count: 9
source_sha256: b0fb8541aae6b69360c8654c7ad7b1b25ca2411b2cd727c4add74025093829a4
verification: partial
---
# portfolio_studis_de

[Original PDF](../../portfolio_studis_de.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../portfolio_studis_de.pdf#page=1)

~~~~text
Data Science

DAS PORTFOLIO IN ACHT
FOLIEN


Prof. Dr. Frank-Michael Schleif
frank-michael.schleif@thws.de
~~~~

## Page 002

[Original page 2](../../portfolio_studis_de.pdf#page=2)

~~~~text
                                      DREI ABGABEN, KEINE KLAUSUR

 • Statt einer Klausur ein Portfolio: drei Abgaben im Semester, in einer Gruppe
   (Größe je nach Teilnehmerzahl), und am Ende eine mündliche Prüfung.
 • M1 20 % · M2 20 % · M3 30 % · M4 20 %. M3 ist die Dashboard-Abgabe, M4 die
   mündliche Verteidigung.
 • Jede Gruppe bekommt ihren eigenen Ausschnitt der AWC-Datenbank — ein
   Vertriebsgebiet × eine Produktkategorie. Jede Gruppe rechnet also mit
   anderen Zahlen.

Die verbindlichen Fassungen
Dieses Deck ist der Überblick. Was jeder Meilenstein verlangt, steht auf seinem
Aufgabenblatt — M1_sheet.pdf, M2_sheet.pdf, M3_sheet.pdf; wie abgegeben
wird, steht in HANDIN.pdf. Alles in Moodle. Bei Widersprüchen gelten sie. Jede
Aufgabe eines Blatts wird bewertet — und kaum eine kann ein Skript prüfen.
~~~~

## Page 003

[Original page 3](../../portfolio_studis_de.pdf#page=3)

~~~~text
                                  HEUTE: EINHEIT 00, JEDE/R FÜR SICH



    Anna, Ben und Cem sitzen in dieser Vorlesung. Diese Woche arbeitet jede/r allein
    — Gruppen kommen nach der nächsten Sitzung.

     • Datenbank Adventureworks2019 auf dem eigenen Rechner einrichten,
       erreichbar aus Python oder KNIME — nicht aus einer CSV.
     • Der ganze Test ist eine Zahl: SELECT COUNT(*) FROM
       Sales_SalesOrderHeader muss 31465 liefern.
     • Übung 1 und 2 vom Blatt — Erkunden und Dokumentieren. Abgegeben wird
       davon nichts.




2
~~~~

## Page 004

[Original page 4](../../portfolio_studis_de.pdf#page=4)

~~~~text
                      SCHRITT 1 — ANMELDUNG, UND DIE EINE FALLE


    Alle drei füllen einmal das Formular aus (Link in Moodle). Sieben Felder.

    partners: Matrikelnummern, und nur gegenseitig
    Wer zusammenarbeiten will, muss sich gegenseitig nennen — mit
    Matrikelnummer, nicht mit Namen.
    Anna nennt Ben und Cem. Ben nennt Anna und Cem. Cem nennt Anna und Ben.
    Nennt Cem die anderen nicht, wird sein Wunsch ignoriert — und er landet in einer
    anderen Gruppe.

    Einseitige Wünsche werden still übergangen — so wird niemand in eine Gruppe gezogen.
    Und ein Wunschverbund, der größer als eine Gruppe ist, wird geteilt.


3
~~~~

## Page 005

[Original page 5](../../portfolio_studis_de.pdf#page=5)

~~~~text
                   SCHRITT 2 — IHR BEKOMMT DREI DINGE ZUGETEILT



    Nicht gewählt — zugeteilt, per Mail:
    Gruppennummer          z. B. G07. Der Dreier bleibt zusammen, aber eine Gruppe kann
                           größer sein: es kann jemand dazukommen, den ihr nicht kennt.
    Euer Ausschnitt        z. B. Northwest × Clothing. Ab Einheit 04 rechnet ihr nur noch damit.
    Upload-Link            Ein Nextcloud-Ordner, der nur Uploads annimmt: hochladen ja —
                           auﬂisten, herunterladen, löschen nein.
    Einheit 01 läuft noch auf einem Aufwärm-Ausschnitt für alle gleich
    (Deutschland/Reseller). Der eigene gilt ab Einheit 04.




4
~~~~

## Page 006

[Original page 6](../../portfolio_studis_de.pdf#page=6)

~~~~text
                                                                 DIE VIER BESTANDTEILE

             aus            was drin ist
    M1       U03 + U04      eigene Beobachtung, Proﬁling-Report, Cleaning-Log, Metadatendatei
    M2       U06–U08        die bereinigte Flat-Tabelle, Ähnlichkeitsstudie, Cluster, fünf Plots, Peer
                            Review
    M3       U09            drei belegte Fragen, ein KPI-Dashboard (nicht der Explorer), ML-Readiness
                            — bewertet nach der Abgabe
    M4       —              die mündliche Verteidigung: die Gruppe stellt vor, jede/r antwortet zum
                            eigenen Abschnitt. Nichts abzugeben.


    Sie bauen aufeinander auf
    M1 entscheidet, was mit eurem Ausschnitt nicht stimmt; M2 führt dieses Log aus und gibt die
    bereinigte Tabelle ab; M3 baut darauf auf. Was ihr in M1 entscheidet, verteidigt ihr mündlich.

    Alle vier zählen — 20 / 20 / 30 / 20 %. M1 und M2 werden im Semester korrigiert und besprochen;
    die Note kommt am Semesterende. M4 gibt es nur in der mündlichen Prüfung. Jede Frist, mit
5   Datum und Uhrzeit: Schedule.pdf.
~~~~

## Page 007

[Original page 7](../../portfolio_studis_de.pdf#page=7)

~~~~text
                                                                  WIE EINE ABGABE AUSSIEHT

    Ein Archiv pro Gruppe und Abgabe — M1_G07.zip — hochgeladen von einer Person
    im Namen aller. Keine Einzelabgaben.
     1   group: G07
     2   slice_id: S15
     3   members:
     4    - name: Anna Beispiel
     5      responsible_for: Proﬁling, Fehlwertanalyse
     6    - name: Ben Muster
     7      responsible_for: Cleaning-Log, Entscheidungen 1-4
     8    - name: Cem Oernek
     9      responsible_for: Ausreisser, Plots
    10   ﬁndings: {lines: 2873, orders: 1480, customers: 1211, ...}


    responsible_for ist Pﬂicht, in euren eigenen Worten — das einzige individuelle Signal in
    einer Gruppennote.


6
~~~~

## Page 008

[Original page 8](../../portfolio_studis_de.pdf#page=8)

~~~~text
                                                   VOR DEM UPLOAD: SELBST PRÜFEN



     1   python3 check_submission.py M1_G07.zip


    Liegt im Template-Kit. Aus slices.csv kennt es nur die Größe eures Ausschnitts
    (Zeilen, Bestellungen, Kunden) — weicht euer Extrakt davon ab, stimmt der Filter
    nicht. Eure übrigen Befunde kennt es nicht; es prüft die Form:
     1   FIX manifest: ﬁndings.lines says 9,999, but slice S04 has 6,392
     2   FIX report.pdf is missing (a .md or .tex source is not the deliverable)


    Es bewertet nichts — es verhindert nur, dass etwas an einer Formalie scheitert. Nutzt es.
    Läuft es ohne Befund durch, sind die häuﬁgen Fehler weg — nicht jeder formale Punkt.




7
~~~~

## Page 009

[Original page 9](../../portfolio_studis_de.pdf#page=9)

~~~~text
                                               ZWEI FALLEN — UND DIE NOTE


    Rechnet mit eurem Ausschnitt
    Zahlen aus der Vorlesung oder von einer anderen Gruppe fallen maschinell auf: die
    drei Größenzahlen (lines, orders, customers) werden gegen euren zugewiesenen
    Ausschnitt geprüft.

    Wenn die Gruppe eure Arbeit nicht vertritt
    Mail an mich, vor der Frist. Kein zweites Archiv in den Ordner — zwei verschiedene
    Archive halten die ganze Gruppe auf, bis ihr euch geeinigt habt.

    Die Note: In der Regel bekommen alle die Gruppennote; individuelle Noten bleiben
    möglich. In der mündlichen Prüfung wird jede/r einzeln befragt, zu dem, was im
    responsible_for steht — und keine zwei Mitglieder bekommen dieselbe Frage.

8
~~~~
