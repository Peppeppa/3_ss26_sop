---
source_id: DS-R008
original_file: HANDIN.pdf
source_type: reference
language: en
page_count: 5
source_sha256: 37d61885c93a5c4d014507e7f0de8a053e754232de857bc75a8edd2c48ce073e
verification: partial
---
# HANDIN

[Original PDF](../../HANDIN.pdf). Vollständige Textschicht. Rekonstruktionen sind separat markiert. Seiten- und Aufgabenabdeckung geprüft; keine vollständige manuelle Überprüfung aller Layout- und Formelzeichen.

## Page 001

[Original page 1](../../HANDIN.pdf#page=1)

~~~~text
                           What to hand in, and how



Contents
What to hand in, and how                                                                             1
  1. The milestones . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .            1
  2. One archive per group . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           2
  3. Start from the template . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           2
  4. What is inside — flat . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .         2
  5. manifest.yaml . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           3
  6. What every milestone has to do . . . . . . . . . . . . . . . . . . . . . . . . . . .            4
  7. The oral — M4 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           5
  8. Using an LLM . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .            5
  9. Before you upload . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           5

What to hand in, and how
This file is about the process: groups, the archive, the manifest, the rules every hand-in
follows, the oral and the deadline. What each milestone asks you to do is on its own task
sheet — M1_sheet.pdf, M2_sheet.pdf, M3_sheet.pdf in the Moodle course. If a slide, a script or a
conversation disagrees with a sheet or with this file, the sheet and this file win.
Overview in eight slides: portfolio_studis_en.pdf (or _de). Dates are not here — they are
in Schedule.pdf in the Moodle course, so this file does not go stale. Each upload is due 23:59
German time on its day.



1. The milestones
Your group has one slice of AWC — one sales territory × one product category — for the whole
semester. Every group has a different one, so every group reports different numbers.

         built in          the task                                                         weight

M1       U03 + U04         data quality: profile, diagnose, decide — M1_sheet.pdf           20 %
M2       U06 + U07 + U08   the cleaned table and its structure — M2_sheet.pdf               20 %
M3       U09               questions, KPI dashboard, leakage, ML-readiness — M3_sheet.pdf   30 %
M4       —                 the defence in the oral — §7. Nothing to hand in                 20 %
formal   all               clean, complete, on time — across M1 to M4                       10 %



The three build on each other. M1 decides what is wrong with your slice and how each
defect should be handled. M2 executes that log and hands in the cleaned flat table it produces.
M3 is built on that table and nothing else. So a decision you take in M1 is one you have to live
with in M2 and defend in the oral.
All four count towards the mark. M1 and M2 are corrected and discussed during the
semester, so the feedback can still change what you do next; the mark for them is given at the


                                                    1
~~~~

### DS-R008-P001-T01 – Milestone weights (table)

| Milestone | Built in | Task | Weight |
|---|---|---|---:|
| M1 | U03 + U04 | Data quality: profile, diagnose, decide | 20% |
| M2 | U06 + U07 + U08 | Cleaned table and its structure | 20% |
| M3 | U09 | Questions, KPI dashboard, leakage, ML-readiness | 30% |
| M4 | — | Oral defence; nothing to hand in | 20% |
| formal | all | Clean, complete, on time | 10% |


## Page 002

[Original page 2](../../HANDIN.pdf#page=2)

~~~~text
What to hand in, and how



end. M3 is marked from what you hand in, M4 is the oral (§7). Marks are per group as a
rule; any part can be marked individually where the work or the oral calls for it.
Register in the first week. Group registration opens on the first date and closes on the
second; groups and slices are announced there, and each group receives its own upload link
by mail. Schedule.pdf in Moodle carries the dates.
If you join later, you are added to a group that already exists, or to a new one if none has
room — nobody is reshuffled out of a group they have been working in. What you cannot get
back is a milestone that has already been handed in: join after the M1 deadline and M1 is
not graded for you. Your group keeps its M1 mark, you do not inherit it, and your portfolio
is M2, M3, M4 and the formal side — M1's 20 % is gone before you start. There is no
substitute task. You are still expected to know your group's slice as well as everyone else in
the oral, including the cleaning decisions M1 made without you.

2. One archive per group
M1_G07.zip             <- M<milestone>_<group>.zip, nothing else

   • Your group id is the one in your group mail: G and two digits for BIN/BWI, B and two
     digits for BSED (M1_B01.zip). It goes into the file name, group: in the manifest and the
     report header; G07 here is only the example.
   • Exactly one archive per group per milestone, in your group's Nextcloud folder. No indi-
     vidual uploads. Whoever uploads does so on behalf of the group; submitted_by records
     who.
   • Re-uploading is fine. Nextcloud adds (2), (3) rather than overwriting; the newest
     counts.
   • Two archives with different names are a conflict, not a version: nothing is graded until
     the group says which one counts.
   • If your group will not represent your work, mail me before the deadline — that is what
     email is for, and not a second archive in the folder.

3. Start from the template
Download M1_template.zip (and M2, M3) from Moodle: a manifest with placeholders, a report.tex
with one section per task of the sheet, in the sheet's order, a starting point for either tool
(analysis.py / slice_knime.md), and the self-check from §9. Fill it in and delete the % PROMPT lines
as you go.
unpack   ->   rename the folder to M1_G07   ->   fill in   ->   zip the CONTENTS as M1_G07.zip

Both starting points do the same thing: filter the extract down to your slice and print its three
identity counts, so nobody fails a mechanical check for a clerical reason. They stop there:
everything the sheet asks for is the work. Keep the sections and their order.

4. What is inside — flat
M1_G07.zip
├── report.pdf         what is graded: one section per task of the sheet
├── manifest.yaml      read by a script — see §5
└── analysis.py        your code — or workflow.knwf, or a .sql, or several files

Each sheet lists, in its first box, the files its milestone adds: the metadata file in M1; clean_-
flat.csv in M2; dashboard_orders.csv, the dashboard and management_report_delivery.pdf in M3.

Put every figure into report.pdf (exported as PNG or PDF, or a screenshot of a KNIME view);
separate image files are not marked. M2's plots from before the peer review go into an appendix
of the same PDF. No folders — a deep tree is what check_submission.py warns about. The kit
ships both a Python starting point (analysis.py) and the KNIME equivalent (slice_knime.md) —
use one, delete the other. A .knwf is your code exactly as a .py is.


                                                 2
~~~~

## Page 003

[Original page 3](../../HANDIN.pdf#page=3)

~~~~text
What to hand in, and how



5. manifest.yaml
Read by a script, so keys and spelling matter. The template ships it filled with placeholders —
edit that rather than retyping this.
group: G07
slice_id: S14
milestone: M1
submitted_by: 300042           # matrikel of whoever uploads, for the group
members:
  - name: Anna Beispiel
    responsible_for: profiling table, missing-value analysis
  - name: Ben Muster
    responsible_for: cleaning log, decisions 1-6
  - name: Cem Örnek
    responsible_for: outlier section, plots

findings:                         # what your report states — the template lists
  lines: 2873                     # every key your milestone needs; analysis.py
  orders: 1480                    # prints the first three
  customers: 1211
  linetotal_median: 34.20
  iqr_outliers_orders: 96
  months_covered: 26


responsible_for is mandatory, per member, in your own words. It is the individual record
inside group work, and it is what you are asked about in the oral.
M2 adds a cleaned: block, about the table you hand in:
cleaned:                    # recomputed from YOUR clean_flat.csv
  rows: 2680                # data rows, without the header
  columns: 23
  median_of: LineTotal      # any numeric column of your cleaned table
  median: 34.20


There is no reference value here and there cannot be — every group cleans differently. rows and
columns are checked against the clean_flat.csv in your own archive and must match it exactly;
median within a small tolerance. check_submission.py does this before you upload, so a number
you typed instead of computing is something you find yourself.
M2 also has to add up. Three more blocks, and again nothing is compared to a reference —
they have to be consistent with each other and with the files you hand in:
cleaning:
  rows_in: 3668             # order lines your slice started with
  rows_removed: 988         # summed over the decisions that remove rows
  rows_out: 2680            # = cleaned.rows, and = rows_in - rows_removed

matrix:
  objects: 1180             # rows of your feature matrix
  features: 9
  dropped_because: ""       # only if objects < customers in your cleaned table

clusters:
  k: 3
  sizes: [480, 500, 200] # one count per cluster
  unassigned: 0          # objects your method left unlabelled, if any


   • The cleaning log has to close. rows_in is your slice's own line count, and rows_in −


                                                     3
~~~~

### DS-R008-P003-Y01 – Manifest example (structured transcription)

```yaml
group: G07
slice_id: S14
milestone: M1
submitted_by: 300042
members:
  - name: Anna Beispiel
    responsible_for: profiling table, missing-value analysis
  - name: Ben Muster
    responsible_for: cleaning log, decisions 1-6
  - name: Cem Örnek
    responsible_for: outlier section, plots
findings:
  lines: 2873
  orders: 1480
  customers: 1211
  linetotal_median: 34.20
  iqr_outliers_orders: 96
  months_covered: 26
```

Additional M2 example blocks (placeholder values from the sheet, NOT group results):

```yaml
cleaned:
  rows: 2680
  columns: 23
  median_of: LineTotal
  median: 34.20
cleaning:
  rows_in: 3668
  rows_removed: 988
  rows_out: 2680
matrix:
  objects: 1180
  features: 9
  dropped_because: ""
clusters:
  k: 3
  sizes: [480, 500, 200]
  unassigned: 0
```


## Page 004

[Original page 4](../../HANDIN.pdf#page=4)

~~~~text
What to hand in, and how



     rows_removed must equal rows_out. The per-decision table in your report has to sum to
     rows_removed. M1 decided and M2 executes, so this only adds up if you actually ran your
     own log.
   • The matrix cannot have more objects than your cleaned table has customers. It
     may have fewer — dropping customers with too little history is a modelling decision and a
     defensible one. It just has to be a stated decision: put the reason in dropped_because, and
     nothing is held against you.
   • The clusters have to cover the matrix: sizes plus unassigned equals objects. k itself is
     never compared against anything — there is no right k, and claiming otherwise would be
     dishonest.
Which numbers a milestone needs, and how each is computed, is in the box at the end of its
sheet. Take the numbers from your own output, not by retyping from the report — a typo
looks exactly like a wrong analysis. findings are compared against your slice: counts exactly
(for the outlier counts, every common quartile method counts as right), money and ratios within
a small tolerance. A mismatch means the analysis did not run on your slice. Everything else
is read by a person — the decisions and the reasoning, which are what the mark is about.

6. What every milestone has to do
Five things hold for M1, M2 and M3 alike, on top of the milestone's own sheet.
  ⚠ MARKED — the mark turns on this. A MARKED item you skip is not a formatting slip;
  it is the part that was being assessed, and check_submission.py catches at most a password
  left in the archive; the rest only a reader can judge. If you skim this file, skim to those.

⚠ MARKED — report.pdf, and keep it short. Tables and short statements, not flowing text.
For every decision say: what you decided, the number that made you decide it, and
what you rejected.
  ”We cleaned the data” is not a decision. ”We kept all 379 IQR-flagged lines, because at order
  grain only 294 of 2,340 orders are flagged and deleting them would delete the revenue we
  are analysing” is.

⚠ MARKED — The extract that everything else starts from (M1, M2, M3). Before any
milestone has anything to report, your group needs one flat table at order-line grain, built
from the database by a script — never by hand, never by a file somebody once exported. It
carries the transaction facts, the order-level context, the product attributes and grouping, the
customer identity and the geography, and it is rebuilt by a single run: python3 … from an empty
session, or a KNIME workflow that survives a Reset and one Execute All.
This script is in every archive, because §6 asks that every number be reproducible and this is
the file every number descends from. If it does not run, the milestone does not start.
⚠ MARKED — Figures stand on their own: every axis labelled with its unit, a legend wher-
ever there is more than one series, a caption saying what to read from it.
⚠ MARKED — Everything must be reproducible. The archive contains what produced the
numbers — .py, .sql, .ipynb or a KNIME .knwf — and it must run against the course extract. A
number no script in the archive can regenerate does not count as a result. Say which script
produced which table or figure.
⚠ MARKED — No password in the archive. Your script reads the database password from
the environment (AWC_DB_PW), an option file or a secret store — never from a literal in code, a
notebook cell or a saved KNIME node setting. Say in the report how it is supplied, so I can run
it. The archive is uploaded: a password in it is a password you have given away.
Tools are your choice, and you may mix them — e.g. KNIME for the pipeline and anything
you like for the figures. Say which you used and why; the figure requirements are the same
either way.


                                               4
~~~~

## Page 005

[Original page 5](../../HANDIN.pdf#page=5)

~~~~text
What to hand in, and how



7. The oral — M4
M4 is not a fourth upload. There is nothing extra to write, and it is only awarded in that
sitting: a portfolio without the oral is not a portfolio with fewer points — it is an examination
not taken.
Per group: the group presents its result, then each member is asked about their own
section — the one named in responsible_for — across all three milestones, not just the last
one. No two members get the same question. It asks three things, the same three for everyone:
  1. Your own section — what you decided, and why that way rather than otherwise.
  2. One number, defended — which script produced it, and what would have to change for
     it to come out differently.
  3. The alternative you rejected — what else you could have done, and why you did not.
  responsible_for is where M4 starts. You write it yourself, in your own words, in every
  manifest — and it is what the questions are built from. ”Helped with everything” gives the
  examiner nothing to ask about, which is not to your advantage. Name a part of the work
  and own it.
Questions come from your group's own measured numbers. There is nothing to memorise
and nothing in any task description. Marks are per group as a rule; the questions are
individual, though, so the oral can lead to individual marks where the answers call for it.

8. Using an LLM
Allowed, and not something to hide. An LLM — an agent with access to the database even more
so — can produce much of a milestone, your slice's numbers included. What it cannot do is
account for it: in the oral each of you is asked why — the alternative you rejected, the number
that forced the decision — about your own section, across all three milestones. Hand in only
what you can defend.

9. Before you upload
From inside the unpacked kit:
python3 check_submission.py M1_G07.zip


It checks what a script can — the name, the manifest keys, the size of your extract (lines, orders,
customers) against your slice, that report.pdf and your code are there — so nothing fails for a
clerical reason. If a size is wrong it names the expected one; your other findings it does not
know. Exit code 0 means nothing left to fix. Run it.
What it cannot check is whether your decisions are defensible, and that is what the mark de-
pends on.
Re-uploading, and the deadline. Upload as often as you like before the deadline — the
last upload that arrives in time is the one graded, and the earlier ones are simply ignored.
Keep the filename the same; a second, differently named archive in the same folder is not a
new version, it is two submissions, and it stops the group being graded until you say which one
counts.
After the deadline nothing counts. An upload written at 00:05 is not a late version of your
submission — it is not a submission. If nothing arrived in time, that milestone's percentage is
lost. The deadline is 23:59 German time on the date in Schedule.pdf, so do not start uploading
at 23:55: an upload that is still running at midnight has missed it.




                                                5
~~~~
