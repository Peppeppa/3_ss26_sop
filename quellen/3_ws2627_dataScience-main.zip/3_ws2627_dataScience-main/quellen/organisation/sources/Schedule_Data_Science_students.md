---
source_id: DS-R004
original_file: Schedule_Data_Science_students.pdf
source_type: reference
language: en
page_count: 1
source_sha256: 7308fd4a2897beb2913348258a19b3ac3d889d2e48d8b5396cdd61e6cbb5237f
verification: partial
---
# Schedule_Data_Science_students

[Original PDF](../../Schedule_Data_Science_students.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../Schedule_Data_Science_students.pdf#page=1)

~~~~text
                         Lecture Data Science (WiSe 2026/2027) -- in the room: Tuesdays 15:15-18:30


Number Date              Format      Core topic                                    Unit   What you must do
Phase 1
           1 Tue 06.10   SHL         Introduction, setup, AWC; data vs             U00    Group registration opens; it closes at the next date
                                     information; scale levels
           2 Tue 13.10   SHL         Tabular and tidy data; joins; the AWC flat-   U01    Registration closes; your group and data slice are
                                     table                                                announced
           3 Tue 20.10   SHL         From the SQL console to a re-runnable         U02
                                     program
           4 Tue 27.10   SHL         Formats, serialisation, metadata; k-anonymity U03

           5 Thu 05.11   SHL         Data quality: profiling, then cleaning with   U04    Different time: 13:30-16:45
                                     reasons
           6 Tue 10.11   SHL         Beyond tables: time series, sequences, graphs U05

           7 Tue 17.11   SHL      Features, similarity and distance                U06
--           Mon 23.11   DEADLINE M1 submit                                               M1 due 23:59 German time

           8 Tue 24.11   SHL         Mid-term (M1): profiling + cleaning log       --     Your group presents M1 (slice + cleaning log)
Phase 2
           9 Tue 01.12   SHL         Dimensionality reduction: PCA, t-SNE, clusters U07

          10 Tue 08.12   SHL      EDA I: statistics before pictures                U08a
          11 Tue 15.12   SHL      EDA II: visualisation, colour, how plots lie     U08b   Bring your M2 plots: peer review in the room
--           Fri 18.12   DEADLINE M2 submit                                               M2 due 23:59 German time: revised plots and the
                                                                                          originals
          12 Tue 22.12   ONLINE   M2 discussed: analysis, similarity, EDA          --     M2 discussed, online
          13 Tue 12.01   SHL      Dashboards, communication, ML-readiness,         U09
                                  leakage
          14 Tue 19.01   SHL      Last lecture slot; no new material               --     Bring your open M3 questions
--           Mon 25.01   DEADLINE M3 submit                                               M3 due 23:59 German time -- earlier is welcome

--          t.b.d.       DEADLINE Oral part: M4                                           Oral exam (M4) in the exam period: your group
                                                                                          presents, each member answers for their own
                                                                                          section
~~~~
