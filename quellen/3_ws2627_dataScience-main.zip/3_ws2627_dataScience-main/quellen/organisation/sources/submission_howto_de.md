---
source_id: DS-R006
original_file: submission_howto_de.pdf
source_type: reference
language: de
page_count: 3
source_sha256: 067e06ca478549b53b735e2fe567c064fd40a765ac3b4e078a0d962cc4a5dc85
verification: partial
---
# submission_howto_de

[Original PDF](../../submission_howto_de.pdf). Vollständige Textschicht; keine vollständige manuelle Sichtprüfung.

## Page 001

[Original page 1](../../submission_howto_de.pdf#page=1)

~~~~text
Abgabe, Schritt für Schritt                                                                               Data Science — Portfolio



Abgabe, Schritt für Schritt
Ein durchgespieltes Beispiel für eine Portfolio-Abgabe
Hier geht eine erfundene Gruppe einmal komplett durch eine Abgabe — vom leeren Kit bis zur Datei
im Upload-Ordner. Nichts davon ist eine Regel — die Regeln stehen in HANDIN.pdf, und wenn sich
beide widersprechen, gilt HANDIN.pdf. Hier steht das Wie.
Einmal lesen, bevor ihr zum ersten Mal abgebt. Es sind die zehn am besten investierten Minuten
im Modul: die zehn formalen Punkte verliert man, indem man das hier falsch macht —
verdienen kann man sie nicht.
 Unser Beispiel: Gruppe G00, Slice S00, Meilenstein M1. S00 gibt es nicht, alle Zahlen unten sind erfun-
 den — hier ist also nichts zum Abschreiben. Euer Slice hat eigene Zahlen, und die werden dagegen geprüft.

Der ganze Weg, einmal am Stück


                    1                     2                    3                       4                      5
                Kit holen              arbeiten            ausfüllen               exportieren              bauen
             M1_template.zip            Zahlen         manifest.yaml              report.pdf             M1_G00.zip
                                      entstehen
                                                                        FIX genannt → beheben,
                                                                       neu packen, nochmal prüfen



                                                                                        7
                                                        fertig — gew-                                         6
                                                          ertet wird               hochladen        ok
                                                           die letzte                                       check_
                                                                                   euer Grup-
                                                      rechtzeitige Datei                                 submission.py
                                                                                     penlink



Schritt 0 — was ihr abgebt, in einem Satz. Eine ZIP-Datei, pro Gruppe, pro Meilenstein,
in den eigenen Upload-Link der Gruppe. Nicht eine pro Person. Kein Ordner. Kein Cloud-Link.
Keine E-Mail.
Schritt 1 — das Kit holen
M1_template.zip aus Moodle laden und entpacken. Darin arbeiten — wie der Ordner heißt, ist egal; wie
die ZIP heißt, nicht.
manifest.yaml                 füllt ihr aus — wird von einem Skript gelesen
report.tex                    ein Gerüst; Word oder sonst etwas geht auch
analysis.py                   ein Startpunkt — druckt eure Zahlen aus
slice_knime.md                der KNIME-Weg, falls euch der lieber ist
check_submission.py           euer Selbsttest, vor dem Hochladen
slices.csv                    was in eurem Slice stehen muss
README.md                     was dieser Meilenstein im Detail verlangt

Schritt 2 und 3 — laufen lassen, dann Zahlen übertragen
Welchen Weg ihr auch nehmt — am Ende habt ihr Zahlen. analysis.py druckt genau die, die das
Manifest will. Kopieren, nicht abtippen — ein Tippfehler ist für das prüfende Skript nicht von einer
falschen Auswertung zu unterscheiden, und ihr verliert einen Punkt für eine Zahl, die ihr richtig hattet.


                     $ python3 analysis.py                                     group: G00
                     slice S00 –- Beispielland / Beispielkat.                  slice_id: S00
                     lines          4,206                                      milestone: M1
                     orders         1,903                                      findings:
                     customers      1,244                                        lines: 4206
                     linetotal_median 41.55                                      orders: 1903
                     iqr_outliers_ord. 87                                        customers: 1244
                     months_covered    26                                        linetotal_median: 41.55
                                                                                 iqr_outliers_orders: 87
                                                               kopieren,         months_covered: 26
                                                             nie abtippen




Drei Dinge gehen hier häufiger schief als alles andere zusammen:


                                                                1
~~~~

## Page 002

[Original page 2](../../submission_howto_de.pdf#page=2)

~~~~text
Abgabe, Schritt für Schritt                                                                   Data Science — Portfolio



   1. responsible_for schwammig. “Mitarbeit”, “alles zusammen”, “Koordination” — genau danach werdet ihr per-
      sönlich in der mündlichen Prüfung (M4) gefragt. Schreibt in eigenen Worten, was ihr wirklich gemacht habt. Es ist
      der einzige individuelle Nachweis in der Gruppenarbeit.
   2. Zahlen abgetippt statt kopiert.
   3. slice_id geraten. Er wird mit eurer Gruppe bekannt gegeben. Die Zahlen eines fremden Slices zu melden ist kein
      Rundungsfehler.

M2 will etwas mehr: einen cleaned:-Block zur abgegebenen Tabelle — Zeilen, Spalten und den
Median einer Spalte, die ihr benennt; alle drei werden aus eurer eigenen clean_flat.csv nachgerechnet.
Jedes Kit bringt das passende Manifest mit; nehmt das aus dem Kit.
Schritt 4 — der Bericht
report.pdf. Ein PDF. Kein .md, kein .tex, kein .docx, kein nach HTML exportiertes Notebook. Die
% PROMPT:-Zeilen in report.tex sind eine Checkliste — jede löschen, sobald ihr sie beantwortet
habt. Die mit % PROMPT: !! tragen Punkte; eine gelöschte !!-Zeile, an deren Stelle nichts steht, ist die
teuerste Art von Leere. Abbildungen gehören ins PDF; einen Bilderordner gibt es nicht.

Schritt 5 — die ZIP bauen: flach und exakt benannt
Formale Punkte verliert man am häufigsten, indem man den Ordner zippt statt seinen Inhalt. Die
Dateien markieren, dann komprimieren — nicht mit Rechtsklick auf den Ordner.

                     WRONG                                              RIGHT
                     M1_G00.zip                                         M1_G00.zip
                       \__ M1_template/                                   \__ report.pdf
                            \__ report.pdf                                \__ manifest.yaml
                            \__ manifest.yaml                             \__ analysis.py
                            \__ analysis.py                                    (oder workflow.knwf,
                     jeder Pfad ist falsch                                      oder eure .sql)
                     für jedes Skript                                     \__ awc_flat.metadata.yaml
                                                                               (nur M1)
                                                                        flach, kein Ordner



Der Name ist M<Nummer>_<Gruppe>.zip: M1_G00.zip, M2_G00.zip, M3_G00.zip. Nichts anderes — nicht
M1_G00_final.zip, nicht M1_G00_final_WIRKLICH.zip, nicht Abgabe.zip.

Schritt 6 — den Selbsttest laufen lassen, immer wieder
Aus dem Kit heraus, gegen die eben gebaute ZIP. Der erste Lauf sieht meistens aus wie der obere Kasten,
und das ist völlig normal — beheben, was er nennt, ZIP neu bauen, nochmal laufen lassen, bis es aussieht
wie der untere.

                                     $ python3 check_submission.py M1_G00.zip
                                     M1_G00.zip: 3 entries
                                       warn __MACOSX / .DS_Store-Müll
                                       FIX   findings.orders says 1,930,
                                             aber Slice S00 hat 1,903
                                       FIX   Cem Örnek hat ein leeres
                                             responsible_for
                                         beheben, neu packen, nochmal


                                     M1_G00.zip: 3 entries
                                       ok    nothing a script can catch.
                                             Now re-read M1_sheet.pdf and
                                             HANDIN §6: is every task answered,
                                             every decision stated with the number
                                             behind it?


Laufen lassen. Jedes Mal. Er prüft nur, was ein Skript prüfen kann — den Namen, die Schlüssel, die
Größe eures Extrakts gegen euren Slice, ob Bericht und Code wirklich drin sind. Ob eure Begründungen
gut sind, kann er nicht sagen. Aber alles, was er findet, würde euch sonst formale Punkte kosten —
völlig ohne Grund.

Schritt 7 — hochladen, und die Frist

                                                              2
~~~~

## Page 003

[Original page 3](../../submission_howto_de.pdf#page=3)

~~~~text
Abgabe, Schritt für Schritt                                                                           Data Science — Portfolio



Eure Gruppe hat einen Upload-Link, bekannt gegeben zusammen mit Gruppe und Slice. Es ist ein
File Drop: ihr könnt Dateien hineinlegen, aber nicht sehen oder herunterladen, was drin ist — auch eure
eigenen früheren Uploads nicht. Das ist so gewollt.

                                                                                 23:59
                                                                                 Frist
                               so oft hochladen, wie ihr wollt — gew-                        keine späte Fassung:
                                 ertet wird die letzte rechtzeitige                             keine Abgabe




                      22:10                    23:10                    23:58                     00:05
                      erster                   besser                   final                     weg



   • Gleicher Dateiname beim erneuten Hochladen. Zwei unterschiedlich benannte Archive in einem Ordner sind keine
     neue Fassung, sondern zwei Abgaben — und es wird nichts bewertet, bis eure Gruppe sagt, welche zählt.
   • 23:59 deutscher Zeit, am Tag aus Schedule.pdf. Ein Upload, der um Mitternacht noch läuft, ist zu spät, und
     was danach ankommt, zählt gar nicht — der Prozentsatz dieses Meilensteins ist dann einfach weg. Fangt nicht um
     23:55 an.


Was es kostet, wenn es schiefgeht
Zehn von hundert Punkten sind formal: Rechtschreibung, Layout, Vollständigkeit, Frist. Man verdient
sie nicht durch Ordentlichkeit — geht davon aus, dass ihr sie habt, und verliert sie durch:
was                                                warum es kostet
ZIP heißt anders als M1_G00.zip                    muss von Hand gesucht und umbenannt werden
Ordner gezippt statt der Dateien                   jeder Pfad ist für jedes Skript falsch
report.md oder .tex statt report.pdf               abzugeben ist das PDF
responsible_for leer oder “Mitarbeit”              dann gibt es keinen individuellen Nachweis
Zahlen abgetippt und nun falsch                    nicht von einer falschen Auswertung zu unterscheiden
ein Datenbank-Passwort irgendwo im                 ihr habt das Passwort verschenkt
Archiv
__MACOSX/, .DS_Store, venv/, .git/                 Rauschen in etwas, das ein Mensch liest
um 00:05 hochgeladen                               es ist nicht angekommen

 Einiges davon findet check_submission.py, bevor ihr hochladet — nicht alles, und nicht das Letzte. Also
 laufen lassen, und das Archiv einmal selbst durchsehen.




                                                                    3
~~~~
