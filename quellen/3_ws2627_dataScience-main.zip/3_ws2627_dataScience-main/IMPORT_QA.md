# Import- und Qualitätsbericht – 2026-11-28

1. Inventar und Extraktion: 27 Originale über Git-Blob-SHA-1 mit lokalen Uploads abgeglichen. 517 nichtleere Seitentexte, Seitenabdeckung vor Commit geprüft. 40 Aufgaben mit stabilen IDs. Originale bewusst unverändert in quellen/.
2. Normalisierung: 24 ausgewählte semantische Rekonstruktionen (Mermaid, LaTeX, Diagrammbeschreibung, Scree-Tabelle). Rest als Layout-Text. Originalseiten verlinkt, keine separaten Bildassets auf GitHub. Keine erfundenen grafischen Datenpunkte.
3. QA: technische Originalidentität und Seitenabdeckung geprüft. Vollständige manuelle Sichtprüfung sämtlicher Abbildungen, Tabellen, Formeln und Codeblöcke steht aus. Kein Dokument verified.
4. Rekonstruktionstest: U07 S.16 explizit aus GitHub-Markdown zurückgelesen. PC1–PC9 Summe 100%, PC1+PC2 66.9%, 90%-Schwelle erstmals bei 5 Komponenten. Kein allgemeiner Nachweis, dass alle Abbildungen ohne Original-PDF rekonstruierbar sind.
5. Persistenz: 27 Textquellen auf main gespeichert. Neue Originale Glossary_en, HANDIN, M1_sheet, M2_sheet, M3_sheet, midterm_slide wurden während des Imports durch einen weiteren Commit hinzugefügt und bleiben unkonvertiert. Zehn ZIP-Archive und ihre Inhalte fehlen im Repository. Diese Lücken sind im INDEX.md dokumentiert.

## Ergänzungsimport 2026-11-28

- Sechs weitere Original-PDFs mit lokalen Uploads anhand Git-Blob-SHA-1 abgeglichen. 18 physische Seiten und 20 Portfolio-Aufgaben extrahiert; ausgewählte Tabellen, YAML-Beispiele und alle zentralen Diagramme der Portfolio-Blätter als Markdown/Mermaid rekonstruiert. Insgesamt 33 GitHub-PDF-Textfassungen, 535 Seiten, 60 Aufgaben (40 Unit + 20 Portfolio).
- 13 lokale ZIP-Archive per CRC geprüft, 134 Nutzdateien extrahiert (116 Unit, 4 AWC, 7+7 Templates), 41 Python-Dateien per AST geparst, 0 Syntaxfehler. Keine Ausführung gegen die Datenbank. Sechs eingebettete Referenz-PDFs mit 11 Seiten: lokale Markdown-Fassungen vorhanden. Alter Sammelband nicht integriert.
- Lokal erzeugtes Ergänzungspaket: 703 Dateien, darunter 546 Seitenbilder. 33 frühere lokale Markdown-Quellen (einschließlich der sechs eingebetteten Referenz-PDFs) auf Original-SHA-256, Seitenzahl, fortlaufende Seitenüberschriften und Bildverweise überprüft, keine Fehler. Für die sechs neuen Quellen Originalhash und Seitenbilder ergänzt. Paket und Binärdateien noch nicht auf GitHub, kein automatischer Import.
- Wichtig: physische Bildreferenz ist keine semantische Annotation. Alle 33 GitHub-Textfassungen weiterhin partial; kein vollständiger seitenweiser fachlicher Vergleich aller Tabellen, Formeln und Abbildungen. Gruppenabgaben und Datenbank-Reproduzierbarkeit ungeprüft, weil nicht zugänglich.

## Abschließender Rücklesetest

Alle 33 GitHub-Markdown-Quellen erneut abgerufen und gegen lokale Original-SHA-256 und fortlaufende Seitenüberschriften geprüft. Ein Metadaten-Tippfehler (DS-U04-EX: falsches Zeichen in source_sha256) gefunden und korrigiert. Die sechs neuen Quellen wurden zusätzlich mit der PDF-Textschicht verglichen: alle 18 Textblöcke identisch nach Whitespace-Normalisierung. Register: 33 Quellen, 60 Aufgaben, keine fehlenden Link-Zielpfade. Keine vollständige semantische Sichtprüfung der 535 Seiten; Status partial bleibt bestehen.
